var aaa;
define([], function () {
    aaa = avalon.define({
        $id: "aaa",
        userShow:true,
        aaaValue:"我是基本的数据绑定",
        arr1:[{name:'张三',age:'17'},{name:'李四',age:'44'}],
        obj1:{
            name:"王五",
            age:"21"
        },
        arr2:[[1, 2], [5, 6], [9, 10],[0,11,22,0]],
        arr3:[{
            name:"技术部",
            code:"123",
            isChecked:false
        },{
            name:"运维部",
            code:"42",
            isChecked:true
        },{
            name:"人事部",
            code:"66",
            isChecked:false
        }],
        clickEvent:function(){
            alert('我是基础点击')
        },
        clickEvent_1:function(){
            alert('多个点击_1')
        },
        clickEvent_2:function(){
            alert('多个点击_2')
        },
        tab: function (type) {
            aaa.userShow = type == 'user' ? true : false;
        },
        checked:function(index){
            aaa.arr3[index].$model.isChecked = !aaa.arr3[index].$model.isChecked;
        }
    });
    avalon.scan();
    return avalon.controller(function ($ctrl) {
        // 视图渲染后，意思是avalon.scan完成
        $ctrl.$onRendered = function () {
            console.log("aaa.js渲染完成---1");
        }
        // 进入视图
        $ctrl.$onEnter = function (params) {
        	console.log("aaa.js进入视图---2");
        	//vm.openPage(vm.urlParams,'');
        }
        // 对应的视图销毁前
        $ctrl.$onBeforeUnload = function () { 
        	console.log("aaa.js视图销毁前---3");
        	//register_app.b = login.a;
        }
        // 指定一个avalon.scan视图的vmodels，vmodels = $ctrl.$vmodels.concact(DOM树上下文vmodels)
        $ctrl.$vmodels = []
    });
});
avalon.filters.doAge = function(age) {
    if(age <18){
        return '未成年'
    }
    return '成年';
};