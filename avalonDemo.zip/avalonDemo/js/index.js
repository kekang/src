var vm;//这里的vm是全局的，不管页面如何切换

require.config({
    debug: false,
    baseUrl: 'js/'
});

require(['router/mmState', 'router/router'], function () {
    vm = avalon.define({
        $id: "index",
        aaaValue:"我是基本的数据绑定_index",
        change:function(){
            aaa.avalue = '2'
            console.log(aaa.avalue)
        },
        openPage: function (op, args) {//vm.openPage('bbb','')---vm.openPage('bbb/2','ccc=1')
            var obj = {};
            if(args) obj.query = '?' + args;
			avalon.router.go(op, obj);
        }
    });
    //路由
    arguments[1].init(); //加载'router/router'的function内容
    avalon.state.config({
        onBeforeUnload: function () { //路由跳转前执行
			console.log("index.js(根路由跳转前执行)---1");
        },
        onLoad: function () { //路由完成后执行
           console.log("index.js(根路由完成后执行)---2");
        }
    });
     //启动路由,开始监听URL变化,历史记录堆栈管理
    avalon.history.start({
        fireAnchor: false
    });

    avalon.scan();
});

