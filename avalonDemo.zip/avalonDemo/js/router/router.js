define(function () {
    return {
        init: function () {
            avalon.state("aaa", {
                url: "/",
                views: {
                    "": {
                        templateUrl: "./html/aaa.html",
                        controllerUrl: "aaa.js"
                    }
                }
            });
            avalon.state("aaa", {
            	url: "/aaa",                
                views: {
                    "": {
                        templateUrl: "./html/aaa.html",
                        controllerUrl: "aaa.js"
                    }
                }
            }).state("bbb", {
                url: "/bbb",
                views: {
                    "": {
                        templateUrl: "./html/bbb.html",
                        controllerUrl: "bbb.js"
                    }
                }
            }).state("bbb/2", {
                url: "/bbb/2",
                views: {
                    "": {
                        templateUrl: "./html/bbb2.html",
                        controllerUrl: "bbb2.js"
                    }
                }
            }).state("bbb/1", {
                url: "/bbb/1",
                views: {
                    "": {
                        templateUrl: "./html/bbb1.html",
                        controllerUrl: "bbb1.js"
                    }
                }
            });
        }
    };
});