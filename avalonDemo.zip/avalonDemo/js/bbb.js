var bbb;
define([], function () {
    bbb = avalon.define({
        $id: "bbb",
        role_roleMenuList:[],
        query:function(){
            var arr = [{
                "coMenuRelInfoDTO":{"companyNo":"C001","idIcpComMenuReInfo":"549487573B5E121DE053F882140AB88E","menuCode":"sm","menuName":"系统管理","menuSort":"01","menuUrl":"system","parentCode":"0"},
                "subMenuList":[
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5D121DE053F882140AB88E","menuCode":"sm1","menuName":"菜单管理","menuSort":"02","menuUrl":"menu","parentCode":"sm"},
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5C121DE053F882140AB88E","menuCode":"sm2","menuName":"机构管理","menuSort":"03","menuUrl":"org","parentCode":"sm"},
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5B121DE053F882140AB88E","menuCode":"sm3","menuName":"用户管理","menuSort":"04","menuUrl":"user","parentCode":"sm"},
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5A121DE053F882140AB88E","menuCode":"sm4","menuName":"角色管理","menuSort":"05","menuUrl":"role","parentCode":"sm"}]
            },{
                "coMenuRelInfoDTO":{"companyNo":"C001","idIcpComMenuReInfo":"549487573B5E121DE053F882140AB88E","menuCode":"am","menuName":"询价管理","menuSort":"01","menuUrl":"system","parentCode":"0"},
                "subMenuList":[
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5D121DE053F882140AB88E","menuCode":"am1","menuName":"丰盛的","menuSort":"06","menuUrl":"menu1","parentCode":"am"},
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5C121DE053F882140AB88E","menuCode":"am2","menuName":"过放电","menuSort":"07","menuUrl":"org2","parentCode":"am"},
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5B121DE053F882140AB88E","menuCode":"am3","menuName":"的撒的撒","menuSort":"08","menuUrl":"user3","parentCode":"am"},
                    {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5A121DE053F882140AB88E","menuCode":"am4","menuName":"范德萨","menuSort":"09","menuUrl":"role4","parentCode":"am"}]
            }];
            var list = [
                {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5E121DE053F882140AB88E","menuCode":"sm","menuName":"系统管理","menuSort":"01","menuUrl":"system","parentCode":"0"},
                {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5D121DE053F882140AB88E","menuCode":"sm1","menuName":"菜单管理","menuSort":"02","menuUrl":"menu","parentCode":"sm"},
                {"companyNo":"C001","idIcpComMenuReInfo":"549487573B5C121DE053F882140AB88E","menuCode":"sm2","menuName":"机构管理","menuSort":"03","menuUrl":"org","parentCode":"sm"}
            ];
            for(var j = 0; j < arr.length;j++){
                arr[j].isClosed = false;
                arr[j].isChecked = false;
                var arr1 = arr[j].subMenuList;
                for(var k = 0; k < arr1.length;k++){
                    arr1[k].isChecked = false;
                }
            }
            /*for(var i = 0; i < list.length;i++){
                for(var j = 0; j < arr.length;j++){
                    arr[j].isClosed = false;
                    if(list[i].menuCode == arr[j].coMenuRelInfoDTO.menuCode){
                        arr[j].isChecked = true;
                    }
                    var arr1 = arr[j].subMenuList;
                    for(var k = 0; k < arr1.length;k++){
                        if(list[i].menuCode == arr1[k].menuCode){
                            arr1[k].isChecked = true;
                        }
                    }
                }
            }*/
            bbb.role_roleMenuList = arr;
        },
        role_stateTab:function(i){//角色菜单折叠
            bbb.role_roleMenuList[i].isClosed = !bbb.role_roleMenuList[i].isClosed;
        },
        role_checked:function(type,i,j){//角色菜单选中联动
            if(type == 'frist'){
                bbb.role_roleMenuList[i].$model.isChecked = !bbb.role_roleMenuList[i].$model.isChecked;
                bbb.toCheckedInList(bbb.role_roleMenuList[i].subMenuList,bbb.role_roleMenuList[i].isChecked);
            }else if(type == 'second'){
                bbb.role_roleMenuList[i].subMenuList[j].$model.isChecked = !bbb.role_roleMenuList[i].subMenuList[j].$model.isChecked;
                bbb.childChecked(i);
            }
        },
        childChecked:function(j){//子菜单选中状态触发父级菜单是否选中
            var arr1 = bbb.role_roleMenuList[j].subMenuList,flag = true;//flag是否全选，true是false否
            for(var i = 0;i < arr1.length;i++){
                if(!arr1[i].isChecked){
                    flag = false;
                    break
                }
            }
            bbb.role_roleMenuList[j].isChecked = flag
        },
        toCheckedInList:function(list,bull){//父菜单选中状态触发子级菜单是否选中
            for(var i = 0;i < list.length;i++){
                list[i].isChecked = bull;
            }
        }
    });
    avalon.scan();
    return avalon.controller(function ($ctrl) {
        // 视图渲染后，意思是avalon.scan完成
        $ctrl.$onRendered = function () {
            console.log("bbb.js渲染完成---1");
        }
        // 进入视图
        $ctrl.$onEnter = function (params) {
        	console.log("bbb.js进入视图---2");
        	//vm.openPage(vm.urlParams,'');
        }
        // 对应的视图销毁前
        $ctrl.$onBeforeUnload = function () { 
        	console.log("bbb.js视图销毁前---3");
        	//register_app.b = login.a;
        }
        // 指定一个avalon.scan视图的vmodels，vmodels = $ctrl.$vmodels.concact(DOM树上下文vmodels)
        $ctrl.$vmodels = []
    });
});
