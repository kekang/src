# 保险云 App 前端 (Vue)

## 构建步骤（命令）

``` bash
# 安装依赖
npm install

# 启动开发模式，http://localhost:8080 热替换
npm run dev

# 构建
npm run build

# 单元测试
npm run unit

# e2e测试
npm run e2e

# 执行所有测试
npm test
```

特殊点记录：
一、health
    1，footerBut.vue文件中，sessionStorage.leaflet = ""作用是回退时返回到首页(此时无宣传页)，再回退才到宣传页
二、miniInsure
    1，miniCompute.vue文件引用datetime-picker-2：组件datetime-picker换肤changeColor默认颜色是健康险之类的值
        而小微默认值与之不同，为方便，用..-2，引用不同的换肤方法消除异常
三、1，境外旅行险，旅行开始日期T+1，范围180，结束日期范围=开始日期 至 开始日期+184(后端返回保障期限)；
    2，单次旅行，如果选择开始日期后，开始日期大于结束日期，将结束日期等于开始日期
    3，多次旅行，开始日期可选结束日期不可行，结束日期自动变为开始日期+1年-一天
补充：
    关于vuex，尽量在vuex中声明会用到的属性，不然以state[k] = obj[k]等动态添加到vuex中的属性，展示时可能会出问题
    (如小微录入发票页，输入发票抬头，往vuex动态插属性，后点保单类型，输入框变为空)
