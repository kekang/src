// see http://vuejs-templates.github.io/webpack for documentation.
var path = require('path')

//var chost = 'test-iicp-dmzstg.pingan.com.cn'

var chost = 'proxy3.paic.com.cn/proxyforwebx.pac'//测试环境

//var chost = 'IQSH-D0602:9002'
//var chost = 'iqsh-l0867:9112' // 开发环境，曾冰清机器
//var chost = 'IQSH-L0943:9112' // 开发环境，万梅机器

module.exports = {

  build: {
    env: require('./prod.env'),
    index: path.resolve(__dirname, '../dist/index.html'),
    assetsRoot: path.resolve(__dirname, '../dist'),
    assetsSubDirectory: 'static',
    assetsPublicPath: './',
    productionSourceMap: false,
    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css']
  },
  dev: {
    env: require('./dev.env'),
    port: 8080,
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
      proxyTable: {
          '/icp_yl_dmz': {
              target: 'http://' + chost,
              changeOrigin: true,
              pathRewrite: {
                  // '^/icp_yl_dmz': '',
              }
          },
          '/icp_yl': {
              target: 'http://' + chost,
              changeOrigin: true,
              pathRewrite: {
                  //'^/icp_yl': '',
              }
          },
          '/mssp': {
              target: 'http://' + chost,
              changeOrigin: true,
              pathRewrite: {
                  //'^/mssp': '',
              }
          },
          '../../../../mock':{
              target: 'localhost:8080/',
              changeOrigin: true,
              pathRewrite: {
                  '^/../../../../mock': '',
              }
          }
      },
    // CSS Sourcemaps off by default because relative paths are "buggy"
    // with this option, according to the CSS-Loader README
    // (https://github.com/webpack/css-loader#sourcemaps)
    // In our experience, they generally work as expected,
    // just be aware of this issue when enabling this option.
    cssSourceMap: false
  }
}
