<template>
    <div>
        <!--<headerBack v-show = "partnerCode" title="" fixed></headerBack>-->
        <!--<headerBack v-show = "callback" title="" :url="back" fixed></headerBack>-->
        <transition name="fade" mode="out-in">
            <router-view class="main-container"></router-view>
        </transition>
    </div>
</template>
<script>
    import headerBack from "../components/header/index"
    export default {
        data(){
          return{
              partnerCode:"",
              callback:"",
            }
        },
        mounted(){
            if(window.location.hash.split("?")[1]){
                var SK_channelid = window.location.hash.split("?")[1].split("&");
                for(let eq = 0;eq<SK_channelid.length;eq++){
                    if(SK_channelid[eq].split("=")[0]=="SK_channelid"){
                        sessionStorage.setItem("SK_channelid",SK_channelid[eq].split("=")[1]);
                        break;
                    }
                }
            }

//            let hashLocation = location.hash,params = hashLocation.split('?')[1],param = params.split('&'),
//                code,url;
//            for(let i = 0;i<param.length;i++){
//                if(param[i].indexOf('partnerCode') == 0){
//                    code = param[i].split('=')[1]
//                }
//                if(param[i].indexOf('callBackUrl') == 0){
//                    url = param[i].split('=')[1]
//                }
//            }
//            if(code){
//                localStorage.partnerCode = code
//                if(url){
//                    localStorage.callBackUrl = decodeURIComponent(url)
//                }
//            }
        },
//        watch: {
//            // 如果路由有变化，会再次执行该方法
//            '$route': 'change'
//        },
//        methods:{
//            change(){
//                let hashLocation = location.hash;
//                let hashSplit = hashLocation.split('#/!/')[1]
//                let hashName = hashSplit.split('?')[0];
//                //创宝网
//                if(localStorage.partnerCode == 'CZBX18'){
//                    //个险和团险
//                    if(hashName != 'cusPay' && hashName != 'sinConfirm' ){
//                        if (hashName == 'productDetail' || hashName == 'familyPublicity' || hashName == 'complete') {
//                            this.partnerCode = ''
//                            this.callback = "CZBX18"
//                            this.back = localStorage.callBackUrl
//                        }else{
//                            this.callback = ""
//                            this.partnerCode = 'CZBX18'
//                        }
//                    }
//                }
//            }
//        },
        components:{
//            headerBack
        }
    }

</script>
<style>
/*body > iframe {*/
    /*width: 0px;*/
    /*height: 0px;*/
    /*border: none;*/
/*}*/

.main-container {
    -webkit-transition: all .3s ease-in-out;
    width: 100%;
}

.fade-enter, .fade-leave-active {
    opacity: 0;
}

.fade-enter {
    /*-webkit-transform: translate2d( 0, 0);*/
    /*transform: translate2d(0, 0);*/
}

.fade-leave-active {
    /*-webkit-transform: translate2d(-1%, 0);*/
    /*transform: translate2d(-1%, 0);*/
}

</style>
