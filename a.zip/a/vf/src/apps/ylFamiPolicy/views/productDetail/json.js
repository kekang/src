function getAhProductDetail(){
    let obj = {
        "askedQuestions": "",
        "defaultShow": {
            "idProductCombined": "ICP00005501",
            "idInsType": "000030",
            "combinedPlanCode": "P1130WF11",
            "idPersonType": "36",
            "combinedName": "境外旅游亚洲经济型单次"
        },
        "icpProductCode": "ICP000055",
        "insurPersons": [
            {
                "personMinAge": "0",
                "gender": "9",
                "insType": [{
                    "maxInsNum": "5",
                    "maxInsAge": "22",
                    "minInsAge": "0",
                    "defaultValue": "10",
                    "idInsType": "000030"
                }],
                "personName": "0-80周岁因旅游等出国的人群",
                "personMaxAge": "80",
                "idPersonType": "36"
            }
        ],
        "resultMsg": "成功",
        "qualifiedCrowd": "0-80周岁，因旅游、商务、探亲而出国的人群",
        "buyNoticeLink": "BUYNOTICE0001004",
        "needInsurBirthday": "Y",
        "maxEffDelay": "3",
        "productMode": "T",
        "minEffDelay": "1",
        "clauses": [

        ],
        "bigPictureLink": "D:\\h5\\product\\img\\ICP000055.jpg",
        "productDetail": "1.承保在亚洲地区旅行的意外身故和突发急性病身故等责任|2.24小时紧急医疗救援等服务|3.提供中英文互译保单，电子保单彩色激光打印后可用于办理签证（具体以使馆要求为准）",
        "insurePeriod": "184",
        "resultCode": "00000",
        "appAgeMin": "18",
        "appAgeMax": "80",
        "leaflet": "",
        "dutyItems": {
            "PD00000000000108": {
                "dutyName": "休养期酒店住宿",
                "undwrtRange": "如授权医生认为被保险人出院后因医疗上的需要应在当地休养，救援服务机构将安排被保险人在出院后立即入住当地一普通的酒店以便其休养。本公司承担的酒店房间费用最高0.65万。"
            },
            "PD00000000000116": {
                "dutyName": "协助送回未成年子女",
                "undwrtRange": "若被保险人因遭受意外伤害、突发疾病、紧急医疗转运或遭遇身故而导致随行未满十六周岁之未成年子女无人照料，由本公司支付并由救援服务机构安排其未成年子女经最近途径的一张单程经济舱机票返回国内，但其原有之机票应交由救援服务机构处理。必要时，救援服务机构将安排护送人员随行返国并由本公司支付费用。本公司承担的上述费用最高4万。"
            },
            "PD00000000000107": {
                "dutyName": "紧急救援医疗服务",
                "undwrtRange": "被保险人遭受意外事故或突发急性病，经救援服务机构的授权医生确认需要医疗援助的，本公司将通过救援机构安排被保险人至距事发地最近或授权医生认为最合适的医院就医，本公司通过救援机构就每一保险事故被保险人治疗期间合理且必要的医疗费用，在扣除约定免赔额后，按约定给付比例承担给付医疗费用的责任。本公司累计承担的医疗费用总额以紧急救援医疗保险金额为限，累计给付金额达到其紧急救援医疗保险金额时，本公司对被保险人该项保险责任终止。"
            },
            "PD00000000000115": {
                "dutyName": "公共交通意外身故",
                "undwrtRange": "被保险人以乘客身份在乘坐所投保的客运公共交通工具（飞机、火车、轮船、汽车）期间因遭受意外事故，并自事故发生之日起180日内因该事故身故的。"
            },
            "PD00000000000114": {
                "dutyName": "亲属前往处理后事",
                "undwrtRange": "被保险人因遭受意外伤害事故或突发急性病，并完全且直接导致被保险人于三十天（含）内在境外身故的，根据被保险人亲属的要求，经救援服务机构许可，该被保险人的一名成年直系亲属可以前往被保险人身故地，本公司负责承担该名亲属经济交通方式下的往返费用以及实际支出的合理住宿费，最高0.65万。"
            },
            "PD00000000000109": {
                "dutyName": "公共交通意外身故",
                "undwrtRange": "被保险人以乘客身份在乘坐所投保的客运公共交通工具（飞机、火车、轮船、汽车）期间因遭受意外事故，并自事故发生之日起180日内因该事故身故的。"
            },
            "PD00000000000104": {
                "dutyName": "紧急医疗转运和送返",
                "undwrtRange": "授权医生从医疗角度认为被保险人病情需要，且当地医院条件不能保证被保险人得到充分的救治时，救援服务机构将以事发地能够提供的最合适的方式安排医疗设备、运输工具及随行医护人员，将被保险人转运至授权医生认为更适当的医院接受治疗，本公司承担相应的运送费用。"
            },
            "PD00000000000103": {
                "dutyName": "意外身故和残疾",
                "undwrtRange": "被保险人在旅行期间因遭受意外事故，并自事故发生之日起180日内因该事故身故或残疾的。"
            },
            "PD00000000000106": {
                "dutyName": "遗体/骨灰转运",
                "undwrtRange": "被保险人因遭受意外伤害事故或突发急性病导致在境外身故的，根据被保险人亲属的要求，救援服务机构或其授权代表根据事发当地实际情况并在不违反当地法律的情况下安排遗体保存或火化，且将被保险人之遗体或骨灰送返至被保险人在中华人民共和国境内（港、澳、台地区除外）的常住地。"
            },
            "PD00000000000105": {
                "dutyName": "亲属慰问探访",
                "undwrtRange": "经授权医生与主治医生共同认定被保险人在境外的预计住院时间超过八（8）日(不包括8日)，根据被保险人的要求，经救援服务机构许可，该被保险人的一名成年直系亲属可以前往被保险人住院地点探视，本公司负责承担该名亲属经济交通方式下的往返费用以及实际支出的合理住宿费，最高1.5万。"
            },
            "PD00000000000102": {
                "dutyName": "公共交通意外身故",
                "undwrtRange": "被保险人以乘客身份在乘坐所投保的客运公共交通工具（飞机、火车、轮船、汽车）期间因遭受意外事故，并自事故发生之日起180日内因该事故身故的。"
            },
            "PD00000000000113": {
                "dutyName": "出境旅行救援住院津贴",
                "undwrtRange": "旅行期间遭受意外事故或突发急性病，经授权医生确认并由救援机构安排进行住院治疗的，本公司按被保险人的合理住院天数乘以500元/天给付紧急救援住院津贴保险金。紧急救援住院津贴保险金累计给付日数最多为180日。累计给付紧急救援住院津贴保险金的日数达到180日时，对被保险人该项保险责任终止。"
            },
            "PD00000000000112": {
                "dutyName": "意外身故和残疾",
                "undwrtRange": "被保险人在旅行期间因遭受意外事故，并自事故发生之日起180日内因该事故身故或残疾的。"
            },
            "PD00000000000111": {
                "dutyName": "当地安葬/丧葬",
                "undwrtRange": "被保险人因遭受意外伤害事故或突发急性病直接导致在境外身故的，根据被保险人亲属的要求并在不违反当地法律的情况下，救援服务机构或其授权代表安排在事发当地安葬被保险人。本公司承担安葬费用，最高以保险单上载明的相应的保险金额为限。"
            },
            "PD00000000000110": {
                "dutyName": "递送药物和医疗用品",
                "undwrtRange": "若被保险人无法在其所在地获得护理和治疗所必需的基本药物、药品和医疗用品，救援服务机构可安排递送。前提是该药品必须有医生处方，且是医疗不可或缺的且无相适的药品可在当地处方取得，并且国家或国际卫生和海关法规没有限制运送该类药品、药物或医疗物品。前述的药品、药物或医疗物品的成本及递送的费用由保险公司承担，最高1万。"
            }
        },
        "needSocialSecurity": "N",
        "smallPictureLink": "D:\\h5\\product\\img\\minICP000055.jpg",
        "personProducts": {
            "36": [
                {
                    "idProductCombined": "ICP00005501",
                    "dutys": [
                        {
                            "amountName": "10万",
                            "dutyName": "公共交通意外身故",
                            "combinedDutyId": "PCD0000000000249",
                            "dutyId": "PD00000000000102"
                        },
                        {
                            "amountName": "10万",
                            "dutyName": "意外身故和残疾",
                            "combinedDutyId": "PCD0000000000251",
                            "dutyId": "PD00000000000103"
                        },
                        {
                            "amountName": "10万",
                            "dutyName": "紧急医疗转运和送返",
                            "combinedDutyId": "PCD0000000000244",
                            "dutyId": "PD00000000000104"
                        },
                        {
                            "amountName": "10万",
                            "dutyName": "遗体/骨灰转运",
                            "combinedDutyId": "PCD0000000000245",
                            "dutyId": "PD00000000000106"
                        },
                        {
                            "amountName": "10万",
                            "dutyName": "紧急救援医疗服务",
                            "combinedDutyId": "PCD0000000000235",
                            "dutyId": "PD00000000000107"
                        },
                        {
                            "amountName": "10万",
                            "dutyName": "公共交通意外身故",
                            "combinedDutyId": "PCD0000000000248",
                            "dutyId": "PD00000000000109"
                        },
                        {
                            "amountName": "1.5万",
                            "dutyName": "当地安葬/丧葬",
                            "combinedDutyId": "PCD0000000000246",
                            "dutyId": "PD00000000000111"
                        },
                        {
                            "amountName": "10万",
                            "dutyName": "意外身故和残疾",
                            "combinedDutyId": "PCD0000000000250",
                            "dutyId": "PD00000000000112"
                        },
                        {
                            "amountName": "10万",
                            "dutyName": "公共交通意外身故",
                            "combinedDutyId": "PCD0000000000247",
                            "dutyId": "PD00000000000115"
                        }
                    ],
                    "combinedOrder": "1",
                    "isDefault": "Y",
                    "idInsType": "000030",
                    "combinedPlanCode": "P1130WF11",
                    "combinedName": "境外旅游亚洲经济型单次"
                },
                {
                    "idProductCombined": "ICP00005503",
                    "dutys": [
                        {
                            "amountName": "20万",
                            "dutyName": "公共交通意外身故",
                            "combinedDutyId": "PCD0000000000264",
                            "dutyId": "PD00000000000102"
                        },
                        {
                            "amountName": "20万",
                            "dutyName": "意外身故和残疾",
                            "combinedDutyId": "PCD0000000000266",
                            "dutyId": "PD00000000000103"
                        },
                        {
                            "amountName": "30万",
                            "dutyName": "紧急医疗转运和送返",
                            "combinedDutyId": "PCD0000000000254",
                            "dutyId": "PD00000000000104"
                        },
                        {
                            "amountName": "30万",
                            "dutyName": "遗体/骨灰转运",
                            "combinedDutyId": "PCD0000000000255",
                            "dutyId": "PD00000000000106"
                        },
                        {
                            "amountName": "20万",
                            "dutyName": "紧急救援医疗服务",
                            "combinedDutyId": "PCD0000000000252",
                            "dutyId": "PD00000000000107"
                        },
                        {
                            "amountName": "20万",
                            "dutyName": "公共交通意外身故",
                            "combinedDutyId": "PCD0000000000263",
                            "dutyId": "PD00000000000109"
                        },
                        {
                            "amountName": "1.5万",
                            "dutyName": "当地安葬/丧葬",
                            "combinedDutyId": "PCD0000000000256",
                            "dutyId": "PD00000000000111"
                        },
                        {
                            "amountName": "20万",
                            "dutyName": "意外身故和残疾",
                            "combinedDutyId": "PCD0000000000265",
                            "dutyId": "PD00000000000112"
                        },
                        {
                            "amountName": "500元/天",
                            "dutyName": "出境旅行救援住院津贴",
                            "combinedDutyId": "PCD0000000000253",
                            "dutyId": "PD00000000000113"
                        },
                        {
                            "amountName": "0.65万",
                            "dutyName": "亲属前往处理后事",
                            "combinedDutyId": "PCD0000000000261",
                            "dutyId": "PD00000000000114"
                        },
                        {
                            "amountName": "20万",
                            "dutyName": "公共交通意外身故",
                            "combinedDutyId": "PCD0000000000262",
                            "dutyId": "PD00000000000115"
                        },
                        {
                            "amountName": "4万",
                            "dutyName": "协助送回未成年子女",
                            "combinedDutyId": "PCD0000000000259",
                            "dutyId": "PD00000000000116"
                        },
                        {
                            "amountName": "1.5万",
                            "dutyName": "亲属慰问探访",
                            "combinedDutyId": "PCD0000000000258",
                            "dutyId": "PD00000000000105"
                        },
                        {
                            "amountName": "0.65万",
                            "dutyName": "休养期酒店住宿",
                            "combinedDutyId": "PCD0000000000260",
                            "dutyId": "PD00000000000108"
                        },
                        {
                            "amountName": "1万",
                            "dutyName": "递送药物和医疗用品",
                            "combinedDutyId": "PCD0000000000257",
                            "dutyId": "PD00000000000110"
                        }
                    ],
                    "combinedOrder": "3",
                    "isDefault": "N",
                    "idInsType": "000032",
                    "combinedPlanCode": "P1130WG09",
                    "combinedName": "境外旅游亚洲豪华型单次"
                }
            ]
        },
        "productDesc": "承保在亚洲地区旅行的意外身故和医疗",
        "insurePeriodType": "D",
        "hasHealth": "N",
        "productName": "境外亚洲旅游保险"
    };
    return obj;
}

module.exports = {
    getAhProductDetail
}