<template>
    <div class="healthIndex">
        <!--头信息-->
        <headImg></headImg>
        <!--产品信息-->
        <product></product>
        <!--保障计划-->
        <protection></protection>
        <!--服务协议和提交按钮-->
        <footerBut></footerBut>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";
    .healthIndex{
        background-color: @background-color-dark;
    }
    body{
        background-color: @background-color-dark;
    }
</style>
<script>
    import headImg from './headImg.vue'
    import product from './product.vue'
    import protection from './protection.vue'
    import footerBut from './footerBut.vue'

    import {Msg,Loading} from 'components'
    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import { getAhProductDetail,policyInquiry } from '../../apis/asia.api.js'
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import * as asiaAc from "../../vuex/actionTypes/asia.action.types"
    import {changeColor} from "../../../../utils/skin"
    import filter from "../../../../utils/filter"

    export default{
        data(){
            return{
                fontColor:""
            }
        },
        beforeMount(){
            //无痕浏览
            function isLocalStorageSupported() {
                var testKey = 'test',storage = window.sessionStorage;
                try {
                    storage.setItem(testKey, 'testValue');
                    storage.removeItem(testKey);
                    return true;
                } catch (error) {return false;}
            }
            if(isLocalStorageSupported()){
                if(this.$route.query.icpProductCode){
                    sessionStorage.icpProductCode = this.$route.query.icpProductCode
                    sessionStorage.partnerCode = this.$route.query.partnerCode
                    sessionStorage.keyCode = this.$route.query.keyCode?this.$route.query.keyCode:'';
                    sessionStorage.agencyNo = this.$route.query.agencyNo?this.$route.query.agencyNo:'';
                    sessionStorage.empno = this.$route.query.empno?this.$route.query.empno:'';
                }
                sessionStorage.remark = this.$route.query.remark || sessionStorage.remark || '';
                sessionStorage.fontColor = changeColor();
            }

            //if(this.$store.state.asia.productDetail){
                //sessionStorage.stateObj = JSON.stringify(this.$store.state.asia);
            //}else{
                //if(sessionStorage.stateObj) this.$store.commit(asiaMu.setState,JSON.parse(sessionStorage.stateObj));
            //}

        },
        mounted(){
            document.body.scrollTop = 1;
            if(!sessionStorage.icpProductCode){
                Msg.alert('抱歉，目前不支持无痕浏览模式')
                return;
            }else{
                if(!this.$store.state.asia.productDetail){//无价格说明无记录(用户第一次进或刷新了页面)，发请求
                    this.getAhProductDetail();
                }
            }
        },
        methods:{
            getAhProductDetail(){
                getAhProductDetail({//getRelatedProduct
                    "agencyNo":sessionStorage.agencyNo,
                    "empno":sessionStorage.empno,
                    "icpProductCode":sessionStorage.icpProductCode,
                    "partnerCode":sessionStorage.partnerCode,
                    "dataSource":'H5',
                    "userId":sessionStorage.userId
                }).then((msg) =>{
                    console.log(msg)
                    if(msg.body.resultCode == "00000"){
                        this.$store.commit(asiaMu.setProductDetail,msg.body);
                        this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
                    }
                });
            }
        },
        computed: {
            ...mapState({
                numbers:state=>state.asia.numbers
            })
        },
        components:{
            headImg,
            product,
            protection,
            footerBut,
            Msg,
            Loading,
            datetimePicker,
            picker,
            popup
        }
    }
</script>
