<template>
    <div class="site">
        <section class="site_com">
            <div class="site_block" id='divs'>
                <div class="site_roll">
                    <section>
                        <div class="line_com"><!--label换成了span标签，原因是在安卓上点击label事件会执行两次-->
                            <span class="line" v-for="(item,index) of occupationList" @click="selectOcc(item.occupationCode,item.fullName,item.dangerGrade)"><span>{{item.fullName}}</span></span>
                        </div>
                    </section>
                </div>
            </div>
        </section>
    </div>
</template>
<style lang="less" scoped >
    @fontsize:1.5rem;
    .site{
        height: 667px;
        height: 100vh;
        width:100%;

        .header_seek{
            height: 10%;
            height: 10vh;
            background: #FFFFFF;
            text-align: center;
            box-sizing: border-box;
            padding:1rem;
            input{
                display: inline-block;
                line-height: 2.4rem;
                font-size: @fontsize;
                text-indent: 1em;
                width: 90%;
            }
        }
        .site_com{
            width: 100%;
            height: 100%;
            height: 100vh;
            background: blue;
            display: box;			  /* OLD - Android 4.4- */
            display: -webkit-box;	  /* OLD - iOS 6-, Safari 3.1-6 */
            display: -moz-box;		 /* OLD - Firefox 19- (buggy but mostly works) */
            display: -ms-flexbox;	  /* TWEENER - IE 10 */
            display: -webkit-flex;	 /* NEW - Chrome */
            display: flex;			 /* NEW, Spec - Opera 12.1, Firefox 20+ */
            /* 09版 */
            -webkit-box-orient: horizontal;
            /* 12版 */
            -webkit-flex-direction: row;
            -moz-flex-direction: row;
            -ms-flex-direction: row;
            -o-flex-direction: row;
            flex-direction: row;

            .site_block{
                width: 100%;
                background: #FFFFFF;
                overflow: auto;
                .site_roll{
                    width: 100%;
                    section{
                        .id{
                            width: 100%;
                            line-height: 2rem;
                            background: #F0F0F5;
                            padding-left: 8%;
                            font-size: 1.7rem;
                            font-weight: 600;
                        }
                        .line_com{
                            margin-left: 8%;
                            .line{
                                position: relative;
                                display: block;
                                line-height: 3.4rem;
                                font-size: @fontsize;
                                border-bottom: 1px solid #E9E9E7;
                                display: box;			  /* OLD - Android 4.4- */
                                display: -webkit-box;	  /* OLD - iOS 6-, Safari 3.1-6 */
                                display: -moz-box;		 /* OLD - Firefox 19- (buggy but mostly works) */
                                display: -ms-flexbox;	  /* TWEENER - IE 10 */
                                display: -webkit-flex;	 /* NEW - Chrome */
                                display: flex;			 /* NEW, Spec - Opera 12.1, Firefox 20+ */
                                /* 09版 */
                                -webkit-box-orient: horizontal;
                                /* 12版 */
                                -webkit-flex-direction: row;
                                -moz-flex-direction: row;
                                -ms-flex-direction: row;
                                -o-flex-direction: row;
                                flex-direction: row;

                                /* 09版 */
                                -webkit-box-pack: space-between;
                                /* 12版 */
                                -webkit-justify-content: space-between;
                                -moz-justify-content: space-between;
                                -ms-justify-content: space-between;
                                -o-justify-content: space-between;
                                justify-content: space-between;

                                input{
                                    position: absolute;
                                    clip: rect(0,0,0,0);
                                }
                                .icon{
                                    display: block;
                                    text-align: right;
                                    height: .9rem;
                                    width: 1.5rem;
                                    opacity: 0;
                                    position: relative;
                                    top:1rem;
                                    right:.5rem;
                                    box-sizing: border-box;
                                    border-bottom: 3px solid #F76C6C;
                                    border-left: 3px solid #F76C6C;
                                    transition: all .1s ease-in;
                                    transform: rotate(-30deg);
                                }
                                input[type="checkbox"]:checked + label{
                                    opacity: 1;
                                    transform: rotate(-45deg);
                                }
                            }
                            .line:last-child{
                                border-bottom: 1px solid transparent;
                            }
                        }
                    }
                }
            }
            .index{
                width: 8%;
                text-align: center;
                background: #FFFFFF;
                padding-top: 10%;
                font-size: 1.6rem;
                a{
                    display: block;
                    width: 100%;
                    color: #1975FF;
                    font-weight: 600;
                }
            }
        }
        .footer{
            height: 8%;
            height: 8vh;
            display: box;			  /* OLD - Android 4.4- */
            display: -webkit-box;	  /* OLD - iOS 6-, Safari 3.1-6 */
            display: -moz-box;		 /* OLD - Firefox 19- (buggy but mostly works) */
            display: -ms-flexbox;	  /* TWEENER - IE 10 */
            display: -webkit-flex;	 /* NEW - Chrome */
            display: flex;			 /* NEW, Spec - Opera 12.1, Firefox 20+ */
            /* 09版 */
            -webkit-box-orient: horizontal;
            /* 12版 */
            -webkit-flex-direction: row;
            -moz-flex-direction: row;
            -ms-flex-direction: row;
            -o-flex-direction: row;
            flex-direction: row;

            /* 09版 */
            -webkit-box-pack: space-between;
            /* 12版 */
            -webkit-justify-content: space-between;
            -moz-justify-content: space-between;
            -ms-justify-content: space-between;
            -o-justify-content: space-between;
            justify-content: space-between;

            /* 09版 */
            -webkit-box-align: center;
            /* 12版 */
            -webkit-align-items: center;
            -moz-align-items: center;
            -ms-align-items: center;
            -o-align-items: center;
            align-items: center;


            padding: 0 1.5rem;
            background: #F0F0F5;
            .botton_con{
                a{
                    background: #FFFFFF;
                    display: inline-block;
                    width: 5rem;
                    line-height: 3rem;
                    border:1px solid #cccccc;
                    text-align: center;
                    margin-left: 1.5rem;
                }
            }
        }
    }
    .noSelect{
        color: #BCBCBC;
    }
</style>
<script>
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import { getOccupationTypeInfo } from '../../apis/asia.api.js'
    export default{
        data(){
            return {
                searchText:''//搜索内容
            }
        },
        beforeMount(){
            if(this.$store.state.asia.productDetail){
                sessionStorage.stateObj = JSON.stringify(this.$store.state.asia);
            }else{
                this.$store.commit(asiaMu.setState,JSON.parse(sessionStorage.stateObj));
            }
        },
        mounted(){
            this.getOccupationTypeInfo(this.$store.state.asia.occupationCode2||this.$store.state.asia.occupationCode,2);
        },
        updated(){

        },
        methods:{
            selectOcc(occupationCode,fullName,grade){
                this.$store.commit(asiaMu.setOccupationCode,[occupationCode,grade]);
                this.$store.commit(asiaMu.setOccupationName,fullName);
                this.$store.commit(asiaMu.setOccupationList,[]);
                this.$router.push({'name':"choose_3"})
            },
            getOccupationTypeInfo(occupationCode,grade){
                let obj = {
                    idInsurCompany:this.$store.state.asia.productDetail.idInsurCompany,
                    //idInsurCompany:'0001',
                    occupationCode:occupationCode,
                    grade:grade
                }
                getOccupationTypeInfo(obj).then((msg) =>{
                    if(msg.body.resultCode == "00000"){
                        if(msg.body.occupationTypeList.length == 0){
                            this.$store.commit(asiaMu.upCustomerInfoList,[this.$store.state.asia.personOccIndex,{insurOccupationType:this.$store.state.asia.occupationName,insurOccupationTypeCode:this.$store.state.asia.occupationCode}]);
                            this.$store.commit(asiaMu.setOccupationCode,'');
                            this.$store.commit(asiaMu.setOccupationList,[]);
                            this.$router.go(-2);
                        }else{
                            this.$store.commit(asiaMu.setOccupationList,msg.body.occupationTypeList);
                        }
                    }
                })
            }
        },
        computed: {
            ...mapState({
                occupationList:state=>state.asia.occupationList
            })
        },
        beforeDestroy(){
            //回首页
            this.$store.commit(asiaMu.setOccupationList,[]);
        }
    }
</script>
