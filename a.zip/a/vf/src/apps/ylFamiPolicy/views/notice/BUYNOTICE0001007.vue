<template>
    <div class="service-Terms">
        <h1>投保须知</h1>
        <p class="for-margin">1、本投保人兹申明以上述各项内容填写属实。</p>
        <p class="for-margin">2、本投保人已阅读<span @click="goClause" style="color:red">《平安家庭保综合意外保险适用条款》</span>，特别就条款中有关责任免除和投保人、被保险人义务的内容进行阅读。本投保人同意投保，接受条款全部内容。投保须知内容如下：
        <br/>(1)·共用保额：本保单下各项保险责任的共用保额为该保单下成年被保险人的保险金额。该共用保额为保单下所有家庭成员共有，无论一人或多人使用，其累计赔付上限为该项保险责任的约定保额；
        <br/>(2).未成年人意外身故/残疾保险金额上限为10万元；
        <br/>(3).意外伤害医疗每次保险事故免赔额为100元；
        <br/>(4).“未成年子女”释义：指投保时健康出生满30天至17周岁的家庭成员；
        <br/>(5).因工作发生的意外身故、伤残及意外医疗责任，仅保障1-3类职业人员，其他保障不限职业类别。</p>
        <p class="for-margin">3、根据《中华人民共和国合同法》第十一条规定，数据电文是合法的合同表现形式。本人接受以平安养老保险股份有限公司提供的电子保单作为本投保书成立的合法有效凭证，具有完全证据效力。</p>
        <p class="for-margin">4、本人授权平安集团，除法律另有规定之外，将本人提供给平安集团的信息、享受平安集团服务产生的信息（包括本单证签署之前提供和产生的信息）以及平安集团根据本条约定查询、收集的信息，用于平安集团及其因服务必要委托的合作伙伴为本人提供服务、推荐产品、开展市场调查与信息数据分析。
            本人授权平安集团，除法律另有规定之外，基于为本人提供更优质服务和产品的目的，向平安集团因服务必要开展合作的伙伴提供、查询、收集本人的信息。
            为确保本人信息的安全，平安集团及其合作伙伴对上述信息负有保密义务，并采取各种措施保证信息安全。
            本条款自本单证签署时生效，具有独立法律效力，不受合同成立与否及效力状态变化的影响。
            本条所称“平安集团”是指中国平安保险（集团）股份有限公司及其直接或间接控股的公司，以及中国平安保险（集团）股份有限公司直接或间接作为其单一最大股东的公司。
            如您不同意上述授权条款的部分或全部，可致电客服热线（95511）取消或变更授权。</p>
    </div>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
export default{
    data () {
        return {
            fontColor:"#ff6600",
            clauseColor:"#2688c4"
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
        document.body.scrollTop = 0;
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
            "浏览投保须知":'浏览投保须知'
        });
    },
    methods: {
        goClause(type){
            this.$router.push({'name':'P1125'});
        }
    }
}
</script>
<style scoped lang="less">
    .header{
        height: 6.6rem;
        background:#4b89dc;
        box-shadow:0px 2px 12px 0px #e9eef5;
    }
    .content{
        padding-top: 4rem;
        padding-right: 2rem;
        padding-left: 2rem;
    }
    h1{
        text-align: center;
        font-size: 2rem;
        margin-bottom: 2rem;
        margin-top: 1rem;
        color: #454545;
    }
    h2{
        font-size: 1.6rem;
        color: #454545;
        margin-bottom: 1.8rem;
    }
    p{
        font-size: 1.5rem;
        color: #454545;
        line-height: 2.2rem;
        padding-left: 1rem;
        padding-right: 1rem;
    }
    .blank{
        text-indent: 4ex
    }
    .for-margin{
        margin-bottom: 1.5rem;
    }
</style>
