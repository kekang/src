<template>
    <div>
        <table border=0 cellpadding=0 cellspacing=0 width=643 style='border-collapse:
 collapse;table-layout:fixed;width:482pt;left: 150px;position: relative;'>
            <col class=x64 width=118 style='mso-width-source:userset;width:88pt'>
            <col class=x64 width=137 style='mso-width-source:userset;width:102pt'>
            <col class=x125 width=75 style='mso-width-source:userset;width:56pt'>
            <col class=x64 width=239 style='mso-width-source:userset;width:179pt'>
            <col class=x126 width=74 style='mso-width-source:userset;width:55pt'>
            <tr height=72 style='mso-height-source:userset;height:54pt' id='r0'>
                <td colspan=5 id='tc0' height=72 class=x151 style='border-bottom:2px solid windowtext;height:54pt;' >2009版团险职业分类表</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1'>
                <td height=20 class=x65 style='height:15pt;' ><a name="_FILTERDATABASE" ><span style='font-size:12pt;color:#000000;font-weight:400;text-decoration:none;text-line-through:none;font-family:"黑体";'>大分类</span></a></td>
                <td class=x66>中分类</td>
                <td class=x67></td>
                <td class=x68>小分类</td>
                <td class=x69>类别</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r2'>
                <td rowspan=4 height=78 class=x183 style='border-top: 2px solid windowtext;border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:58.5pt;overflow:hidden;' >00一般职业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td rowspan=2 height=39 class=x184 style='height:29.25pt;' >0001机关团体公司</td>
                <td class=x70>0001001</td>
                <td class=x71>机关内勤(不从事凶险工作)</td>
                <td class=x72>1</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r3'>
                <td class=x70>0001002</td>
                <td class=x71>机关外勤（不属于本表下列职业分类所列者)</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r4'>
                <td rowspan=2 height=39 class=x184 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >0002工厂</td>
                <td class=x74>0002001</td>
                <td class=x75>工厂负责人（不亲自作业）</td>
                <td class=x72>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r5'>
                <td class=x70>0002002</td>
                <td class=x76>工厂厂长（不亲自作业）</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r6'>
                <td rowspan=19 height=363 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:272.25pt;overflow:hidden;' >01农牧业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td rowspan=12 height=229 class=x184 style='border-bottom:2px solid windowtext;height:171.75pt;' >0101农业</td>
                <td class=x74>0101001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>农场经营者（不亲自作业）</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r7'>
                <td class=x70>0101002</td>
                <td class=x71>农夫</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r8'>
                <td class=x70>0101003</td>
                <td class=x71>长短工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r9'>
                <td class=x70>0101004</td>
                <td class=x71>果农</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r10'>
                <td class=x70>0101005</td>
                <td class=x71>苗圃栽培人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r11'>
                <td class=x70>0101006</td>
                <td class=x71>花圃栽培人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r12'>
                <td class=x70>0101007</td>
                <td class=x71>饲养家禽家畜人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r13'>
                <td class=x70>0101008</td>
                <td class=x71>农业技师、指导员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r14'>
                <td class=x70>0101009</td>
                <td class=x71>农业机械之操作或修理人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r15'>
                <td class=x70>0101010</td>
                <td class=x71>农具商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r16'>
                <td class=x70>0101011</td>
                <td class=x71>糖厂技工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r17'>
                <td class=x70>0101012</td>
                <td class=x71>昆虫(蜜蜂)饲养人员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r18'>
                <td rowspan=7 height=134 class=x184 style='border-bottom:2px solid windowtext;height:100.5pt;' >0102牧业</td>
                <td class=x74>0102001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>畜牧场经营者(不亲自作业)</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r19'>
                <td class=x70>0102002</td>
                <td class=x71>畜牧工作人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r20'>
                <td class=x70>0102003</td>
                <td class=x71>兽医</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r21'>
                <td class=x70>0102004</td>
                <td class=x71>动物养殖人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r22'>
                <td class=x70>0102005</td>
                <td class=x71>驯养人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r23'>
                <td class=x70>0102006</td>
                <td class=x71>猛兽饲养工(动物园)</td>
                <td class=x78>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r24'>
                <td class=x70>0102007</td>
                <td class=x71>有毒动物饲养工（蛇、蝎子、蜈蚣等）</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r25'>
                <td rowspan=11 height=211 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:158.25pt;' >02渔业</td>
                <td rowspan=9 height=172 class=x184 style='border-bottom:2px solid windowtext;height:129pt;' >0201内陆渔业</td>
                <td class=x74>0201001 </td>
                <td class=x77>渔场经营者（不亲自作业）</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r26'>
                <td class=x70>0201002</td>
                <td class=x71>渔场经营者(亲自作业)</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r27'>
                <td class=x70>0201003</td>
                <td class=x71>养殖工人(内陆)</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r28'>
                <td class=x70>0201004</td>
                <td class=x71>热带鱼养殖者、水族馆经营者</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r29'>
                <td class=x70>0201005</td>
                <td class=x71>捕鱼人(内陆)</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r30'>
                <td class=x70>0201006</td>
                <td class=x71>捕鱼人(沿海)</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r31'>
                <td class=x70>0201007</td>
                <td class=x71>水产实验人员(室内)</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r32'>
                <td class=x70>0201008</td>
                <td class=x71>养殖工人(沿海)</td>
                <td class=x78>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r33'>
                <td class=x70>0201009</td>
                <td class=x71>水产加工工人</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r34'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >0202海上渔业</td>
                <td class=x74>0202001 </td>
                <td class=x77>远洋渔船船员</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r35'>
                <td class=x70>0202002</td>
                <td class=x71>近海渔船船员</td>
                <td class=x73>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r36'>
                <td rowspan=32 height=613 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:459.75pt;' >03木材森林业</td>
                <td rowspan=6 height=115 class=x185 style='border-bottom:3px solid windowtext;height:86.25pt;' >0301森林砍伐业</td>
                <td class=x74>0301001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>领班、监工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r37'>
                <td class=x70>0301002</td>
                <td class=x71>伐木工人</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r38'>
                <td class=x70>0301003</td>
                <td class=x71>锯木工人</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r39'>
                <td class=x70>0301004</td>
                <td class=x71>运材车辆之司机及押运人员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r40'>
                <td class=x70>0301005</td>
                <td class=x71>起重机之操作人员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r41'>
                <td class=x70>0301006</td>
                <td class=x71>装运工人、挂钩工人</td>
                <td class=x79>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r42'>
                <td rowspan=12 height=230 class=x184 style='border-bottom:2px solid windowtext;height:172.5pt;' >0302木材加工业</td>
                <td class=x74>0302001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>木材工厂现场之职员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r43'>
                <td class=x70>0302002</td>
                <td class=x71>领班</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r44'>
                <td class=x70>0302003</td>
                <td class=x71>分级员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r45'>
                <td class=x70>0302004</td>
                <td class=x71>检查员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r46'>
                <td class=x70>0302005</td>
                <td class=x71>标记员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r47'>
                <td class=x70>0302006</td>
                <td class=x71>磅秤员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r48'>
                <td class=x70>0302007</td>
                <td class=x71>锯木工人</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r49'>
                <td class=x70>0302008</td>
                <td class=x71>防腐剂工人</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r50'>
                <td class=x70>0302009</td>
                <td class=x71>木材储藏槽工人</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r51'>
                <td class=x70>0302010</td>
                <td class=x71>木材搬运工人</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r52'>
                <td class=x70>0302011</td>
                <td class=x71>吊车操作人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r53'>
                <td class=x70>0302012</td>
                <td class=x71>合板制造人员</td>
                <td class=x73>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r54'>
                <td rowspan=6 height=115 class=x184 style='height:86.25pt;' >0303造林业</td>
                <td class=x74>0303001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>领班</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r55'>
                <td class=x70>0303002</td>
                <td class=x71>山地造林人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r56'>
                <td class=x70>0303003</td>
                <td class=x71>山林管理人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r57'>
                <td class=x70>0303004</td>
                <td class=x71>森林防火人员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r58'>
                <td class=x70>0303005</td>
                <td class=x71>平地育苗人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r59'>
                <td class=x70>0303006</td>
                <td class=x71>实验室育苗栽培人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r60'>
                <td rowspan=8 height=153 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:114.75pt;' >0304农林牧渔服务业 </td>
                <td class=x74>0304001</td>
                <td class=x77>技术服务咨询人员</td>
                <td class=x72>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r61'>
                <td class=x70>0304002</td>
                <td class=x71>拖拉机驾驶员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r62'>
                <td class=x70>0304003</td>
                <td class=x71>联合收割机驾驶员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r63'>
                <td class=x70>0304004</td>
                <td class=x71>农用运输车驾驶员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r64'>
                <td class=x70>0304005</td>
                <td class=x71>农用机械操作及修理人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r65'>
                <td class=x70>0304006</td>
                <td class=x71>沼气工程施工人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r66'>
                <td class=x70>0304007</td>
                <td class=x71>能源设备安装、调试、检修人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r67'>
                <td class=x80>0304008</td>
                <td class=x81>沼气生产管理人员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r68'>
                <td rowspan=16 height=309 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:231.75pt;' >04矿业采掘业</td>
                <td class=x82>0401坑道内作业</td>
                <td class=x74>0401001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>矿工、采掘工、爆破工</td>
                <td class=x73>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r69'>
                <td rowspan=6 height=115 class=x184 style='border-bottom:2px solid windowtext;height:86.25pt;' >0402坑道外作业</td>
                <td class=x74>0402001<span style='mso-spacerun:yes'>&nbsp; </span></td>
                <td class=x77>经营者(不到现场者)</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r70'>
                <td class=x70>0402002</td>
                <td class=x71>经营者(现场监督者)</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r71'>
                <td class=x70>0402003</td>
                <td class=x71>经理人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r72'>
                <td class=x70>0402004</td>
                <td class=x71>矿寻工程师、技师、领班</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r73'>
                <td class=x70>0402005</td>
                <td class=x71>工人</td>
                <td class=x78>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r74'>
                <td class=x70>0402006</td>
                <td class=x71>工矿安全人员</td>
                <td class=x73>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r75'>
                <td class=x82>0403海上作业</td>
                <td class=x74>0403001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>海上所有作业人员(潜水人员拒保)</td>
                <td class=x73>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r76'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >0404采矿石业</td>
                <td class=x74>0404001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>采石业工人</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r77'>
                <td class=x70>0404002</td>
                <td class=x71>采砂业工人</td>
                <td class=x73>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r78'>
                <td rowspan=6 height=115 class=x184 style='border-bottom:2px solid windowtext;height:86.25pt;' >0405陆上油矿开采业</td>
                <td class=x74>0405001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>行政人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r79'>
                <td class=x70>0405002</td>
                <td class=x71>工程师</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r80'>
                <td class=x70>0405003</td>
                <td class=x71>技术员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r81'>
                <td class=x70>0405004</td>
                <td class=x71>油气井清洁保养修护工</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r82'>
                <td class=x70>0405005</td>
                <td class=x71>钻勘设备安装换修保养工</td>
                <td class=x78>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r83'>
                <td class=x70>0405006</td>
                <td class=x71>钻油井工人</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r84'>
                <td rowspan=165 height=3139 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:2354.25pt;' >05交通运输业</td>
                <td rowspan=25 height=476 class=x183 style='border-right:2px solid windowtext;height:357pt;' >0501陆运</td>
                <td class=x74>0501001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x75>出租车企业、物流企业负责人</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r85'>
                <td class=x70>0501002</td>
                <td class=x76>外务员（无驾照人员）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r86'>
                <td class=x70>0501003</td>
                <td class=x76>汽车客运服务员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r87'>
                <td class=x70>0501004</td>
                <td class=x76>自用小客车司机</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r88'>
                <td class=x70>0501005</td>
                <td class=x76>自用大客车司机</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r89'>
                <td class=x70>0501006</td>
                <td class=x76>出租车、救护车司机</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r90'>
                <td class=x70>0501007</td>
                <td class=x76>游览车司机及服务员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r91'>
                <td class=x70>0501008</td>
                <td class=x76>客运车司机及服务员（市区内）</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r92'>
                <td class=x70>0501009</td>
                <td class=x76>小型客货两用车司机</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r93'>
                <td class=x70>0501011</td>
                <td class=x76>人力三轮车夫</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r94'>
                <td class=x70>0501012</td>
                <td class=x76>铁牛车驾驶、混凝土预拌车驾驶员`</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r95'>
                <td class=x70>0501013</td>
                <td class=x76>机动三轮车夫</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r96'>
                <td class=x70>0501014</td>
                <td class=x76>柜台售票员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r97'>
                <td class=x70>0501015</td>
                <td class=x76>客运车稽核人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r98'>
                <td class=x70>0501016</td>
                <td class=x76>货车司机、随车工人</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r99'>
                <td class=x70>0501017</td>
                <td class=x76>搬运工人、装卸工人</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r100'>
                <td class=x70>0501018</td>
                <td class=x76>矿石车司机、随车工人</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r101'>
                <td class=x70>0501019</td>
                <td class=x76>工程卡车司机、随车人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r102'>
                <td class=x70>0501020</td>
                <td class=x76>液化、氧化油罐车司机、随车工人</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r103'>
                <td class=x70>0501022</td>
                <td class=x76>缆车操纵员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r104'>
                <td class=x70>0501023</td>
                <td class=x76>公路收费及监控人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r105'>
                <td class=x70>0501024</td>
                <td class=x76>加油站工作人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r106'>
                <td class=x83>0501025</td>
                <td class=x76>客运车司机及服务员（中长途、高速路段）</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r107'>
                <td class=x83>0501026</td>
                <td class=x76>汽车货运站务员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r108'>
                <td class=x83>0501027</td>
                <td class=x76>汽车运输调度员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r109'>
                <td rowspan=26 height=495 class=x184 style='border-bottom:2px solid windowtext;height:371.25pt;' >0502铁路</td>
                <td class=x74>0502001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>铁路站长</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r110'>
                <td class=x70>0502002</td>
                <td class=x71>铁路票房工作人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r111'>
                <td class=x70>0502003</td>
                <td class=x71>铁路播音员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r112'>
                <td class=x70>0502004</td>
                <td class=x71>铁路一般内勤人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r113'>
                <td class=x70>0502005</td>
                <td class=x71>铁路车站检票员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r114'>
                <td class=x70>0502006</td>
                <td class=x71>铁路服务台人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r115'>
                <td class=x70>0502007</td>
                <td class=x71>铁路月台上工作人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r116'>
                <td class=x70>0502008</td>
                <td class=x71>车站治安巡视人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r117'>
                <td class=x70>0502009</td>
                <td class=x71>铁路行李搬运工人</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r118'>
                <td class=x70>0502010</td>
                <td class=x71>铁路车站清洁工人</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r119'>
                <td class=x70>0502011</td>
                <td class=x71>铁路随车人员(技术人员除外)</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r120'>
                <td class=x70>0502012</td>
                <td class=x71>铁路机车驾驶员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r121'>
                <td class=x70>0502013</td>
                <td class=x71>铁路机车燃料填充员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r122'>
                <td class=x70>0502014</td>
                <td class=x71>铁路机工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r123'>
                <td class=x70>0502015</td>
                <td class=x71>铁路电工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r124'>
                <td class=x70>0502016</td>
                <td class=x71>铁路修护厂厂长</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r125'>
                <td class=x70>0502017</td>
                <td class=x71>铁路修护厂内勤</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r126'>
                <td class=x70>0502018</td>
                <td class=x71>铁路修护厂工程师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r127'>
                <td class=x70>0502019</td>
                <td class=x71>铁路修护厂技工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r128'>
                <td class=x70>0502020</td>
                <td class=x71>铁路修路工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r129'>
                <td class=x70>0502021</td>
                <td class=x71>铁路维护员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r130'>
                <td class=x70>0502022</td>
                <td class=x71>铁路平交道看守人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r131'>
                <td class=x70>0502023</td>
                <td class=x71>铁路货运领班</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r132'>
                <td class=x70>0502024</td>
                <td class=x71>铁路货运、搬运工人</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r133'>
                <td class=x70>0502025</td>
                <td class=x71>铁路通信工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r134'>
                <td class=x70>0502026</td>
                <td class=x71>铁路押运员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r135'>
                <td rowspan=81 height=1540 class=x186 style='border-bottom:2px solid windowtext;height:1155pt;' >0503航运</td>
                <td class=x74></td>
                <td class=x84>客货轮（沿海）</td>
                <td class=x72></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r136'>
                <td class=x70>0503001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x76>船长</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r137'>
                <td class=x70>0503002</td>
                <td class=x76>轮机长</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r138'>
                <td class=x70>0503003</td>
                <td class=x76>高级船员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r139'>
                <td class=x70>0503004</td>
                <td class=x76>大副</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r140'>
                <td class=x70>0503005</td>
                <td class=x76>二副</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r141'>
                <td class=x70>0503006</td>
                <td class=x76>三副</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r142'>
                <td class=x70>0503007</td>
                <td class=x76>大管轮</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r143'>
                <td class=x70>0503008</td>
                <td class=x76>二管轮</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r144'>
                <td class=x70>0503009</td>
                <td class=x76>三管轮</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r145'>
                <td class=x70>0503010</td>
                <td class=x76>报务员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r146'>
                <td class=x70>0503011</td>
                <td class=x76>事务长</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r147'>
                <td class=x70>0503012</td>
                <td class=x76>医务人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r148'>
                <td class=x70>0503013</td>
                <td class=x76>水手长</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r149'>
                <td class=x70>0503014</td>
                <td class=x76>水手</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r150'>
                <td class=x70>0503015</td>
                <td class=x76>铜匠</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r151'>
                <td class=x70>0503016</td>
                <td class=x76>木匠</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r152'>
                <td class=x70>0503017</td>
                <td class=x76>泵匠</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r153'>
                <td class=x70>0503018</td>
                <td class=x76>电机师</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r154'>
                <td class=x70>0503019</td>
                <td class=x76>厨师</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r155'>
                <td class=x70>0503020</td>
                <td class=x76>服务生</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r156'>
                <td class=x70>0503021</td>
                <td class=x76>实习生</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r157'>
                <td class=x70></td>
                <td class=x76><font class="font1"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></font><font class="font7">游览船及小汽艇</font></td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r158'>
                <td class=x70>0503022 </td>
                <td class=x76>游览船之驾驶及工作人员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r159'>
                <td class=x70>0503023</td>
                <td class=x76>小汽艇之驾驶及工作人员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r160'>
                <td class=x70></td>
                <td class=x76><font class="font1"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></font><font class="font7">港口作业</font></td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r161'>
                <td class=x70>0503024<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x76>码头工人及领班</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r162'>
                <td class=x70>0503025</td>
                <td class=x76>堆高机操作员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r163'>
                <td class=x70>0503026</td>
                <td class=x76>仓库管理人、理货员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r164'>
                <td class=x70>0503027</td>
                <td class=x76>领航员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r165'>
                <td class=x70>0503028</td>
                <td class=x76>引水员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r166'>
                <td class=x70>0503029</td>
                <td class=x76>关务人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r167'>
                <td class=x70>0503030</td>
                <td class=x76>稽查人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r168'>
                <td class=x70>0503031</td>
                <td class=x76>缉私人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r169'>
                <td class=x70>0503032</td>
                <td class=x85>拖船驾驶员及工作人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r170'>
                <td class=x70>0503033</td>
                <td class=x76>渡船驾驶员及工作人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r171'>
                <td class=x70>0503034</td>
                <td class=x76>救难船员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r172'>
                <td class=x70></td>
                <td class=x86>客货轮（内河）</td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r173'>
                <td class=x70>0503035 </td>
                <td class=x76>船长</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r174'>
                <td class=x83>0503036</td>
                <td class=x76>轮机长</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r175'>
                <td class=x70>0503037</td>
                <td class=x76>高级船员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r176'>
                <td class=x83>0503038</td>
                <td class=x76>大副</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r177'>
                <td class=x70>0503039</td>
                <td class=x76>二副</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r178'>
                <td class=x83>0503040</td>
                <td class=x76>三副</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r179'>
                <td class=x70>0503041</td>
                <td class=x76>大管轮</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r180'>
                <td class=x83>0503042</td>
                <td class=x76>二管轮</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r181'>
                <td class=x70>0503043</td>
                <td class=x76>三管轮</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r182'>
                <td class=x83>0503044</td>
                <td class=x76>报务员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r183'>
                <td class=x70>0503045</td>
                <td class=x76>事务长</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r184'>
                <td class=x83>0503046</td>
                <td class=x76>医务人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r185'>
                <td class=x70>0503047</td>
                <td class=x76>水手长</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r186'>
                <td class=x83>0503048</td>
                <td class=x76>水手</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r187'>
                <td class=x70>0503049</td>
                <td class=x76>铜匠</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r188'>
                <td class=x83>0503050</td>
                <td class=x76>木匠</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r189'>
                <td class=x70>0503051</td>
                <td class=x76>泵匠</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r190'>
                <td class=x83>0503052</td>
                <td class=x76>电机师</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r191'>
                <td class=x70>0503053</td>
                <td class=x76>厨师</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r192'>
                <td class=x83>0503054</td>
                <td class=x76>服务生</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r193'>
                <td class=x70>0503055</td>
                <td class=x76>实习生</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r194'>
                <td class=x87></td>
                <td class=x86>客货轮（远洋）</td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r195'>
                <td class=x83>0503056</td>
                <td class=x76>船长</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r196'>
                <td class=x83>0503057</td>
                <td class=x76>轮机长</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r197'>
                <td class=x83>0503058</td>
                <td class=x76>高级船员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r198'>
                <td class=x83>0503059</td>
                <td class=x76>大副</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r199'>
                <td class=x83>0503060</td>
                <td class=x76>二副</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r200'>
                <td class=x83>0503061</td>
                <td class=x76>三副</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r201'>
                <td class=x83>0503062</td>
                <td class=x76>大管轮</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r202'>
                <td class=x83>0503063</td>
                <td class=x76>二管轮</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r203'>
                <td class=x83>0503064</td>
                <td class=x76>三管轮</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r204'>
                <td class=x83>0503065</td>
                <td class=x76>报务员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r205'>
                <td class=x83>0503066</td>
                <td class=x76>事务长</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r206'>
                <td class=x83>0503067</td>
                <td class=x76>医务人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r207'>
                <td class=x83>0503068</td>
                <td class=x76>水手长</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r208'>
                <td class=x83>0503069</td>
                <td class=x76>水手</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r209'>
                <td class=x83>0503070</td>
                <td class=x76>铜匠</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r210'>
                <td class=x83>0503071</td>
                <td class=x76>木匠</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r211'>
                <td class=x83>0503072</td>
                <td class=x76>泵匠</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r212'>
                <td class=x83>0503073</td>
                <td class=x76>电机师</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r213'>
                <td class=x83>0503074</td>
                <td class=x76>厨师</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r214'>
                <td class=x83>0503075</td>
                <td class=x76>服务生</td>
                <td class=x78>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r215'>
                <td class=x88>0503076</td>
                <td class=x82>实习生</td>
                <td class=x73>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r216'>
                <td rowspan=33 height=628 class=x183 style='border-bottom:2px solid windowtext;height:471pt;' >0504空运</td>
                <td class=x70></td>
                <td class=x76><font class="font1"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></font><font class="font7">航空站</font></td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r217'>
                <td class=x70>0504001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x76>站长</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r218'>
                <td class=x70>0504002</td>
                <td class=x76>播音员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r219'>
                <td class=x70>0504003</td>
                <td class=x76>服务台人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r220'>
                <td class=x70>0504004</td>
                <td class=x76>一般内勤人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r221'>
                <td class=x70>0504005</td>
                <td class=x76>塔台工作人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r222'>
                <td class=x70>0504006</td>
                <td class=x76>关务人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r223'>
                <td class=x70>0504007</td>
                <td class=x76>检查人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r224'>
                <td class=x70>0504008</td>
                <td class=x76>运务人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r225'>
                <td class=x70>0504009</td>
                <td class=x76>缉私人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r226'>
                <td class=x70>0504010</td>
                <td class=x76>站内清洁工人(航空大厦内)</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r227'>
                <td class=x70>0504011</td>
                <td class=x76>机场内交通车司机</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r228'>
                <td class=x70>0504012</td>
                <td class=x76>行李货运搬运工人</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r229'>
                <td class=x70>0504013</td>
                <td class=x76>加添燃料人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r230'>
                <td class=x70>0504014</td>
                <td class=x76>飞机洗刷人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r231'>
                <td class=x70>0504015</td>
                <td class=x76>清洁工(站外、航空大厦外)</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r232'>
                <td class=x70>0504016</td>
                <td class=x76>跑道维护工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r233'>
                <td class=x70>0504017</td>
                <td class=x76>机械员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r234'>
                <td class=x70>0504018</td>
                <td class=x76>飞机修护人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r235'>
                <td class=x70></td>
                <td class=x76><font class="font1"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></font><font class="font7">航空公司</font></td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r236'>
                <td class=x70>0504019<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x76>办事处人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r237'>
                <td class=x70>0504020</td>
                <td class=x76>票务人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r238'>
                <td class=x70>0504021</td>
                <td class=x76>机场柜台工作人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r239'>
                <td class=x70>0504022</td>
                <td class=x76>清仓工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r240'>
                <td class=x70></td>
                <td class=x76><font class="font1"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></font><font class="font7">航空货运</font></td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r241'>
                <td class=x70>0504023<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x76>航空一般内勤人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r242'>
                <td class=x70>0504024</td>
                <td class=x76>外务员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r243'>
                <td class=x70>0504025</td>
                <td class=x76>报关人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r244'>
                <td class=x70>0504026</td>
                <td class=x76>理货员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r245'>
                <td class=x70></td>
                <td class=x76><font class="font1"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></font><font class="font7">空勤人员</font></td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r246'>
                <td class=x70>0504027<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x76>民航机飞行人员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r247'>
                <td class=x70>0504028</td>
                <td class=x76>机上服务员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r248'>
                <td class=x70>0504029</td>
                <td class=x76>直升机飞行人员</td>
                <td class=x73>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r249'>
                <td rowspan=16 height=307 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;height:230.25pt;' >06餐饮旅游业</td>
                <td rowspan=3 height=58 class=x184 style='height:43.5pt;' >0601旅游业</td>
                <td class=x74>0601001</td>
                <td class=x77>一般内勤人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r250'>
                <td class=x70>0601002</td>
                <td class=x71>外务员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r251'>
                <td class=x70>0601003</td>
                <td class=x71>导游、领队</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r252'>
                <td rowspan=6 height=115 class=x184 style='border-bottom:2px solid windowtext;height:86.25pt;' >0602旅馆业</td>
                <td class=x74>0602001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>负责人</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r253'>
                <td class=x70>0602002</td>
                <td class=x71>一般内勤工作人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r254'>
                <td class=x70>0602003</td>
                <td class=x71>外务员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r255'>
                <td class=x70>0602004</td>
                <td class=x71>收帐员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r256'>
                <td class=x70>0602005</td>
                <td class=x71>技工 </td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r257'>
                <td class=x70></td>
                <td class=x71>注：餐饮部工作人员比照餐饮业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x89></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r258'>
                <td rowspan=7 height=134 class=x184 style='border-bottom:2px solid windowtext;height:100.5pt;' >0603餐饮业</td>
                <td class=x74>0603001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>经理人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r259'>
                <td class=x70>0603002</td>
                <td class=x71>一般内勤服务人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r260'>
                <td class=x70>0603003</td>
                <td class=x71>柜台人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r261'>
                <td class=x70>0603004</td>
                <td class=x71>收帐员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r262'>
                <td class=x70>0603005</td>
                <td class=x71>采购人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r263'>
                <td class=x70>0603006</td>
                <td class=x71>厨师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r264'>
                <td class=x70>0603007</td>
                <td class=x71>服务人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r265'>
                <td rowspan=98 height=1870 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:1402.5pt;' >07建筑工程</td>
                <td rowspan=39 height=742 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:556.5pt;' >0701建筑公司<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>0701001</td>
                <td class=x90>建筑设计人员</td>
                <td class=x91>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r266'>
                <td class=x70>0701002</td>
                <td class=x92>制图员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r267'>
                <td class=x70>0701003</td>
                <td class=x92>测量员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r268'>
                <td class=x70>0701004</td>
                <td class=x92>工程监理</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r269'>
                <td class=x70>0701005</td>
                <td class=x92>监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r270'>
                <td class=x70>0701006</td>
                <td class=x92>建筑公司负责人、业务员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r271'>
                <td class=x70>0701007</td>
                <td class=x92>引导参观工地服务人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r272'>
                <td class=x70>0701008</td>
                <td class=x92>模板工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r273'>
                <td class=x70>0701009</td>
                <td class=x92>木工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r274'>
                <td class=x70>0701010</td>
                <td class=x92>泥水工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r275'>
                <td class=x70>0701011</td>
                <td class=x92>油漆工、喷漆工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r276'>
                <td class=x70>0701012</td>
                <td class=x92>水电工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r277'>
                <td class=x70>0701013</td>
                <td class=x92>钢骨结构工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r278'>
                <td class=x70>0701014</td>
                <td class=x92>鹰架架设工人、铁工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r279'>
                <td class=x70>0701015</td>
                <td class=x92>焊工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r280'>
                <td class=x70>0701016</td>
                <td class=x92>建筑工程车辆驾驶员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r281'>
                <td class=x70>0701017</td>
                <td class=x92>建筑工程机械操作员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r282'>
                <td class=x70>0701018</td>
                <td class=x92>承包商（土木建筑）</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r283'>
                <td class=x70>0701019</td>
                <td class=x92>磨石工人</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r284'>
                <td class=x70>0701020</td>
                <td class=x92>洗石工人</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r285'>
                <td class=x70>0701021</td>
                <td class=x92>石棉瓦或浪板安装人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r286'>
                <td class=x70>0701022</td>
                <td class=x92>金属门窗装修工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r287'>
                <td class=x70>0701023</td>
                <td class=x92>排水工程人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r288'>
                <td class=x70>0701024</td>
                <td class=x92>防水工程人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r289'>
                <td class=x70>0701025</td>
                <td class=x92>拆屋、迁屋工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r290'>
                <td class=x70>0701026</td>
                <td class=x94>凿岩工</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r291'>
                <td class=x70>0701027</td>
                <td class=x95>砌筑、砌砖工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r292'>
                <td class=x70>0701028</td>
                <td class=x94>混凝土工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r293'>
                <td class=x70>0701029</td>
                <td class=x94>混凝土制品模具工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r294'>
                <td class=x70>0701030</td>
                <td class=x94>混凝土搅拌机械操作工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r295'>
                <td class=x70>0701031</td>
                <td class=x95>装饰装修工（室内）（基础装修至毛坯）</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r296'>
                <td class=x70>0701032</td>
                <td class=x95>装饰装修工（室外）（基础装修至毛坯）</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r297'>
                <td class=x70>0701033</td>
                <td class=x94>室内成套设施装饰工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r298'>
                <td class=x70>0701034</td>
                <td class=x94>古建筑结构施工工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r299'>
                <td class=x70>0701035</td>
                <td class=x94>古建筑装饰工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r300'>
                <td class=x70>0701036</td>
                <td class=x95>房屋维修工人</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r301'>
                <td class=x70>0701038</td>
                <td class=x95>轻钢彩板安装和维修人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r302'>
                <td class=x70>0701039</td>
                <td class=x95>室内装饰装修质量检验员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r303'>
                <td class=x70>0701040</td>
                <td class=x95>室内环境治理员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r304'>
                <td rowspan=19 height=362 class=x184 style='border-bottom:2px solid windowtext;height:271.5pt;' >0702铁路公路铺设<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x74>0702001</td>
                <td class=x96>工程设计人员</td>
                <td class=x128>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r305'>
                <td class=x70>0702002</td>
                <td class=x97>现场勘测人员（山区）</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r306'>
                <td class=x70>0702003</td>
                <td class=x97>现场勘测人员（非山区）</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r307'>
                <td class=x70>0702004</td>
                <td class=x97>监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r308'>
                <td class=x70>0702005</td>
                <td class=x97>工程机械操作员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r309'>
                <td class=x70>0702006</td>
                <td class=x97>工程车辆驾驶员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r310'>
                <td class=x70>0702007</td>
                <td class=x97>铺设工人(山地)</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r311'>
                <td class=x70>0702008</td>
                <td class=x97>铺设工人(平地)</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r312'>
                <td class=x70>0702009</td>
                <td class=x97>维护工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r313'>
                <td class=x70>0702010</td>
                <td class=x97>电线架设及维护工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r314'>
                <td class=x70>0702011</td>
                <td class=x97>管道铺设及维护工人</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r315'>
                <td class=x70>0702012</td>
                <td class=x97>高速公路工程人员(含美化人员)</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r316'>
                <td class=x70>0702013</td>
                <td class=x98>筑路、养护工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r317'>
                <td class=x70>0702014</td>
                <td class=x98>铁道线路工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r318'>
                <td class=x70>0702015</td>
                <td class=x98>铁路舟桥工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r319'>
                <td class=x70>0702016</td>
                <td class=x98>道岔制修工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r320'>
                <td class=x70>0702017</td>
                <td class=x98>枕木处理工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r321'>
                <td class=x70>0702018</td>
                <td class=x98>铁路平交道看守人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r322'>
                <td class=x80>0702019</td>
                <td class=x99>铁路修护厂技工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r323'>
                <td rowspan=5 height=96 class=x184 style='border-bottom:2px solid windowtext;height:72pt;' >0703造修船业</td>
                <td class=x70>0703001</td>
                <td class=x96>设计人员</td>
                <td class=x128>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r324'>
                <td class=x70>0703002</td>
                <td class=x92>监工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r325'>
                <td class=x70>0703003</td>
                <td class=x92>工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r326'>
                <td class=x70>0703004</td>
                <td class=x92>拆船工人</td>
                <td class=x93>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r327'>
                <td class=x70></td>
                <td class=x92>注：造修游艇人员职业类别各减一级</td>
                <td class=x93></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r328'>
                <td rowspan=3 height=58 class=x184 style='border-bottom:2px solid windowtext;height:43.5pt;' >0704电梯、升降机</td>
                <td class=x74>0704001</td>
                <td class=x96>安装工人</td>
                <td class=x128>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r329'>
                <td class=x70>0704002</td>
                <td class=x92>操作员(不含矿场使用者)</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r330'>
                <td class=x70>0704003</td>
                <td class=x94>电梯、升降机修理及维护工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r331'>
                <td rowspan=8 height=153 class=x185 style='border-bottom:3px solid windowtext;height:114.75pt;' >0705装璜业</td>
                <td class=x74>0705001</td>
                <td class=x96>设计制图人员</td>
                <td class=x128>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r332'>
                <td class=x70>0705002</td>
                <td class=x92>地毯之装设人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r333'>
                <td class=x70>0705003</td>
                <td class=x92>室内装璜人员(不含木工、油漆工)</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r334'>
                <td class=x70>0705005</td>
                <td class=x92>室外装璜人员</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r335'>
                <td class=x70>0705006</td>
                <td class=x95>承包商、监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r336'>
                <td class=x70>0705007</td>
                <td class=x95>PVC材质制造、装修工人</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r337'>
                <td class=x70>0705008</td>
                <td class=x95>金属门窗制造、装修工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r338'>
                <td class=x70>0705009</td>
                <td class=x95>木工、油漆工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r339'>
                <td rowspan=18 height=344 class=x184 style='border-bottom:2px solid windowtext;height:258pt;overflow:hidden;' >0706安装及其他<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>0706001</td>
                <td class=x96>安装玻璃幕墙工人</td>
                <td class=x128>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r340'>
                <td class=x70>0706002</td>
                <td class=x95>钢结构安装工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r341'>
                <td class=x70>0706003</td>
                <td class=x95>机械设备安装工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r342'>
                <td class=x70>0706004</td>
                <td class=x95>电气设备安装工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r343'>
                <td class=x70>0706005</td>
                <td class=x95>中央空调系统安装及维护人员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r344'>
                <td class=x70>0706006</td>
                <td class=x95>管工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r345'>
                <td class=x70>0706007</td>
                <td class=x95>防火系统、警报器安装人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r346'>
                <td class=x70>0706008</td>
                <td class=x95>地质探测员（山区）</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r347'>
                <td class=x70>0706009</td>
                <td class=x95>地质探测员（海上）</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r348'>
                <td class=x70>0706010</td>
                <td class=x95>工地看守员(平地)</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r349'>
                <td class=x70>0706011</td>
                <td class=x95>海湾港口工程人员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r350'>
                <td class=x70>0706012</td>
                <td class=x95>水坝工程人员、挖井工程人员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r351'>
                <td class=x70>0706013</td>
                <td class=x95>桥梁工程人员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r352'>
                <td class=x70>0706014</td>
                <td class=x95>隧道工程人员</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r353'>
                <td class=x70>0706015</td>
                <td class=x95>潜水工作人员</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r354'>
                <td class=x70>0706016</td>
                <td class=x95>爆破工作人员</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r355'>
                <td class=x70>0706017</td>
                <td class=x95>挖泥船工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r356'>
                <td class=x70>0706018</td>
                <td class=x95>中小型施工机械操作工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r357'>
                <td rowspan=6 height=115 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:86.25pt;' >0707测绘工程<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>0707001</td>
                <td class=x96>大地、工程测量工程技术人员</td>
                <td class=x128>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r358'>
                <td class=x95>0707002</td>
                <td class=x95>摄影测量与遥感工程技术人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r359'>
                <td class=x95>0707003</td>
                <td class=x95>地图制图与印刷工程技术人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r360'>
                <td class=x95>0707004</td>
                <td class=x95>海洋测绘工程技术人员（非海上作业）</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r361'>
                <td class=x95>0707005</td>
                <td class=x95>海洋测绘工程技术人员（海上作业）</td>
                <td class=x93>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r362'>
                <td class=x95>0707006</td>
                <td class=x95>地质勘探工程技术人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r363'>
                <td rowspan=273 height=5196 class=x145 style='border-right:2px solid windowtext;height:3897pt;' >08制造加工维修业</td>
                <td rowspan=32 height=609 class=x184 style='height:456.75pt;' >0801冶金业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>0801001</td>
                <td class=x96>工程师</td>
                <td class=x128>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r364'>
                <td class=x70>0801002</td>
                <td class=x95>领班、监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r365'>
                <td class=x70>0801003</td>
                <td class=x95>高炉原料工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r366'>
                <td class=x70>0801004</td>
                <td class=x95>高炉炉前工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r367'>
                <td class=x70>0801005</td>
                <td class=x95>高炉运转工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r368'>
                <td class=x70>0801006</td>
                <td class=x95>炼钢原料工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r369'>
                <td class=x70>0801007</td>
                <td class=x95>炼钢工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r370'>
                <td class=x70>0801008</td>
                <td class=x95>炼钢浇铸工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r371'>
                <td class=x70>0801009</td>
                <td class=x95>练钢准备工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r372'>
                <td class=x70>0801010</td>
                <td class=x95>铁合金原料工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r373'>
                <td class=x70>0801011</td>
                <td class=x95>铁合金电炉冶炼工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r374'>
                <td class=x70>0801012</td>
                <td class=x95>重冶备料工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r375'>
                <td class=x70>0801013</td>
                <td class=x95>焙烧工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r376'>
                <td class=x70>0801014</td>
                <td class=x95>火法冶炼工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r377'>
                <td class=x70>0801015</td>
                <td class=x95>电解精炼工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r378'>
                <td class=x70>0801016</td>
                <td class=x95>烟气制酸工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r379'>
                <td class=x70>0801017</td>
                <td class=x95>铝电解工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r380'>
                <td class=x70>0801018</td>
                <td class=x95>多晶制取工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r381'>
                <td class=x70>0801019</td>
                <td class=x95>轧制原料工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r382'>
                <td class=x70>0801020</td>
                <td class=x95>酸洗工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r383'>
                <td class=x70>0801021</td>
                <td class=x95>金属材料涂层工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r384'>
                <td class=x70>0801022</td>
                <td class=x95>金属材热处理工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r385'>
                <td class=x70>0801023</td>
                <td class=x95>焊管工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r386'>
                <td class=x70>0801024</td>
                <td class=x95>金属挤压工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r387'>
                <td class=x70>0801025</td>
                <td class=x95>铸轧工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r388'>
                <td class=x70>0801026</td>
                <td class=x95>铸管备品工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r389'>
                <td class=x70>0801027</td>
                <td class=x95>铸管工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r390'>
                <td class=x70>0801028</td>
                <td class=x95>碳素石墨加工工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r391'>
                <td class=x70>0801029</td>
                <td class=x95>硬质合金成型工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r392'>
                <td class=x70>0801030</td>
                <td class=x95>硬质合金精加工工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r393'>
                <td class=x70>0801031</td>
                <td class=x95>冶炼风机工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r394'>
                <td class=x70>0801032</td>
                <td class=x95>有色金属冶炼工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r395'>
                <td rowspan=38 height=723 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:542.25pt;' >0802机械制造维修业<span style='mso-spacerun:yes'>&nbsp; </span><br></td>
                <td class=x74>0802001</td>
                <td class=x96>企业负责人</td>
                <td class=x128>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r396'>
                <td class=x95>0802002</td>
                <td class=x95>领班、监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r397'>
                <td class=x95>0802003</td>
                <td class=x95>技工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r398'>
                <td class=x95>0802004</td>
                <td class=x95>车床工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r399'>
                <td class=x95>0802005</td>
                <td class=x95>车床工(全自动)</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r400'>
                <td class=x95>0802006</td>
                <td class=x95>车工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r401'>
                <td class=x95>0802007</td>
                <td class=x95>铣工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r402'>
                <td class=x95>0802008</td>
                <td class=x95>磨工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r403'>
                <td class=x95>0802009</td>
                <td class=x95>镗工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r404'>
                <td class=x95>0802010</td>
                <td class=x95>钻床工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r405'>
                <td class=x95>0802011</td>
                <td class=x95>组合机床工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r406'>
                <td class=x95>0802012</td>
                <td class=x95>加工中心操作工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r407'>
                <td class=x95>0802013</td>
                <td class=x95>拉床、锯床工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r408'>
                <td class=x95>0802014</td>
                <td class=x95>弹性元件制造工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r409'>
                <td class=x95>0802015</td>
                <td class=x95>铸造、锻造工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r410'>
                <td class=x95>0802016</td>
                <td class=x95>冲压工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r411'>
                <td class=x95>0802017</td>
                <td class=x95>剪切工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r412'>
                <td class=x95>0802018</td>
                <td class=x95>焊工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r413'>
                <td class=x95>0802019</td>
                <td class=x95>金属热处理工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r414'>
                <td class=x95>0802020</td>
                <td class=x95>粉末冶金处理工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r415'>
                <td class=x95>0802021</td>
                <td class=x95>冷作钣金工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r416'>
                <td class=x95>0802022</td>
                <td class=x95>涂装工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r417'>
                <td class=x95>0802023</td>
                <td class=x95>电切削工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r418'>
                <td class=x95>0802024</td>
                <td class=x95>电镀工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r419'>
                <td class=x95>0802025</td>
                <td class=x95>磨具制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r420'>
                <td class=x95>0802026</td>
                <td class=x95>仪器仪表元件制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r421'>
                <td class=x95>0802027</td>
                <td class=x95>装配工,品管人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r422'>
                <td class=x95>0802028</td>
                <td class=x95>基础件、部件装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r423'>
                <td class=x95>0802029</td>
                <td class=x95>装配钳工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r424'>
                <td class=x95>0802030</td>
                <td class=x95>汽轮机、内燃机装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r425'>
                <td class=x95>0802031</td>
                <td class=x95>锅炉设备装配工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r426'>
                <td class=x95>0802032</td>
                <td class=x95>电机装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r427'>
                <td class=x95>0802033</td>
                <td class=x95>有关高压电之工作人员</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r428'>
                <td class=x95>0802034</td>
                <td class=x95>铁心叠装工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r429'>
                <td class=x95>0802035</td>
                <td class=x95>变压器,互感器装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r430'>
                <td class=x95>0802036</td>
                <td class=x95>高低压电器装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r431'>
                <td class=x95>0802037</td>
                <td class=x95>电焊机装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r432'>
                <td class=x95>0802038</td>
                <td class=x95>电炉装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r433'>
                <td rowspan=6 height=115 class=x184 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:86.25pt;' >0803电子器械产品业</td>
                <td class=x74>0803001</td>
                <td class=x96>工程师</td>
                <td class=x128>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r434'>
                <td class=x95>0803002</td>
                <td class=x95>领班、监工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r435'>
                <td class=x95>0803003</td>
                <td class=x95>修理工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r436'>
                <td class=x95>0803004</td>
                <td class=x95>制造工 </td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r437'>
                <td class=x95>0803005</td>
                <td class=x95>仪器仪表装调工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r438'>
                <td class=x95>0803006</td>
                <td class=x129>包装工人</td>
                <td class=x130>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r439'>
                <td rowspan=4 height=77 class=x184 style='border-bottom:2px solid windowtext;height:57.75pt;' >0804电机业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>0804001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x95>工程师</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r440'>
                <td class=x131>0804002</td>
                <td class=x95>领班、监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r441'>
                <td class=x131>0804003</td>
                <td class=x95>有关高压电之工作人员</td>
                <td class=x93>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r442'>
                <td class=x132>0804004</td>
                <td class=x129>装配修理工、冷冻修理厂工人</td>
                <td class=x130>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r443'>
                <td rowspan=17 height=324 class=x187 style='border-right:2px solid #000000;border-bottom:2px solid windowtext;height:243pt;overflow:hidden;' >0806水泥业(包括水泥、石膏、石灰、陶器)</td>
                <td class=x95>0806001</td>
                <td class=x95>工程师</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r444'>
                <td class=x95>0806002</td>
                <td class=x95>领班</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r445'>
                <td class=x95>0806003</td>
                <td class=x95>水泥生产制造工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r446'>
                <td class=x95>0806004</td>
                <td class=x95>采掘工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r447'>
                <td class=x95>0806005</td>
                <td class=x95>爆破工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r448'>
                <td class=x95>0806006</td>
                <td class=x95>石灰焙烧工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r449'>
                <td class=x95>0806007</td>
                <td class=x95>陶瓷、木炭、砖块制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r450'>
                <td class=x95>0806008</td>
                <td class=x95>砖、瓦生产工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r451'>
                <td class=x95>0806009</td>
                <td class=x95>加气混凝土制品工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r452'>
                <td class=x95>0806010</td>
                <td class=x95>保温、吸音材料制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r453'>
                <td class=x95>0806011</td>
                <td class=x95>装饰石材生产工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r454'>
                <td class=x95>0806012</td>
                <td class=x95>石棉制品工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r455'>
                <td class=x95>0806013</td>
                <td class=x95>金刚石制品工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r456'>
                <td class=x95>0806014</td>
                <td class=x95>人工合成制品工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r457'>
                <td class=x95>0806015</td>
                <td class=x95>耐火制品制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r458'>
                <td class=x95>0806016</td>
                <td class=x95>古建琉璃工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r459'>
                <td class=x132>0806017</td>
                <td class=x133>搪瓷胚体制做工</td>
                <td class=x130>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r460'>
                <td rowspan=106 height=2015 class=x187 style='height:1511.25pt;' >0807化工业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x134>0807001</td>
                <td class=x95>工程师</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r461'>
                <td class=x131>0807002</td>
                <td class=x95>技术人员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r462'>
                <td class=x131>0807003</td>
                <td class=x95>领班、监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r463'>
                <td class=x131>0807004</td>
                <td class=x95>电池制造(技师)</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r464'>
                <td class=x131>0807005</td>
                <td class=x95>电池制造(工人)</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r465'>
                <td class=x131>0807006</td>
                <td class=x95>液化气体制造工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r466'>
                <td class=x131>0807007</td>
                <td class=x95>化工原料准备工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r467'>
                <td class=x131>0807008</td>
                <td class=x95>压缩机工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r468'>
                <td class=x131>0807009</td>
                <td class=x95>气体净化工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r469'>
                <td class=x131>0807010</td>
                <td class=x95>过滤工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r470'>
                <td class=x131>0807011</td>
                <td class=x95>油加热工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r471'>
                <td class=x131>0807012</td>
                <td class=x95>制冷工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r472'>
                <td class=x131>0807013</td>
                <td class=x95>蒸发工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r473'>
                <td class=x131>0807014</td>
                <td class=x95>蒸馏工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r474'>
                <td class=x131>0807015</td>
                <td class=x95>萃取工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r475'>
                <td class=x131>0807016</td>
                <td class=x95>吸收工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r476'>
                <td class=x131>0807017</td>
                <td class=x95>吸附工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r477'>
                <td class=x131>0807018</td>
                <td class=x95>干燥工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r478'>
                <td class=x131>0807019</td>
                <td class=x95>结晶工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r479'>
                <td class=x131>0807020</td>
                <td class=x95>造粒工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r480'>
                <td class=x131>0807021</td>
                <td class=x95>防腐蚀工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r481'>
                <td class=x131>0807022</td>
                <td class=x95>化工工艺试验工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r482'>
                <td class=x131>0807023</td>
                <td class=x95>化工总控工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r483'>
                <td class=x131>0807024</td>
                <td class=x95>燃料油生产工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r484'>
                <td class=x131>0807025</td>
                <td class=x95>润滑油,脂生产工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r485'>
                <td class=x131>0807026</td>
                <td class=x95>石油产品精制工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r486'>
                <td class=x131>0807027</td>
                <td class=x95>油制气工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r487'>
                <td class=x131>0807028</td>
                <td class=x95>备煤筛焦工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r488'>
                <td class=x131>0807029</td>
                <td class=x95>焦炉调温工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r489'>
                <td class=x131>0807030</td>
                <td class=x95>炼焦工,焦炉机车司机</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r490'>
                <td class=x131>0807031</td>
                <td class=x95>煤制气工</td>
                <td class=x93>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r491'>
                <td class=x131>0807032</td>
                <td class=x95>煤气储运工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r492'>
                <td class=x131>0807033</td>
                <td class=x95>合成氨生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r493'>
                <td class=x131>0807034</td>
                <td class=x95>尿素生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r494'>
                <td class=x131>0807035</td>
                <td class=x95>硝酸铵生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r495'>
                <td class=x131>0807036</td>
                <td class=x95>碳酸氢铵生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r496'>
                <td class=x131>0807037</td>
                <td class=x95>硫酸铵生产工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r497'>
                <td class=x131>0807038</td>
                <td class=x95>过磷酸铵生产工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r498'>
                <td class=x131>0807039</td>
                <td class=x95>复合磷肥生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r499'>
                <td class=x131>0807040</td>
                <td class=x95>钙镁磷肥生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r500'>
                <td class=x131>0807041</td>
                <td class=x95>氯化钾生产工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r501'>
                <td class=x131>0807042</td>
                <td class=x95>微量元素混肥生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r502'>
                <td class=x131>0807043</td>
                <td class=x95>硫酸生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r503'>
                <td class=x131>0807044</td>
                <td class=x95>硝酸生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r504'>
                <td class=x131>0807045</td>
                <td class=x95>盐酸生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r505'>
                <td class=x131>0807046</td>
                <td class=x95>磷酸生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r506'>
                <td class=x131>0807047</td>
                <td class=x95>纯碱生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r507'>
                <td class=x131>0807048</td>
                <td class=x95>烧碱生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r508'>
                <td class=x131>0807049</td>
                <td class=x95>氟化盐生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r509'>
                <td class=x131>0807050</td>
                <td class=x95>缩聚磷酸盐生产工</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r510'>
                <td class=x131>0807051</td>
                <td class=x95>无机化学生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r511'>
                <td class=x131>0807052</td>
                <td class=x95>高频等离子工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r512'>
                <td class=x131>0807053</td>
                <td class=x95>气体深冷分离工,制氧工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r513'>
                <td class=x131>0807054</td>
                <td class=x95>工业气体液化工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r514'>
                <td class=x131>0807055</td>
                <td class=x95>炭黑制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r515'>
                <td class=x131>0807056</td>
                <td class=x95>二氧化硫制造工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r516'>
                <td class=x131>0807057</td>
                <td class=x95>脂肪烃生产工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r517'>
                <td class=x131>0807058</td>
                <td class=x95>环烃生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r518'>
                <td class=x131>0807059</td>
                <td class=x95>烃类衍生物生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r519'>
                <td class=x131>0807060</td>
                <td class=x95>聚乙烯生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r520'>
                <td class=x131>0807061</td>
                <td class=x95>聚丙烯生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r521'>
                <td class=x131>0807062</td>
                <td class=x95>聚苯乙烯生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r522'>
                <td class=x131>0807063</td>
                <td class=x95>聚丁二烯生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r523'>
                <td class=x131>0807064</td>
                <td class=x95>聚氯乙烯生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r524'>
                <td class=x131>0807065</td>
                <td class=x95>酚醛树脂生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r525'>
                <td class=x131>0807066</td>
                <td class=x95>环氧树脂生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r526'>
                <td class=x131>0807067</td>
                <td class=x95>丙烯睛-丁二烯-苯乙烯共聚物生产工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r527'>
                <td class=x131>0807068</td>
                <td class=x95>橡胶生产工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r528'>
                <td class=x131>0807069</td>
                <td class=x95>橡胶半成品制造者</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r529'>
                <td class=x131>0807070</td>
                <td class=x95>橡胶成型工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r530'>
                <td class=x131>0807071</td>
                <td class=x95>橡胶硫化工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r531'>
                <td class=x131>0807072</td>
                <td class=x95>废胶再生工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r532'>
                <td class=x131>0807073</td>
                <td class=x95>塑料制品配料工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r533'>
                <td class=x131>0807074</td>
                <td class=x95>塑料制品成型工（自动）</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r534'>
                <td class=x131>0807075</td>
                <td class=x95>塑料制品成型人员（其他）</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r535'>
                <td class=x131>0807076</td>
                <td class=x95>化纤聚合工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r536'>
                <td class=x131>0807077</td>
                <td class=x95>湿纺远液制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r537'>
                <td class=x131>0807078</td>
                <td class=x95>纺丝工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r538'>
                <td class=x131>0807079</td>
                <td class=x95>化纤后处理工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r539'>
                <td class=x131>0807080</td>
                <td class=x95>纺丝凝固浴液配制工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r540'>
                <td class=x131>0807081</td>
                <td class=x95>无纺布制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r541'>
                <td class=x131>0807082</td>
                <td class=x95>化纤纺丝精密组件工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r542'>
                <td class=x131>0807083</td>
                <td class=x95>合成革制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r543'>
                <td class=x131>0807084</td>
                <td class=x95>有机合成工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r544'>
                <td class=x131>0807085</td>
                <td class=x95>农药生物测试试验工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r545'>
                <td class=x131>0807086</td>
                <td class=x95>染料标准工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r546'>
                <td class=x131>0807087</td>
                <td class=x95>染料应用试验工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r547'>
                <td class=x131>0807088</td>
                <td class=x95>染料拼混工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r548'>
                <td class=x131>0807089</td>
                <td class=x95>研磨分散工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r549'>
                <td class=x131>0807090</td>
                <td class=x95>催化剂制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r550'>
                <td class=x131>0807091</td>
                <td class=x95>催化剂试验工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r551'>
                <td class=x131>0807092</td>
                <td class=x95>涂料合成树脂工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r552'>
                <td class=x131>0807093</td>
                <td class=x95>制漆配色调制工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r553'>
                <td class=x131>0807094</td>
                <td class=x95>溶剂制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r554'>
                <td class=x131>0807095</td>
                <td class=x95>化学试剂制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r555'>
                <td class=x131>0807096</td>
                <td class=x95>化工添加剂制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r556'>
                <td class=x131>0807097</td>
                <td class=x95>片基制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r557'>
                <td class=x131>0807098</td>
                <td class=x95>感光材料制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r558'>
                <td class=x131>0807099</td>
                <td class=x95>感光材料试验工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r559'>
                <td class=x131>0807100</td>
                <td class=x95>暗盒制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r560'>
                <td class=x131>0807101</td>
                <td class=x95>废片,白银回收工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r561'>
                <td class=x131>0807102</td>
                <td class=x95>磁粉制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r562'>
                <td class=x131>0807103</td>
                <td class=x95>磁记录材料制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r563'>
                <td class=x131>0807104</td>
                <td class=x95>磁记录材料试验工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r564'>
                <td class=x131>0807105</td>
                <td class=x95>感光鼓涂敷工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r565'>
                <td class=x132>0807106</td>
                <td class=x133>其他有毒物品生产工</td>
                <td class=x130>拒保 </td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r566'>
                <td rowspan=2 height=39 class=x188 style='border-bottom:2px solid windowtext;height:29.25pt;' >0808火药、炸药、烟花业</td>
                <td class=x131>0808001</td>
                <td class=x95>火药炸药业人员</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r567'>
                <td class=x132>0808002</td>
                <td class=x133>烟花爆竹业人员</td>
                <td class=x130>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r568'>
                <td rowspan=9 height=172 class=x188 style='border-bottom:2px solid windowtext;height:129pt;overflow:hidden;' >0809机动车、自行车制造业与修理业</td>
                <td class=x131>0809001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x95>工程师</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r569'>
                <td class=x131>0809002</td>
                <td class=x95>修理保养工人(汽车、摩托车)</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r570'>
                <td class=x131>0809003</td>
                <td class=x95>领班、监工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r571'>
                <td class=x131>0809004</td>
                <td class=x95>试车人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r572'>
                <td class=x131>0809005</td>
                <td class=x95>汽车(拖拉机)装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r573'>
                <td class=x131>0809006</td>
                <td class=x95>铁路车辆制造装修工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r574'>
                <td class=x131>0809007</td>
                <td class=x95>电机车装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r575'>
                <td class=x131>0809008</td>
                <td class=x95>摩托车装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r576'>
                <td class=x132>0809009</td>
                <td class=x133>助动车、自行车装配修理工</td>
                <td class=x130>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r577'>
                <td rowspan=59 height=1122 class=x187 style='border-bottom:2px solid windowtext;height:841.5pt;' >0810纺织印染及成衣业</td>
                <td class=x131>0810001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x95>工程师</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r578'>
                <td class=x131>0810002</td>
                <td class=x95>设计师</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r579'>
                <td class=x131>0810003</td>
                <td class=x95>纤维验配工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r580'>
                <td class=x131>0810004</td>
                <td class=x95>开清棉工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r581'>
                <td class=x131>0810005</td>
                <td class=x95>纤维染色工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r582'>
                <td class=x131>0810006</td>
                <td class=x95>加湿软麻工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r583'>
                <td class=x131>0810007</td>
                <td class=x95>选剥煮茧工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r584'>
                <td class=x131>0810008</td>
                <td class=x95>纤维梳理工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r585'>
                <td class=x131>0810009</td>
                <td class=x95>并条工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r586'>
                <td class=x131>0810010</td>
                <td class=x95>粗纱工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r587'>
                <td class=x131>0810011</td>
                <td class=x95>绢纺精炼工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r588'>
                <td class=x131>0810012</td>
                <td class=x95>细纱工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r589'>
                <td class=x131>0810013</td>
                <td class=x95>简并摇工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r590'>
                <td class=x131>0810014</td>
                <td class=x95>捻线工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r591'>
                <td class=x131>0810015</td>
                <td class=x95>制线工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r592'>
                <td class=x131>0810016</td>
                <td class=x95>缫丝工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r593'>
                <td class=x131>0810017</td>
                <td class=x95>整经工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r594'>
                <td class=x131>0810018</td>
                <td class=x95>浆纱工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r595'>
                <td class=x131>0810019</td>
                <td class=x95>穿经工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r596'>
                <td class=x131>0810020</td>
                <td class=x95>织布工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r597'>
                <td class=x131>0810021</td>
                <td class=x95>织物验修工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r598'>
                <td class=x131>0810022</td>
                <td class=x95>意匠纹版工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r599'>
                <td class=x131>0810023</td>
                <td class=x95>织造工人</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r600'>
                <td class=x131>0810024</td>
                <td class=x95>纬编工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r601'>
                <td class=x131>0810025</td>
                <td class=x95>经编工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r602'>
                <td class=x131>0810026</td>
                <td class=x95>横机工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r603'>
                <td class=x131>0810027</td>
                <td class=x95>织袜工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r604'>
                <td class=x131>0810028</td>
                <td class=x95>铸、钳针工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r605'>
                <td class=x131>0810029</td>
                <td class=x95>坯布检查修理工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r606'>
                <td class=x131>0810030</td>
                <td class=x95>印染烧毛工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r607'>
                <td class=x131>0810031</td>
                <td class=x95>煮炼漂工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r608'>
                <td class=x131>0810032</td>
                <td class=x95>印染洗涤工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r609'>
                <td class=x131>0810033</td>
                <td class=x95>印染烘干工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r610'>
                <td class=x131>0810034</td>
                <td class=x95>印染丝光工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r611'>
                <td class=x131>0810035</td>
                <td class=x95>印染定型工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r612'>
                <td class=x131>0810036</td>
                <td class=x95>纺织针织染色工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r613'>
                <td class=x131>0810037</td>
                <td class=x95>印花工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r614'>
                <td class=x131>0810038</td>
                <td class=x95>印染雕刻制版工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r615'>
                <td class=x131>0810039</td>
                <td class=x95>印染后处理工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r616'>
                <td class=x131>0810040</td>
                <td class=x95>印染成品定等装潢工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r617'>
                <td class=x131>0810041</td>
                <td class=x95>印染染化料配制工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r618'>
                <td class=x131>0810042</td>
                <td class=x95>工艺染织制作工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r619'>
                <td class=x131>0810043</td>
                <td class=x95>染整工人</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r620'>
                <td class=x131>0810044</td>
                <td class=x95>裁剪工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r621'>
                <td class=x131>0810045</td>
                <td class=x95>缝纫工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r622'>
                <td class=x131>0810046</td>
                <td class=x95>缝纫品整型工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r623'>
                <td class=x131>0810047</td>
                <td class=x95>裁缝</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r624'>
                <td class=x131>0810048</td>
                <td class=x95>剧装工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r625'>
                <td class=x131>0810049</td>
                <td class=x95>制鞋工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r626'>
                <td class=x131>0810050</td>
                <td class=x95>制帽工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r627'>
                <td class=x131>0810051</td>
                <td class=x95>皮革加工工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r628'>
                <td class=x131>0810052</td>
                <td class=x95>毛皮加工工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r629'>
                <td class=x131>0810053</td>
                <td class=x95>缝纫制品充填处理工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r630'>
                <td class=x131>0810054</td>
                <td class=x95>胶制服装上胶工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r631'>
                <td class=x131>0810055</td>
                <td class=x95>服装水洗工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r632'>
                <td class=x131>0810056</td>
                <td class=x95>纺织纤维检验工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r633'>
                <td class=x131>0810057</td>
                <td class=x95>针纺织品检验工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r634'>
                <td class=x131>0810058</td>
                <td class=x95>印染工艺检验工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r635'>
                <td class=x132>0810059</td>
                <td class=x133>服装鞋帽检验工</td>
                <td class=x130>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r636'>
                <td rowspan=144 height=2755 class=x175 style='border-top: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:2066.25pt;' >08制造加工维修业</td>
                <td rowspan=9 height=172 class=x187 style='border-bottom:2px solid windowtext;height:129pt;' >0811造纸工业</td>
                <td class=x131>0811001</td>
                <td class=x95>领班、监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r637'>
                <td class=x131>0811002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x95>制浆备料工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r638'>
                <td class=x131>0811003</td>
                <td class=x95>制浆设备操作工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r639'>
                <td class=x131>0811004</td>
                <td class=x95>制浆废液回收利用工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r640'>
                <td class=x131>0811005</td>
                <td class=x95>造纸工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r641'>
                <td class=x131>0811006</td>
                <td class=x95>纸张整饰工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r642'>
                <td class=x131>0811007</td>
                <td class=x95>宣纸书画纸制作工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r643'>
                <td class=x131>0811008</td>
                <td class=x95>纸箱制作工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r644'>
                <td class=x132>0811009</td>
                <td class=x133>纸盒制作工</td>
                <td class=x130>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r645'>
                <td rowspan=7 height=134 class=x187 style='border-bottom:2px solid windowtext;height:100.5pt;' >0812家具制造业</td>
                <td class=x131>0812001<span style='mso-spacerun:yes'>&nbsp; </span></td>
                <td class=x95>技术人员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r646'>
                <td class=x131>0812002</td>
                <td class=x95>领班、监工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r647'>
                <td class=x131>0812003</td>
                <td class=x95>木制家具制造工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r648'>
                <td class=x131>0812004</td>
                <td class=x95>木制家具修理工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r649'>
                <td class=x131>0812005</td>
                <td class=x95>金属家具制造工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r650'>
                <td class=x131>0812006</td>
                <td class=x95>金属家具修理工人</td>
                <td class=x93>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r651'>
                <td class=x132>0812007</td>
                <td class=x133 style='overflow:hidden;' >木材及家具检验工（不含加工、维修、制作<span style='display:none'>操作）</span></td>
                <td class=x130>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r652'>
                <td rowspan=34 height=647 class=x189 style='border-bottom:3px solid windowtext;height:485.25pt;' >0813工艺品生产加工业</td>
                <td class=x131>0813001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x95>手工工艺品加工工人</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r653'>
                <td class=x131>0813007</td>
                <td class=x95>地毯制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r654'>
                <td class=x131>0813008</td>
                <td class=x95>金属、塑料、木制玩具装配工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r655'>
                <td class=x131>0813009</td>
                <td class=x95>布绒玩具制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r656'>
                <td class=x131>0813010</td>
                <td class=x95>搪塑玩具制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r657'>
                <td class=x131>0813011</td>
                <td class=x95>漆器制胎工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r658'>
                <td class=x131>0813012</td>
                <td class=x95>彩绘雕填制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r659'>
                <td class=x131>0813013</td>
                <td class=x95>漆器镶嵌工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r660'>
                <td class=x131>0813014</td>
                <td class=x95>机绣工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r661'>
                <td class=x131>0813015</td>
                <td class=x95>手绣制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r662'>
                <td class=x131>0813016</td>
                <td class=x95>抽纱调编工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r663'>
                <td class=x131>0813017</td>
                <td class=x95>景泰蓝制作工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r664'>
                <td class=x131>0813018</td>
                <td class=x95>金属摆件工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r665'>
                <td class=x131>0813019</td>
                <td class=x95>装饰美工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r666'>
                <td class=x131>0813020</td>
                <td class=x95>雕塑翻制工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r667'>
                <td class=x131>0813021</td>
                <td class=x95>壁画制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r668'>
                <td class=x131>0813022</td>
                <td class=x95>油画外框制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r669'>
                <td class=x131>0813023</td>
                <td class=x95>装裱工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r670'>
                <td class=x131>0813024</td>
                <td class=x95>版画制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r671'>
                <td class=x131>0813025</td>
                <td class=x95>民间工艺品制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r672'>
                <td class=x131>0813026</td>
                <td class=x95>人造花制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r673'>
                <td class=x131>0813027</td>
                <td class=x95>工艺画制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r674'>
                <td class=x131></td>
                <td class=x95>文化体育用品制造</td>
                <td class=x93></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r675'>
                <td class=x131>0813028</td>
                <td class=x95>墨制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r676'>
                <td class=x131>0813029</td>
                <td class=x95>墨水制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r677'>
                <td class=x131>0813030</td>
                <td class=x95>墨汁制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r678'>
                <td class=x131>0813031</td>
                <td class=x95>绘图仪器制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r679'>
                <td class=x131>0813032</td>
                <td class=x95>静电复印机消耗材制造工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r680'>
                <td class=x131>0813033</td>
                <td class=x95>笔类制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r681'>
                <td class=x131>0813034</td>
                <td class=x95>印泥制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r682'>
                <td class=x131>0813035</td>
                <td class=x95>制球工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r683'>
                <td class=x131>0813036</td>
                <td class=x95>球拍、球网制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r684'>
                <td class=x131>0813037</td>
                <td class=x95>健身器材制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r685'>
                <td class=x132>0813038</td>
                <td class=x133>乐器制作工</td>
                <td class=x130>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r686'>
                <td rowspan=2 height=40 class=x187 style='border-bottom:2px solid windowtext;height:30pt;' >0814电线电缆光缆制造业</td>
                <td class=x131>0814001</td>
                <td class=x95>技术人员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r687'>
                <td class=x132>0814002</td>
                <td class=x133>工人</td>
                <td class=x130>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r688'>
                <td rowspan=45 height=856 class=x187 style='border-bottom:2px solid windowtext;height:642pt;overflow:hidden;' >0815食品饮料烟草加工业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x131>0815001</td>
                <td class=x95>领班、监工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r689'>
                <td class=x131>0815002</td>
                <td class=x95>制米工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r690'>
                <td class=x131>0815003</td>
                <td class=x95>制粉工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r691'>
                <td class=x131>0815004</td>
                <td class=x95>制油工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r692'>
                <td class=x131>0815005</td>
                <td class=x95>食糖制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r693'>
                <td class=x131>0815006</td>
                <td class=x95>糖果、巧克力制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r694'>
                <td class=x131>0815007</td>
                <td class=x95>乳品预处理工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r695'>
                <td class=x131>0815008</td>
                <td class=x95>乳品加工工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r696'>
                <td class=x131>0815009</td>
                <td class=x95>速冻食品制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r697'>
                <td class=x131>0815010</td>
                <td class=x95>食品罐头加工工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r698'>
                <td class=x131>0815011</td>
                <td class=x95>饮料制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r699'>
                <td class=x131>0815012</td>
                <td class=x95>酒类酿造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r700'>
                <td class=x131>0815013</td>
                <td class=x95>酶制剂制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r701'>
                <td class=x131>0815014</td>
                <td class=x95>酱油酱醋类制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r702'>
                <td class=x131>0815015</td>
                <td class=x95>酱腌菜制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r703'>
                <td class=x131>0815016</td>
                <td class=x95>食用调料制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r704'>
                <td class=x131>0815017</td>
                <td class=x95>味精制作工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r705'>
                <td class=x131>0815018</td>
                <td class=x95>糕点、面包烘焙工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r706'>
                <td class=x131>0815019</td>
                <td class=x95>糕点装饰工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r707'>
                <td class=x70>0815020</td>
                <td class=x101>米面主食制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r708'>
                <td class=x70>0815021</td>
                <td class=x101>油脂制品工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r709'>
                <td class=x70>0815022</td>
                <td class=x101>植物蛋白制作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r710'>
                <td class=x70>0815023</td>
                <td class=x101>豆制品制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r711'>
                <td class=x70>0815024</td>
                <td class=x101>猪屠宰加工工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r712'>
                <td class=x70>0815025</td>
                <td class=x101>牛羊屠宰加工工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r713'>
                <td class=x70>0815026</td>
                <td class=x101>肠衣工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r714'>
                <td class=x70>0815027</td>
                <td class=x101>禽类屠宰加工工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r715'>
                <td class=x70>0815028</td>
                <td class=x101>熟肉制品加工工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r716'>
                <td class=x70>0815029</td>
                <td class=x101>蛋品及再制蛋品加工工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r717'>
                <td class=x70>0815030</td>
                <td class=x101>饲料原料清理上料工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r718'>
                <td class=x70>0815031</td>
                <td class=x101>饲料粉碎工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r719'>
                <td class=x70>0815032</td>
                <td class=x101>饲料配料混合工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r720'>
                <td class=x70>0815033</td>
                <td class=x101>饲料添加剂预混工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r721'>
                <td class=x70>0815034</td>
                <td class=x101>冰块制造工人</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r722'>
                <td class=x70>0815035</td>
                <td class=x101>装罐工人</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r723'>
                <td class=x70>0815036</td>
                <td class=x101>烟叶调制工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r724'>
                <td class=x70>0815037</td>
                <td class=x101>烟叶制丝工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r725'>
                <td class=x70>0815038</td>
                <td class=x101>烟叶分级工</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r726'>
                <td class=x70>0815039</td>
                <td class=x101>挂杆复烤工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r727'>
                <td class=x70>0815040</td>
                <td class=x101>打烟复烤工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r728'>
                <td class=x70>0815041</td>
                <td class=x101>烟叶回潮工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r729'>
                <td class=x70>0815042</td>
                <td class=x101>烟叶发酵工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r730'>
                <td class=x70>0815043</td>
                <td class=x101>烟用二醋片制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r731'>
                <td class=x70>0815044</td>
                <td class=x101>烟用丝束制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r732'>
                <td class=x70>0815045</td>
                <td class=x101>滤棒工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r733'>
                <td rowspan=37 height=715 class=x184 style='height:536.25pt;' >0816家电制造维修业</td>
                <td class=x74>0816001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x107>工程师</td>
                <td class=x135>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r734'>
                <td class=x70>0816002</td>
                <td class=x76>空调机装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r735'>
                <td class=x70>0816003</td>
                <td class=x76>电冰箱、电冰柜制造装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r736'>
                <td class=x70>0816004</td>
                <td class=x76>洗衣机制造装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r737'>
                <td class=x70>0816005</td>
                <td class=x76>小型家用电器装配工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r738'>
                <td class=x70>0816006</td>
                <td class=x104>缝纫机制造装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r739'>
                <td class=x70>0816007</td>
                <td class=x104>家用空调、太阳能热水器安装与维修</td>
                <td class=x93>5</td>
            </tr>
            <tr height=30 style='mso-height-source:userset;height:22.5pt' id='r740'>
                <td class=x70>0816008</td>
                <td class=x104 style='overflow:hidden;' >其他家用电器安装与维修（除空调、太阳能热水器外）</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r741'>
                <td class=x70>0816009</td>
                <td class=x101>电极丝制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r742'>
                <td class=x70>0816010</td>
                <td class=x101>真空电子器件金属零件制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r743'>
                <td class=x70>0816011</td>
                <td class=x101>液晶显示器件制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r744'>
                <td class=x70>0816012</td>
                <td class=x101>半导体芯片制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r745'>
                <td class=x70>0816013</td>
                <td class=x101>电阻器制造者</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r746'>
                <td class=x70>0816014</td>
                <td class=x101>电容器制造者</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r747'>
                <td class=x70>0816015</td>
                <td class=x101>微波铁氧体元器件制造工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r748'>
                <td class=x70>0816016</td>
                <td class=x101>石英晶体元器件加工制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r749'>
                <td class=x70>0816017</td>
                <td class=x101>电声器件制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r750'>
                <td class=x70>0816018</td>
                <td class=x101>专用继电器制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r751'>
                <td class=x70>0816019</td>
                <td class=x101>高频电感器件制造者</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r752'>
                <td class=x70>0816020</td>
                <td class=x101>磁头制造者</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r753'>
                <td class=x70>0816021</td>
                <td class=x101>印制电路制作工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r754'>
                <td class=x70>0816022</td>
                <td class=x101>薄膜加热制造工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r755'>
                <td class=x70>0816023</td>
                <td class=x102>真空电子器件装配工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r756'>
                <td class=x70>0816024</td>
                <td class=x101>真空电子器件装调工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r757'>
                <td class=x70>0816025</td>
                <td class=x101>电子设备装接工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r758'>
                <td class=x70>0816026</td>
                <td class=x101>电子真空镀膜工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r759'>
                <td class=x70>0816027</td>
                <td class=x101>石英晶体生长设备操作工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r760'>
                <td class=x70>0816028</td>
                <td class=x108>焊接工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r761'>
                <td class=x70>0816029</td>
                <td class=x101>电子产品制版工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r762'>
                <td class=x70>0816030</td>
                <td class=x101>半导体分立器件、集成电路装调工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r763'>
                <td class=x70>0816031</td>
                <td class=x108>包装工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r764'>
                <td class=x70>0816032</td>
                <td class=x108>冲床工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r765'>
                <td class=x70>0816033</td>
                <td class=x108>剪床工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r766'>
                <td class=x70>0816034</td>
                <td class=x108>铣床工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r767'>
                <td class=x70>0816035</td>
                <td class=x108>铸造工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r768'>
                <td class=x70>0816036</td>
                <td class=x108>车床工(全自动)</td>
                <td class=x93>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r769'>
                <td class=x80>0816037</td>
                <td class=x109>车床工(其他)</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r770'>
                <td rowspan=10 height=191 class=x184 style='border-bottom:2px solid windowtext;height:143.25pt;' >0818玻璃制造业</td>
                <td class=x70>0818001</td>
                <td class=x108>监工</td>
                <td class=x135>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r771'>
                <td class=x70>0818002</td>
                <td class=x101>玻璃配料工</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r772'>
                <td class=x70>0818003</td>
                <td class=x101>玻璃溶化工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r773'>
                <td class=x70>0818004</td>
                <td class=x101>玻璃制板及玻璃成型工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r774'>
                <td class=x70>0818005</td>
                <td class=x101>玻璃加工工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r775'>
                <td class=x70>0818006</td>
                <td class=x101>玻璃制品装饰加工工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r776'>
                <td class=x70>0818007</td>
                <td class=x101>玻璃纤维制品工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r777'>
                <td class=x70>0818008</td>
                <td class=x101>玻璃钢制品工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r778'>
                <td class=x70>0818009</td>
                <td class=x101>石英玻璃制品加工工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r779'>
                <td class=x70>0818010</td>
                <td class=x102>玻璃搬运工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r780'>
                <td rowspan=21 height=401 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:300.75pt;' >09出版广告业</td>
                <td rowspan=14 height=267 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:200.25pt;' >0901出版印刷业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>0901001</td>
                <td class=x90>内勤人员</td>
                <td class=x135>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r781'>
                <td class=x70>0901002</td>
                <td class=x92>外勤记者</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r782'>
                <td class=x70>0901003</td>
                <td class=x94>文字记者</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r783'>
                <td class=x70>0901004</td>
                <td class=x92>摄影记者</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r784'>
                <td class=x70>0901005</td>
                <td class=x92>战地记者</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r785'>
                <td class=x70>0901006</td>
                <td class=x95>编辑</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r786'>
                <td class=x70>0901007</td>
                <td class=x94>校对员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r787'>
                <td class=x70>0901008</td>
                <td class=x94>翻译</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r788'>
                <td class=x70>0901009</td>
                <td class=x92>推销员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r789'>
                <td class=x70>0901010</td>
                <td class=x92>排版工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r790'>
                <td class=x70>0901011</td>
                <td class=x92>装订工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r791'>
                <td class=x70>0901012</td>
                <td class=x92>印刷工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r792'>
                <td class=x70>0901013</td>
                <td class=x92>送货员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r793'>
                <td class=x80>0901014</td>
                <td class=x110>送报员</td>
                <td class=x130>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r794'>
                <td rowspan=7 height=134 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:100.5pt;' >0902广告业</td>
                <td class=x70>0902001</td>
                <td class=x94>撰稿员、一般内勤</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r795'>
                <td class=x70>0902002</td>
                <td class=x94>广告设计人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r796'>
                <td class=x70>0902003</td>
                <td class=x94>广告业务员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r797'>
                <td class=x70>0902004</td>
                <td class=x95>广告招牌绘制人员（地面）</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r798'>
                <td class=x70>0902005</td>
                <td class=x94>广告片拍摄录制人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r799'>
                <td class=x70>0902006</td>
                <td class=x94>广告招牌架设人员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r800'>
                <td class=x70>0902007</td>
                <td class=x94>霓虹光管安装及维修人员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r801'>
                <td rowspan=28 height=534 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:400.5pt;' >10医药卫生保健</td>
                <td rowspan=19 height=362 class=x184 style='border-bottom:2px solid windowtext;height:271.5pt;' >1001医疗卫生<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>1001001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x90>医务行政人员</td>
                <td class=x135>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r802'>
                <td class=x70>1001002</td>
                <td class=x92>一般医师</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r803'>
                <td class=x70>1001003</td>
                <td class=x101>精神科医师、看护、护士</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r804'>
                <td class=x70>1001004</td>
                <td class=x101>急诊科医师</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r805'>
                <td class=x70>1001005</td>
                <td class=x101>乡村医师</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r806'>
                <td class=x70>1001006</td>
                <td class=x101>一般护士</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r807'>
                <td class=x70>1001007</td>
                <td class=x101>急诊护士</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r808'>
                <td class=x70>1001008</td>
                <td class=x101>手术室护士</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r809'>
                <td class=x70>1001009</td>
                <td class=x101>监狱、看守所医生护理人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r810'>
                <td class=x70>1001010</td>
                <td class=x101>护理员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r811'>
                <td class=x70>1001011</td>
                <td class=x102>药剂检验人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r812'>
                <td class=x70>1001012</td>
                <td class=x92>放射线之技术人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r813'>
                <td class=x70>1001013</td>
                <td class=x92>放射线之修理人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r814'>
                <td class=x70>1001014</td>
                <td class=x101>配膳员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r815'>
                <td class=x70>1001015</td>
                <td class=x101>卫生检查员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r816'>
                <td class=x70>1001016</td>
                <td class=x101>医用气体工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r817'>
                <td class=x70>1001017</td>
                <td class=x101>卫生防疫、妇幼保健员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r818'>
                <td class=x70>1001018</td>
                <td class=x101>医院炊事</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r819'>
                <td class=x70>1001019</td>
                <td class=x102>医院勤杂工、清洁工</td>
                <td class=x130>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r820'>
                <td rowspan=9 height=172 class=x184 style='border-bottom:2px solid windowtext;height:129pt;' >1002制药制剂业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>1002001</td>
                <td class=x111>化学合成制药工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r821'>
                <td class=x70>1002002</td>
                <td class=x101>生化药品制造工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r822'>
                <td class=x70>1002003</td>
                <td class=x101>发酵工程制药工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r823'>
                <td class=x70>1002004</td>
                <td class=x101>疫苗制品工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r824'>
                <td class=x70>1002005</td>
                <td class=x101>血液制品工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r825'>
                <td class=x70>1002006</td>
                <td class=x101>基因工程产品工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r826'>
                <td class=x70>1002007</td>
                <td class=x101>药物制剂工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r827'>
                <td class=x70>1002008</td>
                <td class=x101>淀粉、葡萄糖制造工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r828'>
                <td class=x70>1002009</td>
                <td class=x102>医药代表</td>
                <td class=x130>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r829'>
                <td rowspan=93 height=1793 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:1344.75pt;' >11娱乐业</td>
                <td rowspan=32 height=625 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:468.75pt;' >1101广播电影电视业</td>
                <td class=x74>1101001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x75>制片人</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r830'>
                <td class=x70>1101002</td>
                <td class=x76>影片商</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r831'>
                <td class=x70>1101003</td>
                <td class=x76>编剧</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r832'>
                <td class=x70>1101004</td>
                <td class=x76>一般演员、导演</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r833'>
                <td class=x70>1101005</td>
                <td class=x76>武打演员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r834'>
                <td class=x70>1101006</td>
                <td class=x76>特技演员</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r835'>
                <td class=x70>1101007</td>
                <td class=x76>武术指导</td>
                <td class=x93>3</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r836'>
                <td class=x70>1101008</td>
                <td class=x76>配音演员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r837'>
                <td class=x70>1101009</td>
                <td class=x76>播音员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r838'>
                <td class=x70>1101010</td>
                <td class=x76>节目主持人</td>
                <td class=x93>1</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r839'>
                <td class=x70>1101011</td>
                <td class=x76>道具师</td>
                <td class=x93>2</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r840'>
                <td class=x70>1101012</td>
                <td class=x76>剪辑师</td>
                <td class=x93>1</td>
            </tr>
            <tr height=21 style='mso-height-source:userset;height:15.75pt' id='r841'>
                <td class=x70>1101013</td>
                <td class=x76>美工师</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r842'>
                <td class=x70>1101014</td>
                <td class=x76>化妆师</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r843'>
                <td class=x70>1101015</td>
                <td class=x76>场记</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r844'>
                <td class=x70>1101016</td>
                <td class=x76>跑片员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r845'>
                <td class=x70>1101017</td>
                <td class=x76>摄影工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r846'>
                <td class=x70>1101018</td>
                <td class=x76>灯光及音响效果工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r847'>
                <td class=x70>1101019</td>
                <td class=x76>冲片工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r848'>
                <td class=x70>1101020</td>
                <td class=x76>洗片工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r849'>
                <td class=x70>1101021</td>
                <td class=x76>影视舞台烟火特效员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r850'>
                <td class=x70>1101022</td>
                <td class=x76>电视记者</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r851'>
                <td class=x70>1101023</td>
                <td class=x76>机械工、电工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r852'>
                <td class=x70>1101024</td>
                <td class=x76>影视设备机械员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r853'>
                <td class=x70>1101025</td>
                <td class=x76>广播电视天线工</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r854'>
                <td class=x70>1101026</td>
                <td class=x76>有线广播电视机线员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r855'>
                <td class=x70>1101027</td>
                <td class=x112>广播电视编播工程技术人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r856'>
                <td class=x70>1101028</td>
                <td class=x112>广播电视传输覆盖工程技术人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r857'>
                <td class=x70>1101029</td>
                <td class=x112>电影工程技术人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r858'>
                <td class=x70>1101030</td>
                <td class=x76>布景搭设人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r859'>
                <td class=x70>1101031</td>
                <td class=x76>电影院售票员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r860'>
                <td class=x70>1101032</td>
                <td class=x76>电影院放映人员、服务人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r861'>
                <td rowspan=5 height=96 class=x184 style='border-bottom:2px solid windowtext;height:72pt;' >1102高尔夫球馆</td>
                <td class=x74>1102001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x135>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r862'>
                <td class=x70>1102002</td>
                <td class=x71>球场保养人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r863'>
                <td class=x70>1102003</td>
                <td class=x71>维护工人</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r864'>
                <td class=x70>1102004</td>
                <td class=x71>球童</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r865'>
                <td class=x70>1102005</td>
                <td class=x71>职业高尔夫球员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r866'>
                <td rowspan=4 height=77 class=x184 style='border-bottom:2px solid windowtext;height:57.75pt;' >1103保龄球馆</td>
                <td class=x74>1103001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>记分员</td>
                <td class=x135>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r867'>
                <td class=x70>1103002</td>
                <td class=x71>柜台人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r868'>
                <td class=x70>1103003</td>
                <td class=x71>机械保护员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r869'>
                <td class=x70>1103004</td>
                <td class=x71>清洁工人</td>
                <td class=x130>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r870'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >1104撞球馆</td>
                <td class=x74>1104001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>负责人</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r871'>
                <td class=x70>1104002</td>
                <td class=x71>记分员</td>
                <td class=x130>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r872'>
                <td rowspan=5 height=96 class=x185 style='border-bottom:3px solid windowtext;height:72pt;' >1105游泳池</td>
                <td class=x74>1105001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>负责人</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r873'>
                <td class=x70>1105002</td>
                <td class=x71>管理员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r874'>
                <td class=x70>1105003</td>
                <td class=x71>教练</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r875'>
                <td class=x70>1105004</td>
                <td class=x71>售票员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r876'>
                <td class=x70>1105005</td>
                <td class=x71>救生员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r877'>
                <td rowspan=4 height=78 class=x184 style='border-bottom:2px solid windowtext;height:58.5pt;' >1106海水浴场</td>
                <td class=x74>1106001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>负责人</td>
                <td class=x135>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r878'>
                <td class=x70>1106002</td>
                <td class=x71>管理员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r879'>
                <td class=x70>1106003</td>
                <td class=x71>售票员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r880'>
                <td class=x70>1106004</td>
                <td class=x71>救生员</td>
                <td class=x93>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r881'>
                <td rowspan=9 height=172 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:129pt;' >1107其他游乐园</td>
                <td class=x74>1107001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>负责人</td>
                <td class=x135>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r882'>
                <td class=x70>1107002</td>
                <td class=x71>售票员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r883'>
                <td class=x70>1107003</td>
                <td class=x71>电动玩具操作员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r884'>
                <td class=x70>1107004</td>
                <td class=x71>一般清洁工</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r885'>
                <td class=x70>1107005</td>
                <td class=x71>兽栏清洁工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r886'>
                <td class=x70>1107006</td>
                <td class=x71>水电机械工</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r887'>
                <td class=x70>1107007</td>
                <td class=x71>动物园驯兽师</td>
                <td class=x93>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r888'>
                <td class=x70>1107008</td>
                <td class=x71>饲养人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r889'>
                <td class=x80>1107009</td>
                <td class=x81>兽医(动物园)</td>
                <td class=x130>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r890'>
                <td rowspan=15 height=286 class=x183 style='border-right:2px solid windowtext;height:214.5pt;' >1108艺术及演艺人员</td>
                <td class=x74>1108001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>作曲人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r891'>
                <td class=x70>1108002</td>
                <td class=x71>编曲人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r892'>
                <td class=x70>1108003</td>
                <td class=x71>演奏人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r893'>
                <td class=x70>1108004</td>
                <td class=x71>音乐指挥</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r894'>
                <td class=x70>1108005</td>
                <td class=x71>绘画人员</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r895'>
                <td class=x70>1108006</td>
                <td class=x71>舞蹈演艺人员、歌星</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r896'>
                <td class=x70>1108007</td>
                <td class=x71>服装模特</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r897'>
                <td class=x70>1108008</td>
                <td class=x71>戏曲演员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r898'>
                <td class=x70>1108009</td>
                <td class=x71>皮影戏演员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r899'>
                <td class=x70>1108010</td>
                <td class=x71>木偶戏演员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r900'>
                <td class=x70>1108011</td>
                <td class=x71>杂技魔术演员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r901'>
                <td class=x70>1108012</td>
                <td class=x71>舞台监督</td>
                <td class=x93>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r902'>
                <td class=x70>1108013</td>
                <td class=x71>雕塑人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r903'>
                <td class=x70>1108014</td>
                <td class=x71>戏剧演员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r904'>
                <td class=x70>1108015</td>
                <td class=x71>高空杂技、飞车、飞人演员</td>
                <td class=x130>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r905'>
                <td rowspan=17 height=324 class=x184 style='border-bottom:2px solid windowtext;height:243pt;' >1109特种营业</td>
                <td class=x74>1109001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>咖啡厅工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r906'>
                <td class=x70>1109002</td>
                <td class=x71>茶室工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r907'>
                <td class=x70>1109003</td>
                <td class=x71>酒家工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r908'>
                <td class=x70>1109004</td>
                <td class=x71>乐户工作人员</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r909'>
                <td class=x70>1109005</td>
                <td class=x71>舞厅工作人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r910'>
                <td class=x70>1109006</td>
                <td class=x71>歌厅工作人员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r911'>
                <td class=x70>1109007</td>
                <td class=x71>酒吧工作人员</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r912'>
                <td class=x70>1109008</td>
                <td class=x71>娱乐、餐饮业负责人</td>
                <td class=x93>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r913'>
                <td class=x70 align=right x:num="1109009">1109009</td>
                <td class=x71>保安人员</td>
                <td class=x93>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r914'>
                <td class=x70 align=right x:num="1109010">1109010</td>
                <td class=x71>调酒师</td>
                <td class=x93>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r915'>
                <td class=x70 align=right x:num="1109011">1109011</td>
                <td class=x71>乐队人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r916'>
                <td class=x70 align=right x:num="1109012">1109012</td>
                <td class=x71>歌唱人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r917'>
                <td class=x70 align=right x:num="1109013">1109013</td>
                <td class=x71>DJ</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r918'>
                <td class=x70 align=right x:num="1109014">1109014</td>
                <td class=x71>迎宾</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r919'>
                <td class=x70 align=right x:num="1109015">1109015</td>
                <td class=x71>舞蹈演艺人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r920'>
                <td class=x70 align=right x:num="1109016">1109016</td>
                <td class=x71>电子游戏厅工作人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r921'>
                <td class=x70 align=right x:num="1109017">1109017</td>
                <td class=x71>网吧管理人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r922'>
                <td rowspan=28 height=545 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:408.75pt;' >12文教机构</td>
                <td rowspan=14 height=278 class=x184 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:208.5pt;' >1201教育机构</td>
                <td class=x113>1201001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教育、教学单位行政人员</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r923'>
                <td class=x103>1201002</td>
                <td class=x71>教师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r924'>
                <td class=x103>1201003</td>
                <td class=x71>学生</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r925'>
                <td class=x103>1201004</td>
                <td class=x71>校工</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r926'>
                <td class=x103>1201005</td>
                <td class=x71>军训教官、体育教师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r927'>
                <td class=x103>1201006</td>
                <td class=x71>汽车驾驶训练班教练及学员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r928'>
                <td class=x103>1201007</td>
                <td class=x71>教育、教学单位司机</td>
                <td class=x78>3</td>
            </tr>
            <tr height=30 style='mso-height-source:userset;height:22.5pt' id='r929'>
                <td class=x103>1201008</td>
                <td class=x71 style='overflow:hidden;' >体校、技校教师、学生（除武术、特殊运动学校）</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r930'>
                <td class=x103>1201009</td>
                <td class=x71>戏曲舞蹈教师、学生</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r931'>
                <td class=x103>1201010</td>
                <td class=x71>杂技教师、学生</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r932'>
                <td class=x103>1201011</td>
                <td class=x71>飞行训练教官及学员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r933'>
                <td class=x103>1201012</td>
                <td class=x71>警校、军校学生</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r934'>
                <td class=x103 align=right x:num="1201013">1201013</td>
                <td class=x71>特殊运动班学生（拳击、摔跤、跆拳道等）</td>
                <td class=x78>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r935'>
                <td class=x103 align=right x:num="1201014">1201014</td>
                <td class=x71>武术学校学生</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r936'>
                <td rowspan=14 height=267 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:200.25pt;overflow:hidden;' >1202考古、文物保护及其他</td>
                <td class=x105>1202001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>负责人(出版商、书店、文具店)</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r937'>
                <td class=x114>1202002</td>
                <td class=x71>店员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r938'>
                <td class=x114>1202003</td>
                <td class=x71>外务员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r939'>
                <td class=x114>1202004</td>
                <td class=x71>送货员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r940'>
                <td class=x114>1202005</td>
                <td class=x71>图书馆工作人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r941'>
                <td class=x114>1202006</td>
                <td class=x71>博物馆工作人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r942'>
                <td class=x115></td>
                <td class=x116>考古及文物保护工作</td>
                <td class=x117></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r943'>
                <td class=x114>1202007</td>
                <td class=x118>考古工作者</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r944'>
                <td class=x114>1202008</td>
                <td class=x118>文物鉴定和保管人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r945'>
                <td class=x114>1202009</td>
                <td class=x118>文物保护专业人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r946'>
                <td class=x114>1202010</td>
                <td class=x118>考古发掘工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r947'>
                <td class=x114>1202011</td>
                <td class=x118>文物修复工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r948'>
                <td class=x114>1202012</td>
                <td class=x118>文物拓印工</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r949'>
                <td class=x114>1202013</td>
                <td class=x118>古旧书画修复工</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r950'>
                <td rowspan=5 height=96 class=x184 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:72pt;' >13宗教机构</td>
                <td rowspan=5 height=96 class=x184 style='border-bottom:2px solid windowtext;height:72pt;' >1300宗教人士</td>
                <td class=x74>1300001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>寺庙及教堂管理人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r951'>
                <td class=x70>1300002</td>
                <td class=x71>宗教团体工作人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r952'>
                <td class=x70>1300003</td>
                <td class=x71>僧尼、道士、传教人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r953'>
                <td class=x70>1300004</td>
                <td class=x71>乩童</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r954'>
                <td class=x70>1300005<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>宗教职业者</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r955'>
                <td rowspan=55 height=1049 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:786.75pt;' >14公共事业</td>
                <td rowspan=11 height=210 class=x183 style='border-bottom:2px solid windowtext;height:157.5pt;' >1401邮政与通信</td>
                <td class=x105>1401001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>内勤人员</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r956'>
                <td class=x114>1401002</td>
                <td class=x71>投递员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r957'>
                <td class=x114>1401003</td>
                <td class=x119>邮政设备安装、维护人员</td>
                <td class=x120>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r958'>
                <td class=x114>1401004</td>
                <td class=x119>包裹邮物人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r959'>
                <td class=x114>1401005</td>
                <td class=x71>包裹搬运人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r960'>
                <td class=x114>1401006</td>
                <td class=x119>通信设备维护人员</td>
                <td class=x120>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r961'>
                <td class=x114>1401007</td>
                <td class=x119>通信系统供电设备、空调设备安装维护人员</td>
                <td class=x120>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r962'>
                <td class=x114>1401008</td>
                <td class=x71>电信装置维护修理人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r963'>
                <td class=x114>1401009</td>
                <td class=x71>电信工程设施架设人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r964'>
                <td class=x114>1401010</td>
                <td class=x71>电台天线维护人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r965'>
                <td class=x114>1401011</td>
                <td class=x71>光缆铺设人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r966'>
                <td rowspan=29 height=552 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:414pt;' >1402电力</td>
                <td class=x74>1402001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x75>内勤人员</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r967'>
                <td class=x70>1402002</td>
                <td class=x76>抄表员、收费员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r968'>
                <td class=x70>1402003</td>
                <td class=x101>电力拖动与自动控制工程技术人员</td>
                <td class=x106>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r969'>
                <td class=x70>1402004</td>
                <td class=x101>电线电缆与电工材料工程技术人员</td>
                <td class=x106>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r970'>
                <td class=x70>1402005</td>
                <td class=x101>发电工程技术人员</td>
                <td class=x106>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r971'>
                <td class=x70>1402006</td>
                <td class=x101>输变电工程技术人员</td>
                <td class=x106>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r972'>
                <td class=x70>1402007</td>
                <td class=x101>供用电工程技术人员</td>
                <td class=x106>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r973'>
                <td class=x70>1402008</td>
                <td class=x101>发电厂电动机检修工</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r974'>
                <td class=x70>1402009</td>
                <td class=x101>水轮机检修工</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r975'>
                <td class=x70>1402010</td>
                <td class=x101>水电站水利机械试验工</td>
                <td class=x106>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r976'>
                <td class=x70>1402011</td>
                <td class=x101>水电自动装置检修工</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r977'>
                <td class=x70>1402012</td>
                <td class=x101>高压线路带电检修工</td>
                <td class=x106>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r978'>
                <td class=x70>1402013</td>
                <td class=x101>变压器检修工</td>
                <td class=x106>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r979'>
                <td class=x70>1402014</td>
                <td class=x101>变电设备检修工</td>
                <td class=x106>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r980'>
                <td class=x70>1402015</td>
                <td class=x101>电气试验员</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r981'>
                <td class=x70>1402016</td>
                <td class=x101>继电保护员</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r982'>
                <td class=x70>1402017</td>
                <td class=x101>电力装置维护修理工</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r983'>
                <td class=x70>1402018</td>
                <td class=x101>电力负荷控制员</td>
                <td class=x106>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r984'>
                <td class=x70>1402019</td>
                <td class=x101>用电监察员</td>
                <td class=x106>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r985'>
                <td class=x70>1402020</td>
                <td class=x101>装表核算收费员</td>
                <td class=x106>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r986'>
                <td class=x70>1402021</td>
                <td class=x101>装表接电工</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r987'>
                <td class=x70>1402022</td>
                <td class=x101>电能计量装置检修工</td>
                <td class=x106>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r988'>
                <td class=x70>1402023</td>
                <td class=x101>变电设备安装工</td>
                <td class=x106>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r989'>
                <td class=x70>1402024</td>
                <td class=x101>变配电室值班电工</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r990'>
                <td class=x70>1402025</td>
                <td class=x101>常用电机检修工</td>
                <td class=x106>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r991'>
                <td class=x70>1402026</td>
                <td class=x101>牵引电力线路安装维护工</td>
                <td class=x106>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r992'>
                <td class=x70>1402027</td>
                <td class=x101>维修电工</td>
                <td class=x106>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r993'>
                <td class=x70>1402028</td>
                <td class=x76>电力设施架设人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r994'>
                <td class=x70>1402029</td>
                <td class=x76>电力高压电工程设施人员</td>
                <td class=x73>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r995'>
                <td rowspan=9 height=172 class=x184 style='border-bottom:2px solid windowtext;height:129pt;' >1403自来水(水利)</td>
                <td class=x74>1403001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x75>工程师</td>
                <td class=x72>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r996'>
                <td class=x70>1403002</td>
                <td class=x76>水坝、水库管理人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r997'>
                <td class=x70>1403003</td>
                <td class=x76>水利工程设施人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r998'>
                <td class=x70>1403004</td>
                <td class=x76>自来水管装修人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r999'>
                <td class=x70>1403005</td>
                <td class=x76>抄表员,收费员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1000'>
                <td class=x70>1403006</td>
                <td class=x76>自来水厂水质分析员(实地)</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1001'>
                <td class=x70>1403007</td>
                <td class=x104>水泵或提水站的管理人员</td>
                <td class=x100>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1002'>
                <td class=x70>1403008</td>
                <td class=x104>水泵或提水站的维修人员</td>
                <td class=x100>5</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1003'>
                <td class=x70>1403009</td>
                <td class=x104>河道清淤的工人</td>
                <td class=x121>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1004'>
                <td rowspan=6 height=115 class=x184 style='border-bottom:2px solid windowtext;height:86.25pt;' >1404燃气<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>1404001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>工程师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1005'>
                <td class=x70>1404002</td>
                <td class=x71>管线装修工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1006'>
                <td class=x70>1404003</td>
                <td class=x71>收费员、抄表员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1007'>
                <td class=x70>1404004</td>
                <td class=x71>检查员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1008'>
                <td class=x70>1404005</td>
                <td class=x71>燃气器具制造工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1009'>
                <td class=x70>1404006</td>
                <td class=x71>燃气储气槽,分装厂之工作人员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1010'>
                <td rowspan=47 height=894 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:670.5pt;overflow:hidden;' >15一般买卖<br>（零售批发业）</td>
                <td rowspan=47 height=894 class=x183 style='border-bottom:2px solid windowtext;height:670.5pt;' >1501买卖</td>
                <td class=x74>1501001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x75>厨具商</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1011'>
                <td class=x70>1501002</td>
                <td class=x76>陶瓷器商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1012'>
                <td class=x70>1501003</td>
                <td class=x76>古董商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1013'>
                <td class=x70>1501004</td>
                <td class=x76>花卉商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1014'>
                <td class=x70>1501005</td>
                <td class=x76>米商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1015'>
                <td class=x70>1501006</td>
                <td class=x76>杂货商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1016'>
                <td class=x70>1501007</td>
                <td class=x76>玻璃商（不含搬运和加工）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1017'>
                <td class=x70>1501008</td>
                <td class=x76>果菜商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1018'>
                <td class=x70>1501009</td>
                <td class=x76>石材商（不含搬运和加工）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1019'>
                <td class=x70>1501010</td>
                <td class=x76>建材商（不含搬运和加工）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1020'>
                <td class=x70>1501011</td>
                <td class=x76>铁材商（不含搬运和加工）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1021'>
                <td class=x70>1501012</td>
                <td class=x76>木材商（不含搬运和加工）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1022'>
                <td class=x70>1501013</td>
                <td class=x76>五金商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1023'>
                <td class=x70>1501014</td>
                <td class=x76>电器商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1024'>
                <td class=x70>1501015</td>
                <td class=x76>水电卫生器材商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1025'>
                <td class=x70>1501016</td>
                <td class=x76>家具商（不含搬运和加工）</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1026'>
                <td class=x70>1501017</td>
                <td class=x76>自行车买卖商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1027'>
                <td class=x70>1501018</td>
                <td class=x76>机车买卖商(不含修理)</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1028'>
                <td class=x70>1501019</td>
                <td class=x76>汽车买卖商(不含修理)</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1029'>
                <td class=x70>1501020</td>
                <td class=x76>车辆器材商(不含矿物油)</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1030'>
                <td class=x70>1501021</td>
                <td class=x76>矿物油、香烛买卖商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1031'>
                <td class=x70>1501022</td>
                <td class=x76>眼镜商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1032'>
                <td class=x70>1501023</td>
                <td class=x76>食品商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1033'>
                <td class=x70>1501024</td>
                <td class=x76>文具商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1034'>
                <td class=x70>1501025</td>
                <td class=x76>布商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1035'>
                <td class=x70>1501026</td>
                <td class=x76>服饰买卖商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1036'>
                <td class=x70>1501027</td>
                <td class=x76>农具商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1037'>
                <td class=x70>1501028</td>
                <td class=x76>售货商</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1038'>
                <td class=x70>1501029</td>
                <td class=x76>碾米商 </td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1039'>
                <td class=x70>1501030</td>
                <td class=x76>鱼贩</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1040'>
                <td class=x70>1501031</td>
                <td class=x76>肉贩</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1041'>
                <td class=x70>1501032</td>
                <td class=x76>屠宰</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1042'>
                <td class=x70>1501033</td>
                <td class=x76>屠牛<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1043'>
                <td class=x70>1501034</td>
                <td class=x76>药品买卖商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1044'>
                <td class=x70>1501035</td>
                <td class=x76>医疗器械仪器商</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1045'>
                <td class=x70>1501036</td>
                <td class=x76>化学原料商、农药买卖商</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1046'>
                <td class=x70>1501037</td>
                <td class=x76>手工艺品买卖商</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1047'>
                <td class=x70>1501038</td>
                <td class=x76>银楼珠宝、当铺负责人及工作人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1048'>
                <td class=x122></td>
                <td class=x123>燃气器具店</td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1049'>
                <td class=x70>1501039</td>
                <td class=x76>负责人</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1050'>
                <td class=x70>1501040</td>
                <td class=x76>店员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1051'>
                <td class=x70>1501041</td>
                <td class=x76>送货员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1052'>
                <td class=x70>1501042</td>
                <td class=x76>装饰工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1053'>
                <td class=x122></td>
                <td class=x123>液化燃气零售店</td>
                <td class=x78></td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1054'>
                <td class=x70>1501043</td>
                <td class=x76>负责人及工作人员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1055'>
                <td class=x70>1501044</td>
                <td class=x76>送货员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1056'>
                <td class=x70>1501045</td>
                <td class=x76>液化燃气分装工</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1057'>
                <td rowspan=41 height=782 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;height:586.5pt;' >16服务业</td>
                <td rowspan=6 height=115 class=x184 style='border-bottom:2px solid windowtext;height:86.25pt;overflow:hidden;' >1601金融、保险、证券业<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x74>1601001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>金融一般内勤人员</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1058'>
                <td class=x70>1601002</td>
                <td class=x71>金融外务员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1059'>
                <td class=x70>1601003</td>
                <td class=x71>保险收费员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1060'>
                <td class=x70>1601004</td>
                <td class=x71>保险调查员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1061'>
                <td class=x70>1601005</td>
                <td class=x71>征信人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1062'>
                <td class=x70>1601006</td>
                <td class=x71>现金运送车司机、点钞员、押送员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1063'>
                <td rowspan=7 height=134 class=x184 style='border-bottom:2px solid windowtext;height:100.5pt;' >1602自由业</td>
                <td class=x74>1602001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>律师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1064'>
                <td class=x70>1602002</td>
                <td class=x71>会计师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1065'>
                <td class=x70>1602003</td>
                <td class=x71>代书(内勤)</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1066'>
                <td class=x70>1602004</td>
                <td class=x71>经纪人(内勤)</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1067'>
                <td class=x70>1602005</td>
                <td class=x71>鉴定估价师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1068'>
                <td class=x70>1602006</td>
                <td class=x71>速录师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1069'>
                <td class=x70>1602007</td>
                <td class=x71>土地房屋买卖介绍人</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1070'>
                <td rowspan=28 height=533 class=x183 style='height:399.75pt;' >1603其他<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><br></td>
                <td class=x74>1603001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x75>公证员</td>
                <td class=x72>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1071'>
                <td class=x70>1603002</td>
                <td class=x76>报关行外务员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1072'>
                <td class=x70>1603003</td>
                <td class=x76>理发师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1073'>
                <td class=x70>1603004</td>
                <td class=x76>美容师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1074'>
                <td class=x70>1603005</td>
                <td class=x76>保健按摩师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1075'>
                <td class=x70>1603006</td>
                <td class=x76>修脚师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1076'>
                <td class=x70>1603007</td>
                <td class=x76>钟表匠</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1077'>
                <td class=x70>1603008</td>
                <td class=x76>鞋匠、伞匠</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1078'>
                <td class=x70>1603009</td>
                <td class=x76>洗衣店工人</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1079'>
                <td class=x70>1603010</td>
                <td class=x76>勘查师</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1080'>
                <td class=x70>1603011</td>
                <td class=x76>警卫人员(工厂、公司行号、大楼)</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1081'>
                <td class=x70>1603012</td>
                <td class=x76>大楼管理员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1082'>
                <td class=x70>1603013</td>
                <td class=x76>摄影师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1083'>
                <td class=x70>1603014</td>
                <td class=x76>道路清洁工,垃圾车司机及随车工人</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1084'>
                <td class=x70>1603015</td>
                <td class=x76>下水道清洁工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1085'>
                <td class=x70>1603016</td>
                <td class=x76>清洁打腊工人</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1086'>
                <td class=x70>1603017</td>
                <td class=x76>高楼外部清洁工、烟囱清洁工</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1087'>
                <td class=x70>1603018</td>
                <td class=x76>废物回收人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1088'>
                <td class=x70>1603020</td>
                <td class=x76>收费站、停车场收费人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1089'>
                <td class=x70>1603021</td>
                <td class=x76>加油站工作人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1090'>
                <td class=x70>1603022</td>
                <td class=x76>地磅场工作人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1091'>
                <td class=x70>1603023</td>
                <td class=x76>洗车工人</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1092'>
                <td class=x70 align=right x:num="1603024">1603024</td>
                <td class=x76>殡仪服务员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1093'>
                <td class=x70 align=right x:num="1603025">1603025</td>
                <td class=x76>尸体接运工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1094'>
                <td class=x70 align=right x:num="1603026">1603026</td>
                <td class=x76>尸体防腐工</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1095'>
                <td class=x70 align=right x:num="1603027">1603027</td>
                <td class=x76>尸体整容工</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1096'>
                <td class=x70 align=right x:num="1603028">1603028</td>
                <td class=x76>尸体火化工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1097'>
                <td class=x136 align=right x:num="1603029">1603029</td>
                <td class=x137>墓地管理员</td>
                <td class=x138>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1098'>
                <td rowspan=2 height=39 class=x184 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >17家庭管理</td>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >1701家政管理</td>
                <td class=x70>1701001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x76>家政服务员（小时工）</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1099'>
                <td class=x70>1701002</td>
                <td class=x76>保姆（全日制）</td>
                <td class=x78>3</td>
            </tr>
            <tr height=16 class=x124 style='mso-height-source:userset;height:12pt' id='r1100'>
                <td rowspan=30 height=581 class=x183 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:435.75pt;overflow:hidden;' >18公检法等<br>执法检查机关</td>
                <td rowspan=8 height=150 class=x190 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:112.5pt;overflow:hidden;' >1801法院、检察院工作人员</td>
                <td class=x140 align=right x:num="1801001">1801001</td>
                <td class=x141>人民法院负责人</td>
                <td class=x139>1</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1101'>
                <td class=x70 align=right x:num="1801002">1801002</td>
                <td class=x76>人民检察院负责人</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1102'>
                <td class=x70 align=right x:num="1801003">1801003</td>
                <td class=x76>法官</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1103'>
                <td class=x70 align=right x:num="1801004">1801004</td>
                <td class=x76>检查官</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1104'>
                <td class=x70 align=right x:num="1801005">1801005</td>
                <td class=x76>法医</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1105'>
                <td class=x70 align=right x:num="1801006">1801006</td>
                <td class=x76>法警</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1106'>
                <td class=x70 align=right x:num="1801007">1801007</td>
                <td class=x76>书记员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=20 class=x124 style='mso-height-source:userset;height:15pt' id='r1107'>
                <td class=x70 align=right x:num="1801008">1801008</td>
                <td class=x142>商业犯罪调查处理人员</td>
                <td class=x138>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1108'>
                <td rowspan=7 height=134 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:100.5pt;' >1802公安警务工作人员</td>
                <td class=x140 align=right x:num="1802001">1802001</td>
                <td class=x76>警务行政及内勤人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1109'>
                <td class=x70 align=right x:num="1802002">1802002</td>
                <td class=x76>警察（负有巡逻任务者）</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1110'>
                <td class=x70 align=right x:num="1802003">1802003</td>
                <td class=x76>监狱看守所管理人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1111'>
                <td class=x70 align=right x:num="1802004">1802004</td>
                <td class=x76>交通警察</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1112'>
                <td class=x70 align=right x:num="1802005">1802005</td>
                <td class=x76>刑警</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1113'>
                <td class=x70 align=right x:num="1802006">1802006</td>
                <td class=x76>警务特警</td>
                <td class=x78>6</td>
            </tr>
            <tr height=20 class=x124 style='mso-height-source:userset;height:15pt' id='r1114'>
                <td class=x136 align=right x:num="1802007">1802007</td>
                <td class=x142>防暴警察、武警</td>
                <td class=x138>拒保</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1115'>
                <td rowspan=15 height=297 class=x183 style='border-bottom:2px solid windowtext;height:222.75pt;overflow:hidden;' >1803其他执法、治安及特种工作人员</td>
                <td class=x70 align=right x:num="1803001">1803001</td>
                <td class=x76>港口机场警卫及安全人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=30 class=x124 style='mso-height-source:userset;height:22.5pt' id='r1116'>
                <td class=x70 align=right x:num="1803002">1803002</td>
                <td class=x76 style='overflow:hidden;' >工商、税务、海关、城管等特定国家行政执法人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1117'>
                <td class=x70 align=right x:num="1803003">1803003</td>
                <td class=x76>缉私人员</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1118'>
                <td class=x70 align=right x:num="1803004">1803004</td>
                <td class=x76>违禁品检查员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1119'>
                <td class=x70 align=right x:num="1803005">1803005</td>
                <td class=x76>治安调查人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1120'>
                <td class=x70 align=right x:num="1803006">1803006</td>
                <td class=x76>保安人员（办公楼、物业）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1121'>
                <td class=x70 align=right x:num="1803007">1803007</td>
                <td class=x76>保安人员（工厂、银行）</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1122'>
                <td class=x70 align=right x:num="1803008">1803008</td>
                <td class=x76>防毒防化防核抢险员</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1123'>
                <td class=x70 align=right x:num="1803009">1803009</td>
                <td class=x76>一般事故抢险员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1124'>
                <td class=x70 align=right x:num="1803010">1803010</td>
                <td class=x76>抢险救援器材工具调配工</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1125'>
                <td class=x70 align=right x:num="1803011">1803011</td>
                <td class=x76>火险监督员、防火审核员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1126'>
                <td class=x70 align=right x:num="1803012">1803012</td>
                <td class=x76>可燃气体（毒气）检测员、危险物品监督员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1127'>
                <td class=x70 align=right x:num="1803013">1803013</td>
                <td class=x76>消防队队员</td>
                <td class=x78>6</td>
            </tr>
            <tr height=19 class=x124 style='mso-height-source:userset;height:14.25pt' id='r1128'>
                <td class=x70 align=right x:num="1803014">1803014</td>
                <td class=x76>火灾嘹望观察员（嘹望塔）</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 class=x124 style='mso-height-source:userset;height:15pt' id='r1129'>
                <td class=x70 align=right x:num="1803015">1803015</td>
                <td class=x142>火灾嘹望观察员（直升机）</td>
                <td class=x138>6</td>
            </tr>
            <tr height=45 style='mso-height-source:userset;height:33.75pt' id='r1130'>
                <td rowspan=11 height=261 class=x184 style='border-left: 2px solid windowtext;border-right:2px solid windowtext;height:195.75pt;' >19军人</td>
                <td rowspan=11 height=261 class=x184 style='height:195.75pt;' >1901现役军人</td>
                <td class=x140>1901001<span style='mso-spacerun:yes'>&nbsp; </span></td>
                <td class=x76 style='overflow:hidden;' >一般地面部队人员(含陆军野战、机械修护、土木工程、飞弹、战车及空军炮、飞机修护等)</td>
                <td class=x78>3</td>
            </tr>
            <tr height=45 style='mso-height-source:userset;height:33.75pt' id='r1131'>
                <td class=x114>1901002</td>
                <td class=x71 style='overflow:hidden;' >特种兵(海军陆站队、伞兵、水兵、爆破兵、蛙人、化学兵、负有布雷爆破任务之工兵、情报单位负有特殊任务者)<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span></td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1132'>
                <td class=x70>1901003</td>
                <td class=x71>行政及内勤人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1133'>
                <td class=x70>1901004</td>
                <td class=x71>宪兵</td>
                <td class=x78>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1134'>
                <td class=x70>1901005</td>
                <td class=x71>后勤补给及通讯地勤人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1135'>
                <td class=x70 align=right x:num="1901006">1901006</td>
                <td class=x71>军事研究单位纸上设计人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1136'>
                <td class=x70>1901007</td>
                <td class=x71>军事单位武器、弹药研究及管理人员</td>
                <td class=x78>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1137'>
                <td class=x70>1901008</td>
                <td class=x71 style='overflow:hidden;' >空军飞行官兵、空军海洋巡弋舰艇及潜艇官兵</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1138'>
                <td class=x70>1901009</td>
                <td class=x71>前线军人</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1139'>
                <td class=x70>1901010</td>
                <td class=x71>军校学生及入伍受训新兵</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1140'>
                <td class=x70>1901011</td>
                <td class=x71>军医院官兵</td>
                <td class=x78>2</td>
            </tr>
            <tr height=22 style='mso-height-source:userset;height:16.5pt' id='r1141'>
                <td rowspan=9 height=193 class=x184 style='border-top: 2px solid windowtext;border-left: 2px solid windowtext;border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:144.75pt;overflow:hidden;' >20IT业<br>（软、硬件开发<br>制作）<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td rowspan=9 height=193 class=x184 style='border-top: 2px solid windowtext;border-bottom:2px solid windowtext;height:144.75pt;overflow:hidden;' >2001<span style='mso-spacerun:yes'>&nbsp; </span>IT业（软、硬件开发制作）</td>
                <td class=x74>2001001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>维护工程师</td>
                <td class=x139>2</td>
            </tr>
            <tr height=22 style='mso-height-source:userset;height:16.5pt' id='r1142'>
                <td class=x70>2001002</td>
                <td class=x71>计算机系统分析技术人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=22 style='mso-height-source:userset;height:16.5pt' id='r1143'>
                <td class=x70>2001003</td>
                <td class=x71>销售人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=22 style='mso-height-source:userset;height:16.5pt' id='r1144'>
                <td class=x70 align=right x:num="2001004">2001004</td>
                <td class=x71>计算机硬件技术人员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=22 style='mso-height-source:userset;height:16.5pt' id='r1145'>
                <td class=x70 align=right x:num="2001005">2001005</td>
                <td class=x71>计算机软件技术人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=22 style='mso-height-source:userset;height:16.5pt' id='r1146'>
                <td class=x70 align=right x:num="2001006">2001006</td>
                <td class=x71>计算机网络技术人员</td>
                <td class=x78>1</td>
            </tr>
            <tr height=22 style='mso-height-source:userset;height:16.5pt' id='r1147'>
                <td class=x70 align=right x:num="2001007">2001007</td>
                <td class=x71>计算机乐谱制作师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1148'>
                <td class=x70 align=right x:num="2001008">2001008</td>
                <td class=x71>数字视频合成师</td>
                <td class=x78>1</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1149'>
                <td class=x70 align=right x:num="2001009">2001009</td>
                <td class=x71>计算机软件产品检验员</td>
                <td class=x73>1</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1150'>
                <td rowspan=73 height=1425 class=x191 style='border-right: 2px solid windowtext;border-bottom: 2px solid windowtext;border-left: 2px solid windowtext;height:1068.75pt;overflow:hidden;' >21职业运动<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></td>
                <td rowspan=3 height=58 class=x184 style='border-bottom:2px solid windowtext;height:43.5pt;' >2101高尔夫球</td>
                <td class=x74>2101001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1151'>
                <td class=x70>2101002</td>
                <td class=x71>高尔夫球球员</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1152'>
                <td class=x70>2101003</td>
                <td class=x71>球童</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1153'>
                <td rowspan=2 height=39 class=x185 style='border-bottom:3px solid windowtext;height:29.25pt;' >2102保龄球</td>
                <td class=x74>2102001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1154'>
                <td class=x70>2102002</td>
                <td class=x71>保龄球球员</td>
                <td class=x79>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1155'>
                <td rowspan=2 height=40 class=x184 style='border-bottom:2px solid windowtext;height:30pt;' >2103桌球</td>
                <td class=x74>2103001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1156'>
                <td class=x80>2103002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x81>桌球球员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1157'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2104乒乓球、羽毛球</td>
                <td class=x70>2104001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1158'>
                <td class=x70>2104002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>球员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1159'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2105游泳</td>
                <td class=x74>2105001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1160'>
                <td class=x70>2105002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>游泳人员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1161'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2106射箭</td>
                <td class=x74>2106001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1162'>
                <td class=x70>2106002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>射箭人员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1163'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2107网球</td>
                <td class=x74>2107001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1164'>
                <td class=x70>2107002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>网球球员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1165'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2108垒球</td>
                <td class=x74>2108001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1166'>
                <td class=x70>2108002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>垒球球员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1167'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2109溜冰</td>
                <td class=x74>2109001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1168'>
                <td class=x70>2109002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>溜冰人员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1169'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2110射击</td>
                <td class=x74>2110001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1170'>
                <td class=x70>2110002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>射击人员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1171'>
                <td class=x143>2111民族体育活动</td>
                <td class=x74>2111001<span style='mso-spacerun:yes'>&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1172'>
                <td class=x144><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>(不含竞技性)</td>
                <td class=x70>2111002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>民族体育活动人员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1173'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2112举重</td>
                <td class=x74>2112001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1174'>
                <td class=x70>2112002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>举重人员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1175'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2113篮球</td>
                <td class=x74>2113001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1176'>
                <td class=x70>2113002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>篮球球员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1177'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2114排球</td>
                <td class=x74>2114001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1178'>
                <td class=x70>2114002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>排球球员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1179'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2115棒球</td>
                <td class=x74>2115001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1180'>
                <td class=x70>2115002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>棒球球员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1181'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2116田径</td>
                <td class=x74>2116001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1182'>
                <td class=x70>2116002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>参赛人员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1183'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2117体操</td>
                <td class=x74>2117001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1184'>
                <td class=x70>2117002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>体操人员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1185'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2118滑雪</td>
                <td class=x74>2118001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1186'>
                <td class=x70>2118002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>滑雪人员</td>
                <td class=x73>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1187'>
                <td rowspan=2 height=39 class=x185 style='border-bottom:3px solid windowtext;height:29.25pt;' >2119帆船</td>
                <td class=x74>2119001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1188'>
                <td class=x70>2119002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>驾乘人员</td>
                <td class=x79>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1189'>
                <td rowspan=2 height=40 class=x184 style='border-bottom:2px solid windowtext;height:30pt;' >2120划船</td>
                <td class=x74>2120001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1190'>
                <td class=x70>2120002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>驾乘人员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1191'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2121泛舟</td>
                <td class=x74>2121001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1192'>
                <td class=x70>2121002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>驾乘人员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1193'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2122巧固球</td>
                <td class=x74>2122001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1194'>
                <td class=x70>2122002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>巧固球球员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1195'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2123手球</td>
                <td class=x74>2123001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1196'>
                <td class=x70>2123002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>手球球员</td>
                <td class=x73>3</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1197'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2124风浪板</td>
                <td class=x74>2124001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1198'>
                <td class=x70>2124002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>驾乘人员</td>
                <td class=x73>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1199'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2125水上摩托车</td>
                <td class=x74>2125001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1200'>
                <td class=x70>2125002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>驾乘人员</td>
                <td class=x73>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1201'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2126足球</td>
                <td class=x74>2126001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1202'>
                <td class=x70>2126002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>足球球员</td>
                <td class=x73>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1203'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2127曲棍球</td>
                <td class=x74>2127001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1204'>
                <td class=x70>2127002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>曲棍球球员</td>
                <td class=x73>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1205'>
                <td rowspan=2 height=39 class=x184 style='border-bottom:2px solid windowtext;height:29.25pt;' >2128冰上曲棍球</td>
                <td class=x74>2128001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1206'>
                <td class=x70>2128002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>冰上曲棍球球员</td>
                <td class=x73>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1207'>
                <td rowspan=2 height=39 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >2129橄榄球</td>
                <td class=x74>2129001<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x77>教练</td>
                <td class=x72>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1208'>
                <td class=x70>2129002<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span></td>
                <td class=x71>橄榄球球员</td>
                <td class=x73>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1209'>
                <td rowspan=2 height=39 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >2130摔跤</td>
                <td class=x74>2130001</td>
                <td class=x77>教练</td>
                <td class=x78>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1210'>
                <td class=x80>2130002</td>
                <td class=x81>摔跤运动员</td>
                <td class=x78>5</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1211'>
                <td rowspan=2 height=39 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >2131击剑</td>
                <td class=x74>2131001</td>
                <td class=x77>教练</td>
                <td class=x72>3</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1212'>
                <td class=x80>2131002</td>
                <td class=x81>击剑运动员</td>
                <td class=x73>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1213'>
                <td rowspan=3 height=58 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:43.5pt;' >2132拳击</td>
                <td class=x74>2132001</td>
                <td class=x77>教练</td>
                <td class=x72>4</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1214'>
                <td class=x70>2132002</td>
                <td class=x71>职业拳击运动员</td>
                <td class=x78>拒保</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1215'>
                <td class=x80>2132003</td>
                <td class=x81>业余拳击运动员</td>
                <td class=x73>6</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1216'>
                <td rowspan=2 height=39 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >2133乒乓球运动</td>
                <td class=x74>2133001</td>
                <td class=x77>教练员</td>
                <td class=x72>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1217'>
                <td class=x80>2133002</td>
                <td class=x81>乒乓球球员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1218'>
                <td rowspan=2 height=39 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >2134水球运动</td>
                <td class=x74>2134001</td>
                <td class=x77>教练员</td>
                <td class=x72>2</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1219'>
                <td class=x80>2134002</td>
                <td class=x81>水球球员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1220'>
                <td rowspan=2 height=39 class=x183 style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:29.25pt;' >2135马术运动</td>
                <td class=x74>2135001</td>
                <td class=x77>教练员</td>
                <td class=x72>4</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1221'>
                <td class=x80>2135002</td>
                <td class=x81>马术运动员</td>
                <td class=x73>6</td>
            </tr>
            <tr height=20 style='mso-height-source:userset;height:15pt' id='r1222'>
                <td class=x80>2136裁判人员</td>
                <td class=x80>2136001</td>
                <td class=x81>裁判人员</td>
                <td class=x73>2</td>
            </tr>
            <tr height=19 style='mso-height-source:userset;height:14.25pt' id='r1223'>
                <td height=19 class=x64 style='height:14.25pt'></td>
                <td class=x64></td>
                <td class=x125></td>
                <td class=x64></td>
                <td class=x126></td>
            </tr>
            <tr height=104 class=x127 style='mso-height-source:userset;height:78pt' id='r1224'>
                <td colspan=5 id='tc1' height=104 class=x180 style='height:78pt;overflow:hidden;' >注：若职业中包含高处作业，则相应职业类别需根据实际情况上浮1-2个等级。<br>高处作业是指人在一定位置为基准的高处进行的作业。国家标准GB3608—93《高处作业分级》规定：“凡在坠落高度基准面2m以上（含2m）有可能坠落的高处进行作业，都称为高处作业。”根据这一规定，在建筑业中涉及到高处作业的范围是相当广泛的。在建筑物内作业时，若在2m以上的架子上进行操作，即为高处作业。</td>
            </tr>
        </table>

    </div>
</template>
<style>
    table
 {mso-displayed-decimal-separator:"\.";
 mso-displayed-thousand-separator:"\,";}
@page
 {
 mso-header-data:"";
 mso-footer-data:"";
 margin:1in 0.75in 1in 0.75in;
 mso-header-margin:0.5in;
 mso-footer-margin:0.5in;
 mso-page-orientation:Portrait;
 }
tr
 {mso-height-source:auto;
 mso-ruby-visibility:none;}
col
 {mso-width-source:auto;
 mso-ruby-visibility:none;}
br
 {mso-data-placement:same-cell;}
ruby
 {ruby-align:left;}

.font1
 {
 color:#000000;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体"; }

.font7
 {
 color:#000000;
 font-size:9pt;
 font-weight:700;
 font-style:normal;
 font-family:"黑体"; }

td
 {mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 color:#000000;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 mso-ignore:padding;}

.x64
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x65
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"黑体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x66
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"黑体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x67
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"黑体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x68
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"黑体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x69
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"黑体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x70
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x71
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x72
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x73
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x74
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x75
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x76
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x77
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x78
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x79
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:3px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x80
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x81
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x82
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x83
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"Times New Roman","serif";
 border-top:none;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x84
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:700;
 font-style:normal;
 font-family:"黑体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x85
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"黑体";
 border:none;
 mso-protection:locked visible;
 }
.x86
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:700;
 font-style:normal;
 font-family:"黑体";
 border:none;
 mso-protection:locked visible;
 }
.x87
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:700;
 font-style:normal;
 font-family:"黑体";
 border-top:none;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x88
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"Times New Roman","serif";
 border-top:none;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x89
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x90
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x91
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x92
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x93
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x94
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x95
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x96
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x97
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x98
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x99
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x100
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"Times New Roman","serif";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x101
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x102
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x103
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x104
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x105
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:left;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x106
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x107
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x108
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x109
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x110
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x111
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x112
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x113
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:none;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x114
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:left;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x115
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x116
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:700;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x117
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:700;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x118
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:10pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x119
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x120
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x121
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"Times New Roman","serif";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x122
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x123
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:700;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x124
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x125
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x126
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x127
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:12pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }
.x128
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x129
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid #000000;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x130
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid #000000;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x131
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:none;
 border-left:2px solid #000000;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x132
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid #000000;
 border-left:2px solid #000000;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x133
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid #000000;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x134
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:bottom;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid #000000;
 border-right:none;
 border-bottom:none;
 border-left:2px solid #000000;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x135
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid #000000;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x136
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid #000000;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x137
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid #000000;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x138
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid #000000;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x139
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid #000000;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x140
 {
 mso-style-parent:style0;
 mso-number-format:"\@";
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid #000000;
 border-right:none;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x141
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid #000000;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x142
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid #000000;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x143
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid #000000;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x144
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:general;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:2px solid #000000;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }
.x145
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:2px solid windowtext;
 border-right:2px solid windowtext;
 border-bottom:none;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }

.x151
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:middle;
 white-space:nowrap;
 background:auto;
 mso-pattern:auto;
 font-size:20pt;
 font-weight:700;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:none;
 border-bottom:2px solid windowtext;
 border-left:none;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }

.x175
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:center;
 vertical-align:top;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:9pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border-top:none;
 border-right:2px solid windowtext;
 border-bottom:2px solid windowtext;
 border-left:2px solid windowtext;
 mso-diagonal-down:none;
 mso-diagonal-up:none;
 mso-protection:locked visible;
 }

.x180
 {
 mso-style-parent:style0;
 mso-number-format:General;
 text-align:left;
 vertical-align:middle;
 white-space:normal;word-wrap:break-word;
 background:auto;
 mso-pattern:auto;
 font-size:10pt;
 font-weight:400;
 font-style:normal;
 font-family:"宋体";
 border:none;
 mso-protection:locked visible;
 }

</style>
<script>

</script>
