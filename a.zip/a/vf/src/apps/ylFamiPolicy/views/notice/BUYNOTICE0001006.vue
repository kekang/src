<template>
    <div class="service-Terms">
        <h1>投保须知</h1>
        <p class="for-margin">1、本投保人兹申明以上述各项内容填写属实，已征得被保险人同意，并认可保险金额。</p>
        <p class="for-margin">2、本投保人已阅读<span style="color:red" @click="goClause">《家庭综合保险条款》<span>，并特别就条款中有关<span style="color:red">责任免除<span>和投保人、被保险人义务的内容进行阅读。本投保人特此同意接受条款全部内容，以及投保须知详情。投保须知内容如下：
        <br/>(1).本产品适用年龄为0－60周岁，被保险人均应为身体健康，能正常工作、学习和生活的人员，被保险人仅限1-3类职业人员，若被保险人从事4类及4类以上职业或拒保职业，不属于保险责任范围。<span style="color:red" @click="seeZY">查看职业分类表</span>，职业类别不明请咨询40088-95512转2。
        <br/>(2).意外住院津贴，每次事故给付天数以10天为限。
        <br/>(3).保险期限：本保险的期限为1年，生效日期最早为支付保费当日起的第八日。
        <br/>(4).投保份数：每位被保险人最多投保壹份。
        <br/>(5).受益人：本保险方案的受益人为法定。</p>
        <p class="for-margin">3、根据《中华人民共和国合同法》第十一条规定，数据电文是合法的合同表现形式。本人接受以平安养老保险股份有限公司提供的电子保单作为本投保书成立的合法有效凭证，具有完全证据效力。</p>
        <p class="for-margin">
            4、本人授权平安集团，除法律另有规定之外，将本人提供给平安集团的信息、享受平安集团服务产生的信息（包括本单证签署之前提供和产生的信息）以及平安集团根据本条约定查询、收集的信息，用于平安集团及其因服务必要委托的合作伙伴为本人提供服务、推荐产品、开展市场调查与信息数据分析。<br/>
            本人授权平安集团，除法律另有规定之外，基于为本人提供更优质服务和产品的目的，向平安集团因服务必要开展合作的伙伴提供、查询、收集本人的信息。<br/>
            为确保本人信息的安全，平安集团及其合作伙伴对上述信息负有保密义务，并采取各种措施保证信息安全。<br/>
            本条款自本单证签署时生效，具有独立法律效力，不受合同成立与否及效力状态变化的影响。<br/>
            本条所称“平安集团”是指中国平安保险（集团）股份有限公司及其直接或间接控股的公司，以及中国平安保险（集团）股份有限公司直接或间接作为其单一最大股东的公司。<br/>
            如您不同意上述授权条款的部分或全部，可致电客服热线（95511）取消或变更授权。
        </p>
    </div>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
export default{
    data () {
        return {
            fontColor:"#ff6600",
            clauseColor:"#2688c4"
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
        document.body.scrollTop = 0;
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
            "浏览投保须知":'浏览投保须知'
        });
    },
    methods: {
        goClause(type){
            this.$router.push({'name':'P1125'});
        },
        seeZY(){
            this.$router.push({'name':'zhiye'});
        }
    }
}
</script>
<style scoped lang="less">
    .header{
        height: 6.6rem;
        background:#4b89dc;
        box-shadow:0px 2px 12px 0px #e9eef5;
    }
    .content{
        padding-top: 4rem;
        padding-right: 2rem;
        padding-left: 2rem;
    }
    h1{
        text-align: center;
        font-size: 2rem;
        margin-bottom: 2rem;
        margin-top: 1rem;
        color: #454545;
    }
    h2{
        font-size: 1.6rem;
        color: #454545;
        margin-bottom: 1.8rem;
    }
    p{
        font-size: 1.5rem;
        color: #454545;
        line-height: 2.2rem;
        padding-left: 1rem;
        padding-right: 1rem;
    }
    .blank{
        text-indent: 4ex
    }
    .for-margin{
        margin-bottom: 1.5rem;
    }
</style>
