<template>
    <section  v-bind:class="{info_box_hidden: !arrow}" class="info_box">
        <div class="info_box_head"  @click="spread" :style="{color:fontColor}">保障期限</div>
        <p class="arrow" @click="spread" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div class="info_box_text">
            <div class="left">自</div>
            <div class="right">{{limitDate}} 零时起</div>
        </div>
        <div class="info_box_text">
            <div class="left">至</div>
            <div class="right">{{deadline}} 二十四时止</div>
        </div>
    </section>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';

export default{
    data(){
        return{
            arrow:true,
            limitDate:"",
            deadline:"",
            fontColor:"#2688c4"
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        }
    },
    computed: {
        ...mapState({
            limitDate:state=>state.asia.infoByProductDetail.effDate,
            deadline:state=>state.asia.infoByProductDetail.effDateEnd
        })
    }
}
</script>
<style  scoped lang="less">
    @import "../../../../styles/insureDetail.less";
</style>
