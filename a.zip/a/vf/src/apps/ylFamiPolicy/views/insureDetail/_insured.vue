<template>
    <div>
    <section v-bind:class="{info_box_hidden: !arrow}" class="info_box insure" ref="troggle" v-for="(item,index) of customerInfoList">
        <div class="info_box_head"  @click="spread" :data-id="index"  :style="{color:fontColor}" v-if="index == '0'">投保人（被保险人{{index + 1}}）</div>
        <div class="info_box_head"  @click="spread" :data-id="index"  :style="{color:fontColor}" v-if="index != '0'">被保险人{{index + 1}}</div>
        <p class="arrow" @click="spread" :data-id="index" v-bind:class="{arrow_up: !arrow}" ref="arrow" :style="{color:fontColor}"></p>
        <div class="info_box_text">
            <div class="info_box_text">
                <div class="left">姓名</div>
                <div class="right" >{{item.name}}</div>
            </div>
            <div v-if="index == 0 || item.relationshipWithPrimaryInsurant == '2'" class="info_box_text">
                <div class="left">职业类型</div>
                <div class="right" >{{item.insurOccupationType}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件类型</div>
                <div class="right" >{{item.appType | apptype}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">性别</div>
                <div class="right" >{{item.sexType | sex}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">出生日期</div>
                <div class="right" >{{item.birthday}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件号码</div>
                <div class="right" >{{item.appNums}}</div>
            </div>
            <div v-if="item.phone" class="info_box_text">
                <div class="left">手机号</div>
                <div class="right" >{{item.phone}}</div>
            </div>
            <div v-if="item.email" class="info_box_text">
                <div class="left">邮箱</div>
                <div class="right" >{{item.email}}</div>
            </div>
    </section>
    </div>
</template>
<script>
import Vue from 'vue'
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import filter from "../../../../utils/filter"
import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"

export default{
    data(){
        return{
            arrow:true,
            fontColor:"#2688c4",
            place:true,
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
    },
    methods: {
        spread(e){
            if(this.$refs.troggle[e.target.dataset.id].className == "info_box insure"){
                this.$refs.troggle[e.target.dataset.id].className = 'info_box insure info_box_hidden'
                this.$refs.arrow[e.target.dataset.id].className = 'arrow arrow_up'
                }else{
                this.$refs.troggle[e.target.dataset.id].className = 'info_box insure'
                this.$refs.arrow[e.target.dataset.id].className = 'arrow'
            }
        }
    },
    computed: {
        ...mapState({
            customerInfoList:state=>state.asia.customerInfoList,
        })
    }
}
Vue.filter( 'apptype' , function(value) {
    switch(value){
        case "01":
            return "身份证";
        case "02":
            return "护照";
        case "03":
            return "军人证";
        case "06":
            return "港澳台回乡证";
        case "07":
            return "出生证";
        case "08":
            return "户口本";
    }
});
Vue.filter( 'sex' , function(value) {
    switch(value){
        case "M":
            return "男";
        case "F":
            return "女";
    }
});
</script>
<style scoped lang="less">
    @import "../../../../styles/insureDetail.less";
    .insure{
        margin: 1rem auto;
    }
    .insure:last-child{
        margin-bottom: 0;
    }
    .insure:first-child{
        margin-top: 0;
    }
</style>
