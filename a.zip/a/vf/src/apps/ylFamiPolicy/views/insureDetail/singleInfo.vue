<template >
    <div>
        <div class="info_box_head" :style="{color:themeColor}" v-if="index == '0'">投保人（被保险人{{index + 1}}）</div>
        <div class="info_box_head" :style="{color:themeColor}" v-if="index != '0'">被保险人{{index + 1}}</div>
        <!--姓名-->
        <div class="info_box_text">
            <div class="left">姓名*</div>
            <input name="name" v-model="name" @input="detailAdd('name')" placeholder="请填写姓名" class="rightblank right" maxlength="8" :disabled="isOpen == 'N'" style="color:#666">
        </div>
        <div v-if="isOpen == 'Y'">
                    <!--职业-->
                    <div v-if="index == 0 || relationshipWithPrimaryInsurant == '2'" class="info_box_text">
                        <div class="left">职业类型*</div>
                        <div @click="selectOcc">
                            <div class="rightarrow" ></div>
                            <div name="type" class="right">{{insurOccupationType || '请选择' | doLen}}</div>
                        </div>
                    </div>
                    <!--与投保人关系-->
                    <div v-if="index != 0" class="info_box_text">
                        <div class="left">与投保人关系*</div>
                        <div>
                            <!--<div class="rightarrow" ></div>-->
                            <div name="type" class="right">{{relationshipWithPrimaryInsurant | relation}}</div>
                        </div>
                    </div>
                    <!--证件类型-->
                    <div class="info_box_text" style="border-bottom: 1px solid #eee;">
                        <div class="left">证件类型*</div>
                        <div @click="chooseType(1)">
                            <div class="rightarrow" ></div>
                            <div name="type" class="right">{{appType | apptypes}}</div>
                        </div>
                        <popup v-model="popupVisible1" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="insurePer(1,'N')" :style="{color:themeColor}">取消</span>
                                <span class="confirm" @click="insurePer(1,'Y')" :style="{color:themeColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="apptypeList" @change="onValuesChange1">
                                </picker>
                            </div>
                        </popup>
                    </div>
                    <div class="info_box_text" v-if="showSexBir">
                        <div class="left">性别*</div>
                        <div @click="chooseType(2)">
                            <div class="rightarrow" ></div>
                            <div name="type" class="right">{{sexType | sex}}</div>
                        </div>
                        <popup v-model="popupVisible2" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="insurePer(2,'N')" :style="{color:themeColor}">取消</span>
                                <span class="confirm" @click="insurePer(2,'Y')" :style="{color:themeColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="sexList" @change="onValuesChange2">
                                </picker>
                            </div>
                        </popup>
                    </div>
                    <div v-if="showSexBir" class="info_box_text" style="border-bottom: 1px solid #eee;">
                        <div class="left">出生日期*</div>
                        <div @click="openDatePic('picker')">
                            <div class="rightarrow" ></div>
                            <span name="birth" class="right">{{birthday}}</span>
                        </div>
                        <datetime-picker
                                ref="picker"
                                type="date"
                                :startDate= "start"
                                :endDate="end"
                                @confirm="dateConfirm"
                                :TPick="TPick"
                        >
                        </datetime-picker>
                    </div>
        </div>
        <div class="info_box_text">
            <div class="left">证件号码*</div>
            <input name="name" v-model="appNums" @input="detailAdd('appNums')" placeholder="请填写证件号码" class="rightblank right" maxlength="18" :disabled="isOpen == 'N'" style="color:#666">
        </div>
        <div v-if="isOpen == 'Y'">
                    <div v-if="index == 0" class="info_box_text">
                        <div class="left">手机号*</div>
                        <input name="name" v-model="phone" @input="detailAdd('phone')" placeholder="请填写手机号" class="rightblank right" maxlength="11">
                    </div>
                    <div v-if="index == 0" class="info_box_text">
                        <div class="left">邮箱</div>
                        <input name="name" v-model="email" @input="detailAdd('email')" placeholder="请填写邮箱" class="rightblank right" maxlength="25">
                    </div>
        </div>
        <div class="info_box_text infolast">
            <cell title="" :style="{color:themeColor}" v-if="isOpen == 'Y'">
                <div @click="save('Y')" class="textright icon_save"><span>保存</span></div>
            </cell>

            <cell title="" :style="{color:themeColor}" v-if="isOpen == 'N'">
                <div @click="save('N')" class="textright icon_edit"><span>编辑</span></div>
            </cell>
        </div>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    /*@import "../../../../assets/iconfonts/health/iconfont.css";*/
    @import "../../../../assets/iconfonts/groupIns/iconfont.css";
    .icon_del:before {
        font-family: "iconfont" !important;
        font-size:2rem;
        fill: currentColor;
        overflow: hidden;
        content: "\e600";
    }
    .icon_edit:before {
        font-family: "iconfont" !important;
        font-size: 1.9rem;
        fill: currentColor;
        overflow: hidden;
        content: "\E648";
        position: absolute;
        right: 3rem;
    }
    .icon_save:before {
        font-family: "iconfont" !important;
        font-size:2rem;
        fill: currentColor;
        overflow: hidden;
        position:absolute;
        right:3rem;
        content: "\e700";
    }
    .infolast{
        border-bottom:none;
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;

    }
    .textright{
        >span{
            position:absolute;
            right:0
        }
        height: 3rem;
        position:relative;
        width:100%;
        text-align:right
    }
    .society{
        float: right;
        /*margin-right: 1rem;*/
    }
    .hasSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        margin-right: 1rem;
        border-radius: 4px;
    }
    .noSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        border-radius: 4px;
    }

    .main-container{
        background-color:@background-color-dark;
        position: absolute;
        width: 100%;
        min-height: 100%;
    }
    .left{
        float:left;
    }
    .right{
        float: right;
        /*width: 20rem;*/
        text-align: right;
        height: 4.3rem;
    }
    .rightDel{
        float: right;
        /*width: 20rem;*/
        text-align: right;
        height: 4.3rem;
        margin-right: 1rem;
    }
    .rightblank{
        //margin-right: 1.5rem;
    }
    .rightarrow{
        float: right;
        width: 1.5rem;
        margin: 1.5rem -0.5rem 0 0.5rem;
        height: 1.8rem;
        background:url("../../../../assets/images/health/arrow.png") no-repeat;
        background-size: 1.6rem 1.6rem;
        position: relative;
    }
    .rightarrow:before{
        content: '';
        position: absolute;
        top: -15px;
        right: -10px;
        bottom: -15px;
        left: -20px;
    }
    .info_box{
        width:95%;
        margin:1.0rem auto;
        border-radius:8px
    }
    input {
        border: none;
        line-height: 4.3rem;
        margin-top: 1px;
        text-align: right;
        font-size: 1.5rem;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        color: #666666;
        background-color:#fff
    }
    .info_box_text{
        height:4.5rem;
        line-height:4.5rem;
        padding: 0 0.8rem 0 1.2rem;
        background-color:#FFFFFF;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.5rem;
        color: #666666;
        border-bottom:1px solid #eee;
    }

    .info_box_text:last-child{
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-bottom:0;
    }
    .info_box_head{
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        text-align:center;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@background-color-light;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.7rem;
        color: @iconfont;
    }
    .showBar{
        height: 40px;
        border-bottom: solid 1px #eaeaea;
    }
    .cancle{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: left;
    }
    .confirm{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: right;
    }
    .picker-items {
        border-top: 1px solid #e4e4e4;
    }
    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
    }
    .next_button>p{
        width:95%;
        margin:0rem auto 0;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@font-color-blue;
        border-radius:8px;
        color:#FFF;
        font-size:1.7rem;
        line-height:4.5rem;
        text-align:center;
    }
    #sex_2,#sex_1{

    }
    input#checkInput {
        display: none;
    }
    #checkInput +label{
        -webkit-appearance: none;
        background-color: #fafafa;
        border: 1px solid @font-color-grey;
        padding: 0.7rem;
        display: inline-block;
        border-radius:0.4rem;
        position: relative;
        top:3px
    }

    #checkInput+label{
        background-color: #fff;
        border: 1px solid @font-color-grey;
        position: relative;
    }
    #checkInput+label::before {
        content: '';
        position: absolute;
        top: -13px;
        right: -13px;
        bottom: -13px;
        left: -13px;
    }
    #checkInput:checked+label:before{
        font-family: "health" !important;
        content: "\e63a";
        /*color: @iconfont;*/
        position: absolute;
        top: -1.5rem;
        font-size: 1.5rem;
        left: 0px;
    }
    .mail{
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
    }
    .leftMail{
        -webkit-box-flex: 1;
        -ms-flex: 1;
        flex: 1
    }
    .rightMail{
        -webkit-box-flex: 3;
        -ms-flex: 3;
        flex: 3
    }
    .Infro>section:last-child{
        margin-bottom: 8rem;
    }

</style>
<script>
    import Vue from 'vue'
    import {Msg} from "components";
    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import cell from '../../../../components/cell/index.vue'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import * as asiaAc from "../../vuex/actionTypes/asia.action.types"
    import filter from "../../../../utils/filter"

    export default{
        props: {
            //回调函数
            fnt:{
                type:Function,
                default:function(){
                }
            },
            //序号
            index:{
                type:Number,
                default:0
            },
            obj:{
                type:String,
                default:''
            }
        },
        data(){
            return{
                info:{
                },
                TPick:"end",
                apptypeList:[{//,'出生证'
                    flex: 1,
                    values:['身份证','护照','军人证','港澳台回乡证','户口本']
                }],
                sexList:[{
                    flex: 1,
                    values:['男','女'],
                }],
                appType:'',
                sexType:"",
                birthday:"",
                nowBirthday:"",//解决身份证类型输入身份证时，生日显示异常
                minBir:"",
                maxBir:"",
                name:"",
                appNums:"",
                phone:"",
                email:"",
                insurOccupationType:"",
                relationshipWithPrimaryInsurant:"",
                isOpen:"Y",

                showSexBir:false,//
                selected1:"身份证",
                selected2:"男",
                popupVisible1:false,
                popupVisible2:false,
                start:new Date(),
                end:new Date(),
                themeColor:"#2688c4"
            }
        },
        components:{
            datetimePicker,
            picker,
            popup,
            cell
        },
        update(){
            console.log(111)
        },
        methods: {
            chooseType(num){
                this['popupVisible' + num] = true;
            },
            insurePer(num,type){
                if(num == '1' && type == 'Y'){//证件类型
                    if(this.selected1 == '身份证'){
                        this.appType = '01';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{appType:"01"}]);
                    }else if(this.selected1 == '护照'){
                        this.appType = '02';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{appType:"02"}]);
                    }else if(this.selected1 == '军人证'){
                        this.appType = '03';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{appType:"03"}]);
                    }else if(this.selected1 == '港澳台回乡证'){
                        this.appType = '06';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{appType:"06"}]);
                    }else if(this.selected1 == '出生证'){
                        this.appType = '07';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{appType:"07"}]);
                    }else if(this.selected1 == '户口本'){
                        this.appType = '08';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{appType:"08"}]);
                    }
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "被保人信息页面",{
                        "被保人证件类型":this.selected1
                    });
                }else if(num == '2' && type == 'Y'){//性别
                    if(this.selected2 == '男'){
                        this.sexType = 'M';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{sexType:"M"}]);
                    }else if(this.selected2 == '女'){
                        this.sexType = 'F';
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{sexType:"F"}]);
                    }
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "被保人信息页面",{
                        "被保人性别":this.selected2
                    });
                }
                this['popupVisible' + num] = false
            },
            onValuesChange1(picker, values){
                this.selected1 = values[0];
            },
            onValuesChange2(picker, values){
                this.selected2 = values[0];
            },
            onValuesChange3(picker, values){
                this.selected3 = values[0];
            },
            openDatePic(type){
                this.TPick = "start"
                this.$refs[type].open();
            },
            dateConfirm(confirm){
                let year = confirm.getFullYear(),
                        month = confirm.getMonth()+1 ,
                        day = confirm.getDate();
                if(month < 10) month = "0" +month
                if(day < 10) day = "0" + day;
                this.birthday = year + '-'+ month + '-' + day;
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保人信息页面",{
                    "被保人生日":this.birthday.indexOf('-') > -1 ? this.birthday.substring(0,7) : this.birthday.substring(0,6)
                });
                this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{birthday:year + '-'+ month + '-' + day}]);
            },
            detailAdd(type){
                let o = {};
                o[type] = event.target.value;
                this[type] = event.target.value;
                this.$store.commit(asiaMu.upCustomerInfoList,[this.index,o]);
                if(type == 'appNums' &&　(this.appType == '01' || this.appType == '08')){
                    let bir = filter.check.birthID(this.appNums);
                    bir = bir.substring(0,4) + '-' + bir.substring(4,6) + '-' + bir.substring(6,8);
                    this.nowBirthday = bir;
                    let sex = filter.check.sexconfirm(this.appNums);
                    this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{birthday:bir,sexType:sex}]);
                }
            },
            selectOcc(){
                this.$store.commit(asiaMu.setPersonOccByIndex,this.index);
                this.$router.push({'name':"occupation"})
            },
            checkVal(){
                if(!this.name){
                    Msg.alert('该被保人姓名不可为空')
                    return false;
                }else if(!filter.check.checkName(this.name)){
                    Msg.alert('该被保人姓名格式不正确')
                    return false;
                }
                if(this.relationshipWithPrimaryInsurant != '3'){
                    if(!this.insurOccupationType){
                        Msg.alert('请选择该被保人职业')
                        return false;
                    }else{
                        if(this.grade[this.index] == '0' || (this.grade[this.index] && this.grade[this.index] > this.maxDangerGrade)){
                            Msg.alert('该被保人职业不在投保范围内，请重新选择')
                            return false;
                        }
                    }
                }
                if(this.appNums){
                    if(this.appType == "01" || this.appType == "08"){
                        if(!filter.check.EmitIdCodeValid(this.appNums)){
                            Msg.alert('该被保人证件号码不正确')
                            return false;
                        }
                        if(Date.parse(this.nowBirthday) < Date.parse(this.minBir) || Date.parse(this.nowBirthday) > Date.parse(this.maxBir)){//maxBir:"2016-11-17",minBir:"2015-05-18"
                            Msg.alert('该被保人出生日期不在该年龄段，请检查')
                            return false;
                        }
                    }else{
                        //投保人护照校验
                        if(this.appType == "02"){
                            if(!filter.check.checkPassport(this.appNums)){
                                Msg.alert('该被保人护照号码不正确')
                                return false;
                            }
                        }
                        //投保人军人证校验
                        if(this.appType == "03"){
                            if(!filter.check.armymanId(this.appNums)){
                                Msg.alert('该被保人军人证号码不正确')
                                return false;
                            }
                        }
                        //投保人出生证校验
                        if(this.appType == "07"){
                            if(!filter.check.checkBirthCard_emit(this.appNums)){
                                Msg.alert('该被保人出生证号码不正确')
                                return false;
                            }
                        }
                        //投保人港澳台回乡证
                        if(this.appType == "06"){
                            if(!filter.check.checkHK(this.appNums)){
                                Msg.alert('该被保人港澳台回乡证号码不正确')
                                return false;
                            }
                        }
                    }
                }else{
                    Msg.alert('该被保人证件号码不为空')
                    return false;
                }
                if(this.phone){
                    if(!filter.check.checkPh(this.phone)){
                        Msg.alert('该被保人手机号格式不正确')
                        return false;
                    }
                }
                if(Date.parse(this.birthday) < Date.parse(this.info.minBir) || Date.parse(this.birthday) > Date.parse(this.info.maxBir)){//maxBir:"2016-11-17",minBir:"2015-05-18"
                    Msg.alert('该被保人出生日期不在该年龄段，请检查')
                    return false;
                }
                return true;
            },
            save(type){
                if(type == 'Y'){
                    if(this.checkVal()){
                        this.isOpen = 'N'
                        this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{isOpen:'N'}]);
                    }
                }else{
                    this.isOpen = 'Y'
                    this.$store.commit(asiaMu.upCustomerInfoList,[this.index,{isOpen:'Y'}]);
                }
            }
        },
        computed:{
            ...mapState({
                maxDangerGrade:state=>state.asia.productDetail.maxDangerGrade,
                grade:state=>state.asia.grade
            })
        },
        watch:{
            appType(){
                if(!(this.appType == '01' || this.appType == '08')){
                    this.showSexBir = true;
                }else{
                    this.showSexBir = false;
                }
            }
        },
        mounted(){
            this.themeColor = sessionStorage.fontColor;
            this.info = JSON.parse(this.obj);

            this.appType = this.info.appType;
            this.sexType = this.info.sexType;
            this.birthday = this.info.birthday;
            this.minBir = this.info.minBir;
            this.maxBir = this.info.maxBir;
            this.name = this.info.name;
            this.appNums = this.info.appNums;
            this.phone = this.info.phone;
            this.email = this.info.email;
            this.insurOccupationType = this.info.insurOccupationType;
            this.relationshipWithPrimaryInsurant = this.info.relationshipWithPrimaryInsurant;
            this.isOpen = this.info.isOpen;

            this.start = new Date(this.info.minBir);
            this.end = new Date(this.info.maxBir);
            if(this.relationshipWithPrimaryInsurant == '3'){//子女证件类型控制
                this.apptypeList[0].values.length = 3;
            }
        },
        beforeMount(){

        }
    }
Vue.filter( 'apptypes' , function(value) {
    switch(value){
        case "01":
            return "身份证";
        case "02":
            return "护照";
        case "03":
            return "军人证";
        case "06":
            return "港澳台回乡证";
        case "07":
            return "出生证";
        case "08":
            return "户口本";
    }
});
Vue.filter( 'sex' , function(value) {
    switch(value){
        case "M":
            return "男";
        case "F":
            return "女";
    }
});
Vue.filter( 'relation' , function(value) {
    switch(value){
        case "1":
            return "本人";
        case "2":
            return "配偶";
        case "3":
            return "子女";
    }
});
Vue.filter( 'doLen' , function(value) {
    if(value.length > 10){
        return value.substring(0,10) + '...'
    }
    return value
});
</script>
