<template>
    <section v-bind:class="{info_box_hidden: !arrow}" class="inContent info_box">
        <div class="info_box_head"  @click="spread" :style="{color:fontColor}">保障内容</div>
        <p class="arrow" @click="spread" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div v-for="(duty,index) in dutyItems" @click="spreadDetail" :data-id="index" ref="spreadTitle" class="info_box_text">
            <div v-if="duty.dutyName">
                <div class="left dutyName" :data-id = "index">{{duty.dutyName}}</div>
                <div class="right arrow1" :data-id = "index">{{duty.amountName}}</div>
                <hr style="width: 110%;margin-left: -5%;border-top: 1px dashed #aaa;margin-bottom: 0; margin-top: 0;"  class="hide">
                <div class="hide small_text" :data-id = "index">
                    <div class="undwrtRange">{{duty.undwrtRange}}</div>
                </div>
            </div>
            <div v-if="!duty.dutyName">
                <div class="left dutyName" :data-id = "index"><b>{{duty.name}}</b></div>
            </div>
        </div>
    </section>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';

export default{
    data(){
        return{
            arrow:true,
            fontColor:"#2688c4"
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        },
        spreadDetail(event){
            let dom;
            if(event.target.nodeName == 'B') return;//点到标题，不执行
            if(event.target.className == 'left dutyName' && event.target.children.length == 1) return;//点到标题，不执行
            if(event.target.className == 'info_box_text'){//点到循环的祖父级，定位到父级
                if(event.target.nodeName == 'B' || event.target.children.length == 1) return;//点到标题，不执行
                dom = event.target.children[0];
            }else if(event.target.className == ''){//点到div，不执行
                dom = event.target;
            }else if(event.target.className == 'undwrtRange'){//点到责任详细，不执行
                return;
            }else{//点到子级，定位到父级
                dom = event.target.parentNode;
            }
            dom.children[1].className = dom.children[1].className == "right arrow1" ? "right arrow-b": "right arrow1"
            dom.children[2].className = dom.children[2].className == "hide" ? "": "hide"
            dom.children[3].className = dom.children[3].className =="hide small_text" ? "small_text" :"hide small_text"
        }
    },
    computed: {
        ...mapState({
            dutyItems:state=>state.asia.infoByProductDetail.dutyItems,
        })
    }
}
</script>
<style scoped lang="less">
    @import "../../../../styles/insureDetail.less";
    .hide{
        display: none;
    }
    .dutyName{
        width: 45%;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        display: inline-block;
    }
</style>
