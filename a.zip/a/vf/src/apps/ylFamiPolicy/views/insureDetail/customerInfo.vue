<template >
    <div id="customerInfo">
        <article class="Infro">
            <!--投保人信息-->
            <section class="info_box" v-for="(objs,index) of customerInfoList">
                <singleinfo :index="index" :obj="JSON.stringify(objs)" :fnt="action"></singleinfo>
            </section>
        </article>
        <div class="next_button" @click="next">
            <p :style="{backgroundColor:themeColor}">下一步</p>
        </div>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    /*@import "../../../../assets/iconfonts/health/iconfont.css";*/
    @import "../../../../assets/iconfonts/groupIns/iconfont.css";
    .icon_del:before {
        font-family: "iconfont" !important;
        font-size:2rem;
        fill: currentColor;
        overflow: hidden;
        content: "\e600";
    }

    .society{
        float: right;
        /*margin-right: 1rem;*/
    }
    .hasSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        margin-right: 1rem;
        border-radius: 4px;
    }
    .noSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        border-radius: 4px;
    }

    .main-container{
        background-color:@background-color-dark;
        position: absolute;
        width: 100%;
        min-height: 100%;
    }
    .left{
        float:left;
    }
    .right{
        float: right;
        /*width: 20rem;*/
        text-align: right;
        height: 4.3rem;
    }
    .rightDel{
        float: right;
        /*width: 20rem;*/
        text-align: right;
        height: 4.3rem;
        margin-right: 1rem;
    }
    .rightblank{
        //margin-right: 1.5rem;
    }
    .rightarrow{
        float: right;
        width: 1.5rem;
        margin: 1.5rem -0.5rem 0 0.5rem;
        height: 1.8rem;
        background:url("../../../../assets/images/health/arrow.png") no-repeat;
        background-size: 1.6rem 1.6rem;
        position: relative;
    }
    .rightarrow:before{
        content: '';
        position: absolute;
        top: -15px;
        right: -10px;
        bottom: -15px;
        left: -20px;
    }
    .info_box{
        width:95%;
        margin:1.0rem auto;
        border-radius:8px
    }
    input {
        border: none;
        line-height: 4.3rem;
        margin-top: 1px;
        text-align: right;
        font-size: 1.5rem;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        color: #666666;
        background-color:#fff
    }
    .info_box_text{
        height:4.5rem;
        line-height:4.5rem;
        padding: 0 0.8rem 0 1.2rem;
        background-color:#FFFFFF;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.5rem;
        color: #666666;
        border-bottom:1px solid #eee;
    }

    .info_box_text:last-child{
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-bottom:0;
    }
    .info_box_head{
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        text-align:center;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@background-color-light;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.7rem;
        color: @iconfont;
    }
    .showBar{
        height: 40px;
        border-bottom: solid 1px #eaeaea;
    }
    .cancle{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: left;
    }
    .confirm{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: right;
    }
    .picker-items {
        border-top: 1px solid #e4e4e4;
    }
    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
    }
    .next_button>p{
        width:95%;
        margin:0rem auto 0;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@font-color-blue;
        border-radius:8px;
        color:#FFF;
        font-size:1.7rem;
        line-height:4.5rem;
        text-align:center;
    }
    #sex_2,#sex_1{

    }
    input#checkInput {
        display: none;
    }
    #checkInput +label{
        -webkit-appearance: none;
        background-color: #fafafa;
        border: 1px solid @font-color-grey;
        padding: 0.7rem;
        display: inline-block;
        border-radius:0.4rem;
        position: relative;
        top:3px
    }

    #checkInput+label{
        background-color: #fff;
        border: 1px solid @font-color-grey;
        position: relative;
    }
    #checkInput+label::before {
        content: '';
        position: absolute;
        top: -13px;
        right: -13px;
        bottom: -13px;
        left: -13px;
    }
    #checkInput:checked+label:before{
        font-family: "health" !important;
        content: "\e63a";
        /*color: @iconfont;*/
        position: absolute;
        top: -1.5rem;
        font-size: 1.5rem;
        left: 0px;
    }
    .mail{
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
    }
    .leftMail{
        -webkit-box-flex: 1;
        -ms-flex: 1;
        flex: 1
    }
    .rightMail{
        -webkit-box-flex: 3;
        -ms-flex: 3;
        flex: 3
    }
    .Infro>section:last-child{
        margin-bottom: 8rem;
    }

</style>
<script>
    import Vue from 'vue'
    import {Msg}from "components";
    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import singleinfo from './singleInfo.vue'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import {recordInsured} from "../../apis/asia.api"
    import filter from "../../../../utils/filter"

    export default{
        data(){
            return{
                themeColor:'#2688c4',
                isOk:true,
            }
        },
        components:{
            datetimePicker,
            picker,
            popup,
            singleinfo
        },
        beforeMount(){
            if(this.$store.state.asia.productDetail){
                sessionStorage.stateObj = JSON.stringify(this.$store.state.asia);
            }else{
                this.$store.commit(asiaMu.setState,JSON.parse(sessionStorage.stateObj));
            }
        },
        mounted(){
            this.themeColor = sessionStorage.fontColor;
        },
        methods: {
            action(type){
                this.isOk = type;
            },
            checkVal(){
                let flag = true;
                for(let i = 0; i <this.customerInfoList.length;i++){
                    if(!this.customerInfoList[i].name){
                        Msg.alert('第' + (i + 1) + '位被保人姓名不可为空')
                        flag = false;
                        break;
                    }else if(!filter.check.checkName(this.customerInfoList[i].name)){
                        Msg.alert('第' + (i + 1) + '位被保人姓名格式不正确')
                        flag = false;
                        break;
                    }
                    if(!this.customerInfoList[i].eName){
                        Msg.alert('第' + (i + 1) + '位被保人英文名不可为空')
                        flag = false;
                        break;
                    }else if(!/^[A-Za-z ]+$/.test(this.customerInfoList[i].eName)){
                        Msg.alert('投保人英文名不正确')
                        return false;
                    }

                    if(this.customerInfoList[i].appNums){
                        if(this.customerInfoList[i].appType == "01" || this.customerInfoList[i].appType == "08"){
                            if(!filter.check.EmitIdCodeValid(this.customerInfoList[i].appNums)){
                                Msg.alert('第' + (i + 1) + '位被保人证件号码不正确')
                                flag = false;
                                break;
                            }
                        }else{
                            //投保人护照校验
                            if(this.customerInfoList[i].appType == "02"){
                                if(!filter.check.checkPassport(this.customerInfoList[i].appNums)){
                                    Msg.alert('第' + (i + 1) + '位被保人护照号码不正确')
                                    flag = false;
                                    break;
                                }
                            }
                            //投保人军人证校验
                            if(this.customerInfoList[i].appType == "03"){
                                if(!filter.check.armymanId(this.customerInfoList[i].appNums)){
                                    Msg.alert('第' + (i + 1) + '位被保人军人证号码不正确')
                                    flag = false;
                                    break;
                                }
                            }
                            //投保人出生证校验
                            if(this.customerInfoList[i].appType == "07"){
                                if(!filter.check.checkBirthCard_emit(this.customerInfoList[i].appNums)){
                                    Msg.alert('第' + (i + 1) + '位被保人出生证号码不正确')
                                    flag = false;
                                    break;
                                }
                            }
                            //投保人港澳台回乡证
                            if(this.customerInfoList[i].appType == "06"){
                                if(!filter.check.checkHK(this.customerInfoList[i].appNums)){
                                    Msg.alert('第' + (i + 1) + '位被保人港澳台回乡证号码不正确')
                                    flag = false;
                                    break;
                                }
                            }
                        }
                    }else{
                        Msg.alert('第' + (i + 1) + '位被保人证件号码不为空')
                        flag = false;
                        break;
                    }
                    if(this.customerInfoList[i].phone){
                        if(!filter.check.checkPh(this.customerInfoList[i].phone)){
                            Msg.alert('第' + (i + 1) + '位被保人手机号格式不正确')
                            flag = false;
                            break;
                        }
                    }
                }
                return flag;
            },
            checkBir(){//校验生日是否符合
                let flag = true;
                for(let i = 0; i <this.customerInfoList.length;i++){
                    if(Date.parse(this.customerInfoList[i].birthday) < Date.parse(this.customerInfoList[i].minBir) || Date.parse(this.customerInfoList[i].birthday) > Date.parse(this.customerInfoList[i].maxBir)){//maxBir:"2016-11-17",minBir:"2015-05-18"
                        Msg.alert('第' + (i + 1) + '位被保人出生日期不在该年龄段，请检查')
                        flag = false;
                        break;
                    }
                }
                return flag;
            },
            checkSame(memberDetail){
                let arr = [];
                for(let i = 0;i < memberDetail.length;i++){
                    arr.push(memberDetail[i].appNums);
                }
                return filter.check.isRepeat(arr);
            },
            next(){
                //if(this.checkVal()){
                    //if(this.checkBir()){
                        let flag = false;
                        for(let i = 0;i < this.customerInfoList.length;i++){
                            if(this.customerInfoList[i].isOpen == 'Y'){
                                Msg.alert('请先保存第'+(i+1)+'位被保人信息')
                                flag = true
                                break
                            }
                        }
                        if(!flag){
                            if(this.customerInfoList[1].relationshipWithPrimaryInsurant == '2' && this.customerInfoList[1].sexType == this.customerInfoList[0].sexType){//校验本人和配偶性别
                                Msg.alert('配偶性别不能与本人相同，请核对')
                                return
                            }
                            if(!this.checkSame(this.customerInfoList)){
                                this.recordInsured();
                            }else{
                                Msg.alert('证件号码有重复，请核对')
                            }
                        }

                    //}
                //}
            },
            recordInsured(){
                let obj = {//insurePerson,customerInfoList
                    "appClientName":this.customerInfoList[0].name,
                    "appIdType":this.customerInfoList[0].appType,
                    "appIdNo":this.customerInfoList[0].appNums,
                    "appGender":this.customerInfoList[0].sexType,
                    "appBirthday":this.customerInfoList[0].birthday.replace(/-/g, ""),
                    "appMobile":this.customerInfoList[0].phone,
                    "appMail":this.customerInfoList[0].email,
                    "appOccupationType":this.customerInfoList[0].insurOccupationTypeCode,
                    "saleRecordId":this.$store.state.asia.infoByProductDetail.saleRecordId
                };
                let _arr = [],_obj = {};
                for(let i = 0; i <this.customerInfoList.length;i++){
                    let _bir = this.customerInfoList[i].birthday;
                    _bir = _bir.replace(/-/g, "");
                    _obj.insurGender = this.customerInfoList[i].sexType;//	被保人性别
                    _obj.insurClientName = this.customerInfoList[i].name;//	被保人姓名
                    _obj.insurEnglishName = this.customerInfoList[i].eName;//	投保人英文名
                    _obj.insurIdType = this.customerInfoList[i].appType;//	被保人证件类型
                    _obj.insurIdNo = this.customerInfoList[i].appNums;//	被保人证件号码
                    _obj.insurBirthday = _bir;//	被保人生日
                    _obj.insurMobile = this.customerInfoList[i].phone;
                    _obj.insurOccupationType = this.customerInfoList[i].insurOccupationTypeCode || null;
                    _obj.relationshipWithPrimaryInsurant = this.customerInfoList[i].relationshipWithPrimaryInsurant;
                    _obj.jnt = i == 0 ? 'N' : 'Y';//是否是连带保险人
                    _obj.saleRecordId = this.$store.state.asia.infoByProductDetail.saleRecordId;
                    _obj.seqno = i;
                    _arr.push(_obj);
                    _obj = {};
                };
                obj.Insurants = _arr;
                recordInsured(obj).then(({body}) => {
                    if(body.resultCode == "00000"){
                        this.$router.push({'name':"showInfo"})
                    }else{
                        Msg.alert(body.resultMsg)
                    }
                })
            }
        },
        computed: {
            ...mapState({
                customerInfoList:state=>state.asia.customerInfoList,
                insurePerson:state=>state.asia.insurePerson,
                insNum(state){
                    let num = state.asia.numbers;
                    return Number(num[0])+Number(num[1])+Number(num[2])+Number(num[3]);
                },
            })
        }
    }

    Vue.filter( 'apptype' , function(value) {
        switch(value){
            case "01":
                return "身份证";
            case "02":
                return "护照";
            case "03":
                return "军人证";
            case "06":
                return "港澳台回乡证";
            case "07":
                return "出生证";
            case "08":
                return "户口本";
        }
    });
</script>