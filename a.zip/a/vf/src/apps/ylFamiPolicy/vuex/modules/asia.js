/**
 * Created by zhangping702 on 16/12/28.
 */

import Msg from '../../../../components/Msg/Msg'
import filter from '../../../../utils/filter'
import { policyInquiry} from '../../apis/asia.api'
import * as asiaMu from "../mutationTypes/asia.mutation.types.js"
import * as asiaAc from "../actionTypes/asia.action.types.js"

export default {
    //状态
    state: {
        productDetail:'',//产品详情数据
        infoByProductDetail:{//处理初始化数据得到想要数据
            insType:[],//人群
            dataSlots1:[{flex: 1,values:[]}],
            insObj:{},//被选中的人群信息
            product:[],//产品类型
            dutyItems:[],//责任
            idProductCombined:'',//目前选中的套餐
            saleRecordId:"",
            effDate:"",//生效日
            effDateEnd:"",//截止日
            effDateMax:"",
            effDateMin:"",
            bbrBirMax:"",
            bbrBir:"",
            bbrBirMin:"",
        },
        insurePerson:{
            //本人的
            birthday:"",
            maxBir:"",
            minBir:"",
            //配偶的
            _birthday:"",
            _maxBir:"",
            _minBir:""
        },
        customerInfoList:[{//默认本人
            name:"",
            insurOccupationType:"",
            insurOccupationTypeCode:"",
            relationshipWithPrimaryInsurant:"1",//123本人配偶子女
            appType:'01',
            appNums:"",
            phone:"",
            sexType:"M",//性别
            birthday:"",//生日
            email:"",
            maxBir:"",//生日最大值---时间戳上最大
            minBir:"",//最小值
            isOpen:'Y'//是否展开状态
        }],
        occupationList:[],//职业列表
        occupationCode:"",//查职业列表所需参数，后续有用
        occupationCode2:"",//查职业列表所需参数，后续有用，回退到二级职业有用
        occupationName:"",//查职业列表所需中间变量，后续有用
        personOccIndex:"",//设置录单页人职业标记，后续有用,区分本人还是配偶选择职业
        grade:{},//职业等级
        price:""
    },
    //改变状态（同步）
    mutations: {
        [asiaMu.setProductDetail](state,data){//产品详情数据
            state.productDetail = data;
            //对人群排序（后端是根据人群最小年龄从小到大排序，不符合，需要本人及配偶排在最前面）
            let _pList = data.insurPersons[data.insurPersons.length - 1];
            data.insurPersons.unshift(_pList);
            data.insurPersons.length = data.insurPersons.length - 1;
            //操作人群可选范围
            state.infoByProductDetail.insType = data.insurPersons;
            let _insType = state.infoByProductDetail.insType;
            for(let m2 = 0;m2 < _insType.length;m2++){
                if(m2 == 0) state.infoByProductDetail.insObj = _insType[m2];
                state.infoByProductDetail.dataSlots1[0].values.push(_insType[m2].personName);
            }
            //操作套餐、责任
            //let _arr = JSON.parse(JSON.stringify(data.personProducts));
            let _arr = data.personProducts;
            state.infoByProductDetail.product = [];
            state.infoByProductDetail.dutyItems = [];
            for(let k in _arr){//这三循环目的是state.infoByProductDetail.product添加undwrtRange属性值
                for(let i = 0;i < _arr[k].length;i++){
                    for(let j = 0;j < _arr[k][i].dutys.length;j++){
                        for(let l in data.dutyItems){
                            if(_arr[k][i].dutys[j].dutyId == l){
                                _arr[k][i].dutys[j].undwrtRange = data.dutyItems[l].undwrtRange;
                            }
                        }
                    }
                    /*if(_arr[k][i].isDefault == 'Y'){//取责任和当前套餐id
                        state.infoByProductDetail.dutyItems = _arr[k][i].dutys;
                        state.infoByProductDetail.idProductCombined = _arr[k][i].idProductCombined;
                        state.infoByProductDetail.product = _arr[k];
                    }*/
                }
            }
            //操作套餐、责任
            state.infoByProductDetail.product = state.productDetail.personProducts[state.infoByProductDetail.insObj.idPersonType];
            //state.infoByProductDetail.dutyItems = state.infoByProductDetail.product[0].dutys;
            //操作责任，特殊处理
            let dutyList = state.infoByProductDetail.product[0].dutys;
            let dObj = {},dList=[],o1 = {isChild:true,name:'投保人的子女'},o2 = {isChild:false,name:'投保人及配偶'},readyHasChild=false,readyHasPo=false;
            for(let p = 0;p < dutyList.length;p++){
                dObj = JSON.parse(JSON.stringify(dutyList[p]));
                if(dObj.dutyName.indexOf('child') > -1){
                    if(!readyHasChild){
                        dList.push(o1);
                        readyHasChild = true
                    }
                    dObj.dutyName = dObj.dutyName.substring(0,dObj.dutyName.length-7);
                    dList.push(dObj);
                }else{
                    dList.unshift(dObj);
                    readyHasPo = true
                }
                dObj = {}
            }
            if(readyHasPo) dList.unshift(o2);
            state.infoByProductDetail.dutyItems = dList;
            state.infoByProductDetail.product[0].isDefault = 'Y';
            state.infoByProductDetail.idProductCombined = state.infoByProductDetail.product[0].idProductCombined;
            //生效日
            if(data.fixedEffDate){
                state.infoByProductDetail.effDateMax = state.infoByProductDetail.effDateMin =
                    data.fixedEffDate.substring(0,4)+'-'+data.fixedEffDate.substring(5,7)+'-'+data.fixedEffDate.substring(8,11)
            }else if(!data.fixedEffDate && data.minEffDelay ){
                let t1 = Date.parse(new Date()) + data.minEffDelay*(60*60*24*1000);
                let y = new Date(t1).getFullYear(),m = new Date(t1).getMonth() + 1,d = new Date(t1).getDate();
                if(m < 10) m = "0" + m;
                if(d < 10) d = "0" + d;
                state.infoByProductDetail.effDateMin = y + '-'+ m + '-' + d;
                let t2 = Date.parse(new Date()) + data.maxEffDelay*(60*60*24*1000);
                let y1 = new Date(t2).getFullYear(),m1 = new Date(t2).getMonth() + 1,d1 = new Date(t2).getDate();
                if(m1 < 10) m1 = "0" + m1;
                if(d1 < 10) d1 = "0" + d1;
                state.infoByProductDetail.effDateMax = y1 + '-'+ m1 + '-' + d1;
            }
            state.infoByProductDetail.effDate = state.infoByProductDetail.effDateMin;
            let temp1 = Date.parse(state.infoByProductDetail.effDate) - 60*60*24*1000;
            let temp2 = new Date(temp1).getFullYear()+1,temp3 = new Date(temp1).getMonth() + 1,temp4 = new Date(temp1).getDate();
            if(temp3 < 10) temp3 = "0" + temp3;
            if(temp4 < 10) temp4 = "0" + temp4;
            state.infoByProductDetail.effDateEnd = temp2 + '-'+ temp3 + '-' + temp4;//截止日
            //操作投保人生日范围(本人)
            let _birObj = filter.birTimeRangeZs(data.appAgeMin,data.appAgeMax,25,28);
            state.insurePerson.maxBir = _birObj.max;
            state.insurePerson.birthday = _birObj.max;
            //state.insurePerson.minBir = _birObj.min;为了跟好福利家庭险保持一致
            let yy = new Date(state.infoByProductDetail.effDate).getFullYear() - data.appAgeMax - 1,mm = new Date(state.infoByProductDetail.effDate).getMonth() + 1,dd = new Date(state.infoByProductDetail.effDate).getDate();
            if(mm < 10) mm = "0" + mm;
            if(dd < 10) dd = "0" + dd;
            let p = Date.parse(new Date(yy + '-'+ mm + '-' + dd)) + 24*60*60*1000;
            let a = new Date(p).getFullYear(),b = new Date(p).getMonth() + 1,c = new Date(p).getDate();
            if(b < 10) b = "0" + b;
            if(c < 10) c = "0" + c;
            state.insurePerson.minBir = a + '-'+ b + '-' + c;
            //操作被保人生日范围(配偶)
            let _y = new Date(state.infoByProductDetail.effDate).getFullYear() - data.appAgeMin,_m = new Date(state.infoByProductDetail.effDate).getMonth() + 1,_d = new Date(state.infoByProductDetail.effDate).getDate();
            if(_m < 10) _m = "0" + _m;
            if(_d < 10) _d = "0" + _d;
            state.insurePerson._maxBir = state.insurePerson._birthday = _y + '-'+ _m + '-' + _d;
            state.insurePerson._minBir = state.insurePerson.minBir;
            //设置本人生日范围
            state.customerInfoList[0].maxBir = state.insurePerson.maxBir;
            state.customerInfoList[0].birthday = state.insurePerson.maxBir;
            state.customerInfoList[0].minBir = state.insurePerson.minBir;
            //操作被保人生日范围(子女)
            let _bbrBir = filter.getChildBirByEff(state.infoByProductDetail.effDate);
            state.infoByProductDetail.bbrBirMax = _bbrBir.max;
            state.infoByProductDetail.bbrBir = _bbrBir.max;
            state.infoByProductDetail.bbrBirMin = _bbrBir.min;
            //初始化customerInfoList里面数据
            let obj = getNumByZh(state.infoByProductDetail.insObj.personName);
            let single = {
                name:"",
                insurOccupationType:"",
                insurOccupationTypeCode:"",
                relationshipWithPrimaryInsurant:"2",//123本人配偶子女
                appType:'01',
                appNums:"",
                phone:"",
                sexType:"F",//性别
                birthday:state.insurePerson._maxBir,//生日
                email:"",
                maxBir:state.insurePerson._maxBir,//生日最大值---时间戳上最大
                minBir:state.insurePerson._minBir,//最小值
                isOpen:'Y'//是否展开状态
            }
            if(obj.mate > 0){
                state.customerInfoList.push(JSON.parse(JSON.stringify(single)));
            }
            if(obj.child > 0){
                single.relationshipWithPrimaryInsurant = '3';
                single.maxBir = state.infoByProductDetail.bbrBirMax;
                single.birthday = state.infoByProductDetail.bbrBirMax;
                single.minBir = state.infoByProductDetail.bbrBirMin;
                while (obj.child > 0){
                    state.customerInfoList.push(single);
                    obj.child--;
                }
            }
        },
        [asiaMu.seteffDate](state,data){//选择生效日时，重新设定投被保人生日范围
            state.infoByProductDetail.effDate = data;
            let temp1 = Date.parse(state.infoByProductDetail.effDate) + 60*60*24*1000;
            let temp2 = new Date(temp1).getFullYear()+1,temp3 = new Date(temp1).getMonth() + 1,temp4 = new Date(temp1).getDate();
            if(temp3 < 10) temp3 = "0" + temp3;
            if(temp4 < 10) temp4 = "0" + temp4;
            state.infoByProductDetail.effDateEnd = temp2 + '-'+ temp3 + '-' + temp4;//截止日
            let yy = new Date(state.infoByProductDetail.effDate).getFullYear() - state.productDetail.appAgeMax-1,mm = new Date(state.infoByProductDetail.effDate).getMonth() + 1,dd = new Date(state.infoByProductDetail.effDate).getDate();
            if(mm < 10) mm = "0" + mm;
            if(dd < 10) dd = "0" + dd;
            let p = Date.parse(new Date(yy + '-'+ mm + '-' + dd)) + 24*60*60*1000;
            let a = new Date(p).getFullYear(),b = new Date(p).getMonth() + 1,c = new Date(p).getDate();
            if(b < 10) b = "0" + b;
            if(c < 10) c = "0" + c;
            state.insurePerson.minBir = a + '-'+ b + '-' + c;
            //操作被保人生日范围(配偶)
            let _y = new Date(state.infoByProductDetail.effDate).getFullYear() - state.productDetail.appAgeMin,_m = new Date(state.infoByProductDetail.effDate).getMonth() + 1,_d = new Date(state.infoByProductDetail.effDate).getDate();
            if(_m < 10) _m = "0" + _m;
            if(_d < 10) _d = "0" + _d;
            state.insurePerson._maxBir = state.insurePerson._birthday = _y + '-'+ _m + '-' + _d;
            state.insurePerson._minBir = state.insurePerson.minBir;
            //操作被保人生日范围(子女)
            let _bbrBir = filter.getChildBirByEff(state.infoByProductDetail.effDate);
            state.infoByProductDetail.bbrBirMax = _bbrBir.max;
            state.infoByProductDetail.bbrBir = _bbrBir.max;
            state.infoByProductDetail.bbrBirMin = _bbrBir.min;

            //操作customerInfoList里面数据
            state.customerInfoList.length = 1;//删掉本人以外的数据
            //为以防生效日改变影响投保人生日，从新获取投保人生日范围
            state.customerInfoList[0].maxBir = state.insurePerson.maxBir;
            state.customerInfoList[0].birthday = state.insurePerson.maxBir;
            state.customerInfoList[0].minBir = state.insurePerson.minBir;
            let obj = getNumByZh(state.infoByProductDetail.insObj.personName);
            let single = {
                name:"",
                insurOccupationType:"",
                insurOccupationTypeCode:"",
                relationshipWithPrimaryInsurant:"2",//123本人配偶子女
                appType:'01',
                appNums:"",
                phone:"",
                sexType:"F",//性别
                birthday:state.insurePerson._maxBir,//生日
                email:"",
                maxBir:state.insurePerson._maxBir,//生日最大值---时间戳上最大
                minBir:state.insurePerson._minBir,//最小值
                isOpen:'Y'//是否展开状态
            }
            if(obj.mate > 0){
                state.customerInfoList.push(JSON.parse(JSON.stringify(single)));
            }
            if(obj.child > 0){
                single.relationshipWithPrimaryInsurant = '3';
                single.maxBir = state.infoByProductDetail.bbrBirMax;
                single.birthday = state.infoByProductDetail.bbrBirMax;
                single.minBir = state.infoByProductDetail.bbrBirMin;
                while (obj.child > 0){
                    state.customerInfoList.push(single);
                    obj.child--;
                }
            }
        },
        [asiaMu.setidProductCombined](state,data){//选择套餐
            state.infoByProductDetail.idProductCombined = data;
            for(let i = 0;i < state.infoByProductDetail.product.length;i++){
                if(state.infoByProductDetail.product[i].idProductCombined == data){
                    state.infoByProductDetail.product[i].isDefault = 'Y';
                    //state.infoByProductDetail.dutyItems = state.infoByProductDetail.product[i].dutys;
                    //操作责任，特殊处理
                    let dutyList = state.infoByProductDetail.product[i].dutys;
                    let dObj = {},dList=[],o1 = {isChild:true,name:'投保人的子女'},o2 = {isChild:false,name:'投保人及配偶'},readyHasChild=false,readyHasPo=false;
                    for(let p = 0;p < dutyList.length;p++){
                        dObj = JSON.parse(JSON.stringify(dutyList[p]));
                        if(dObj.dutyName.indexOf('child') > -1){
                            if(!readyHasChild){
                                dList.push(o1);
                                readyHasChild = true
                            }
                            dObj.dutyName = dObj.dutyName.substring(0,dObj.dutyName.length-7);
                            dList.push(dObj);
                        }else{
                            dList.unshift(dObj);
                            readyHasPo = true
                        }
                        dObj = {}
                    }
                    if(readyHasPo) dList.unshift(o2);
                    state.infoByProductDetail.dutyItems = dList;
                }else{
                    state.infoByProductDetail.product[i].isDefault = 'N'
                }
            }
        },
        [asiaMu.setInsType](state,data){
            let _insType = state.infoByProductDetail.insType;
            for(let m = 0;m < _insType.length;m++){
                if(data == _insType[m].personName){
                    state.infoByProductDetail.insObj = _insType[m];
                }
            }
            //操作套餐、责任
            state.infoByProductDetail.product = state.productDetail.personProducts[state.infoByProductDetail.insObj.idPersonType];
            //state.infoByProductDetail.dutyItems = state.infoByProductDetail.product[0].dutys;
            //操作责任，特殊处理
            let dutyList = state.infoByProductDetail.product[0].dutys;
            let dObj = {},dList=[],o1 = {isChild:true,name:'投保人的子女'},o2 = {isChild:false,name:'投保人及配偶'},readyHasChild=false,readyHasPo=false;
            for(let p = 0;p < dutyList.length;p++){
                dObj = JSON.parse(JSON.stringify(dutyList[p]));
                if(dObj.dutyName.indexOf('child') > -1){
                    if(!readyHasChild){
                        dList.push(o1);
                        readyHasChild = true
                    }
                    dObj.dutyName = dObj.dutyName.substring(0,dObj.dutyName.length-7);
                    dList.push(dObj);
                }else{
                    dList.unshift(dObj);
                    readyHasPo = true
                }
                dObj = {}
            }
            if(readyHasPo) dList.unshift(o2);
            state.infoByProductDetail.dutyItems = dList;
            state.infoByProductDetail.product[0].isDefault = 'Y';
            state.infoByProductDetail.idProductCombined = state.infoByProductDetail.product[0].idProductCombined;
            //操作customerInfoList里面数据
            state.customerInfoList.length = 1;//删掉本人以外的数据
            //为以防生效日改变影响投保人生日，从新获取投保人生日范围
            state.customerInfoList[0].maxBir = state.insurePerson.maxBir;
            state.customerInfoList[0].birthday = state.insurePerson.maxBir;
            state.customerInfoList[0].minBir = state.insurePerson.minBir;
            let obj = getNumByZh(state.infoByProductDetail.insObj.personName);
            let single = {
                name:"",
                insurOccupationType:"",
                insurOccupationTypeCode:"",
                relationshipWithPrimaryInsurant:"2",//123本人配偶子女
                appType:'01',
                appNums:"",
                phone:"",
                sexType:"F",//性别
                birthday:state.insurePerson._maxBir,//生日
                email:"",
                maxBir:state.insurePerson._maxBir,//生日最大值---时间戳上最大
                minBir:state.insurePerson._minBir,//最小值
                isOpen:'Y'//是否展开状态
            }
            if(obj.mate > 0){
                state.customerInfoList.push(JSON.parse(JSON.stringify(single)));
            }
            if(obj.child > 0){
                single.relationshipWithPrimaryInsurant = '3';
                single.maxBir = state.infoByProductDetail.bbrBirMax;
                single.birthday = state.infoByProductDetail.bbrBirMax;
                single.minBir = state.infoByProductDetail.bbrBirMin;
                while (obj.child > 0){
                    state.customerInfoList.push(single);
                    obj.child--;
                }
            }
        },
        [asiaMu.upCustomerInfoList](state,data){
            let obj = JSON.parse(JSON.stringify(state.customerInfoList[data[0]]));
            for(let k in data[1]){
                obj[k] = data[1][k];
            }
            state.customerInfoList[data[0]] = obj;
        },
        [asiaMu.setPrice](state,data){
            state.price=data.payPremium;
        },
        [asiaMu.setInsurePerson](state,data){
            for(let k in data){
                state.insurePerson[k] = data[k];
            }
        },
        [asiaMu.setSaleRecordId](state,data){
            state.infoByProductDetail.saleRecordId=data;
        },
        [asiaMu.setOccupationList](state,data){
            state.occupationList=data;
        },
        [asiaMu.setOccupationCode](state,data){
            state.occupationCode=data[0];
            state.grade[state.personOccIndex]=data[1];
        },
        [asiaMu.setOccupationCode2](state,data){
            state.occupationCode2=data;
        },
        [asiaMu.setOccupationName](state,data){
            state.occupationName=data;
        },
        [asiaMu.setPersonOccByIndex](state,data){
            state.personOccIndex=data;
        },
        [asiaMu.setState](state,data){
            for(let i in data){
                state[i] = data[i]
            }
        }
    },
    actions: {
        //询问价格
        async [asiaAc.policyInquiry] ({commit}, data) {
            let _arr = [];
            let _obj = {};
            for(let i = 0;i < data.customerInfoList.length;i++){
                _obj.insNum = '1';
                _obj.idInsType = data.infoByProductDetail.insObj.insType[0].idInsType;
                _obj.relationshipWithPrimaryInsurant = data.customerInfoList[i].relationshipWithPrimaryInsurant;
                _arr.push(_obj);
                _obj = {};
            }
            let submit = {
                idProductCombined:data.infoByProductDetail.idProductCombined,
                insurePeriod:'12',
                insurePeriodType:'M',
                insurants:_arr
            }
            commit(asiaMu.setPrice, await policyInquiry(submit).then(
                function ({body}) {
                    return body
                }
            ));
        }
    }
}
function getNumByZh(zh){//根据中文确定被保人类别和数量
    let obj = {
        mate:"0",
        child:"0"
    }
    if(zh.indexOf('配偶') > -1){
        obj.mate = '1';
    }
    if(zh.indexOf('1') > -1){
        obj.child = '1';
    }
    if(zh.indexOf('2') > -1){
        obj.child = '2';
    }
    return obj
}