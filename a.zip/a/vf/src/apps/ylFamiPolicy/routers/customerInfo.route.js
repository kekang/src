/**
 * Created by zhangping702 on 17/1/18.
 */

export default [{
    path: '/productDetail',
    name: 'productDetail',
    meta: {
        title: '产品详情',
    },
    component: resolve => require(['../views/productDetail/productDetail.vue'], resolve)
},
    {
        path: '/occupation',
        name: 'occupation',
        meta: {
            title: '职业',
        },
        component: resolve => require(['../views/productDetail/chooseOccupation.vue'], resolve)
    },
    {
        path: '/choose_2',
        name: 'choose_2',
        meta: {
            title: '职业',
        },
        component: resolve => require(['../views/productDetail/choose_2.vue'], resolve)
    },
    {
        path: '/choose_3',
        name: 'choose_3',
        meta: {
            title: '职业',
        },
        component: resolve => require(['../views/productDetail/choose_3.vue'], resolve)
    },
    {
        path: '/customerInfo',
        name: 'customerInfo',
        meta: {
            title: '被保人信息',
        },
        component: resolve => require(['../views/insureDetail/customerInfo.vue'], resolve)
    },
    {
        path: '/showInfo',
        name: 'showInfo',
        meta: {
            title: '投保信息',
        },
        component: resolve => require(['../views/insureDetail/showInfo.vue'], resolve)
    },
    {
        path: '/BUYNOTICE0001006',
        name: 'BUYNOTICE0001006',
        meta: {
            title: '购买须知',
        },
        component: resolve => require(['../views/notice/BUYNOTICE0001006.vue'], resolve)
    },
    {
        path: '/BUYNOTICE0001007',
        name: 'BUYNOTICE0001007',
        meta: {
            title: '购买须知',
        },
        component: resolve => require(['../views/notice/BUYNOTICE0001007.vue'], resolve)
    },
    {
        path: '/zhiye',
        name: 'zhiye',
        meta: {
            title: '职业',
        },
        component: resolve => require(['../views/notice/zhiye.vue'], resolve)
    },
    {
        path: '/P1125',
        name: 'P1125',
        meta: {
            title: '职业',
        },
        component: resolve => require(['../views/notice/P1125.vue'], resolve)
    }]
