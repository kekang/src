import IndexView from '../views/IndexView.vue'
export default [{
    path: '/',
    component: IndexView,
}]
