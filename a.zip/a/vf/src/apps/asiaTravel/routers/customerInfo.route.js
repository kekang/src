/**
 * Created by zhangping702 on 17/1/18.
 */

export default [{
    path: '/productDetail',
    name: 'productDetail',
    meta: {
        title: '产品详情',
    },
    component: resolve => require(['../views/productDetail/productDetail.vue'], resolve)
},
    {
        path: '/destination',
        name: 'destination',
        meta: {
            title: '选择目的地',
        },
        component: resolve => require(['../views/productDetail/chooseDestination.vue'], resolve)
    },
    {
        path: '/insureInfo',
        name: 'insureInfo',
        meta: {
            title: '投保人信息',
        },
        component: resolve => require(['../views/insureDetail/insureInfo.vue'], resolve)
    },
    {
        path: '/customerInfo',
        name: 'customerInfo',
        meta: {
            title: '被保人信息',
        },
        component: resolve => require(['../views/insureDetail/customerInfo.vue'], resolve)
    },
    {
        path: '/showInfo',
        name: 'showInfo',
        meta: {
            title: '投保信息',
        },
        component: resolve => require(['../views/insureDetail/showInfo.vue'], resolve)
    },
    {
        path: '/BUYNOTICE0001005',
        name: 'BUYNOTICE0001005',
        meta: {
            title: '购买须知',
        },
        component: resolve => require(['../views/notice/buyNotice.vue'], resolve)
    },{
        path: '/P0555',
        name: 'P0555',
        meta: {
            title: '条款',
        },
        component: resolve => require(['../views/notice/P0555.vue'], resolve)
    },{
        path: '/noPolicyArea',
        name: 'noPolicyArea',
        meta: {
            title: '不承保地区',
        },
        component: resolve => require(['../views/notice/noPolicyArea.vue'], resolve)
    },{
        path: '/profession',
        name: 'profession',
        meta: {
            title: '职业',
        },
        component: resolve => require(['../views/notice/profession.vue'], resolve)
    }]
