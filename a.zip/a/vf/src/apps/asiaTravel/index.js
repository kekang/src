import configApp from '../ConfigApp'
import Routers from './routers'
import stores from './vuex'

const cfg = {
    stores: stores,
    router: {
        routes: [...Routers]
    }
}
configApp(cfg)
