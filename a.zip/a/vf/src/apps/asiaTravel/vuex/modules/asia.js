/**
 * Created by zhangping702 on 16/12/28.
 */

import Msg from '../../../../components/Msg/Msg'
import filter from '../../../../utils/filter'
import { policyInquiry} from '../../apis/asia.api'
import * as asiaMu from "../mutationTypes/asia.mutation.types.js"
import * as asiaAc from "../actionTypes/asia.action.types.js"

export default {
    //状态
    state: {
        productDetail:'',//产品详情数据
        productsList:'',//关联产品数据
        infoByProductDetail:{//处理初始化数据得到想要数据
            icpProductCode:"",//当前产品类型"ICP000055"单次默认，"ICP000056"多次
            slotList:[{flex: 1,values:[]}],//可选产品类型
            insType:[],//人群
            dataSlots1:[{flex: 1,values:[]}],
            dataSlots2:[{flex: 1,values:[]}],
            dataSlots3:[{flex: 1,values:[]}],
            dataSlots4:[{flex: 1,values:[]}],
            product:[],//产品类型
            dutyItems:[],//责任
            idProductCombined:'',//目前选中的套餐
            saleRecordId:"",
            travelTime:{//旅行时间范围
                startTime_1:"",//开始日期
                endTime_1:"",//开始日期
                startTime_2:"",//结束日期
                endTime_2:""//结束日期
            },
            travelStart:"",//旅行开始日期
            travelEnd:"",//结束日期
            isChanged:true,//旅行结束日期是否可更改
            travelType:""//旅行类型
        },
        numbers:[0,1,0,0],//6个月-1周岁,2-60,61-70,71-80
        insurePerson:{//投保人信息
            name:"",
            eName:'',
            appType:'01',
            appNums:"",
            phone:"",
            sexType:"M",//性别
            birthday:"",//生日
            email:"",
            maxBir:"",//生日最大值---时间戳上最大
            minBir:"",//最小值
        },
        customerInfoList:[{
            name:"",
            eName:'',
            appType:'01',
            appNums:"",
            phone:"",
            personType:"1",//人群类型0:6个月-1周岁，123依次类推
            sexType:"M",//性别
            birthday:"",//生日
            maxBir:"",//生日最大值---时间戳上最大
            minBir:"",//最小值
        }],
        destinationList:[],//目的地，原始全部数据
        searchList:[],//搜索出的数据
        destinationObj:{},//目的地，用于未搜索时渲染
        zmList:[],//字母数组
        destinationCode:[],//选中的目的地code
        destinationName:"",//选中的目的地中文
        isSubDestin:false,
        destinStr:"",//目的地传值立即投保用
        price:""
    },
    //改变状态（同步）
    mutations: {
        [asiaMu.setProductDetail](state,data){//产品详情数据
            state.productDetail = data;
            //操作人群可选范围
            state.infoByProductDetail.insType = data.insurPersons[0].insType;
            let _insType = state.infoByProductDetail.insType;
            for(let l = 0;l < _insType.length;l++){
                let _num = ['0'],_n = 1,_m = _insType[l].maxInsNum;
                while(_m > 0){
                    _num.push(_n.toString());
                    _n++;
                    _m--;
                }
                state.infoByProductDetail['dataSlots' + (l+1)][0].values = _num;
            }
            //操作套餐、责任
            let _key = Object.keys(data.personProducts);
            let _arr = JSON.parse(JSON.stringify(data.personProducts[_key]));
            state.infoByProductDetail.product = [];
            state.infoByProductDetail.dutyItems = [];
            for(let i = 0;i < _arr.length;i++){//这三循环目的是state.infoByProductDetail.product添加undwrtRange属性值
                for(let j = 0;j < _arr[i].dutys.length;j++){
                    for(let k in data.dutyItems){
                        if(_arr[i].dutys[j].dutyId == k){
                            _arr[i].dutys[j].undwrtRange = data.dutyItems[k].undwrtRange;
                        }
                    }
                }
                if(_arr[i].isDefault == 'Y'){//取责任和当前套餐id
                    state.infoByProductDetail.dutyItems = _arr[i].dutys;
                    state.infoByProductDetail.idProductCombined = _arr[i].idProductCombined;
                }
            }
            state.infoByProductDetail.product = _arr;
            //操作旅行开始结束日期范围
            let _startTime = Date.parse(new Date()) + 24*60*60*1000;
            let _endTime = Date.parse(new Date()) + 24*60*60*1000*(data.maxEffDelay);//180
            let y = new Date(_startTime).getFullYear(),m = new Date(_startTime).getMonth() + 1,d = new Date(_startTime).getDate();
            if(m < 10) m = "0" + m;
            if(d < 10) d = "0" + d;
            state.infoByProductDetail.travelTime.startTime_1 = state.infoByProductDetail.travelStart = y + '-'+ m + '-' + d;
            let yy = new Date(_endTime).getFullYear(),mm = new Date(_endTime).getMonth() + 1,dd = new Date(_endTime).getDate();
            if(mm < 10) mm = "0" + mm;
            if(dd < 10) dd = "0" + dd;
            state.infoByProductDetail.travelTime.endTime_1 = yy + '-'+ mm + '-' + dd;
            if(data.insurePeriodType == 'D' && data.insurePeriod != '365'){
                let _s = Date.parse(new Date()) + 24*60*60*1000*data.insurePeriod;
                let a = new Date(_s).getFullYear(),b = new Date(_s).getMonth() + 1,c = new Date(_s).getDate();
                if(b < 10) b = "0" + b;
                if(c < 10) c = "0" + c;
                state.infoByProductDetail.travelEnd = a + '-'+ b + '-' + c;//旅行结束日期
                state.infoByProductDetail.travelTime.startTime_2 = state.infoByProductDetail.travelTime.startTime_1;
                let p = Date.parse(new Date()) + 24*60*60*1000*184;
                let yyy = new Date(p).getFullYear(),mmm = new Date(p).getMonth() + 1,ddd = new Date(p).getDate();
                if(mmm < 10) mmm = "0" + mmm;
                if(ddd < 10) ddd = "0" + ddd;
                state.infoByProductDetail.travelTime.endTime_2 = yyy + '-'+ mmm + '-' + ddd;
                state.infoByProductDetail.isChanged = true;
            }else{
                if((data.insurePeriodType == 'D' && data.insurePeriod == '365') || data.insurePeriodType != 'D'){
                    state.infoByProductDetail.isChanged = false;
                    let y = new Date().getFullYear() + 1,m = new Date().getMonth() + 1,d = new Date().getDate();
                    if(m < 10) m = "0" + m;
                    if(d < 10) d = "0" + d;
                    let p = Date.parse(new Date(y + '-'+ m + '-' + d));
                    let y1 = new Date(p).getFullYear(),m1 = new Date(p).getMonth() + 1,d1 = new Date(p).getDate();
                    if(m1 < 10) m1 = "0" + m1;
                    if(d1 < 10) d1 = "0" + d1;
                    state.infoByProductDetail.travelEnd = y1 + '-'+ m1 + '-' + d1;//旅行结束日期
                }
            }

            //操作投保人生日范围
            let _birObj = filter.birTimeRangeZs(data.appAgeMin,data.appAgeMax,25,28);
            state.insurePerson.maxBir = _birObj.max;
            state.insurePerson.birthday = _birObj.max;
            state.insurePerson.minBir = _birObj.min;
            //初始化默认被保人生日等信息
            let _bbrBir = filter.getBirByEff(2,60,state.infoByProductDetail.travelStart);
            state.customerInfoList[0].maxBir = _bbrBir.max;
            state.customerInfoList[0].birthday = _bbrBir.max;
            state.customerInfoList[0].minBir = _bbrBir.min;
            //操作被保人生日范围
        },
        [asiaMu.setProductsList](state,data){//关联产品数据
            state.productsList = data;
            let _arr = [];
            for(let i = 0;i < data.length;i++){
                if(data[i].isDefault == 'Y'){
                    state.infoByProductDetail.icpProductCode = data[i].icpProductCode;
                    _arr.unshift(data[i].h5Value);
                }else{
                    _arr.push(data[i].h5Value);
                }
            }
            state.infoByProductDetail.slotList[0].values = _arr;
            state.infoByProductDetail.travelType = _arr[0];
        },
        [asiaMu.updateProductsList](state,data){//关联产品数据
            state.productsList[data[0]].isDefault = data[1];
            if(data[1] == 'Y') state.infoByProductDetail.icpProductCode = data[2];
        },
        [asiaMu.setidProductCombined](state,data){//选择套餐
            state.infoByProductDetail.idProductCombined = data;
            for(let i = 0;i < state.infoByProductDetail.product.length;i++){
                if(state.infoByProductDetail.product[i].idProductCombined == data){
                    state.infoByProductDetail.product[i].isDefault = 'Y';
                    state.infoByProductDetail.dutyItems = state.infoByProductDetail.product[i].dutys;
                }else{
                    state.infoByProductDetail.product[i].isDefault = 'N'
                }
            }
        },
        [asiaMu.setNumbers](state,data){
            state.numbers[data[0]] = data[1];
            state.customerInfoList = [];
            let obj = {
                name:"",
                eName:'',
                appType:'01',
                appNums:"",
                phone:"",
                personType:"",
                sexType:"M",//性别
                birthday:"",//生日
                maxBir:"",//生日最大值---时间戳上最大
                minBir:""//最小值
            }
            for(let i = 0;i < state.numbers.length;i++){
                let num = state.numbers[i];
                let _obj = JSON.parse(JSON.stringify(obj));
                while (num > 0){
                    _obj.personType = i;
                    let _birObj = {};
                    if(i == 0){
                        _birObj = filter.getBirByEff(180,1,state.infoByProductDetail.travelStart);
                    }else if(i == 1){
                        _birObj = filter.getBirByEff(2,60,state.infoByProductDetail.travelStart);
                    }else if(i == 2){
                        _birObj = filter.getBirByEff(61,70,state.infoByProductDetail.travelStart);
                    }else if(i == 3){
                        _birObj = filter.getBirByEff(71,80,state.infoByProductDetail.travelStart);
                    }
                    _obj.maxBir = _birObj.max;
                    _obj.birthday = _birObj.max;
                    _obj.minBir = _birObj.min;
                    state.customerInfoList.push(_obj);
                    num--;
                }
            }
        },
        [asiaMu.delNumbers](state,data){
            state.numbers[data[0]] = state.numbers[data[0]] - 1;
            state.customerInfoList.splice(data[1],1);
        },
        [asiaMu.upCustomerInfoList](state,data){
            let obj = JSON.parse(JSON.stringify(state.customerInfoList[data[0]]));
            for(let k in data[1]){
                obj[k] = data[1][k];
            }
            state.customerInfoList[data[0]] = obj;
        },
        [asiaMu.setDestinationObj](state,data){
            state.destinationList = data;
            let zmList = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
            let _obj = {},_n = 0,_list = [];
            for(let j = 0;j < zmList.length;j++){
                _n = 0,_obj[zmList[j]] = [];
                for(let k = 0;k < data.length;k++){
                    if(zmList[j] == data[k].firstName) {
                        _n++;
                        data[k].isChecked = false;//开始默认不选中目的地
                        _obj[zmList[j]].push(data[k]);
                        if (_n < 2) _list.push(zmList[j]);
                    }
                }
            }
            for(let i in _obj){//去除空数据
                if(_obj[i].length == 0) delete _obj[i];
            }
            state.destinationObj = _obj;
            state.zmList = _list;
        },
        [asiaMu.selectDestination](state,data){
            state.destinStr = '';
            let _str = '',_arr = [],s = '';
            for(let k in state.destinationObj){
                for(let i = 0;i < state.destinationObj[k].length;i++){
                    if(data[1] == state.destinationObj[k][i].countryCode){
                        state.destinationObj[k][i].isChecked = !state.destinationObj[k][i].isChecked;
                    }
                }
            }
            for(let kk in state.destinationObj){
                for(let ii = 0;ii < state.destinationObj[kk].length;ii++){
                    if(state.destinationObj[kk][ii].isChecked){
                        _arr.push(state.destinationObj[kk][ii].countryCode);
                        s += state.destinationObj[kk][ii].name + '(' + state.destinationObj[kk][ii].english + '),';
                        _str += state.destinationObj[kk][ii].name+',';
                    }
                }
            }
            _str = _str.substring(0,_str.length-1);//去逗号
            s = s.substring(0,s.length-1);//去逗号
            state.destinStr = s;
            if(_str.length > 12){
                _str = _str.substring(0,12) + '...';
            }
            state.destinationName = _str;
            state.destinationCode = _arr;
        },
        [asiaMu.delDestination](state,data){
            state.destinationName = '';
            state.destinationCode = [];
            for(let kk in state.destinationObj){
                for(let ii = 0;ii < state.destinationObj[kk].length;ii++){
                    state.destinationObj[kk][ii].isChecked = false;
                }
            }
        },
        [asiaMu.setIsSubDestin](state,data){
            state.isSubDestin = data;
        },
        [asiaMu.setSearchList](state,data){
            let _arr = [],len = data.length;
            for(let i = 0;i < state.destinationList.length;i++){
                if(state.destinationList[i].pinyin.substring(0,len) == data || state.destinationList[i].name.substring(0,len) == data){
                    _arr.push(state.destinationList[i]);
                }
            }
            state.searchList = _arr;
        },
        [asiaMu.setTravelTime](state,data){
            if(data[0] == 'start'){
                state.infoByProductDetail.travelStart = data[1]
                //再次操作旅行开始结束日期范围
                if(state.productDetail.insurePeriodType == 'D' && state.productDetail.insurePeriod != '365'){
                    let _startTime = Date.parse(data[1]);
                    let _endTime = Date.parse(data[1]) + 24*60*60*1000*(state.productDetail.insurePeriod-1);
                    let y = new Date(_startTime).getFullYear(),m = new Date(_startTime).getMonth() + 1,d = new Date(_startTime).getDate();
                    if(m < 10) m = "0" + m;
                    if(d < 10) d = "0" + d;
                    state.infoByProductDetail.travelTime.startTime_2 = y + '-'+ m + '-' + d;
                    let yy = new Date(_endTime).getFullYear(),mm = new Date(_endTime).getMonth() + 1,dd = new Date(_endTime).getDate();
                    if(mm < 10) mm = "0" + mm;
                    if(dd < 10) dd = "0" + dd;
                    state.infoByProductDetail.travelTime.endTime_2 = yy + '-'+ mm + '-' + dd;
                    if(Date.parse(data[1]) > Date.parse(state.infoByProductDetail.travelEnd)) state.infoByProductDetail.travelEnd = data[1]
                }else{
                    let _startTime = Date.parse(data[1]) - 24*60*60*1000;
                    let a = new Date(_startTime).getFullYear() + 1,b = new Date(_startTime).getMonth() + 1,c = new Date(_startTime).getDate();
                    if(b < 10) b = "0" + b;
                    if(c < 10) c = "0" + c;
                    state.infoByProductDetail.travelEnd = a + '-'+ b + '-' + c;
                }
            }else{
                state.infoByProductDetail.travelEnd = data[1]
            }
        },
        [asiaMu.setTravelType](state,data){
            state.infoByProductDetail.travelType=data;
        },
        [asiaMu.setPrice](state,data){
            state.price=data.payPremium;
        },
        [asiaMu.setInsurePerson](state,data){
            for(let k in data){
                state.insurePerson[k] = data[k];
            }
        },
        [asiaMu.setSaleRecordId](state,data){
            state.infoByProductDetail.saleRecordId=data;
        },
        [asiaMu.setState](state,data){
            for(let i in data){
                state[i] = data[i]
            }
        }
    },
    actions: {
        //询问价格
        async [asiaAc.policyInquiry] ({commit}, data) {
            let _arr = [];
            let _obj = {
                //seqno:'' || null,//被保人序号
                //insurGender:'' || null,//	被保人性别
                //insurBirthday:'' || null,//	被保人生日
                //hasSocialSecurity:'' || null,//	是否有社保
                //relationshipWithPrimaryInsurant:'' || null//	与主被保人的关系
            };
            for(let i = 0;i < data.numbers.length;i++){
                if(data.numbers[i] != '0'){
                    _obj.insNum = data.numbers[i];
                    _obj.idInsType = data.infoByProductDetail.insType[i].idInsType;
                    _arr.push(_obj);
                    _obj = {};
                }
            }
            let submit = {
                idProductCombined:data.infoByProductDetail.idProductCombined,
                insurePeriod:data.productDetail.insurePeriod,
                insurePeriodType:data.productDetail.insurePeriodType,
                //isShareCoverage:this.$store.state.asia.isShareCoverage || null,//是否家庭共享
                insurants:_arr
            }
            if(data.productDetail.insurePeriodType == 'D'){//如果是单次旅行
                submit.insurePeriod = ((Date.parse(data.infoByProductDetail.travelEnd)-Date.parse(data.infoByProductDetail.travelStart))/(24*60*60*1000)) + 1;
            }
            commit(asiaMu.setPrice, await policyInquiry(submit).then(
                function ({body}) {
                    return body
                }
            ));
        }
    }
}