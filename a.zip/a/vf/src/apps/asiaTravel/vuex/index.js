import asia from './modules/asia'
export default {
    asia
}

