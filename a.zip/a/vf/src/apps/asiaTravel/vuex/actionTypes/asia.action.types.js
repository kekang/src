export const policyInquiry = 'policyInquiry'
