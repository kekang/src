import Vue from 'vue'

export function getAhProductDetail (data) {//产品详情
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/product/getAhProductDetail.do'),data)
}
export function getRelatedProduct (data) {//关联产品查询接口
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/product/getRelatedProduct.do'),data)
}
export function getProductDestination (data) {//目的地
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/product/getProductDestination.do'),data)
}
export function policyInquiry (data) {//询价
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/policyInquiry.do'),data)
}
export function ahPolicyInsure (data) {//立即投保
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/ahPolicyInsure.do'),data)
}
export function recordInsuredNew (data) {//记录投被保人
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/insurant/recordInsuredNew.do'),data)
}
export function policyUndwrt (data) {//核保
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/policyUndwrt.do'),data)
}
export function payForICPPAY (data) {//立即支付
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/payment/payForICPPAY.do'),data)
}
