<template>
    <div>
        <section class="service">
            <p>
                <input type="checkbox" class="HP-ui-input-group-radio" name="4" id="check-0" hidden ref="checkbox" @click="check">
                <label for="check-0" :style="{color : themeColor}"></label>
                <span style="color:#666666">我已阅读并同意</span>
                <span @click="noticeNav" class="serviceContext">《投保须知》</span>
            </p>
        </section>
        <div class="footPrice">
            <p class="price">
                <i @click="kefu" class="iconfont icon-kefu" :style="{color:themeColor}"></i>
                <span>优惠价：￥<span class="priceNum" :style="{color:themeColor}">{{price}}</span></span>
            </p>
            <p class="buy" :style="{backgroundColor:themeColor}" @click="skip">
                <span >立即投保</span>
            </p>
        </div>
    </div>
</template>
<style lang="less" scoped>
    @import "../../../../styles/vars.less";
    @import "../../../../assets/kefu/iconfont.css";
    .service{
        height: 4.5rem;
        line-height: 4.5rem;
        margin-top: 1rem;
        background-color: #e4e4e4;
        padding-bottom: 12rem;
        >p{
             height: 4.5rem;
             line-height: 4.5rem;
             padding-left: 2rem;
             font-size: 1.5rem;
             background-color: @background-color-white;
            .serviceContext{
                color: @font-color-blue;
            }
        }
    }
    footer{
        height: 6.5rem;
        position: fixed;
        bottom: 0;
        width: 100%;
    }
    .footPrice{
        padding: 1rem 1rem;
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 6.5rem;
        background-color: rgba(0, 0, 0, 0.3);
        >.price{
             border-bottom-left-radius: 0.8rem;
             border-top-left-radius: 0.8rem;
             padding-left: 1rem;
             height: 4.5rem;
             line-height: 4.3rem;
             width: 65%;/*58*/
             display: inline-block;
             font-size: 1.7rem;
             color:@font-color-black;
             background-color: @background-color-white;
            >i{
                font-size: 2.2rem;
                margin-right: 1.5rem;
                margin-left: .5rem;
            }
         }
        >.buy{
             height: 4.5rem;
             line-height: 4.5rem;
             width: 35%;/*42*/
             display: inline-block;
             /*background-color: @font-color-blue;*/
             border-radius: 0.8rem;
             border-top-left-radius: 0rem;
             border-bottom-left-radius: 0rem;
             float: right;
             color: @font-color-white;
             text-align: center;
             font-size: 1.7rem;
         }
    }
    .priceNum{
        color:@font-color-blue
    }
    .HP-ui-input-group-radio +label{
        -webkit-appearance: none;
        background-color: #fafafa;
        border: 1px solid @font-color-grey;
        padding: 0.7rem;
        display: inline-block;
        border-radius:0.4rem;
        position: relative;
        top:3px
    }

    .HP-ui-input-group-radio+label{
        background-color: #fff;
        border: 1px solid @font-color-grey;
        position: relative;
    }
    .HP-ui-input-group-radio+label::before {
        content: '';
        position: absolute;
        top: -15px;
        right: -15px;
        bottom: -15px;
        left: -15px;
    }
    .HP-ui-input-group-radio:checked+label:before{
        font-family: "health" !important;
        content: "\e63a";
        /*color: @iconfont;*/
        width: 1.5rem;
        height: 1.1rem;
        position: absolute;
        top: -1.5rem;
        text-shadow: 0px;
        font-size: 1.5rem;
        left: 0px;
        font-size: 15px;
    }

    @media screen and (min-width: 320px) and (max-width: 350px) {
        .HP-ui-input-group-radio:checked+label:before{top: -13px;font-size: 12px;}
    }
</style>
<script>
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import {Msg,Loading} from 'components'
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import * as asiaAc from "../../vuex/actionTypes/asia.action.types"
    import { ahPolicyInsure} from '../../apis/asia.api.js'
    import filter from "../../../../utils/filter"
    import "../../../../utils/PAD"
    export default{
        data(){
            return{
                themeColor:'#2688c4',
                lock:false
            }
        },
        methods: {
            kefu(){
                location.href = 'https://ziker-talk.yun.pingan.com/appIm/?msgInfo=&channel=APPIM&authorizerAppid=appimc283aec44342e0a&eid=b3db08dad71ec8b41b6e7253fe86076c';
            },
            skip () {
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "立即投保按钮":'立即投保'
                });
                if (this.lock) {
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "同意投保须知":"同意"
                    });
                    if(this.checkPersonNum()){
                        if(this.travelType.indexOf('多次') > -1 || this.destinationCode.length > 0){
                            this.ahPolicyInsure();
                        }else{
                            Msg.alert('请选择目的地')
                        }

                        //this.$router.push({'name':"insureInfo"})
                    }else{
                        Msg.alert('至少有一位被保人，请选择')
                    }
                } else {
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "同意投保须知":"不同意"
                    });
                    Msg.alert('请先勾选投保须知')
                }
            },
            ahPolicyInsure(){
                let eff = this.$store.state.asia.infoByProductDetail.travelStart;
                eff = eff.replace(/-/g, "");
                let num = this.$store.state.asia.numbers;

                let data = {
                    idProductCombined: this.$store.state.asia.infoByProductDetail.idProductCombined,
                    icpProductCode: this.$store.state.asia.infoByProductDetail.icpProductCode,
                    dutys: this.$store.state.asia.infoByProductDetail.dutyItems,
                    saleAmount: this.$store.state.asia.price,
                    partnerCode: sessionStorage.partnerCode,
                    empno: sessionStorage.empno,
                    effDate: eff,
                    destination:this.destinStr,//中国(china)
                    saleRecordId: this.$store.state.asia.infoByProductDetail.saleRecordId,
                    agencyNo: sessionStorage.agencyNo,
                    //dataSource: this.$store.state.health.dataSource,
                    insurePeriod:this.$store.state.asia.productDetail.insurePeriod,
                    insurePeriodType:this.$store.state.asia.productDetail.insurePeriodType,
                    insNum:Number(num[0])+Number(num[1])+Number(num[2])+Number(num[3])
                }
                if(this.$store.state.asia.productDetail.insurePeriodType == 'D'){//如果是单次旅行
                    data.insurePeriod = ((Date.parse(this.$store.state.asia.infoByProductDetail.travelEnd)-Date.parse(this.$store.state.asia.infoByProductDetail.travelStart))/(24*60*60*1000)) + 1;
                }
                ahPolicyInsure(data).then((msg) =>{
                    if(msg.body.resultCode == "00000"){
                        this.$store.commit(asiaMu.setSaleRecordId,msg.body.saleRecordId);
                        this.$router.push({'name':"insureInfo"})
                    }
                })
            },
            checkPersonNum(){
                if(this.numbers[0] == '0' &&this.numbers[1] == '0' &&this.numbers[2] == '0' &&this.numbers[3] == '0') return false;
                return true;
            },
            noticeNav(){
                this.$router.push({'name':this.$store.state.asia.productDetail.buyNoticeLink})
            },
            check(event){
                this.lock = event.target.checked;
                if(this.lock){
                    //勾选投保须知
                    //SKAPP.onEvent("产品详情页", "同意投保须知",{
                        //icpProductCode:this.$route.query.icpProductCode
                    //});
                }
            }
        },
        mounted(){
            this.themeColor = sessionStorage.fontColor;
        },
        computed: {
            ...mapState({
                price:state=>state.asia.price,
                travelType:state=>state.asia.infoByProductDetail.travelType,
                destinStr:state=>state.asia.destinStr,
                destinationCode:state=>state.asia.destinationCode,
                numbers:state=>state.asia.numbers
            })
        }
    }
</script>
