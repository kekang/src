<template>
    <div class="site">
        <div class="header_seek"><input type="text" placeholder="请输入地址" @input='search'></div>
        <section class="site_com">
            <div class="site_block" v-if="!searchText" id='divs'>
                <div class="site_roll">
                    <section :id="key" v-for="(value, key) in destinationObj">
                        <div class="id">{{key}}</div>
                        <div class="line_com"><!--label换成了span标签，原因是在安卓上点击label事件会执行两次-->
                            <span class="line" v-for="(item,index) of value" @click="selectDes(item.name,item.countryCode)"><span>{{item.name}}</span><input :id="item.countryCode" :checked="item.isChecked" type="checkbox"><label :for="item.countryCode" class="icon"></label></span>
                        </div>
                    </section>
                </div>
            </div>

            <div class="site_block" v-if="searchText">
                <div class="site_roll">
                    <section>
                        <div class="line_com">
                            <span class="line" v-for="(item,index) of searchList" @click="selectDes(item.name,item.countryCode)"><span>{{item.name}}</span><input :id="item.countryCode" :checked="item.isChecked" type="checkbox"><label :for="item.countryCode" class="icon"></label></span>
                        </div>
                    </section>
                </div>
            </div>

            <div class="index">
                <a v-for="(item,index) of zmList" @click="zmClick(item)">{{item}}</a>
            </div>
        </section>
        <div class="footer">
            <p>已选：<span>{{destinationCode.length}}</span></p>
            <div class="botton_con" :class="{noSelect:destinationCode.length == 0}">
                <a :class="{noSelect:destinationCode.length == 0}" @click="next('cz')">重置</a>
                <a :class="{noSelect:destinationCode.length == 0}" @click="next('ok')">确定</a>
            </div>
        </div>
    </div>
</template>
<style lang="less" scoped >
    @fontsize:1.5rem;
    .site{
        height: 667px;
        height: 100vh;
        width:100%;

        .header_seek{
            height: 10%;
            height: 10vh;
            background: #FFFFFF;
            text-align: center;
            box-sizing: border-box;
            padding:1rem;
            input{
                display: inline-block;
                line-height: 2.4rem;
                font-size: @fontsize;
                text-indent: 1em;
                width: 90%;
            }
        }
        .site_com{
            width: 100%;
            height: 82%;
            height: 82vh;
            background: blue;
            display: box;			  /* OLD - Android 4.4- */
            display: -webkit-box;	  /* OLD - iOS 6-, Safari 3.1-6 */
            display: -moz-box;		 /* OLD - Firefox 19- (buggy but mostly works) */
            display: -ms-flexbox;	  /* TWEENER - IE 10 */
            display: -webkit-flex;	 /* NEW - Chrome */
            display: flex;			 /* NEW, Spec - Opera 12.1, Firefox 20+ */
            /* 09版 */
            -webkit-box-orient: horizontal;
            /* 12版 */
            -webkit-flex-direction: row;
            -moz-flex-direction: row;
            -ms-flex-direction: row;
            -o-flex-direction: row;
            flex-direction: row;

            .site_block{
                width: 92%;
                background: #FFFFFF;
                overflow: auto;
                .site_roll{
                    width: 100%;
                    section{
                        .id{
                            width: 100%;
                            line-height: 2rem;
                            background: #F0F0F5;
                            padding-left: 8%;
                            font-size: 1.7rem;
                            font-weight: 600;
                        }
                        .line_com{
                            margin-left: 8%;
                            .line{
                                position: relative;
                                display: block;
                                line-height: 3.4rem;
                                font-size: @fontsize;
                                border-bottom: 1px solid #E9E9E7;
                                display: box;			  /* OLD - Android 4.4- */
                                display: -webkit-box;	  /* OLD - iOS 6-, Safari 3.1-6 */
                                display: -moz-box;		 /* OLD - Firefox 19- (buggy but mostly works) */
                                display: -ms-flexbox;	  /* TWEENER - IE 10 */
                                display: -webkit-flex;	 /* NEW - Chrome */
                                display: flex;			 /* NEW, Spec - Opera 12.1, Firefox 20+ */
                                /* 09版 */
                                -webkit-box-orient: horizontal;
                                /* 12版 */
                                -webkit-flex-direction: row;
                                -moz-flex-direction: row;
                                -ms-flex-direction: row;
                                -o-flex-direction: row;
                                flex-direction: row;

                                /* 09版 */
                                -webkit-box-pack: space-between;
                                /* 12版 */
                                -webkit-justify-content: space-between;
                                -moz-justify-content: space-between;
                                -ms-justify-content: space-between;
                                -o-justify-content: space-between;
                                justify-content: space-between;

                                input{
                                    position: absolute;
                                    clip: rect(0,0,0,0);
                                }
                                .icon{
                                    display: block;
                                    text-align: right;
                                    height: .9rem;
                                    width: 1.5rem;
                                    opacity: 0;
                                    position: relative;
                                    top:1rem;
                                    right:.5rem;
                                    box-sizing: border-box;
                                    border-bottom: 3px solid #F76C6C;
                                    border-left: 3px solid #F76C6C;
                                    transition: all .1s ease-in;
                                    transform: rotate(-30deg);
                                }
                                input[type="checkbox"]:checked + label{
                                    opacity: 1;
                                    transform: rotate(-45deg);
                                }
                            }
                            .line:last-child{
                                border-bottom: 1px solid transparent;
                            }
                        }
                    }
                }
            }
            .index{
                width: 8%;
                text-align: center;
                background: #FFFFFF;
                padding-top: 10%;
                font-size: 1.6rem;
                a{
                    display: block;
                    width: 100%;
                    color: #1975FF;
                    font-weight: 600;
                }
            }
        }
        .footer{
            height: 8%;
            height: 8vh;
            display: box;			  /* OLD - Android 4.4- */
            display: -webkit-box;	  /* OLD - iOS 6-, Safari 3.1-6 */
            display: -moz-box;		 /* OLD - Firefox 19- (buggy but mostly works) */
            display: -ms-flexbox;	  /* TWEENER - IE 10 */
            display: -webkit-flex;	 /* NEW - Chrome */
            display: flex;			 /* NEW, Spec - Opera 12.1, Firefox 20+ */
            /* 09版 */
            -webkit-box-orient: horizontal;
            /* 12版 */
            -webkit-flex-direction: row;
            -moz-flex-direction: row;
            -ms-flex-direction: row;
            -o-flex-direction: row;
            flex-direction: row;

            /* 09版 */
            -webkit-box-pack: space-between;
            /* 12版 */
            -webkit-justify-content: space-between;
            -moz-justify-content: space-between;
            -ms-justify-content: space-between;
            -o-justify-content: space-between;
            justify-content: space-between;

            /* 09版 */
            -webkit-box-align: center;
            /* 12版 */
            -webkit-align-items: center;
            -moz-align-items: center;
            -ms-align-items: center;
            -o-align-items: center;
            align-items: center;


            padding: 0 1.5rem;
            background: #F0F0F5;
            .botton_con{
                a{
                    background: #FFFFFF;
                    display: inline-block;
                    width: 5rem;
                    line-height: 3rem;
                    border:1px solid #cccccc;
                    text-align: center;
                    margin-left: 1.5rem;
                }
            }
        }
    }
    .noSelect{
        color: #BCBCBC;
    }
</style>
<script>
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import { getProductDestination } from '../../apis/asia.api.js'
    import json from "./json"
    export default{
        data(){
            return {
                searchText:''//搜索内容
            }
        },
        mounted(){
            this.fontColor = sessionStorage.fontColor;
            if(this.$store.state.asia.zmList == 0){//无价格说明无记录(用户第一次进或刷新了页面)，发请求
                this.getProductDestination();
            }
        },
        updated(){

        },
        methods:{
            search(){
                this.searchText = event.target.value.replace(/(^\s+)|(\s+$)/g,"").replace(/\s/g,"");
                this.$store.commit(asiaMu.setSearchList,this.searchText.toLocaleLowerCase());
            },
            zmClick(zm){
                //window.scroll(0,document.querySelector('#'+zm).offsetTop || '0');
                document.querySelector('#divs').scrollTop = document.querySelector('#'+zm).offsetTop - 64;
            },
            selectDes(name,code){
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "选择目的地":name
                });
                this.$store.commit(asiaMu.selectDestination,[name,code]);
            },
            next(type){
                if(type == 'ok'){//参照好福利，没选点确定没反应
                    if(this.destinationCode.length > 0){
                        this.$store.commit(asiaMu.setIsSubDestin,true);
                        //this.$router.push({'name':"productDetail"});
                        this.$router.go(-1);
                    }
                }else{
                    this.$store.commit(asiaMu.delDestination,'');
                }
            },
            getProductDestination(){
                getProductDestination({
                    "icpProductCode":sessionStorage.icpProductCode
                }).then((msg) =>{
                    console.log(msg)
                    if(msg.body.resultCode == "00000"){
                        this.$store.commit(asiaMu.setDestinationObj,msg.body.destinationList);
                        //this.policyInquiry();
                        //this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
                    }
                })
                /*let obj = json.getProductDestination();
                this.$store.commit(asiaMu.setDestinationObj,obj);*/
            }
        },
        computed: {
            ...mapState({//BCBCBC
                destinationObj:state=>state.asia.destinationObj,
                destinationCode:state=>state.asia.destinationCode,
                searchList:state=>state.asia.searchList,
                zmList:state=>state.asia.zmList,
                isSubDestin:state=>state.asia.isSubDestin
            })
        },
        beforeDestroy(){
            //回首页
            if(!this.isSubDestin){//点击浏览器返回页面
                this.$store.commit(asiaMu.delDestination,'');
            }
        }
    }
</script>
