<template>
    <div class="product">
        <header>
            <ul @click="product" ref="_product">
                <li :style="{color:product_0}">
                    <p :style="{color:product_0}">
                        产品详情
                        <span :style="{color :themeColor}" class="arrow" id="0"></span>
                    </p>
                </li>
                <li  :style="{color:product_1}" >
                    <p :style="{color:product_1}">
                        理赔流程
                        <span :style="{color :themeColor}" class="arrow1" id="1"></span>
                    </p>
                </li>
                <li :style="{color:product_2}">
                    <p :style="{color:product_2}">
                        常见问题
                        <span :style="{color :themeColor}" class="arrow1" id="2"></span>
                    </p>
                </li>
            </ul>
        </header>
        <!--产品详情-->
        <article class="productDetail" v-show="show_0">
            <section class="productDetailTitle">
                <p v-for="d in detail">{{d}}</p>
            </section>
            <section class="productDetailContent">
                <table class="tablePeo">
                    <tr>
                        <td class="forPeople1">
                            <span class="iconPeople" :style="{color :themeColor}"></span>
                            <span class="forPeople">适用人群</span>
                        </td>
                        <td class="forPeopleCon">
                            <span>{{qualifiedCrowd}}</span>
                        </td>
                    </tr>
                </table>
                <!--<table>-->
                    <!--<tr>-->
                        <!--<td class="period">-->
                            <!--<span class="iconPeriod" :style="{color :themeColor}"></span>-->
                            <!--<span class="insurPeriod">保险期限</span>-->
                        <!--</td>-->
                        <!--<td class="forPeopleCon">-->
                            <!--<span>{{period}}个月</span>-->
                        <!--</td>-->
                    <!--</tr>-->
                <!--</table>-->
            </section>
        </article>
        <!--理赔流程-->
        <article class="claimProcess" v-show="show_1">
            <section class="productDetailTitle special">
                <p>平安将为您提供7*24小时理赔服务。当您发生保险事故后，请按照以下流程申请理赔</p>
            </section>
            <section class="claimProcess1">
                <p class="tel icon icon-lipei" :style="{color : themeColor}">
                    <span class="time-line-line1" :style="{backgroundColor:themeColor}"></span>
                    <span class="telTil" :style="{color : themeColor}">拨打95511报案</span>
                    <span class="telCon">拨打平安全国统一报案电话95511</span>
                </p>
                <p class="adv icon icon-lipei3" :style="{color : themeColor}">
                    <span class="time-line-line1" :style="{backgroundColor:themeColor}"></span>
                    <span class="advTil" :style="{color : themeColor}">理赔相关资讯</span>
                    <span class="telCon">专业人员将协助指导办理理赔</span>
                </p>
                <p class="send icon icon-lipei2" :style="{color : themeColor}">
                    <span class="time-line-line1" :style="{backgroundColor:themeColor}"></span>
                    <span class="sendTil" :style="{color : themeColor}">寄送理赔材料</span>
                    <span class="telCon">准备好相关证明和票据，寄送至指定地点</span>
                </p>
                <p class="exa icon icon-lipei1" :style="{color : themeColor}">
                    <span class="exaTil" >审核</span>
                    <span class="telCon">确实保险责任范围的事故并在有效期范围内赔付结案，支付赔款</span>
                </p>
            </section>
        </article>
        <!--常见问题-->
        <article class="question" v-show="show_2">
            <section class="productDetailContent special">
                <p class="qus" v-for="item of quesAns">
                    <span class="qusTil" :style="{color : themeColor}" v-html="'Q:'+item.question"></span>
                    <span class="qusCon"  v-html="item.answer"></span>
                </p>
            </section>
        </article>
    </div>
</template>
<style scoped lang="less">
@import "../../../../styles/vars.less";
@import "../../../../assets/iconfonts/health/iconfont.css";

.time-line-line1{

    position: absolute;
    left: 3.8rem;
    height: 4rem;
    width: 1px;
    /*background: @iconfont;*/
    top:3.5rem
}
.arrow{
    height: 5rem;

}
.arrow:before{
    font-family: "health" !important;
    font-size: 0.98rem;
    font-style: normal;
    position: absolute;
    content: "\e60a";
    left: 0;
    top: 1.7rem;
}
.arrow1{
    height: 5rem;
    font-size: 10px
}
.arrow1:before{
    font-family: "health" !important;
    /*font-size: 0.98rem;*/
    font-style: normal;
    position: absolute;
    content: "\e60b";
    left: 0;
    top: 1.7rem;
    font-size: 10px
}
/*I5*/
@media screen and (min-width: 320px) and (max-width: 350px) {
.arrow:before,.arrow1:before {font-size: 8px}
}
@media screen and (min-width: 350px) and (max-width: 375px) {
    .arrow:before,.arrow1:before {font-size: 9px}
}
/*I6*/
@media screen and (min-width: 375px) and (max-width: 414px) {
.arrow:before,.arrow1:before {font-size: 10px}
}
/*I6P*/
@media screen and (min-width: 414px) and (max-width: 568px) {
.arrow:before,.arrow1:before {font-size: 11px}
}
/*横屏*/
@media screen and (min-width: 569px) and (max-width: 667px) {
.arrow:before,.arrow1:before {font-size: 17px}
}
@media screen and (min-width: 667px) and (max-width: 737px) {
.arrow:before,.arrow1:before {font-size: 18px}
}
/*Ipad*/
@media screen and (min-width: 737px){
.arrow:before,.arrow1:before {font-size: 19px}
}
.product{
    background-color: @background-color-white;
}
header{
    height:4.5rem;
>ul{
    >li{
            width: 33.33%;
            font-size: 1.7rem;
            float: left;
            text-align: center;
            height:4.5rem;
            line-height: 4.5rem;
            overflow: hidden;
            >p{
                position: relative;
             }
        }
    }
}
.forPeople1{
    padding-left: 2rem;
    line-height: 4.5rem;
    font-size: 1.5rem;
    /*background: url(../../../../assets/images/health/forPeople.png) no-repeat 2rem center;*/
    /*background-size: 2.7rem 2.7rem;*/
    border-bottom: 1px solid #eee;
    width: 38%;
    /* margin-left: 1rem; */
    white-space: nowrap;

>.forPeople{
        margin-left: 1.5rem;
        margin-right: 1.5rem;
    }
>span{
        color: @font-color-black;
    }
}
.iconPeople,.iconPeriod{
    display: inline-block;
    top: .5rem;
    position: relative;
}
.iconPeople:before{
    font-family: "health" !important;
    font-size: 2.7rem;
    font-style: normal;
    /*color: @iconfont;*/
    position: relative;
    content: "\e607";
}
.iconPeriod:before{
    font-family: "health" !important;
    font-size: 2.7rem;
    font-style: normal;
    /*color: @iconfont;*/
    position: relative;
    content: "\e604";
}

.period{
    padding-left: 2rem;
    line-height: 4.5rem;
    font-size: 1.5rem;
    width: 38%;
    /* margin-left: 1rem; */
    white-space: nowrap;
>.insurPeriod{
        margin-left: 1.5rem;
        margin-right: 1.5rem;
    }
>span{
        color: @font-color-black;
    }
}
.forPeopleCon{
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
    font-size: 1.5rem;
    padding-right: 2rem;
}
.forPeopleCon>span{
    color:#666666
}
table{
    width: 100%;
}
.tablePeo{
    border-bottom: 1px solid #eee;
}
.claimProcess{
    position: relative;
}
.productDetail,.claimProcess{
>.productDetailTitle{
        padding-left: 2rem;
        font-size: 1.5rem;
        color:@font-color-black;
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
        padding-right: 2rem;
    }
>.productDetailContent{
        border-top: 1px solid #eee;
    >p{
            height:4.5rem;
            padding-left: 2rem;
            line-height: 4.5rem;
            font-size: 1.5rem;
        >.forPeople{
                margin-left: 4.2rem;
                margin-right: 1.5rem;
            }
        >span{
                color: @font-color-black;
            }
        }
    >p:last-child{
            border-bottom: none;
        }
    >.period{
            background: url(../../../../assets/images/health/period.png) no-repeat 2rem center;
            background-size: 2.7rem 2.7rem;
        >.insurPeriod{
                margin-left: 4.2rem;
                margin-right: 1.5rem;
            }
        }
    }

}
.icon{
    font-size: 3.6rem;
    font-style: normal;
    color: @iconfont;
    position: relative;
}
.icon-lipei:before {
    content: "\e601";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}
.icon-lipei3:before {
    content: "\e605";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}
.icon-lipei2:before {
    content: "\e603";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}
.icon-lipei1:before {
    content: "\e602";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}

.telTil,.advTil,.sendTil,.exaTil{
    margin-bottom: 1rem;
    display: block;
    margin-left: 7.1rem;
    font-size:1.7rem;
    /*color:@font-color-blue;*/
    margin-top: 1.5rem;
}
.telCon{
    /*margin-bottom: 1.5rem;*/
    display: block;
    margin-left: 7.1rem;
    font-size: 1.5rem;
    color: #666666;
    margin-right: 2rem;
}
.claimProcess1{
    padding-bottom: 1.5rem;
}
.claimProcess,.question {
>.special {
        padding-bottom: 0;
    }
}
.question{
>.productDetailContent{
        padding-top: 1.5rem;
        /*padding-bottom: 1.5rem;*/
    }
}
.qus{
    margin-right: 2rem;
    margin-left: 2rem;
    padding-bottom:1.5rem;
>.qusTil{
        display: block;
        font-size: 1.5rem;
        /*color:@font-color-blue ;*/
        margin-bottom: 1rem;
    }
>.qusCon{
        display: block;
        font-size: 1.5rem;
        color: #666666;
    }
}
</style>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
import {quesAndAns} from "../../../../utils/quesAndAns.js"
export default{
    data(){
        return{
            themeColor:'#2688c4',
            product_0:"",
            product_1:"#bcbcbc",
            product_2:"#bcbcbc",
            show_0:true,
            show_1:false,
            show_2:false
        }
    },
    mounted(){
        this.product_0 = this.themeColor = sessionStorage.fontColor;
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
            "浏览产品":"产品详情"
        });
    },
    methods:{
        product(e){//切换事件
            let target = e.target
            if(target.nodeName == "P") target = target.children[0]//target为span标签
            target.className = "arrow";
            let dom = this.$refs._product.querySelectorAll('span');
            for(let i = 0;i<dom.length;i++){
                if(dom[i].id == target.id){
                    this['product_' + dom[i].id] = this.themeColor;//头部样式切换
                    this['show_' + dom[i].id] = true;//底部显示切换
                    if(dom[i].id == '0'){
                        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                            "浏览产品":"产品详情"
                        });
                    }else if(dom[i].id == '1'){
                        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                            "浏览产品":"理赔流程"
                        });
                    }else{
                        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                            "浏览产品":"常见问题"
                        });
                    }
                    continue;
                }
                dom[i].className = "arrow1";
                this['product_' + dom[i].id] = '#bcbcbc';
                this['show_' + dom[i].id] = false;
            }

        }
    },
    computed: {
        ...mapState({
               qualifiedCrowd:state =>state.asia.productDetail.qualifiedCrowd,
               detail(state){
                    if(state.asia.productDetail.productDetail){
                        return state.asia.productDetail.productDetail.split('|');
                    }
               },
               quesAns:state => quesAndAns()[state.asia.productDetail.askedQuestions || 'QA00030000']//默认问题类型QA00030000
        })
    }
}
</script>
