<template>
    <div class="protection">
        <header>
            <p :style="{color:themeColor}">保障计划</p>
        </header>
        <article>
            <section class="protectionCon">
                <ul>
                    <li>
                        <span>6个月 - 1周岁</span>
                        <span @click="chooseType('1')" class="sextype">{{numbers[0]}}人</span>
                        <popup v-model="popupVisible1" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="insurePer('1','N')" :style="{color : themeColor}">取消</span>
                                <span class="confirm" @click="insurePer('1','Y')" :style="{color : themeColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="dataSlots1" @change="onValuesChange1">
                                </picker>
                            </div>
                        </popup>
                    </li>
                    <li>
                        <span>2周岁 - 60周岁</span>
                        <span @click="chooseType('2')" class="sextype">{{numbers[1]}}人</span>
                        <popup v-model="popupVisible2" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="insurePer('2','N')" :style="{color : themeColor}">取消</span>
                                <span class="confirm" @click="insurePer('2','Y')" :style="{color : themeColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="dataSlots2" @change="onValuesChange2">
                                </picker>
                            </div>
                        </popup>
                    </li>
                    <li>
                        <span>61周岁 - 70周岁</span>
                        <span @click="chooseType('3')" class="sextype">{{numbers[2]}}人</span>
                        <popup v-model="popupVisible3" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="insurePer('3','N')" :style="{color : themeColor}">取消</span>
                                <span class="confirm" @click="insurePer('3','Y')" :style="{color : themeColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="dataSlots3" @change="onValuesChange3">
                                </picker>
                            </div>
                        </popup>
                    </li>
                    <li>
                        <span>71周岁 - 80周岁</span>
                        <span @click="chooseType('4')" class="sextype">{{numbers[3]}}人</span>
                        <popup v-model="popupVisible4" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="insurePer('4','N')" :style="{color : themeColor}">取消</span>
                                <span class="confirm" @click="insurePer('4','Y')" :style="{color : themeColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="dataSlots4" @change="onValuesChange4">
                                </picker>
                            </div>
                        </popup>
                    </li>
                    <li>
                        <span>目的地</span>
                        <span @click="chooseDestination" class="sextype">{{destinationName || '请选择'}}</span>
                    </li>
                    <li>
                        <span>旅行类型</span>
                        <span @click="chooseType('5')" class="sextype" v-for="(item,index) of productsList" v-if="item.isDefault == 'Y'">{{item.h5Value}}</span>
                        <popup v-model="popupVisible5" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="insurePer('5','N')" :style="{color : themeColor}">取消</span>
                                <span class="confirm" @click="insurePer('5','Y')" :style="{color : themeColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="slotList" @change="onValuesChange5">
                                </picker>
                            </div>
                        </popup>
                    </li>

                    <li>
                        <span>旅行开始日期</span>
                        <span @click="openDatePic('start')" class="sextype">{{travelStart}}</span>
                        <datetime-picker
                                ref="start"
                                type="date"
                                :value="startDate_start"
                                :startDate="startDate_start"
                                :endDate="startDate_end"

                                @confirm="handleConfirmStart">
                        </datetime-picker>
                        <!--:TPick="TPick"-->
                    </li>
                    <li>
                        <span>旅行结束日期</span>
                        <span @click="openDatePic('end')" class="sextype">{{travelEnd}}</span>
                        <datetime-picker
                                ref="end"
                                type="date"
                                :value="endDate_start"
                                :startDate="endDate_start"
                                :endDate="endDate_end"

                                @confirm="handleConfirmEnd">
                        </datetime-picker>
                    </li>
                </ul>
            </section>

            <section class="protectionType">
                <div>
                    <ul class="special1" id="product_color">
                        <li v-for="(item,index) of product" :style="{width : comWith}"
                            class="special" ref="special">
                            <span  @click="productSelected(index,item.idProductCombined)" :id="index" ref="change">{{item.combinedName}}</span>
                            <i :id="index" ref="isSelected" class="isSelected" :style="{backgroundColor : themeColor}"></i>
                        </li>
                    </ul>
                </div>
                <div v-for="(item,index) of dutyItems">
                    <ul>
                        <li id="dutyName">
                            <p class="arrow" @click="showUndwrtRange(item.dutyId)">
                                <span style="color:#666">{{item.dutyName}}</span>
                                <span class="arrowCon">{{item.amountName}}</span>
                            </p>
                            <p class="undwrt" style="display:none">{{item.undwrtRange}}</p>
                        </li>
                    </ul>
                </div>
            </section>

        </article>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";

    article{
        background-color: @background-color-white;
    }
    .showBar{
        height: 40px;
        border-bottom: solid 1px #eaeaea;
    }
    .cancle{
        display: inline-block;
        font-size: 16px;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: left;
    }
    .confirm{
        display: inline-block;
        font-size: 16px;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: right;
    }
    .protection{
        margin-top: 1rem;
        margin-left:1rem;
        margin-right:1rem;
        border-radius:0.8rem;
    >header{
         height: 4.5rem;
         background-color:@background-color-light;
         line-height:4.5rem;
         border-top-left-radius: 0.8rem;
         border-top-right-radius: 0.8rem;
    >p{
         font-size: 1.7rem;
         /*color:@font-color-blue;*/
         text-align: center;
     }
    };
    >article{
         border-bottom-right-radius: 0.8rem;
         border-bottom-left-radius: 0.8rem;
     }
    }
    .protectionCon{
    >ul{
    >li{
         height: 4.5rem;
         line-height: 4.5rem;
         font-size: 1.5rem;
         padding-left: 1rem;
         border-bottom: 1px solid #eee;
         background: url(../../../../assets/images/health/arrow.png) no-repeat right 0.6rem center;
         background-size: 1.1rem 1.1rem;
    >span{
         color: #666666;
     }
    }
    }
    }
    .protectionType{
    /*height:4.5rem;*/
    >div{
    >ul{
         overflow:hidden;
    >li{
         /*width: 33%;*/
         font-size: 1.5rem;
         float: left;
         text-align: center;
         /*height:4.5rem;*/
         line-height: 4.5rem;
     }
    }
    }
    >div:last-child{
    >ul>li>p{
         border-bottom: none;
     }
    >ul>li>p:last-child{
         border-top: 1px solid #eee;
     }
    }
    }
    .special{
        border-bottom: 1px solid #eee;
    >span{
         width: 100%;
         display: inline-block;
         color: @font-color-grey;
     }
    }
    .special1>li:first-child{
        border-bottom: 1px solid @font-color-blue;
    >span{
     }
    }
    .sextype{
        float: right;
        text-align: right;
        margin-right: 2.6rem;
        /*width: 30%;*/
        position: relative;
    }
    .sextype::before {
        content: '';
        position: absolute;
        top: 0px; right: -2.6rem;
        bottom: 0px; left: 0px;
    }
    #dutyName{
        /*height: 4.5rem;*/
        /*width: 100%;*/
        text-align: left;
        /*margin-left: 1rem;*/
        float: none;
    >li{
    >p{
         color:#666666;
     }
    }
    }
    .undwrt{
        border-bottom: 1px solid #eee;
        line-height: 2rem;
        padding-right: 1rem;
        padding-left: 1rem;
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
        font-size: 1.3rem;
        color: #797979;
    }
    .arrow{
        height: 4.5rem;
        line-height: 4.5rem;
        background: url(../../../../assets/images/health/arrow.png) no-repeat right 0.6rem center;
        background-size: 1.1rem 1.1rem;
        /*margin-right: 0.6rem;*/
        padding-left: 1rem;
        border-bottom: 1px solid #eee;
    }
    .arrow-b{
        height: 4.5rem;
        line-height: 4.5rem;
        background: url(../../../../assets/images/health/arrow1.png) no-repeat right 0.6rem center;
        background-size: 1.1rem 1.1rem;
        /*margin-right: 0.6rem;*/
        padding-left: 1rem;
        border-bottom: 1px solid #eee;
    }
    .arrowCon{
        float: right;
        margin-right: 2.6rem;
        color: #666666;
    }
    .isSelected{
        width: 100%;
        display: none;
        height: 2px;
        background-color: @font-color-blue;
        margin-bottom: -3px;
    }
</style>
<script>

    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import {Msg} from 'components'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import * as asiaAc from "../../vuex/actionTypes/asia.action.types"
    import { getAhProductDetail,policyInquiry} from '../../apis/asia.api.js'
    import filter from "../../../../utils/filter"

    export default{
        data(){
            return{
                themeColor:'#2688c4',
                TPick:"end",//日期组件点击打开默认显示最大日期,配合startDate1使用
                selected1:"0",
                selected2:"0",
                selected3:"0",
                selected4:"0",
                selected5:"单次旅行",
                popupVisible1:false,
                popupVisible2:false,
                popupVisible3:false,
                popupVisible4:false,
                popupVisible5:false,
            }
        },
        components:{
            datetimePicker,
            picker,
            popup
        },
        mounted(){
            console.log('mounted')
            this.themeColor = sessionStorage.fontColor;
            this.setData();
            SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                "旅行类型":"单次旅行"
            });
        },
        updated(){
            let o = document.getElementById('product_color').children;
                for(let j = 0;j < o.length;j++){
                    o[j].style.borderBottomColor = '#BCBCBC';//li
                    o[j].children[0].style.color = '#BCBCBC';//span
                    o[j].children[1].style.display = 'none';//i
                }
            for(let i = 0;i < this.product.length;i++){
                console.log('updated')
                if(this.product[i].isDefault == 'Y'){
                    let pDom = document.getElementById('product_color');
                    pDom.children[i].style.borderBottomColor = this.themeColor;
                    pDom.children[i].children[0].style.color = this.themeColor;
                    pDom.children[i].children[1].style.display = 'block';
                    break;
                }
            }
        },
        methods:{
            setData(){//初始化一些数据dataSlots4，travelType
                let o = document.getElementById('product_color').children;
                for(let j = 0;j < o.length;j++){
                    o[j].style.borderBottomColor = '#BCBCBC';//li
                    o[j].children[0].style.color = '#BCBCBC';//span
                    o[j].children[1].style.display = 'none';//i
                }
                for(let i = 0;i < this.product.length;i++){
                    console.log('setData')
                    if(this.product[i].isDefault == 'Y'){
                        let pDom = document.getElementById('product_color');
                        pDom.children[i].style.borderBottomColor = this.themeColor;//li
                        pDom.children[i].children[0].style.color = this.themeColor;//span
                        pDom.children[i].children[1].style.display = 'block';//i
                        break;
                    }
                }
            },
            chooseType(num){
                this['popupVisible' + num] = true;
            },
            insurePer(num,type){
                if(num == '1' && type == 'Y'){//6-1
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "6个月-1周岁":this.selected1
                    });
                    this.$store.commit(asiaMu.setNumbers,[0,this.selected1]);
                    this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
                }else if(num == '2' && type == 'Y'){//2-60
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "2周岁-60周岁":this.selected2
                    });
                    this.$store.commit(asiaMu.setNumbers,[1,this.selected2]);
                    this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
                }else if(num == '3' && type == 'Y'){//61-70
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "61周岁-70周岁":this.selected3
                    });
                    this.$store.commit(asiaMu.setNumbers,[2,this.selected3]);
                    this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
                }else if(num == '4' && type == 'Y'){//71-80
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "71周岁-80周岁":this.selected4
                    });
                    this.$store.commit(asiaMu.setNumbers,[3,this.selected4]);
                    this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
                }else if(num == '5' && type == 'Y'){//旅行类型
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "旅行类型":this.selected5
                    });
                    this.$store.commit(asiaMu.setTravelType,this.selected5);
                    let icpProductCode = '';
                    for(let i = 0;i < this.productsList.length;i++){
                        if(this.selected5 == this.productsList[i].h5Value){
                            icpProductCode = this.productsList[i].icpProductCode;
                            this.$store.commit(asiaMu.updateProductsList,[i,'Y',icpProductCode]);
                        }else{
                            this.$store.commit(asiaMu.updateProductsList,[i,'N']);
                        }
                    }
                    //if(icpProductCode != this.icpProductCode){//当前产品详情不等于选中产品类型时，再查一次
                        this.getAhProductDetail();
                    //}
                }
                this['popupVisible' + num] = false
            },
            onValuesChange1(picker, values){
                this.selected1 = values[0];
            },
            onValuesChange2(picker, values){
                this.selected2 = values[0];
            },
            onValuesChange3(picker, values){
                this.selected3 = values[0];
            },
            onValuesChange4(picker, values){
                this.selected4 = values[0];
            },
            onValuesChange5(picker, values){
                this.selected5 = values[0];
            },
            openDatePic(type){
                if(type == 'end' && !this.isChanged) return;
                this.TPick = "start"
                this.$refs[type].open();
            },
            handleConfirmStart(confirm){
                let year = confirm.getFullYear(),
                        month = confirm.getMonth()+1 ,
                        day = confirm.getDate();
                if(month < 10) month = "0" +month
                if(day < 10) day = "0" + day;
                let d = year + '-' + month + '-' + day;
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "旅行开始日期":d.indexOf('-') > -1 ? d.substring(0,7) : d.substring(0,6)
                });
                this.$store.commit(asiaMu.setTravelTime,['start',year + '-' + month + '-' + day]);
                this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
            },
            handleConfirmEnd(confirm){
                let year = confirm.getFullYear(),
                        month = confirm.getMonth()+1 ,
                        day = confirm.getDate();
                if(month < 10) month = "0" +month
                if(day < 10) day = "0" + day;
                let d = year + '-' + month + '-' + day;
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "旅行结束日期":d.indexOf('-') > -1 ? d.substring(0,7) : d.substring(0,6)
                });
                this.$store.commit(asiaMu.setTravelTime,['end',year + '-' + month + '-' + day]);
                this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
            },
            chooseDestination(){
                this.$router.push({'name':"destination"})
            },
            productSelected(index,idProductCombined){
                let pDom = document.getElementById('product_color').querySelectorAll('li');
                for(let i = 0;i < pDom.length;i++){
                    pDom[i].style.borderBottomColor = (index == i ? this.themeColor : '#BCBCBC');
                    pDom[i].children[0].style.color = (index == i ? this.themeColor : '#BCBCBC');
                    pDom[i].children[1].style.display = (index == i ? 'block' : 'none');
                }
                this.$store.commit(asiaMu.setidProductCombined,idProductCombined);
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "选择套餐":idProductCombined
                });
                this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
            },
            showUndwrtRange(dutyId){
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "浏览责任描述":dutyId
                });
                let target = event.target;
                if(target.nodeName == 'SPAN') target = target.parentNode;
                target.className = (target.className == 'arrow' ? 'arrow-b' : 'arrow');
                target.parentNode.children[1].style.display = (target.parentNode.children[1].style.display == 'block' ? 'none' : 'block');
            },
            getAhProductDetail(){
                getAhProductDetail({
                    "agencyNo":sessionStorage.agencyNo,
                    "empno":sessionStorage.empno,
                    "icpProductCode":this.$store.state.asia.infoByProductDetail.icpProductCode,
                    "partnerCode":sessionStorage.partnerCode,
                    "dataSource":'H5',
                    "userId":sessionStorage.userId
                }).then((msg) =>{
                    console.log(msg)
                    if(msg.body.resultCode == "00000"){
                        this.$store.commit(asiaMu.setProductDetail,msg.body);
                        this.$store.dispatch(asiaAc.policyInquiry,this.$store.state.asia)
                    }else{
                        Msg.alert(filter.resultCode(msg.body))
                    }
                })
                /*let obj = json.getAhProductDetail();
                this.$store.commit(asiaMu.setProductDetail,obj);*/
            },
            bodyScroll (event){
                event.preventDefault();
            }
        },
        computed: {
            ...mapState({
                startDate_start:state=>new Date(state.asia.infoByProductDetail.travelTime.startTime_1),
                startDate_end:state=>new Date(state.asia.infoByProductDetail.travelTime.endTime_1),
                travelStart:state=>state.asia.infoByProductDetail.travelStart,//旅行开始日期
                endDate_start:state=>new Date(state.asia.infoByProductDetail.travelTime.startTime_2),
                endDate_end:state=>new Date(state.asia.infoByProductDetail.travelTime.endTime_2),
                travelEnd:state=>state.asia.infoByProductDetail.travelEnd,//旅行结束日期
                isChanged:state=>state.asia.infoByProductDetail.isChanged,//旅行结束日期是否可更改
                product:state=>state.asia.infoByProductDetail.product,
                dutyItems:state=>state.asia.infoByProductDetail.dutyItems,
                numbers:state=>state.asia.numbers,//选择人群人数
                insType:state=>state.asia.insType,//人群
                dataSlots1:state=>state.asia.infoByProductDetail.dataSlots1,
                dataSlots2:state=>state.asia.infoByProductDetail.dataSlots2,
                dataSlots3:state=>state.asia.infoByProductDetail.dataSlots3,
                dataSlots4:state=>state.asia.infoByProductDetail.dataSlots4,
                slotList:state=>state.asia.infoByProductDetail.slotList,
                destinationName:state=>state.asia.destinationName,//目的地名字
                productsList:state=>state.asia.productsList,
                icpProductCode:state=>state.asia.infoByProductDetail.icpProductCode,
                comWith:function(state){//动态计算宽度
                    if(state.asia.infoByProductDetail.product.length > 0){
                        let test = parseInt(1/state.asia.infoByProductDetail.product.length*100)
                        return test + '%'
                    }
                    return '33%'
                }
            })
        },
        watch:{
            popupVisible1(){
                if(this.popupVisible){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            popupVisible2(){
                if(this.popupVisible){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            popupVisible3(){
                if(this.popupVisible){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            popupVisible4(){
                if(this.popupVisible){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            popupVisible5(){
                if(this.popupVisible){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            }
        },
        beforeDestroy(){
            document.body.removeEventListener('touchmove',this.bodyScroll,false);
        }
    }
</script>