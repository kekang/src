<template>
    <div class="tk_main">
        <img v-for="(o,i) of arr" :src="'static/img/zy_' + o + '.Jpeg'">
    </div>
</template>
<script>

export default{
    data () {
        return {
            fontColor:"",
            arr:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
    }
}
</script>
<style scoped lang="less">
    *{ margin:0; padding:0;}
    .tk_main{
        margin:0 auto;
        max-width: 700px;
        height:100%;
    }
    .tk_main img{ width:100%;}
</style>
