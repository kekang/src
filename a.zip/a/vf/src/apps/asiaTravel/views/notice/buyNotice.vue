<template>
    <div>
        <section id="wrapper"><div class="pd10"><div>一、投保须知</div>
            <ol class="lists">
                <li>境外旅行保险每位被保险人每个保险期间限投一份，多投无效。</li>
                <li>为保障您的权益，投保之前请您仔细阅读<span  @click="goClause('noPolicyArea')" style="color:red">不承保地区</span>的特别约定。</li>
                <li>
                    <p>不属于承保范围的人群：People that are not eligible for the insurance:</p>
                    <p>不符合投保年龄限制的人群（即年龄大于80周岁或小于6个月者）；</p>
                    <p>People that are not conform to the age limit (i.e., people of more than 80 years old or less than 6 months old);</p>
                    <p>患癫痫病、精神病或精神分裂等疾病的人群；</p>
                    <p>People that suffer from epilepsy, mental disease, schizophrenia, etc.</p>
                    <p>境外旅行目的是为了诊疗或就医的人群；</p>
                    <p>People whose intention for the overseas trip is to seek medical care or treatment;</p>
                    <p>怀孕满6个月以上的孕妇（怀孕未满6个月的孕妇申请投保的须提供医院证明）</p>
                    <p>Pregnant women with pregnancy of over 6 months (for women who have been pregnant for less than 6 months, medical certificates shall be provided at the time of insurance application)</p>
                    <p>执业医师建议不适合作境外旅行的人群；</p>
                    <p>People that are not fit for overseas travel in the opinion of a medical practitioner;</p>
                    <p>申请投保人员已患有某种疾病，正在等候治疗的；</p>
                    <p>People suffering from a certain disease and waiting for treatment;</p>
                    <p>矿业采掘业、海湾港口工程人员、水坝工程人员、挖井工程人员、桥梁工程人员、摔跤、拳击运动员以及职业类别为6类及6类以上的人员（职业类别以我司职业类别分类表为准）；</p>
                    <p>People engaged in the mining industry, gulf port projects, dam projects, well-digging projects, bridge engineering, wrestling athletes, boxers and people whose occupations are listed in Category 6 or above (occupation categorization is subject to the Occupation Category List of Ping An Annuity);</p>
                    <p>申请投保人员出国是为了移民或定居，短期内不打算回国的。</p>
                    <p>People who travel overseas for the purpose of immigration or settling down and do not intend to return home in short term.</p>
                </li>
                <li>为了得到电子保单最佳浏览效果，请您进入以下链接免费安装Adobe Reader最新版本<span style="color:red">http://get.adobe.com/cn/reader/</span>请您使用彩色激光打印机在普通A4纸上打印此保单，请勿使用针打或者喷墨打印机进行打印。</li>
                <li>24小时理赔报案电话：<span style="color:red">95511</span>，24小时全球援助热线(环球救援): <span style="color:red">+86 10 59104999</span>。为了使您出险后尽快得到救援，请务必第一时间拨打全球援助热线报案，以便保险公司和救援公司尽快为您提供医疗救援服务。若未拨打救援热线报案而自行处理，将可能无法理赔。</li>
            </ol></div></section>

    </div>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
export default{
    data () {
        return {
            fontColor:"#ff6600",
            clauseColor:"#2688c4"
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
        document.body.scrollTop = 0;
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
            "浏览投保须知":'浏览投保须知'
        });
    },
    methods: {
        goClause(type){
            this.$router.push({'name':type});
        }
    }
}
</script>
<style scoped lang="less">
    .complete{
        padding: 1rem;
    }
    .pd10 {
        padding: 10px!important;
    }
    * {
        margin: 0;
        padding: 0;
        outline: none;
    }
    ol.lists li {
        line-height: 20px!important;
        margin-bottom: 8px;
    }
    .lists li {
        margin-left: 20px;
    }
    .lists li {
        list-style: decimal;
    }
    ol.lists li .enhance {
        color: #ee5c3f;
    }
    .fwb {
        font-weight: bold;
    }

</style>
