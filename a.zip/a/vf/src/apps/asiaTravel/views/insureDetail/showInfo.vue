<template id = "#cunConfirm">
    <div>
        <!--保险内容-->
        <inContent></inContent>
        <!--投保人信息-->
        <policyHolder></policyHolder>
        <!--被保人信息-->
        <insured></insured>
        <!--受益人信息-->
        <beneficiary></beneficiary>
        <!--保障期限-->
        <insureLimit></insureLimit>
        <!--保费-->
        <insureCharge></insureCharge>
        <div class="next_button">
            <p @click="pay"  :style="{backgroundColor:fontColor}">订单支付</p>
        </div>
    </div>
</template>
<script>
import {Msg}from "components";
import inContent from './_inContent.vue'//保险内容
import policyHolder from './_policyHolder.vue'//投保人
import insured from './_insured.vue'//被保人
import beneficiary from './_beneficiary.vue'//受益人
import insureLimit from './_insureLimit.vue'//保障期限
import insureCharge from './_insureCharge.vue'//保费
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
import { policyUndwrt,payForICPPAY } from '../../apis/asia.api'
import filter from "../../../../utils/filter"


export default{
    data(){
        return{
            fontColor:"#2688c4",
            locked:false
        }
    },
    beforeMount(){
        if(this.$store.state.asia.productDetail){
            sessionStorage.stateObj = JSON.stringify(this.$store.state.asia);
        }else{
            this.$store.commit(asiaMu.setState,JSON.parse(sessionStorage.stateObj));
        }
    },
    mounted(){
        document.body.scrollTop = 0;
        this.fontColor = sessionStorage.fontColor;
        //进入保单预览页
        //SKAPP.onEvent("保单预览页", "进入保单预览页",{
            //icpProductCode:sessionStorage.icpProductCode,
        //});
    },
    components:{
        inContent:inContent,
        policyHolder:policyHolder,
        insured:insured,
        beneficiary:beneficiary,
        insureLimit:insureLimit,
        insureCharge:insureCharge,

    },
    methods: {
        toRGB(color){
            switch (color){
                case "#4285F6":
                    return "rgb(66,133,246)"
                case "#D8A161":
                    return "rgb(216,161,97)"
                case "#FF6600":
                    return "rgb(255,102,0)"
                case "#F76B6C":
                    return "rgb(247,107,108)"
                case "#F11B33":
                    return "rgb(241,27,51)"
                default:
                    return "rgb(38,136,196)"
            }
        },
        pay(){
            //提交订单
            //SKAPP.onEvent("保单预览页", "提交订单",{
                //icpProductCode:sessionStorage.icpProductCode,
            //});
            SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息确认页面",{
                "订单支付":'支付'
            });
            policyUndwrt({saleRecordId:this.$store.state.asia.infoByProductDetail.saleRecordId,saleAmount:this.$store.state.asia.price}).then(({body}) => {
                if(body.resultCode == "00000"){
                    payForICPPAY({saleRecordId: this.$store.state.asia.infoByProductDetail.saleRecordId}).then(({body}) => {
                        if (body.resultCode == "00000"){
                            //this.$router.push({name: 'cusPay'})
                            //SKAPP.onEvent("保单预览页", "跳转支付",{
                                //icpProductCode:sessionStorage.icpProductCode,
                            //});
                            let url = body.payUrl+"?sign="
                            + body.sign + "&" + "returnUrl="
                            + body.returnUrl + "&" + "amount="
                            + body.amount
                            + '&businessOrder='+body.businessOrder
                            + '&projectId='+body.projectId
                            + '&requestDate='+body.requestDate
                            + '&remark='+body.remark
                            + '&productName='+body.productName + '&color='+this.toRGB(this.fontColor);
                            console.log(url);
                            if(body.customerName){
                                url += '&customerName=' + body.customerName;
                            }
                            window.location.href = url;
                        }else{
                            Msg.alert(filter.resultCode(body))
                        }
                    });
                }else{
                    Msg.alert(filter.resultCode(body))
                }
            });
        }
    },
    computed: {
        ...mapState({
        })
    }
}
</script>
<style scoped lang="less">
    @import "../../../../styles/vars.less";

    .fix{
        height: 7.5rem;
        background-color: #f9f9f9;
    }
    .main-container{
        background-color:#E4E4E4;
        position: absolute;
        width: 100%;
        min-height: 100%;
    }

    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
        >p{
            width:95%;
            margin:0rem auto 0;
            height:4.5rem;
            line-height:4.5rem;
            background-color:@font-color-blue;
            border-radius:5px;
            color:#FFF;
            font-size:1.7rem;
            line-height:4.5rem;
            text-align:center;
        }
    }

</style>
