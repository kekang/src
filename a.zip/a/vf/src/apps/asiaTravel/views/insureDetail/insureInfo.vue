<template >
    <div id="customerInfo">
        <article class="Infro">
            <!--投保人信息-->
            <section class="info_box">
                <div class="info_box_head" :style="{color:themeColor}">&nbsp;投保人信息</div>
                <!--姓名-->
                <div class="info_box_text">
                    <div class="left">姓名*</div>
                    <input name="name" v-model="insurePerson.name" @input="detailAdd('name')" placeholder="请填写姓名" class="rightblank right" maxlength="8">
                </div>
                <div class="info_box_text">
                    <div class="left">英文名*</div>
                    <input name="name" v-model="insurePerson.eName" @input="detailAdd('eName')" placeholder="请填写英文名" class="rightblank right" maxlength="20">
                </div>
                <!--证件类型-->
                <div class="info_box_text">
                    <div class="left">证件类型*</div>
                    <div @click="chooseType(1)">
                        <div class="rightarrow" ></div>
                        <div name="type" class="right">{{insurePerson.appType | apptype}}</div>
                    </div>
                    <popup v-model="popupVisible1" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="insurePer(1,'N')" :style="{color:themeColor}">取消</span>
                            <span class="confirm" @click="insurePer(1,'Y')" :style="{color:themeColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="apptype" @change="onValuesChange1">
                            </picker>
                        </div>
                    </popup>
                </div>
                <div class="info_box_text" v-if="showSexBir">
                    <div class="left">性别*</div>
                    <div @click="chooseType(2)">
                        <div class="rightarrow" ></div>
                        <div name="type" class="right">{{insurePerson.sexType | sex}}</div>
                    </div>
                    <popup v-model="popupVisible2" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="insurePer(2,'N')" :style="{color:themeColor}">取消</span>
                            <span class="confirm" @click="insurePer(2,'Y')" :style="{color:themeColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="sexList" @change="onValuesChange2">
                            </picker>
                        </div>
                    </popup>
                </div>
                <div v-if="showSexBir" class="info_box_text">
                    <div class="left">出生日期*</div>
                    <div @click="openDatePic('picker')">
                        <div class="rightarrow" ></div>
                        <span name="birth" class="right">{{insurePerson.birthday}}</span>
                    </div>
                    <datetime-picker
                            ref="picker"
                            type="date"
                            :startDate= "start"
                            :endDate="end"
                            @confirm="dateConfirm"
                            :TPick="TPick"
                    >
                    </datetime-picker>
                </div>

                <div class="info_box_text">
                    <div class="left">证件号码*</div>
                    <input name="name" v-model="insurePerson.appNums" @input="detailAdd('appNums')" placeholder="请填写证件号码" class="rightblank right" maxlength="25">
                </div>
                <div class="info_box_text">
                    <div class="left">手机号*</div>
                    <input name="name" v-model="insurePerson.phone" @input="detailAdd('phone')" placeholder="请填写手机号" class="rightblank right" maxlength="11">
                </div>
                <div class="info_box_text">
                    <div class="left">邮箱</div>
                    <input name="name" v-model="insurePerson.email" @input="detailAdd('email')" placeholder="请填写邮箱" class="rightblank right" maxlength="28">
                </div>
            </section>
        </article>
        <div class="next_button" @click="next">
            <p :style="{backgroundColor:themeColor}">下一步</p>
        </div>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";

    .society{
        float: right;
        /*margin-right: 1rem;*/
    }
    .hasSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        margin-right: 1rem;
        border-radius: 4px;
    }
    .noSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        border-radius: 4px;
    }

    .main-container{
        background-color:@background-color-dark;
        position: absolute;
        width: 100%;
        min-height: 100%;
    }
    .left{
        float:left;
    }
    .right{
        float: right;
        /*width: 20rem;*/
        text-align: right;
        height: 4.3rem;
    }
    .rightblank{
        //margin-right: 1.5rem;
    }
    .rightarrow{
        float: right;
        width: 1.5rem;
        margin: 1.5rem -0.5rem 0 0.5rem;
        height: 1.8rem;
        background:url("../../../../assets/images/health/arrow.png") no-repeat;
        background-size: 1.6rem 1.6rem;
        position: relative;
    }
    .rightarrow:before{
        content: '';
        position: absolute;
        top: -15px;
        right: -10px;
        bottom: -15px;
        left: -20px;
    }
    .info_box{
        width:95%;
        margin:1.0rem auto;
        border-radius:8px
    }
    input {
        border: none;
        line-height: 4.3rem;
        margin-top: 1px;
        text-align: right;
        font-size: 1.5rem;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        color: #666666;
        background-color:#fff
    }
    .info_box_text{
        height:4.5rem;
        line-height:4.5rem;
        padding: 0 0.8rem 0 1.2rem;
        background-color:#FFFFFF;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.5rem;
        color: #666666;
        border-bottom:1px solid #eee;
    }
    .info_box:nth-child(2){
        padding-bottom:6.5rem;
    }
    .info_box_text:last-child{
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-bottom:0;
    }
    .info_box_head{
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@background-color-light;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.7rem;
        color: @iconfont;
        text-align: center;
    }
    .showBar{
        height: 40px;
        border-bottom: solid 1px #eaeaea;
    }
    .cancle{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: left;
    }
    .confirm{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: right;
    }
    .picker-items {
        border-top: 1px solid #e4e4e4;
    }
    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
    }
    .next_button>p{
        width:95%;
        margin:0rem auto 0;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@font-color-blue;
        border-radius:8px;
        color:#FFF;
        font-size:1.7rem;
        line-height:4.5rem;
        text-align:center;
    }
    #sex_2,#sex_1{

    }
    input#checkInput {
        display: none;
    }
    #checkInput +label{
        -webkit-appearance: none;
        background-color: #fafafa;
        border: 1px solid @font-color-grey;
        padding: 0.7rem;
        display: inline-block;
        border-radius:0.4rem;
        position: relative;
        top:3px
    }

    #checkInput+label{
        background-color: #fff;
        border: 1px solid @font-color-grey;
        position: relative;
    }
    #checkInput+label::before {
        content: '';
        position: absolute;
        top: -13px;
        right: -13px;
        bottom: -13px;
        left: -13px;
    }
    #checkInput:checked+label:before{
        font-family: "health" !important;
        content: "\e63a";
        /*color: @iconfont;*/
        position: absolute;
        top: -1.5rem;
        font-size: 1.5rem;
        left: 0px;
    }
    .mail{
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
    }
    .leftMail{
        -webkit-box-flex: 1;
        -ms-flex: 1;
        flex: 1
    }
    .rightMail{
        -webkit-box-flex: 3;
        -ms-flex: 3;
        flex: 3
    }


</style>
<script>
    import Vue from 'vue'
    import {Msg}from "components";
    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
    import * as asiaMu from "../../vuex/mutationTypes/asia.mutation.types"
    import {recordInsured} from "../../apis/asia.api"
    import filter from "../../../../utils/filter"

    export default{
        data(){
            return{
                themeColor:'#2688c4',
                TPick:"end",//日期组件点击打开默认显示最大日期,配合startDate1使用
                apptype:[{
                    flex: 1,
                    values:['身份证','护照','军人证','港澳台回乡证','出生证','户口本']
                }],
                sexList:[{
                    flex: 1,
                    values:['男','女'],
                }],
                selected1:"身份证",
                selected2:"男",
                popupVisible1:false,
                popupVisible2:false
            }
        },
        components:{
            datetimePicker,
            picker,
            popup
        },
        methods: {
            chooseType(num){
                this['popupVisible' + num] = true;
            },
            insurePer(num,type){
                if(num == '1' && type == 'Y'){//证件类型
                    if(this.selected1 == '身份证'){
                        this.$store.commit(asiaMu.setInsurePerson,{appType:"01"});
                    }else if(this.selected1 == '护照'){
                        this.$store.commit(asiaMu.setInsurePerson,{appType:"02"});
                    }else if(this.selected1 == '军人证'){
                        this.$store.commit(asiaMu.setInsurePerson,{appType:"03"});
                    }else if(this.selected1 == '港澳台回乡证'){
                        this.$store.commit(asiaMu.setInsurePerson,{appType:"06"});
                    }else if(this.selected1 == '出生证'){
                        this.$store.commit(asiaMu.setInsurePerson,{appType:"07"});
                    }else if(this.selected1 == '户口本'){
                        this.$store.commit(asiaMu.setInsurePerson,{appType:"08"});
                    }
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保人信息页面",{
                        "投保人证件类型":this.selected1
                    });
                }else if(num == '2' && type == 'Y'){//性别
                    if(this.selected2 == '男'){
                        this.$store.commit(asiaMu.setInsurePerson,{sexType:"M"});
                    }else if(this.selected2 == '女'){
                        this.$store.commit(asiaMu.setInsurePerson,{sexType:"F"});
                    }
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保人信息页面",{
                        "投保人性别":this.selected2
                    });
                }
                this['popupVisible' + num] = false
            },
            onValuesChange1(picker, values){
                this.selected1 = values[0];
            },
            onValuesChange2(picker, values){
                this.selected2 = values[0];
            },
            openDatePic(type){
                this.TPick = "start"
                this.$refs[type].open();
            },
            dateConfirm(confirm){
                let year = confirm.getFullYear(),
                        month = confirm.getMonth()+1 ,
                        day = confirm.getDate();
                if(month < 10) month = "0" +month
                if(day < 10) day = "0" + day;
                let d = year + '-' + month + '-' + day;
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保人信息页面",{
                    "投保人生日":d.indexOf('-') > -1 ? d.substring(0,7) : d.substring(0,6)
                });
                this.$store.commit(asiaMu.setInsurePerson,{birthday:year + '-'+ month + '-' + day});
            },
            detailAdd(type){
                let obj = {};
                obj[type] = event.target.value;
                this.$store.commit(asiaMu.setInsurePerson,obj);
            },
            checkVal(){
                if(!this.insurePerson.name){
                    Msg.alert('投保人姓名不可为空')
                    return false;
                }else if(!filter.check.checkName(this.insurePerson.name)){
                    Msg.alert('投保人姓名格式不正确')
                    return false;
                }
                if(!this.insurePerson.eName){
                    Msg.alert('投保人英文名不可为空')
                    return false;
                }else if(!/^[A-Za-z ]+$/.test(this.insurePerson.eName)){
                    Msg.alert('投保人英文名不正确')
                    return false;
                }

                if(this.insurePerson.appNums){
                    if(this.insurePerson.appType == "01" || this.insurePerson.appType == "08"){
                        if(!filter.check.EmitIdCodeValid(this.insurePerson.appNums)){
                            Msg.alert('投保人证件号码不正确')
                            return false;
                        }else{
                            let bir = filter.check.birthID(this.insurePerson.appNums);
                            bir = bir.substring(0,4) + '-' + bir.substring(4,6) + '-' + bir.substring(6,8);
                            let sex = filter.check.sexconfirm(this.insurePerson.appNums);
                            this.$store.commit(asiaMu.setInsurePerson,{birthday:bir,sexType:sex});
                        }
                    }else{
                        //投保人护照校验
                        if(this.insurePerson.appType == "02"){
                            if(!filter.check.checkPassport(this.insurePerson.appNums)){
                                Msg.alert('投保人护照号码不正确')
                                return false;
                            }
                        }
                        //投保人军人证校验
                        if(this.insurePerson.appType == "03"){
                            if(!filter.check.armymanId(this.insurePerson.appNums)){
                                Msg.alert('投保人军人证号码不正确')
                                return false;
                            }
                        }
                        //投保人出生证校验
                        if(this.insurePerson.appType == "07"){
                            if(!filter.check.checkBirthCard_emit(this.insurePerson.appNums)){
                                Msg.alert('投保人出生证号码不正确')
                                return false;
                            }
                        }
                        //投保人港澳台回乡证
                        if(this.insurePerson.appType == "06"){
                            if(!filter.check.checkHK(this.insurePerson.appNums)){
                                Msg.alert('投保人港澳台回乡证号码不正确')
                                return false;
                            }
                        }
                    }
                }else{
                    Msg.alert('投保人证件号码不正确')
                    return false;
                }
                if(this.insurePerson.phone){
                    if(!filter.check.checkPh(this.insurePerson.phone)){
                        Msg.alert('投保人手机号格式不正确')
                        return false;
                    }
                }else{
                    Msg.alert('投保人手机号不为空')
                    return false;
                }
                return true;
            },
            next(){
                if(this.checkVal()){
                    this.$router.push({'name':"customerInfo"})
                }
            }
        },
        computed: {
            ...mapState({
                insurePerson:state=>state.asia.insurePerson,
                start(state){
                    return new Date(state.asia.insurePerson.minBir);
                },
                end(state){
                    return new Date(state.asia.insurePerson.maxBir);
                },
                showSexBir(state){
                    return !(state.asia.insurePerson.appType == '01' || state.asia.insurePerson.appType == '08')
                }
            })
        },
        beforeMount(){
            if(this.$store.state.asia.productDetail){
                sessionStorage.stateObj = JSON.stringify(this.$store.state.asia);
            }else{
                this.$store.commit(asiaMu.setState,JSON.parse(sessionStorage.stateObj));
            }
        },
        mounted(){
            this.themeColor = sessionStorage.fontColor;
        }
    }

Vue.filter( 'apptype' , function(value) {
    switch(value){
        case "01":
            return "身份证";
        case "02":
            return "护照";
        case "03":
            return "军人证";
        case "06":
            return "港澳台回乡证";
        case "07":
            return "出生证";
        case "08":
            return "户口本";
    }
});
Vue.filter( 'sex' , function(value) {
    switch(value){
        case "M":
            return "男";
        case "F":
            return "女";
    }
});
</script>