<template>
    <section  v-bind:class="{info_box_hidden: !arrow}" class="info_box">
        <div class="info_box_head"  @click="spread" :style="{color:fontColor}">投保人信息</div>
        <p class="arrow" @click="spread" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div class="info_box_text">
            <div class="info_box_text">
                <div class="left">姓名</div>
                <div class="right" >{{insurePerson.name}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">英文名</div>
                <div class="right" >{{insurePerson.eName}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件类型</div>
                <div class="right" >{{insurePerson.appType | apptype}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件号码</div>
                <div class="right" >{{insurePerson.appNums}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">手机号</div>
                <div class="right" >{{insurePerson.phone}}</div>
            </div>
            <div v-if="insurePerson.email" class="info_box_text">
                <div class="left">邮箱</div>
                <div class="right" >{{insurePerson.email}}</div>
            </div>
        </section>
</template>
<script>
import Vue from 'vue'
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import filter from "../../../../utils/filter"


export default{
    data(){
        return{
            arrow:true,
            fontColor:"#2688c4",
            place:true
        }
    },
    mounted(){
        this.fontColor = sessionStorage.fontColor;
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        }
    },
    computed: {
        ...mapState({
            insurePerson:state=>state.asia.insurePerson
        })
    }
}
Vue.filter( 'apptype' , function(value) {
    switch(value){
        case "01":
            return "身份证";
        case "02":
            return "护照";
        case "03":
            return "军人证";
        case "06":
            return "港澳台回乡证";
        case "07":
            return "出生证";
        case "08":
            return "户口本";
    }
});
</script>
<style scoped lang="less">
    @import "../../../../styles/insureDetail.less";
</style>
