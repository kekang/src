/**
 * Created by zhangping702 on 17/1/19.
 */
import Vue from 'vue'

//产品详情
export function getAhProductDetail (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/product/getAhProductDetail.do'),data)
}
//询价接口
export function policyInquiry (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/policyInquiry.do'),data)
}
//立即投保
export function ahPolicyInsure (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/ahPolicyInsure.do'), data);
}
//记录投保人被保人信息
export function recordInsured (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/insurant/recordInsuredNew.do'), data);
}
//支付接口
export function pay (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/payment/payForPAWXHealth.do'), data);
}
//核保
export function policyUndwrt (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/policyUndwrt.do'), data);
}

//投保须知
export function policyHealthRecord (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/policyHealthRecord.do'), data);
}
//智能核保跳转接口
export function policyAiUndwrtForPAH (data) {
    return Vue.http.post(Vue.getUrl('/icp_yl_dmz/policy/policyAiUndwrtForPAH.do'), data);
}