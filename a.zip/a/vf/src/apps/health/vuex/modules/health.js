/**
 * Created by zhangping702 on 16/12/28.
 */

import Msg from '../../../../components/Msg/Msg'
import filter from '../../../../utils/filter'
import {DateFormat} from '../../../../utils/tool'
import { policyInquiry} from '../../apis/health.api'

import * as healthMu from "../mutationTypes/health.mutation.types"
import * as healthAc from "../actionTypes/health.action.types"

export default {
    //状态
    state: {
        productDetail:"",
        personProducts:"",
        //需要dutys和personProduct的原因是，首次进入需要对责任进行排序
        dutys:[],
        personProduct:"",
        details:"",
        //选中性别后的值
        //选中combineName后的值
        duty:"",
        //选中相应duty的描述
        dutyItems:"",
        saleAmount:"",//价格
        chooseSex:[],
        minAge:"",
        maxAge:"",
        sex:"",//人群性别（英文）
        sexZH:"",//人群性别（中文）
        age:"",//年龄
        effDate:"",//有效期
        newtime:"",//有效期时间戳
        //年龄范围
        effMinAge:"",
        effMaxAge:"",
        insureBirthday:"",//出生日期
        insurePeriod:"",//保险期限
        insurePeriodType:"",//保险期限类型
        idProductCombined:"",//Icp套餐代码
        combined:"",//套餐
        combinedName:"",//套餐名字,
        getProductData:"",//产品信息
        //投保人
        detail_1:{
            appBirthday:"",
            appClientName:"",
            appIdNo:"",
            appIdType:"01",
            appMail:"",
            appMobile:"",
            appProvince:"深圳",
            appProvinceCode:"H050000",
            appGender:["M"]
        },
        //被保人
        detail_2:{
            insurBirthday:"",
            insurClientName:"",
            insurGender:[],
            insurIdNo:"",
            insurIdType:"01",
            insurMail:"",
            insurMobile:"",
            InsurProvince:"深圳",
            InsurProvinceCode:"H050000"
        },
        relationShipCode:"1",//关系
        detailData:"",
        saleRecordId:"",//订单号
        effTime:"",//生效日期
        Undwr:"",//核保返回值
        setinsurePay:"",//支付返回值
        //社保
        needSocialSecurity:false,
        hasSocialSecurity:"Y",
        //健康告知
        insureNotice:"",
        //条款
        serviceTerm:"",
        //偶数是否
        select:[],
        //人群
        crowd:[],
        //选中相应duty的描述
        eleDuty:{},
    },
    //改变状态（同步）
    mutations: {
        //从接口获取产品信息
        [healthMu.setProductDetail] (state, data) {

            document.title = sessionStorage.productName = data.productName;
            sessionStorage.buyNoticeLink = data.buyNoticeLink;
            //健康告知
            state.insureNotice = data.healthLink;
            //条款
            state.serviceTerm = data.buyNoticeLink;
            //条款的pdf编号
            if(data.clauses[0]){
                sessionStorage.clauseLink = data.clauses[0].clauseLink
                sessionStorage.clauseName = data.clauses[0].clauseName
                sessionStorage.planCode = data.clauses[0].planCode
            }

            //生效日
            let timestamp = Date.parse(new Date()),newTime;

            if(data.fixedEffDate){
                newTime = Date.parse(new Date(data.fixedEffDate.substring(0,4),
                    data.fixedEffDate.substring(5,7)-1,
                    data.fixedEffDate.substring(8,11)))
                state.newtime=newTime;
            }
            else if(!data.fixedEffDate && data.minEffDelay ){
                newTime = timestamp + data.minEffDelay*(60*60*24*1000)
                state.newtime=newTime;
            }
            else{
                Msg.alert("生效日不能为空")
                return;
            }
            state.effDate = DateFormat(new Date(newTime),"yyyyMMdd")

            state.productDetail = data;
            //人群排序
            for(let i = 0;i<data.insurPersons.length;i++){
                if(data.insurPersons[i].idPersonType == data.defaultShow.idPersonType) {
                    state.crowd.unshift(data.insurPersons[i])
                }else{
                    state.crowd.push(data.insurPersons[i])
                }
            }
            //根据人群，设置默认年龄
            if(state.crowd[0].insType[0].defaultValue){
                state.age = state.crowd[0].insType[0].defaultValue
            }else{
                state.age = state.crowd[0].personMinAge
            }
            state.minAge = state.crowd[0].personMinAge
            state.maxAge = state.crowd[0].personMaxAge

            //根据人群，设置出生日期初始值
            if(state.age == 0){
                let birthTime = Date.parse(new Date(new Date().getFullYear() - state.age,
                    new Date().getMonth(),
                    new Date().getDate()))
                let newBirth = birthTime - 28*(60*60*24*1000)
                state.insureBirthday = DateFormat(new Date(newBirth),"yyyyMMdd")
            }else{
                let timestamp = Date.parse(new Date(new Date().getFullYear()-state.age,
                    new Date().getMonth(),new Date().getDate()));
                timestamp = timestamp - 1*24*60*60*1000
                state.insureBirthday = DateFormat(new Date(timestamp),"yyyyMMdd")
                console.log(state.insureBirthday)
            }

            //根据人群，设置可选性别
            for(let i = 0;i<state.crowd.length;i++){
                state.chooseSex.push(state.crowd[i].personName)
            }

            //根据人群，套餐排序
            let arr =[],index;
            for(let i=0;i<data.insurPersons.length;i++){
                for (index in data.personProducts) {
                    if(state.crowd[i].idPersonType == index){
                        arr.push({personProducts:data.personProducts[index],idPersonType:index})
                        break;
                    }
                }
            }
            state.personProducts = arr;
            //设置默认套餐,套餐已排序
            state.personProduct = state.personProducts[0].personProducts
            //根据套餐，责任排序
            for(let i=0;i<state.personProduct.length;i++){
                state.dutys.push(state.personProduct[i])
            }

            //不需要排序的字段
            state.insurePeriod = data.insurePeriod;
            state.insurePeriodType = data.insurePeriodType;
            state.dutyItems = data.dutyItems
            state.icpProductCode = data.icpProductCode
            //产品详情
            let arrDe=[];
            arrDe.push(data.productDetail.split('|'))
            state.details = arrDe[0]

            //设置默认性别和人群名称
            state.sex = state.crowd[0].gender
            state.sexZH = state.crowd[0].personName

            //设置默认套餐
            for(let i=0;i< state.personProduct.length;i++){
                if(state.personProduct[i].idProductCombined
                    == state.productDetail.defaultShow.idProductCombined){
                    state.duty = state.dutys[i];
                    state.idProductCombined = state.duty.idProductCombined
                }
            }

            if(data.needSocialSecurity == "Y"){
                state.needSocialSecurity = true
                state.hasSocialSecurity = "Y"
            }
        },
        //有效期时间戳
        [healthMu.setNewtime](state,data){
            state.newtime=data;
        },
        //健康告知状态
        [healthMu.setSelect](state,data){
            if(data % 2 == 0){
                state.select[data/2] = false
            }else{
                state.select[(data-1)/2] = true
            }
        },
        //健康告知
        [healthMu.insureNotice](state,data){
            state.insureNotice = data;
        },
        //服务条款
        [healthMu.serviceTerm](state,data){
            state.serviceTerm = data;
        },
        //选中combineName后的值
        [healthMu.setDuty](state,data){
            state.duty = state.dutys[data];
            state.idProductCombined = state.duty.idProductCombined
        },
        //选择性别后改变的值
        [healthMu.setPersonProduct](state,data){
            for(let i=0;i<state.personProducts.length;i++){
                if(state.personProducts[i].idPersonType == state.crowd[data].idPersonType){
                    state.personProduct = state.personProducts[i].personProducts;
                    state.dutys = state.personProducts[i].personProducts;
                }
            }

            //设置组件所需数据
            for(let i =0;i<state.dutys.length;i++){
                state.eleDuty['dutys' + i] = state.dutys[i].dutys
            }
            //设置最大最小年龄
            state.minAge = state.crowd[data].personMinAge
            state.maxAge = state.crowd[data].personMaxAge
        },
        [healthMu.setPrice] (state, data) {
            if(data.resultCode == "00000"){
                state.saleAmount = data.payPremium
            }else{
                Msg.alert(filter.resultCode(data))
            }
        },
        [healthMu.setSex](state,data){
            state.sex = data
        },
        [healthMu.setSexZH](state,data){
            state.sexZH = data
        },
        [healthMu.setAge](state,data){
            state.age = data
        },
        [healthMu.setinsureBirthday](state,data){
            state.insureBirthday = data
        },
        [healthMu.setidProductCombined](state,data){
            state.idProductCombined = data
        },
        [healthMu.setcombinedName](state,data){
            state.combinedName = data
        },
        [healthMu.setapp](state,data){
            let type = data[1];
            switch(type){
                case "appClientName":
                    state.detail_1.appClientName = data[0];
                    break;
                case "appBirthday":
                    state.detail_1.appBirthday = data[0];
                    break;
                case "appIdNo":
                    state.detail_1.appIdNo = data[0];
                    break;
                case "appIdType":
                    state.detail_1.appIdType = data[0];
                    break;
                case "appMail":
                    state.detail_1.appMail = data[0];
                    break;
                case "appMobile":
                    state.detail_1.appMobile = data[0];
                    break;
                case "appProvince":
                    state.detail_1.appProvince = data[0];
                    break;
                case "appProvinceCode":
                    state.detail_1.appProvinceCode = data[0];
                    break;
                case "appGender":
                    state.detail_1.appGender[0] = data[0];
                    break;
            }
        },
        [healthMu.setinsured](state,data){
            let type = data[1];
            switch(type){
                case "insurClientName":
                    state.detail_2.insurClientName = data[0];
                    break;
                case "insurBirthday":
                    state.detail_2.insurBirthday = data[0];
                    break;
                case "insurIdNo":
                    state.detail_2.insurIdNo = data[0];
                    break;
                case "insurIdType":
                    state.detail_2.insurIdType = data[0];
                    break;
                case "insurMail":
                    state.detail_2.insurMail = data[0];
                    break;
                case "insurMobile":
                    state.detail_2.insurMobile = data[0];
                    break;
                case "InsurProvince":
                    state.detail_2.InsurProvince = data[0];
                    break;
                case "InsurProvinceCode":
                    state.detail_2.InsurProvinceCode = data[0];
                    break;
                case "insurGender":
                    state.detail_2.insurGender[0] = data[0];
                    break;
            }
        },
        [healthMu.setSaleRecordId](state,data){
            state.saleRecordId = data.saleRecordId
        },
        [healthMu.seteffDate](state,data){
            state.effDate = data
        },
        [healthMu.seteffAge](state,data){

            if(state.minAge == 0){
                let birthTime = Date.parse(new Date(new Date().getFullYear() - state.minAge,
                    new Date().getMonth(),
                    new Date().getDate()))
                let newBirth = birthTime - 28*(60*60*24*1000)

                let comBirth = DateFormat(new Date(newBirth),"yyyyMMdd")
                state.effMinAge = comBirth + "," + state.minAge
            }else{

                let timestamp = Date.parse(new Date(new Date().getFullYear()-state.minAge,
                    new Date().getMonth(),new Date().getDate()));
                timestamp = timestamp - 1*24*60*60*1000
                let comBirth = DateFormat(new Date(timestamp),"yyyyMMdd")
                state.effMinAge = comBirth + "," + state.minAge
            }
            let comBirthMax = DateFormat(new Date(),"yyyyMMdd")
            state.effMaxAge = comBirthMax + "," + state.maxAge
        },
        [healthMu.setrecordInsured](state,data){
            state.recordInsured = data.detailData
        },
        [healthMu.setinsurePay](state,data){
            if(data.resultCode == "00000"){
                state.insurePay = data
            }else{
                Msg.alert(filter.resultCode(data))
            }
        },
        [healthMu.setUndwrt](state,data){
            if(data.resultCode == "00000"){
                state.Undwrt = data
            }else{
                Msg.alert(filter.resultCode(data))
            }
        },
        [healthMu.setrelation](state,data){
            state.relationShipCode = data
        },
        [healthMu.setHasSocialSecurity](state,data){
            state.hasSocialSecurity = data
        },
        [healthMu.setNeedSocialSecurity](state,data){
            state.needSocialSecurity = data
        },
        [healthMu.setState](state,data){
            for(let i in data){
                state[i] = data[i]
            }
        },
    },
    actions: {
        //询问价格
        async [healthAc.policyInquiry] ({commit}, data) {
            let list = {
                seqno:"1",
                insurGender:data.sex,
                insurBirthday:data.insureBirthday,
                relationshipWithPrimaryInsurant:"1"
            }
            if(data.productDetail.needSocialSecurity == "Y"){
                list.hasSocialSecurity = data.hasSocialSecurity
            }
            let insurants = [list]
            let submit = {
                idProductCombined:data.idProductCombined,
                insurePeriod:data.insurePeriod,
                insurePeriodType:data.insurePeriodType,
                effDate:data.effDate,
                insurants:insurants
            }
            commit(healthMu.setPrice, await policyInquiry(submit).then(
                function ({body}) {
                    return body
                }
            ));
        },
    }
}