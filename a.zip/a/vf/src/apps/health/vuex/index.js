import health from './modules/health'
export default {
    health
}

