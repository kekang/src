
export default [{
    path: '/GaoWei',
    name: 'GaoWei',
    meta: {
        title: '高危人群',
    },
    component: resolve => require(['../views/noticeOfInsurance/GaoWei.vue'], resolve)
},{
    path: '/healthInform',
    name: 'healthInform',
    meta: {
        title: '健康告知',
    },
    component: resolve => require(['../views/noticeOfInsurance/healthInform.vue'], resolve)
},{
    path: '/HEALTH0003001',
        name: 'HEALTH0003001',
        meta: {
        title: '健康告知',
    },
    component: resolve => require(['../views/noticeOfInsurance/HEALTH0003001.vue'], resolve)
},{
    path: '/HEALTH0003002',
        name: 'HEALTH0003002',
        meta: {
        title: '健康告知',
    },
    component: resolve => require(['../views/noticeOfInsurance/HEALTH0003002.vue'], resolve)
},{
    path: '/HEALTH0003003',
        name: 'HEALTH0003003',
        meta: {
        title: '健康告知',
    },
    component: resolve => require(['../views/noticeOfInsurance/HEALTH0003003.vue'], resolve)
},{
    path: '/HEALTH0003004',
        name: 'HEALTH0003004',
        meta: {
        title: '健康告知',
    },
    component: resolve => require(['../views/noticeOfInsurance/HEALTH0003004.vue'], resolve)
},{
    path: '/HEALTH0003005',
    name: 'HEALTH0003005',
    meta: {
        title: '健康告知',
    },
    component: resolve => require(['../views/noticeOfInsurance/HEALTH0003005.vue'], resolve)
},{
    path: '/HEALTH0004001',
        name: 'HEALTH0004001',
        meta: {
        title: '健康告知',
    },
    component: resolve => require(['../views/noticeOfInsurance/HEALTH0004001.vue'], resolve)
},{
    path: '/H704_1',
    name:"H704_1",
    meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H704_1.vue'], resolve)

},{
    path: '/H704_2',
        name: "H704_2",
        meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H704_2.vue'], resolve)
},{
    path: '/H704_3',
        name: "H704_3",
        meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H704_3.vue'], resolve)
},{
    path: '/H714_1',
        name: "H714_1",
        meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H714_1.vue'], resolve)
},{
    path: '/H714_2',
        name: "H714_2",
        meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H714_2.vue'], resolve)
},{
    path: '/H714_3',
        name: "H714_3",
        meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H714_3.vue'], resolve)
},{
    path: '/H751_1',
    name: "H751_1",
    meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H751_1.vue'], resolve)
},{
    path: '/H751_2',
    name: "H751_2",
    meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H751_2.vue'], resolve)
},{
    path: '/H751_3',
    name: "H751_3",
    meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H751_3.vue'], resolve)
},{
    path: '/H753_1',
        name: "H753_1",
        meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H753_1.vue'], resolve)
},{
    path: '/H753_2',
        name: "H753_2",
        meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H753_2.vue'], resolve)
},{
    path: '/H753_3',
        name: "H753_3",
        meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H753_3.vue'], resolve)
},{
    path: '/H754_1',
        name: "H754_1",
        meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H754_1.vue'], resolve)
},{
    path: '/H754_2',
        name: "H754_2",
        meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H754_2.vue'], resolve)
},{
    path: '/H754_3',
        name: "H754_3",
        meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H754_3.vue'], resolve)
},{
    path: '/H707_1',
        name: "H707_1",
        meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H707_1.vue'], resolve)
},{
    path: '/H707_2',
        name: "H707_2",
        meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H707_2.vue'], resolve)
},{
    path: '/H707_3',
        name: "H707_3",
        meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H707_3.vue'], resolve)
},{
    path: '/H707_4',
        name: "H707_4",
        meta: {
        title: '优选直接结算医院网络',
    },
    component: resolve => require(['../views/noticeOfInsurance/H707_4.vue'], resolve)
},{
    path: '/H707_5',
        name: "H707_5",
        meta: {
        title: '个人产品服务告知书',
    },
    component: resolve => require(['../views/noticeOfInsurance/H707_5.vue'], resolve)
},{
    path: '/H804A_1',
    name: "H804A_1",
    meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H804A_1.vue'], resolve)
},{
    path: '/H804A_2',
    name: "H804A_2",
    meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H804A_2.vue'], resolve)
},{
    path: '/H804A_3',
    name: "H804A_3",
    meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H804A_3.vue'], resolve)
},{
    path: '/H804Y_1',
    name: "H804Y_1",
    meta: {
        title: '保险条款',
    },
    component: resolve => require(['../views/noticeOfInsurance/H804Y_1.vue'], resolve)
},{
    path: '/H804Y_2',
    name: "H804Y_2",
    meta: {
        title: '重要声明',
    },
    component: resolve => require(['../views/noticeOfInsurance/H804Y_2.vue'], resolve)
},{
    path: '/H804Y_3',
    name: "H804Y_3",
    meta: {
        title: '理赔须知',
    },
    component: resolve => require(['../views/noticeOfInsurance/H804Y_3.vue'], resolve)
},{
    path: '/noticeNav',
        name: "noticeNav",
        meta: {
        title: '',
    },
    component: resolve => require(['../views/productDetail/noticeOfInsuranceNav.vue'], resolve)
}]