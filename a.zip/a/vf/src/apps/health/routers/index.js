import Index from './index.route'
import customerInfo from './customerInfo.route'
import insuranceNotice from './insuranceNotice.route'
import {isPrd} from 'utils'

function getIndex () {
    if (isPrd()) {
        return []
    } else {
        return Index
    }
}
//解决vue1存在的hashbang问题
function hashBang(hash) {
    for(let i=0;i<hash.length;i++){
        hash[i].path = '/!/' + hash[i].path.split('/')[1]
    }
    return hash
}

export default [
    ...getIndex(),
    ...hashBang(customerInfo),
    ...hashBang(insuranceNotice)
]
