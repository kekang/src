/**
 * Created by zhangping702 on 17/1/18.
 */

export default [{
    path: '/productDetail',
    name: 'productDetail',
    meta: {
        title: '',
    },
    component: resolve => require(['../views/productDetail/productDetail.vue'], resolve)
},{
    path: '/callback',
    name: 'callback',
    meta: {
        title: '',
    },
    component: resolve => require(['../views/publicity/publicity.vue'], resolve)
},{
    path: '/product',
    name: 'product',
    meta: {
        title: '',
    },
    component: resolve => require(['../views/productDetail/productDetail.vue'], resolve)
},{
    path: '/enterInfo',
    name:"customerInfo",
    meta: {
        title: '填写投被保人信息',
    },
    component: resolve => require(['../views/insureDetail/customerInfo.vue'], resolve)
},{
    path: '/test0003',
    name:"customerInfo",
    meta: {
        title: '填写投被保人信息',
    },
    component: resolve => require(['../views/insureDetail/customerInfo.vue'], resolve)
},{
    path: '/failCallBackVue',
    name:"failCallBackVue",
    meta: {
        title: '核保失败',
    },
    component: resolve => require(['../views/insureDetail/failCallBackVue.vue'], resolve)
},{
    path: '/test0004',
    name:"failCallBackVue",
    meta: {
        title: '核保失败',
    },
    component: resolve => require(['../views/insureDetail/failCallBackVue.vue'], resolve)
},{
    path: '/valiInfo',
    name: 'cusConfirm',
    meta: {
        title: '',
    },
    component: resolve => require(['../views/insureDetail/cusConfirm.vue'], resolve)
},{
    path: '/buyCard',
    name: 'cusPay',
    meta: {
        title: '选择支付平台',
    },
    component: resolve => require(['../views/insureDetail/cusPay.vue'], resolve)
},{
    path: '/complete',
    name: 'paySuccess',
    meta: {
        title: '支付成功',
    },
    component: resolve => require(['../views/insureDetail/paySuccess.vue'], resolve)
},{
    path: '/completeAct',
    name: 'paySuccessForAct',
    meta: {
        title: '支付成功',
    },
    component: resolve => require(['../views/insureDetail/paySuccessForAct.vue'], resolve)
}]
