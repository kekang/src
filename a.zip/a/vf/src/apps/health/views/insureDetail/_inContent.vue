<template>
    <section v-bind:class="{info_box_hidden: !arrow}" class="inContent info_box">
        <div class="info_box_head"  @click="spread" :style="{color:fontColor}">保险内容</div>
        <p class="arrow" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div v-for="(duty,index) in duties" @click="spreadDetail" :data-id = "index" ref="spreadTitle" class="info_box_text">
            <div class="left" :data-id = "index">{{duty.dutyName}}</div>
            <div class="right arrow1" :data-id = "index">{{duty.amountName}}</div>
            <hr style="width: 110%;margin-left: -5%;border-top: 1px dashed #aaa;margin-bottom: 0; margin-top: 0;"  class="hide">
            <div v-if="dutyItems[duty.dutyId]"  class="hide small_text" :data-id = "index">
                <div>{{dutyItems[duty.dutyId].undwrtRange}}</div>
            </div>
        </div>
        <!--
        <div v-if=""class="small_text">
            <div>{{}}</div>
        </div>

        <div  class="info_box_text">
            <div class="left">少儿重大疾病</div>
            <div class="right">10万 ></div>
        </div>
        <div  class="info_box_text">
            <div class="left">癌症住院津贴</div>
            <div class="right">50元/天</div>
        </div>
        <div class="small_text">
            <div>90天等待期后，被保险人初次经医院确诊罹患癌症需要治疗的，我们承担相应保险责任</div>
        </div>
        <div  class="info_box_text">
            <div class="left">一般住院津贴</div>
            <div class="right">30元/天</div>
        </div>
        <div  class="info_box_text">
            <div class="left">住院手术治疗津贴</div>
            <div class="right">50元/天</div>
        </div>-->
    </section>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import {changeColor} from "../../../../utils/skin"

export default{
    data(){
        return{
            arrow:true,
            fontColor:"#2688c4"
        }
    },
    mounted(){
        this.fontColor = changeColor()
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        },
        spreadDetail(event){
            let dom = this.$refs.spreadTitle[event.target.dataset.id];
            dom.children[1].className = dom.children[1].className == "right arrow1" ? "right arrow-b": "right arrow1"
            dom.children[2].className = dom.children[2].className == "hide" ? "": "hide"
            dom.children[3].className = dom.children[3].className =="hide small_text" ? "small_text" :"hide small_text"
        }
    },
    computed: {
        ...mapState({
        duties:state=>state.health.duty.dutys,

        dutyItems:state=>state.health.dutyItems,
        })
    }
}
</script>
<style scoped lang="less">
    @import "../../../../styles/insureDetail.less";
    .hide{
        display: none;
    }
</style>
