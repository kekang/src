<template>
    <div class="background">
        <div class="heads">
            <p><b>核保结论</b></p>
        </div>
        <div class="air">
            <p>非常遗憾，被保险人无法投保该险种，您可以选择其他险种投保。</p>
        </div>
        <div class="next">
            <p @click="back" :style="{backgroundColor:fontColor}">返回</p>
        </div>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    .main-container{
        background-color:#E4E4E4;
        position: absolute;
        width: 100%;
        height: 100%;
    }
    .background{
        background: #f9f9f9;
    }
    .heads{
        width: 90%;
        margin: 1rem auto 1rem;
        line-height: 4.5rem;
        font-size: 2.2rem;
        border-radius: 4px;
        text-align: center;

    }
    .air{
        margin: 1rem 2rem 1rem 2rem;
        font-size: 1.5rem;
        border-radius: 4px;

    }
    .next{
        width: 90%;
        margin: 3rem auto 1rem;
        line-height: 4.5rem;
        font-size: 1.5rem;
        color: #fff;
        border-radius: 4px;
        text-align: center;
        background-color: #FF6600;
    }
</style>
<script>
import {changeColor} from "../../../../utils/skin"
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"


export default{
    data(){
        return {

        }
    },
    beforeMount(){
        if(this.$store.state.health.productDetail){
            sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
        }else{
            this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
        }
    },
    methods:{
        popstateListen(){
            var hashLocation = location.hash;
            var hashSplit = hashLocation.split('#/!/')[1]
            var hashName = hashSplit.split('?')[0];
            if (hashName == 'failCallBackVue') {
                location.href = sessionStorage.firstUrl;
            }else{
                console.log('hashName != enterInfo')
            }
        }
    },
    mounted(){
        this.fontColor = changeColor();
        console.log('==='+this.fontColor);
        document.querySelector('.next').style.backgroundColor = this.fontColor;
        //订单支付页
        //SKAPP.onEvent("核保失败页", "进入核保失败页",{
            //icpProductCode:sessionStorage.icpProductCode,
        //});
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "核保失败页",{
            "核保失败页":'核保失败'
        });
        let _thatVue = this;
        if(sessionStorage.icpProductCode == 'ICPH000008'){//e生保后退操作
            if(sessionStorage.enterZNHB){
                window.history.pushState(null,null, "#/!/test0004");
                window.addEventListener("popstate", stateListen, false);
            }
        }
    },
    components:{

    },
    methods: {
        back(){
            SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "核保失败页",{
                "点击返回":'返回'
            });
            location.href = sessionStorage.firstUrl;
        }
    },
    beforeDestroy(){
        window.removeEventListener("popstate", stateListen, false);
    }
}
function stateListen(){
    var hashLocation = location.hash;
    var hashSplit = hashLocation.split('#/!/')[1]
    var hashName = hashSplit.split('?')[0];
    if (hashName == 'failCallBackVue') {
        location.href = sessionStorage.firstUrl;
    }else{
        console.log('hashName != enterInfo')
    }
}
</script>
