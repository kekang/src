<template >
    <div id = "customerInfo">
        <article class="Infro">
            <!--投保人信息-->
            <section class="info_box">
                <div class="info_box_head" :style="{color:fontColor}">投保人信息</div>
                <!--姓名-->
                <div class="info_box_text">
                    <div class="left">姓名*</div>
                    <input name="name" id="name_1" placeholder="请填写真实姓名" class="rightblank right"
                           v-model="detail_1.appClientName" @input="detail_1Name" >
                </div>
                <!--证件类型-->
                <div class="info_box_text">
                    <div class="left">证件类型*</div>
                    <div @click="detail_chooseType">
                        <div class="rightarrow" ></div>
                        <div name="type" id="type_1" class="right">{{apptype}}</div>
                    </div>
                    <popup v-model="popupVisible1" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="cancle1" :style="{color:fontColor}">取消</span>
                            <span class="confirm" @click="confirm1" :style="{color:fontColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="cardTypeList1" @change="onValuesChange">
                            </picker>
                        </div>
                    </popup>
                </div>
                <!--证件号码-->
                <div class="info_box_text">
                    <div class="left">证件号码*</div>
                    <input name="num" id="num_1" placeholder="请填写有效证件号码" class="right rightblank"
                           v-model="detail_1.appIdNo" @input="detail_1Id"/>
                </div>
                <!--性别-->
                <div v-if="sexbirth_1" class="info_box_text">
                    <div class="left">性别*</div>
                    <div @click="chooseSex1">
                        <div class="rightarrow" ></div>
                        <div name="type"  id="sex_1" class="right" ref="sex_1">{{appsex}}</div>
                    </div>
                    <popup v-model="sexVisible1" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="chooseSex1" :style="{color:fontColor}">取消</span>
                            <span class="confirm" @click="confirmSex1" :style="{color:fontColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="sexList1" @change="onSexChange">
                            </picker>
                        </div>
                    </popup>

                </div>
                <!--出生日期-->
                <div v-if="sexbirth_1" class="info_box_text">
                    <div class="left">出生日期*</div>
                    <div @click="datepick1">
                        <div class="rightarrow" ></div>
                        <span name="birth" id="birth_1" class="right">{{appbirth}}</span>
                    </div>
                    <datetime-picker
                            ref="picker1"
                            type="date"
                            :startDate= "start_1"
                            :endDate="end_1"
                            @confirm="dateConfirm_1"
                            :TPick="TPick"
                    >
                    </datetime-picker>
                </div>
                <!--手机号-->
                <div class="info_box_text">
                    <div class="left">手机号*</div>
                    <input maxlength="11" name="ph" id="ph_1" type="tel"  placeholder="请填写手机号" class="right rightblank"
                           v-model="detail_1.appMobile" @input="detail_1Phone" @blur="bury_1"/>
                </div>
                <!--邮件-->
                <div class="info_box_text mail">
                    <div class="left leftMail">邮件</div>
                    <input name="ph" placeholder="请填写邮箱" class="right rightblank rightMail"
                           v-model="detail_1.appMail" @input="detail_1Mall"/>
                </div>
                <!--投保人常住地址-->
                <div class="info_box_text" v-if="place">
                    <div class="left">常住地址*</div>
                    <div  @click="choosePlace1">
                        <div class="rightarrow"></div>
                        <div name="type" class="right" ref="Place_1">{{detail_1.appProvince}}</div>
                    </div>

                    <popup v-model="placeVisible1" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="canclePlace1" :style="{color:fontColor}">取消</span>
                            <span class="confirm" @click="confirmPlace1" :style="{color:fontColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="placeList1" @change="onPlaceChange1">
                            </picker>
                        </div>
                    </popup>
                </div>
            </section>
            <!--被保人信息-->
            <section class="info_box">
                <div class="info_box_head" :style="{color:fontColor}">被保人信息</div>
                <div class="info_box_text">
                     <input id="checkInput" @click="checkSame" type="checkbox" ref="checkIn"/>
                    <label for="checkInput" :style="{color:fontColor}"></label>
                    <span>被保人同投保人</span>
                </div>
                <div class="info_box_text">
                    <div class="left">姓名*</div>
                    <input id="name_2" class="right rightblank unactive"  placeholder="请填写真实姓名"
                           v-model="detail_2.insurClientName" @input="detail_2Name" ref="detail_2Name">
                </div>
                <div class="info_box_text">
                    <div class="left">与投保人关系*</div>
                    <div @click="relation">
                        <div class="rightarrow" ></div>
                        <div id="relation" class="right">{{relationName}}</div>
                    </div>
                    <popup v-model="relaVisible" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="relacan" :style="{color:fontColor}">取消</span>
                            <span class="confirm" @click="relacon" :style="{color:fontColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="relationList" @change="onrelation">
                            </picker>
                        </div>
                    </popup>
                </div>
                <div class="info_box_text">
                    <div class="left">证件类型*</div>
                    <div @click="chooseType2">
                        <div class="rightarrow" ></div>
                        <div  id="type_2" disabled="disabled" class="right">{{insurIdType}}</div>
                    </div>
                    <popup v-model="popupVisible2" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="cancle2" :style="{color:fontColor}">取消</span>
                            <span class="confirm" @click="confirm2" :style="{color:fontColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="cardTypeList2" @change="onValuesSubChange">

                            </picker>
                        </div>
                    </popup>
                </div>
                <div class="info_box_text">
                    <div class="left">证件号码*</div>
                    <input id="num_2" class="right rightblank unactive"
                           placeholder="请填写有效证件号码" v-model="detail_2.insurIdNo" @input="detail_2Id"/>
                </div>
                <div v-if="sexbirth_2" class="info_box_text">
                    <div class="left">性别*</div>
                    <div @click="chooseSex2">
                        <div class="rightarrow" ></div>
                        <div name="type"   id="sex_2" class="right">{{sex2}}</div>
                    </div>
                    <popup v-model="sexVisible2" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="cancleSex2" :style="{color:fontColor}">取消</span>
                            <span class="confirm" @click="confirmSex2" :style="{color:fontColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="sexList2" @change="onSexChange2">
                            </picker>
                        </div>
                    </popup>
                </div>
                <!--被保人出生日期-->
                <div v-if="sexbirth_2" class="info_box_text">
                    <div class="left">出生日期*</div>
                    <div @click="chooseBirth2">
                        <div class="rightarrow" ></div>
                        <span name="name" id="birth_2" class="right">{{Birthdate}}</span>
                    </div>
                </div>
                <!--被保人手机号-->
                <!--<div class="info_box_text">
                    <div class="left">手机号</div>
                    <input  maxlength="11" id="ph_2" type="tel" class="right rightblank unactive"
                            placeholder="请填写手机号" v-model="detail_2.insurMobile" @input="detail_2Phone" @blur="bury_2"/>
                </div>-->
                <!--邮件-->
                <!--<div class="info_box_text mail">
                    <div class="left leftMail">邮件</div>
                    <input name="ph" placeholder="请填写邮箱" class="right rightblank rightMail"
                           v-model="detail_2.insurMail" @input="detail_2Mall"/>
                </div>-->
                <!--被保人常住地址-->
                <div class="info_box_text" v-if="place">
                    <div class="left">常住地址*</div>
                    <div @click="choosePlace2">
                        <div class="rightarrow" ></div>
                        <div name="type"  class="right" ref="Place_2">{{detail_2.InsurProvince}}</div>
                    </div>
                    <popup v-model="placeVisible2" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="canclePlace2" :style="{color:fontColor}">取消</span>
                            <span class="confirm" @click="confirmPlace2" :style="{color:fontColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="placeList2" @change="onPlaceChange2">
                            </picker>
                        </div>
                    </popup>
                </div>
                <!--社保-->
                <div class="info_box_text" @click="society" v-if="needSocialSecurity">
                    <div class="left">社保*</div>
                    <p class="society">
                        <span class="hasSociety" ref="hasSociety" >有</span>
                        <span class="noSociety" ref="noSociety" >无</span>
                    </p>
                </div>
            </section>
        </article>
        <div class="next_button">
            <p @click="next" :style="{backgroundColor:fontColor}">下一步</p>
        </div>
    </div>

</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";

    .society{
        float: right;
        /*margin-right: 1rem;*/
    }
    .hasSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        margin-right: 1rem;
        border-radius: 4px;
    }
    .noSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        border-radius: 4px;
    }

    .main-container{
        background-color:@background-color-dark;
        position: absolute;
        width: 100%;
        min-height: 100%;
    }
    .left{
        float:left;
    }
    .right{
        float: right;
        /*width: 20rem;*/
        text-align: right;
        height: 4.3rem;
    }
    .rightblank{
    //margin-right: 1.5rem;
    }
    .rightarrow{
        float: right;
        width: 1.5rem;
        margin: 1.5rem -0.5rem 0 0.5rem;
        height: 1.8rem;
        background:url("../../../../assets/images/health/arrow.png") no-repeat;
        background-size: 1.6rem 1.6rem;
        position: relative;
    }
    .rightarrow:before{
        content: '';
        position: absolute;
        top: -15px;
        right: -10px;
        bottom: -15px;
        left: -20px;
    }
    .info_box{
        width:95%;
        margin:1.0rem auto;
        border-radius:8px
    }
    input {
        border: none;
        line-height: 4.3rem;
        margin-top: 1px;
        text-align: right;
        font-size: 1.5rem;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        color: #666666;
        background-color:#fff
    }
    .info_box_text{
        height:4.5rem;
        line-height:4.5rem;
        padding: 0 0.8rem 0 1.2rem;
        background-color:#FFFFFF;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.5rem;
        color: #666666;
        border-bottom:1px dashed #aaa;
    }
    .info_box:nth-child(2){
        padding-bottom:6.5rem;
    }
    .info_box_text:last-child{
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-bottom:0;
    }
    .info_box_head{
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        text-align:center;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@background-color-light;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.7rem;
        color: @iconfont;
    }
    .showBar{
        height: 40px;
        border-bottom: solid 1px #eaeaea;
    }
    .cancle{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: left;
    }
    .confirm{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: right;
    }
    .picker-items {
        border-top: 1px solid #e4e4e4;
    }
    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
    }
    .next_button>p{
        width:95%;
        margin:0rem auto 0;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@font-color-blue;
        border-radius:8px;
        color:#FFF;
        font-size:1.7rem;
        line-height:4.5rem;
        text-align:center;
    }
    #sex_2,#sex_1{

    }
    input#checkInput {
        display: none;
    }
    #checkInput +label{
        -webkit-appearance: none;
        background-color: #fafafa;
        border: 1px solid @font-color-grey;
        padding: 0.7rem;
        display: inline-block;
        border-radius:0.4rem;
        position: relative;
        top:3px
    }

    #checkInput+label{
        background-color: #fff;
        border: 1px solid @font-color-grey;
        position: relative;
    }
    #checkInput+label::before {
        content: '';
        position: absolute;
        top: -13px;
        right: -13px;
        bottom: -13px;
        left: -13px;
    }
    #checkInput:checked+label:before{
        font-family: "health" !important;
        content: "\e63a";
        /*color: @iconfont;*/
        position: absolute;
        top: -1.5rem;
        font-size: 1.5rem;
        left: 0px;
    }
    .mail{
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
    }
    .leftMail{
        -webkit-box-flex: 1;
        -ms-flex: 1;
        flex: 1
    }
    .rightMail{
        -webkit-box-flex: 3;
        -ms-flex: 3;
        flex: 3
    }


</style>
<script>
    import {Msg}from "components";
    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
    import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
    import {recordInsured,policyHealthRecord} from "../../apis/health.api"
    import {changeColor} from "../../../../utils/skin"
    import filter from "../../../../utils/filter"
    import {DateFormat} from '../../../../utils/tool'

    export default{
        data(){
            return{
                TPick:"end",
                //投保人证件选择
                popupVisible1:false,
                apptype:"身份证",
                cardTypeList1:[{
                    flex: 1,
                    values:[],
                }],
                changValue1:this.$store.state.health.detail_1.appIdType,
                changValues1:"身份证",
                //投保人性别选择
                sexbirth_1:false,
                sexVisible1:false,
                sexList1:[{
                    flex: 1,
                    values:['男','女'],
                }],
                appsex:"",
                changeSex:"男",
                //投保人生日
                appbirth:"",
                sexbirth_2:false,
                //投被保人关系
                relaVisible:false,
                relationList:[{
                    flex: 1,
                    values:['本人','配偶','子女','父母'],
                    textAlign: 'center',
                }],
                changeRela:"本人",
                //投保人地址
                changePlace1:this.$store.state.health.detail_1.appProvince,
                placeList1:[{
                    flex: 1,
                    values:['深圳','天津','辽宁(除大连)','北京','上海','广东','江苏','浙江'],
                }],
                changePlaces1:this.$store.state.health.detail_1.appProvinceCode,
                //被保人证件类型
                insurIdType:"身份证",
                popupVisible2:false,
                cardTypeList2:[{
                    flex: 1,
                    values:[],
                }],
                changValue2:this.$store.state.health.detail_2.insurIdType,
                changValues2:"身份证",
                //被保人性别
                sexList2:[{
                    flex: 1,
                    values:['男','女'],
                }],
                sex2:"",
                sexVisible2:false,
                changeSex2:"男",
                //投保人身份证性别
                sexID1:"",
                //投保人身份证出生日期
                birthID1:"",
                //被保人身份证性别
                sexID2:"",
                //被保人身份证出生日期
                birthID2:"",
                flag:"others",
                //投保人地址
                placeVisible1:false,
                //被保人地址
                placeVisible2:false,
                changePlace2:this.$store.state.health.detail_2.InsurProvince,
                changePlaces2:this.$store.state.health.detail_2.InsurProvinceCode,
                placeList2:[{
                    flex: 1,
                    values:['深圳','天津','辽宁(除大连)','北京','上海','广东','江苏','浙江'],
                }],
                //颜色
                fontColor:"#2688c4",
                place:true
            }
        },
        beforeMount(){

            if(this.$store.state.health.productDetail){
                sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
            }else{
                this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
            }
        },
        components:{
            datetimePicker,
            picker,
            popup
        },
        methods: {
            //修改投保人姓名
            detail_1Name(e){
                if(this.flag == "self"){
                    this.$store.commit(healthMu.setapp,[e.target.value,"appClientName"])
                    this.$store.commit(healthMu.setinsured,[e.target.value,"insurClientName"])
                }else{
                    this.$store.commit(healthMu.setapp,[e.target.value,"appClientName"])
                }
            },
            //修改投保人证件类型
            detail_chooseType(){
                this.popupVisible1 = true
            },
            cancle1(){
                this.popupVisible1 = false
            },
            confirm1(){
                this.TPick = "end"
                this.popupVisible1 = false
                if(this.flag == "self"){
                    this.$store.commit(healthMu.setapp,[this.changValue1,"appIdType"])
                    this.$store.commit(healthMu.setinsured,[this.changValue1,"insurIdType"])
                    if(this.changValue1 != "01" && this.changValue1 != "08"){
                        this.sexbirth_1 = true
                        this.sexbirth_2 = true
                    }else{
                        this.sexbirth_1 = false
                        this.sexbirth_2 = false
                    }
                    this.apptype = this.changValues1
                    this.insurIdType = this.changValues1
                }else{
                    if(this.changValues1 == "身份证"){
                        this.changValue1 = "01"
                    }
                    this.$store.commit(healthMu.setapp,[this.changValue1,"appIdType"])
                    if(this.changValue1 != "01" && this.changValue1 != "08"){
                        this.sexbirth_1 = true
                    }else{
                        this.sexbirth_1 = false
                    }
                    this.apptype = this.changValues1
                }
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "投保人证件类型":this.changValues1
                });
            },
            onValuesChange(picker, values) {//投保人证件类型选择
                let type;
                switch(values[0]){
                    case"身份证":
                        type = "01"
                        break;
                    case"护照":
                        type = "02"
                        break;
                    case"军人证":
                        type = "03"
                        break;
                    case"港澳台回乡证":
                        type = "06"
                        break;
                    case"出生证":
                        type = "07"
                        break;
                    case"户口本":
                        type = "08"
                        break;
                }
                this.changValue1 = type;
                this.changValues1 = values[0];
            },
            detail_1Id(e){
                if(this.flag == "self"){
                    this.$store.commit(healthMu.setapp,[e.target.value,"appIdNo"])
                    this.$store.commit(healthMu.setinsured,[e.target.value,"insurIdNo"])
                }else{
                    this.$store.commit(healthMu.setapp,[e.target.value,"appIdNo"])
                }
            },
            //修改投保人地址
            choosePlace1(){
                this.placeVisible1 = true
            },
            canclePlace1(){
                this.placeVisible1 = false
            },
            confirmPlace1(){
                this.placeVisible1 = false
                if(this.flag == "self"){
                    this.$store.commit(healthMu.setapp,[this.changePlaces1,"appProvinceCode"])
                    this.$store.commit(healthMu.setapp,[this.changePlace1,"appProvince"])
                    this.$store.commit(healthMu.setinsured,[this.changePlaces1,"InsurProvinceCode"])
                    this.$store.commit(healthMu.setinsured,[this.changePlace1,"InsurProvince"])
                }else{
                    this.$store.commit(healthMu.setapp,[this.changePlaces1,"appProvinceCode"])
                    this.$store.commit(healthMu.setapp,[this.changePlace1,"appProvince"])
                }
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "投保人常住地址":this.changePlaces1
                });
            },
            onPlaceChange1(picker, values){
                this.changePlaces1 = filter.hel_ProvinceCode(values[0])
                this.changePlace1 = values[0]
            },
            //修改性别
            chooseSex1(){
                this.sexVisible1 = !this.sexVisible1
            },
            confirmSex1(){
                this.sexVisible1 = false
                this.appsex = this.changeSex
                let sex;
                switch(this.appsex){
                    case"男":
                        sex = "M"
                        break;
                    case"女":
                        sex = "F"
                        break;
                }
                if(this.flag == "self"){
                    this.$store.commit(healthMu.setapp,[sex,"appGender"])
                }else{
                    this.$store.commit(healthMu.setapp,[sex,"appGender"])
                }
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "投保人性别":this.appsex
                });
            },
            onSexChange(picker, values){
                let sex;
                switch(values[0]){
                    case"男":
                        sex = "M"
                        break;
                    case"女":
                        sex = "F"
                        break;
                }
                this.changeSex = values[0]
            },
            //修改生日
            datepick1(){
                this.$refs.picker1.open();
                this.TPick = "other"
            },
            dateConfirm_1(confirm){

                let insureBirthday = DateFormat(confirm,"yyyyMMdd")
                this.appbirth = DateFormat(confirm,"yyyy-MM-dd");
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "投保人选择生日":insureBirthday.indexOf('-') > -1 ? insureBirthday.substring(0,7) : insureBirthday.substring(0,6)
                });
                this.$store.commit(healthMu.setapp,[insureBirthday,"appBirthday"])
            },
            //修改投保人手机号
            detail_1Phone(e){
                if(this.flag == "self"){
                    this.$store.commit(healthMu.setapp,[e.target.value,"appMobile"])
                    //this.$store.commit(healthMu.setinsured,[e.target.value,"insurMobile"])
                }else{
                    this.$store.commit(healthMu.setapp,[e.target.value,"appMobile"])
                }
            },
            //修改投保人邮箱
            detail_1Mall(e){
                if(this.flag == "self"){
                    this.$store.commit(healthMu.setapp,[e.target.value,"appMail"])
                    //this.$store.commit(healthMu.setinsured,[e.target.value,"insurMail"])
                }else{
                    this.$store.commit(healthMu.setapp,[e.target.value,"appMail"])
                }
            },
            //修改被保人姓名
            detail_2Name(e){
                this.flag = "others"
                this.$refs.checkIn.checked = false
                this.$store.commit(healthMu.setinsured,[e.target.value,"insurClientName"])
            },
            //修改投被保人关系
            relation(){
                this.relaVisible = true
            },
            relacan(){
                this.relaVisible = false
            },
            relacon(){
                this.relaVisible = false
                let type;
                switch(this.changeRela){
                    case"本人":
                        type = "1"
                        this.flag = "self"
                        this.$refs.checkIn.checked = true
                        break;
                    case"配偶":
                        type = "2"
                        this.flag = "others"
                        this.$refs.checkIn.checked = false
                        break;
                    case"子女":
                        type = "4"
                        this.flag = "others"
                        this.$refs.checkIn.checked = false
                        break;
                    case"父母":
                        type = "3"
                        this.flag = "others"
                        this.$refs.checkIn.checked = false
                        break;
                }
                this.relationName = this.changeRela

                this.$store.commit(healthMu.setrelation,type);
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "被保人与投保人关系":this.changeRela
                });
            },
            onrelation(picker, values){
                this.changeRela = values[0];

            },
            //修改被保人常驻地址
            choosePlace2(){
                this.placeVisible2 = true
            },
            canclePlace2(){
                this.placeVisible2 = false
            },
            confirmPlace2(){
                this.placeVisible2 = false
                this.flag = "others"
                this.$refs.checkIn.checked = false
                this.$store.commit(healthMu.setinsured,[this.changePlaces2,"InsurProvinceCode"])
                this.$store.commit(healthMu.setinsured,[this.changePlace2,"InsurProvince"]);
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "被保人常住地址":this.changePlaces2
                });
            },
            onPlaceChange2(picker, values){
                this.changePlaces2 = filter.hel_ProvinceCode(values[0])
                this.changePlace2 = values[0]
            },
            //修改被保人证件类型
            cancle2(){
                this.popupVisible2 = false
            },
            confirm2(){
                this.popupVisible2 = false
                this.flag = "others"
                this.$refs.checkIn.checked = false

                this.$store.commit(healthMu.setinsured,[this.changValue2,"insurIdType"])
                if(this.$store.state.health.detail_2.insurIdType != "01"
                        && this.$store.state.health.detail_2.insurIdType != "08"){
                    this.sexbirth_2 = true
                }else{
                    this.sexbirth_2 = false
                }
                this.insurIdType = this.changValues2;
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "被保人证件类型":this.changValues2
                });
            },
            chooseType2(){
                this.popupVisible2 = true
            },
            onValuesSubChange(picker, values){
                let type;
                switch(values[0]){
                    case"身份证":
                        type = "01"
                        break;
                    case"护照":
                        type = "02"
                        break;
                    case"军人证":
                        type = "03"
                        break;
                    case"港澳台回乡证":
                        type = "06"
                        break;
                    case"出生证":
                        type = "07"
                        break;
                    case"户口本":
                        type = "08"
                        break;
                }
                this.changValue2 = type;
                this.changValues2 = values[0];

            },
            //修改被保人证件号码
            detail_2Id(){
                this.flag = "others"
                this.$refs.checkIn.checked = false
            },
            //修改被保人生日
            chooseBirth2(){
                Msg.alert('被保人出生日期需与前一页所填保持一致，请在前一页修改')
            },
            //修改被保人性别
            chooseSex2(){
                if(this.$store.state.health.sex == "9"){
                    this.sexVisible2 = true
                }else{
                    Msg.alert('被保人性别不可修改')
                }
            },
            confirmSex2(){
                this.sexVisible2 = false
                this.sex2 = this.changeSex2
                let sex;
                switch(this.sex2){
                    case"男":
                        sex = "M"
                        break;
                    case"女":
                        sex = "F"
                        break;
                    case"":
                        sex = "9"
                        break;
                }
                this.$store.commit(healthMu.setinsured,[sex,'insurGender']);
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "被保人性别":this.sex2
                });
            },
            cancleSex2(){
                this.sexVisible2 = false
            },
            onSexChange2(picker, values){
                this.changeSex2 = values[0]
            },
            //修改被保人手机号
            //detail_2Phone(e){
            //    this.flag = "others"
            //    this.$refs.checkIn.checked = false
            //    this.$store.commit(healthMu.setinsured,[e.target.value,"insurMobile"])
            //},
            //修改被保人邮箱
            //detail_2Mall(e){
            //    this.flag = "others"
            //    this.$refs.checkIn.checked = false
            //    this.$store.commit(healthMu.setinsured,[e.target.value,"insurMail"])
            //},
            //社保
            society(){
                Msg.alert('被保人社保需与前一页所填保持一致，请在前一页修改')
            },
            //埋点
            //完成投保人信息录入
            bury_1(){
                //SKAPP.onEvent("人员信息录入页", "完成投保人信息录入",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //appMobile:this.$store.state.health.detail_1.appMobile
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "完成投保人信息录入":'已完成'
                });
            },
            //完成被保人信息录入
            bury_2(){
                //SKAPP.onEvent("人员信息录入页", "完成被保人信息录入",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //insurMobile:this.$store.state.health.detail_2.insurMobile
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                    "完成被保人信息录入":'已完成'
                });
            },
            //下一步
            next(){
                //校验
                let check={};

                //1、投保人手机号校验(不可为空)
                if(this.$store.state.health.detail_1.appMobile){
                    if(this.checkPh(this.$store.state.health.detail_1.appMobile)){
                        check.appMobile = 'true';
                    }else{
                        Msg.alert('投保人手机号格式不正确')
                        return;
                    }
                }else{
                    Msg.alert('投保人手机号不可为空')
                }
                //1.1、投保人身份证和户口本校验
                if(this.$store.state.health.detail_1.appIdType == "01"
                        || this.$store.state.health.detail_1.appIdType == "08"){
                    if(this.$store.state.health.detail_1.appIdNo){
                        if(this.EmitIdCodeValid(this.$store.state.health.detail_1.appIdNo)){
                            check.appIdNo = 'true';
                        }else{
                            Msg.alert('投保人证件号码不正确')
                            return;
                        }
                        this.sexID1 = this.sexconfirm(this.$store.state.health.detail_1.appIdNo)
                        //生成投保人生日和性别
                        this.$store.commit(healthMu.setapp,[this.sexID1,'appGender'])
                        this.birthID1 = this.birthID(this.$store.state.health.detail_1.appIdNo)

                        //校验身份证的出生日期
                        let start = Date.parse(new Date(new Date().getFullYear()-1
                                - this.$store.state.health.productDetail.appAgeMax,new Date().getMonth(),
                                    new Date().getDate()))

                        let timestamp = Date.parse(new Date(new Date().getFullYear()-
                                this.$store.state.health.productDetail.appAgeMin,
                                new Date().getMonth(),new Date().getDate()));
                        timestamp = timestamp - 1*24*60*60*1000
                        let year = new Date(timestamp).getFullYear(),
                                month = new Date(timestamp).getMonth(),
                                day = new Date(timestamp).getDate()

                        let end = Date.parse(new Date(year,month,day))

                        let current = Date.parse(new Date(this.birthID1.substring(0,4),this.birthID1.substring(4,6)-1,
                                this.birthID1.substring(6,8)))

                        if(current > end || current < start){
                            Msg.alert('投保人出生日期超过范围')
                            return;
                        }

                        this.$store.commit(healthMu.setapp,[this.birthID1,'appBirthday'])
                        check.appGender = 'true'
                        check.appBirthday = 'true'
                    }else{
                        Msg.alert('投保人证件号不能为空')
                        return;
                    }
                }else{
                    if(this.$store.state.health.detail_1.appIdNo){
                        //投保人护照校验
                        if(this.$store.state.health.detail_1.appIdType == "02"){
                            if(this.checkPassport(this.$store.state.health.detail_1.appIdNo)){
                                check.appIdNo = 'true';
                            }else{
                                Msg.alert('投保人护照号码不正确')
                                return;
                            }
                        }
                        //投保人军人证校验
                        if(this.$store.state.health.detail_1.appIdType == "03"){
                            if(this.armymanId(this.$store.state.health.detail_1.appIdNo)){
                                check.appIdNo = 'true';
                            }else{
                                Msg.alert('投保人军人证号码不正确')
                                return;
                            }
                        }
                        //投保人出生证校验
                        if(this.$store.state.health.detail_1.appIdType == "07"){
                            if(this.checkBirthCard_emit(this.$store.state.health.detail_1.appIdNo)){
                                check.appIdNo = 'true';
                            }else{
                                Msg.alert('投保人出生证号码不正确')
                                return;
                            }
                        }
                        //投保人港澳台回乡证
                        if(this.$store.state.health.detail_1.appIdType == "06"){
                            if(this.checkHK(this.$store.state.health.detail_1.appIdNo)){
                                check.appIdNo = 'true';
                            }else{
                                Msg.alert('投保人港澳台回乡证号码不正确')
                                return;
                            }
                        }
                        check.appIdNo = 'true';
                    }else{
                        Msg.alert('投保人证件号不能为空')
                        return;
                    }
                    if(this.$store.state.health.detail_1.appGender){
                        check.appGender = 'true';
                    }else{
                        Msg.alert('投保人性别不能为空')
                        return;
                    }
                    if(this.$store.state.health.detail_1.appBirthday){
                        check.appBirthday = 'true';
                    }else{
                        Msg.alert('投保人出生日期不能为空')
                        return;
                    }

                }
                if(this.$store.state.health.detail_1.appIdType){
                    check.appIdType = 'true'
                }else{
                    Msg.alert('投保人证件类型不能为空')
                    return;
                }
                //2、被保人手机号校验(可空)
                if(this.$store.state.health.detail_2.insurMobile){
                    if(this.checkPh(this.$store.state.health.detail_2.insurMobile)){
                        check.insurMobile = 'true'
                    }else{
                        Msg.alert('被保人手机号格式不正确')
                        return;
                    }
                }
                //2.1、被保人身份证校验
                if(this.$store.state.health.detail_2.insurIdType == "01" ||
                        this.$store.state.health.detail_2.insurIdType == "08"){
                    //生成被保人出生日期
                    this.birthID2 = this.birthID(this.$store.state.health.detail_2.insurIdNo)
//                    this.$store.commit(healthMu.setinsured,[this.birthID2,'insurBirthday'])
                    //生成被保人性别
                    this.sexID2 = this.sexconfirm(this.$store.state.health.detail_2.insurIdNo)
                    if(this.$store.state.health.sex == "9"){
                        this.$store.commit(healthMu.setinsured,[this.sexID2,'insurGender'])
                    }else{
                        if(this.sexID2 == this.$store.state.health.sex){
                            this.$store.commit(healthMu.setinsured,[this.sexID2,'insurGender'])
                            check.insurGender = 'true'
                        }else{
                            Msg.alert("被保人性别需要与前一页保持一致")
                            return;
                        }
                    }
                    if(this.EmitIdCodeValid(this.$store.state.health.detail_2.insurIdNo)){
                        if(this.$store.state.health.sex == "9"){
                            if(this.birthID2 == this.$store.state.health.insureBirthday){
                                check.insurIdNo = 'true'
                            }else{
                                Msg.alert("被保人出生日期需要与前一页保持一致")
                                return;
                            }
                            check.insurGender = 'true'
                        }else{
                            if(this.sexID2 == this.$store.state.health.sex &&
                                    this.birthID2 == this.$store.state.health.insureBirthday)
                            {
                                check.insurIdNo = 'true'
                                check.insurGender = 'true'
                            }else{
                            }
                        }

                    }else{
                        Msg.alert('被保人身份证不正确')
                        return;
                    }
                }else{
                    if(this.$store.state.health.detail_2.insurIdType){
                        //被保人护照校验
                        if(this.$store.state.health.detail_2.insurIdType == "02"){
                            if(this.checkPassport(this.$store.state.health.detail_2.insurIdNo)){
                                check.insurIdNo = 'true';
                            }else{
                                Msg.alert('被保人护照号码不正确')
                                return;
                            }
                        }
                        //被保人军人证校验
                        if(this.$store.state.health.detail_2.insurIdType == "03"){
                            if(this.armymanId(this.$store.state.health.detail_2.insurIdNo)){
                                check.insurIdNo = 'true';
                            }else{
                                Msg.alert('被保人军人证号码不正确')
                                return;
                            }
                        }
                        //被保人出生证校验
                        if(this.$store.state.health.detail_2.insurIdType == "07"){
                            if(this.checkBirthCard_emit(this.$store.state.health.detail_2.insurIdNo)){
                                check.insurIdNo = 'true';
                            }else{
                                Msg.alert('被保人出生证号码不正确')
                                return;
                            }

                        }
                        //被保人港澳台回乡证
                        if(this.$store.state.health.detail_2.insurIdType == "06"){
                            if(this.checkHK(this.$store.state.health.detail_2.insurIdNo)){
                                check.insurIdNo = 'true';
                            }else{
                                Msg.alert('被保人港澳台回乡证号码不正确')
                                return;
                            }

                        }
                        check.insurIdNo = 'true';
                    }else{
                        Msg.alert('被保人证件号不能为空')
                        return;
                    }
                }
                if(this.$store.state.health.detail_2.insurIdType){
                    check.insurIdType = 'true'
                }else{
                    Msg.alert('被保人证件类型需要选择')
                    return;
                }
                //3、如果关系是配偶，性别不同
                if(this.$store.state.health.relationShipCode == "2"){
                    if(this.$store.state.health.detail_1.appGender[0] == this.$store.state.health.detail_2.insurGender[0]){
                        Msg.alert('投被保人为配偶关系时，性别不能相同')
                        return;
                    }
                }
                //4、邮箱正则校验
                if(this.$store.state.health.detail_1.appMail){
                    if(this.checkEmail(this.$store.state.health.detail_1.appMail)){
                        check.appMail = "true"
                    }else{
                        Msg.alert('投保人邮箱格式不正确')
                        return;
                    }
                }
                if(this.$store.state.health.detail_2.insurMail){
                    if(this.checkEmail(this.$store.state.health.detail_2.insurMail)){
                        check.insurMail = "true"
                    }else{
                        Msg.alert('被保人邮箱格式不正确')
                        return;
                    }
                }
                //5、姓名
                if(!this.$store.state.health.detail_1.appClientName){

                    return;
                }else{
                    //姓名不能为纯数字
                    if(this.checkName(this.$store.state.health.detail_1.appClientName)){
                        check.appClientName = 'true';
                    }else{
                        Msg.alert('投保人姓名不能为纯数字')
                        return;
                    }
                }
                if(!this.$store.state.health.detail_2.insurClientName){
                    Msg.alert('被保人姓名不能为空')
                    return;
                }else{
                    //姓名不能为纯数字
                    if(this.checkName(this.$store.state.health.detail_2.insurClientName)){
                        check.insurClientName = 'true'
                    }else{
                        Msg.alert('被保人姓名不能为纯数字')
                        return;
                    }
                }
                //6、性别
                if(!this.$store.state.health.detail_1.appGender[0]){
                    Msg.alert('投保人性别不能为空')
                    return;
                }else{
                    check.appGender = 'true';
                }
                if(!this.$store.state.health.detail_2.insurGender[0]){
                    Msg.alert('被保人性别不能为空')
                    return;
                }else{
                    if(this.$store.state.health.sex != "9"){
                        if(this.$store.state.health.detail_2.insurGender[0] == this.$store.state.health.sex )
                        {
                            check.insurGender = 'true'
                        }else{
                            Msg.alert('被保人性别需与前一页保持一致,如需修改请在前一页修改')
                            return;
                        }
                    }else{
                        check.insurGender = 'true'
                    }
                }
                //如果关系为本人，投被保人生日需要相同
                if(this.$store.state.health.relationShipCode == "1"){
                    if(this.$store.state.health.detail_1.appBirthday != this.$store.state.health.detail_2.insurBirthday
                    ||this.$store.state.health.detail_1.appClientName != this.$store.state.health.detail_2.insurClientName
                    ||this.$store.state.health.detail_1.appGender[0] != this.$store.state.health.detail_2.insurGender[0]
                    ||this.$store.state.health.detail_1.appIdNo != this.$store.state.health.detail_2.insurIdNo
                    ||this.$store.state.health.detail_1.appIdType != this.$store.state.health.detail_2.insurIdType
                    //||this.$store.state.health.detail_1.appMail != this.$store.state.health.detail_2.insurMail
                    //||this.$store.state.health.detail_1.appMobile != this.$store.state.health.detail_2.insurMobile
                    ||this.$store.state.health.detail_1.appProvince != this.$store.state.health.detail_2.InsurProvince
                    ||this.$store.state.health.detail_1.appProvinceCode != this.$store.state.health.detail_2.InsurProvinceCode
                    ){
                        Msg.alert('投被保人为本人关系时，所有信息都要相同')
                        return;
                    }
                }


                //问题：关系是本人
                let list = {
                    insurGender: this.$store.state.health.detail_2.insurGender,
                    insurClientName: this.$store.state.health.detail_2.insurClientName,
                    insurIdType: this.$store.state.health.detail_2.insurIdType,
                    insurIdNo: this.$store.state.health.detail_2.insurIdNo,
                    insurBirthday: this.$store.state.health.detail_2.insurBirthday,
                    //insurMobile: this.$store.state.health.detail_2.insurMobile,
                    relationShipCode: this.$store.state.health.relationShipCode,
                    InsurProvince:this.$store.state.health.detail_2.InsurProvince,
                    InsurProvinceCode:this.$store.state.health.detail_2.InsurProvinceCode,
                    //insurMail: this.$store.state.health.detail_2.insurMail,
                    seqno:"1",
                    saleRecordId: this.$store.state.health.saleRecordId,
                    relationshipWithPrimaryInsurant:"1"
                }
                if(this.$store.state.health.needSocialSecurity){
                    list.hasSocialSecurity = this.$store.state.health.hasSocialSecurity
                }
                let insurants = [list]
                var submitData ={
                    saleRecordId: this.$store.state.health.saleRecordId,
                    appClientName: this.$store.state.health.detail_1.appClientName,
                    appIdType:  this.$store.state.health.detail_1.appIdType,
                    appIdNo: this.$store.state.health.detail_1.appIdNo,
                    appGender: this.$store.state.health.detail_1.appGender,
                    appBirthday: this.$store.state.health.detail_1.appBirthday,
                    appMobile: this.$store.state.health.detail_1.appMobile,


                    // 邮箱
                    appMail: this.$store.state.health.detail_1.appMail,

                    // 常住地
                    appProvince:this.$store.state.health.detail_1.appProvince,
                    appProvinceCode:this.$store.state.health.detail_1.appProvinceCode,
                    insurants:insurants
                };
                if(check.appClientName && check.appIdType && check.appIdNo && check.appGender
                         && check.appMobile && check.insurGender && check.insurClientName
                        && check.insurIdType && check.insurIdNo  && check.insurGender
                        && check.appBirthday
                ){
                    //提交人员信息
                    //SKAPP.onEvent("人员信息录入页", "提交人员信息",{
                        //icpProductCode:sessionStorage.icpProductCode,
                    //});
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                        "提交投被保人信息":'确认提交'
                    });

                    //投保人的社保
                    if(this.$store.state.health.needSocialSecurity && this.$store.state.health.relationShipCode == "1"){
                        submitData.hasSocialSecurity = this.$store.state.health.hasSocialSecurity
                    }

                    //记录投保人被保人
                    recordInsured(submitData).then((data) => {
                        if (data.data.resultCode === '00000') {
                            //成功跳转
                            this.$router.push({
                                name: 'cusConfirm'
                            });
                        }else{
                            Msg.alert(filter.resultCode(data.body))
                        };
                    });
                }else{
                    console.log(check.appClientName , check.appIdType , check.appIdNo , check.appGender
                            , check.appMobile , check.insurGender , check.insurClientName
                            , check.insurIdType , check.insurIdNo  , check.insurMobile , check.appGender
                            , check.appBirthday)
                    Msg.alert('信息填写有误')
                }

            },
            //被保人和投保人同一人
            checkSame(){
                //选中
                if(this.$refs.checkIn.checked){
                    //被保人的信息 = 投保人的信息
                    //数据同步
                    this.$store.commit(healthMu.setinsured,
                            [this.$store.state.health.detail_1.appClientName,"insurClientName"])
                    if(this.$store.state.health.sex == "9"){
                        this.$store.commit(healthMu.setinsured,
                                [this.$store.state.health.detail_1.appGender[0],"insurGender"])
                        this.sex2 = this.appsex
                    }
                    this.$store.commit(healthMu.setinsured,
                            [this.$store.state.health.detail_1.appIdNo,"insurIdNo"])
                    this.$store.commit(healthMu.setinsured,
                            [this.$store.state.health.detail_1.appIdType,"insurIdType"])
                    //this.$store.commit(healthMu.setinsured,
                    //        [this.$store.state.health.detail_1.appMail,"insurMail"])
                    this.$store.commit(healthMu.setinsured,
                            [this.$store.state.health.detail_1.appProvince,"InsurProvince"])
                    this.$store.commit(healthMu.setinsured,
                            [this.$store.state.health.detail_1.appProvinceCode,"InsurProvinceCode"])
                    //this.$store.commit(healthMu.setinsured,
                    //        [this.$store.state.health.detail_1.appMobile,"insurMobile"])
                    //部分页面同步
                    if(this.$store.state.health.detail_2.insurIdType != "01" &&
                            this.$store.state.health.detail_2.insurIdType != "08"){
                        this.sexbirth_2 = true
                    }else{
                        this.sexbirth_2 = false
                    }
                    this.insurIdType = this.apptype

                    //投被保人关系
                    this.$store.commit(healthMu.setrelation,"1")
                    this.flag = "self"

//                    if(this.$store.state.health.detail_1.appMobile){
//                        SKAPP.onEvent("人员信息录入页", "完成投保人信息录入",{
//                            icpProductCode:sessionStorage.icpProductCode,
//                            appMobile:this.$store.state.health.detail_1.appMobile
//                        });
//                    }
                    if(this.$store.state.health.detail_2.insurMobile){
                        //SKAPP.onEvent("人员信息录入页", "完成被保人信息录入",{
                            //icpProductCode:sessionStorage.icpProductCode,
                            //insurMobile:this.$store.state.health.detail_2.insurMobile
                        //});
                        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                            "完成被保人信息录入":'已完成'
                        });
                    }
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                        "被保人同投保人":'相同'
                    });
                }else{
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息填写页面",{
                        "被保人同投保人":'不同'
                    });
                    this.flag = "others"
                }

            },
            mountedFunc(){//加载后执行的操作，因智能核保，故提出来
                //人员信息录入页
                //SKAPP.onEvent("人员信息录入页", "进入人员信息录入页",{
                    //icpProductCode:sessionStorage.icpProductCode,
                //});

                //颜色
                this.fontColor = changeColor();
                //设置投保人初始证件类型
                this.changValue1 = this.$store.state.health.detail_1.appIdType
                switch(this.changValue1){
                    case"01":
                        this.apptype = "身份证"
                        this.sexbirth_1 = false;
                        break;
                    case"02":
                        this.apptype = "护照"
                        this.sexbirth_1 = true;
                        break;
                    case"03":
                        this.apptype = "军人证"
                        this.sexbirth_1 = true;
                        break;
                    case"06":
                        this.apptype = "港澳台回乡证"
                        this.sexbirth_1 = true;
                        break;
                    case"07":
                        this.apptype = "出生证"
                        this.sexbirth_1 = true;
                        break;
                    case"08":
                        this.apptype = "户口本"
                        this.sexbirth_1 = false;
                        break;
                }
                //设置投保人初始年龄
                if(this.$store.state.health.detail_1.appBirthday){
                    let year = this.$store.state.health.detail_1.appBirthday.substring(0,4),
                        month = this.$store.state.health.detail_1.appBirthday.substring(4,6),
                        day = this.$store.state.health.detail_1.appBirthday.substring(6,8)
                    this.appbirth = year + '-' + month + '-' + day
                }else{
                    let timestamp = Date.parse(new Date(new Date().getFullYear()-this.$store.state.health.productDetail.appAgeMin,
                            new Date().getMonth(),new Date().getDate()));
                    timestamp = timestamp - 1*24*60*60*1000

                    let appBirthday = DateFormat(new Date(timestamp),"yyyyMMdd")
                    this.appbirth = DateFormat(new Date(timestamp),"yyyy-MM-dd")
                    //设置投保人初始生日
                    this.$store.commit(healthMu.setapp,[appBirthday,'appBirthday'])
                }

                //设置投保人初始性别
                if(this.$store.state.health.detail_1.appGender[0] == "9"){
                    this.appsex = ""
                }else{
                    if(this.$store.state.health.detail_1.appGender[0] == "M"){
                        this.appsex = "男"
                    }else{
                        this.appsex = "女"
                    }
                }

                //设置被保人出生日期
                let year1 = this.$store.state.health.insureBirthday.substring(0,4),
                    month1 = this.$store.state.health.insureBirthday.substring(4,6),
                    day1 = this.$store.state.health.insureBirthday.substring(6,8)
                this.Birthdate = year1 + '-' + month1 + '-' + day1
                this.$store.commit(healthMu.setinsured,[year1 + '' + month1 + '' + day1,'insurBirthday'])
                //设置被保人初始性别
                if(this.$store.state.health.detail_2.insurGender.length == 0 ){
                    if(this.$store.state.health.sex == "9"){
                        this.sex2 = ""
                    }else{
                        this.$store.commit(healthMu.setinsured,
                                [this.$store.state.health.sex,'insurGender'])
                        if(this.$store.state.health.sex == "M"){
                            this.sex2 = "男"
                        }else{
                            this.sex2 = "女"
                        }
                    }
                }else{
                    if(this.$store.state.health.sex != "9"){
                        this.$store.commit(healthMu.setinsured,
                                [this.$store.state.health.sex,'insurGender'])
                    }
                    if(this.$store.state.health.detail_2.insurGender[0] == "M"){
                        this.sex2 = "男"
                    }else{
                        this.sex2 = "女"
                    }
                }
                //设置被保人初始证件类型
                this.changValue2 = this.$store.state.health.detail_2.insurIdType
                switch(this.changValue2){
                    case"01":
                        this.insurIdType = "身份证"
                        this.sexbirth_2 = false;
                        break;
                    case"02":
                        this.insurIdType = "护照"
                        this.sexbirth_2 = true;
                        break;
                    case"03":
                        this.insurIdType = "军人证"
                        this.sexbirth_2 = true;
                        break;
                    case"06":
                        this.insurIdType = "港澳台回乡证"
                        this.sexbirth_2 = true;
                        break;
                    case"07":
                        this.insurIdType = "出生证"
                        this.sexbirth_2 = true;
                        break;
                    case"08":
                        this.insurIdType = "户口本"
                        this.sexbirth_2 = false;
                        break;
                }
                //设置社保
                //社保
                if(this.$store.state.health.needSocialSecurity){
                    if(this.$store.state.health.hasSocialSecurity == "Y"){
                        this.$refs.noSociety.style.color="#666666"
                        this.$refs.noSociety.style.backgroundColor="#BCBCBC"
                        this.$refs.hasSociety.style.backgroundColor=this.fontColor
                        this.$refs.hasSociety.style.color="white"
                    }else if (this.$store.state.health.hasSocialSecurity == "N"){
                        this.$refs.hasSociety.style.color="#666666"
                        this.$refs.hasSociety.style.backgroundColor="#BCBCBC"
                        this.$refs.noSociety.style.backgroundColor=this.fontColor
                        this.$refs.noSociety.style.color="white"

                    }
                }
                //设置初始被保人与投保人关系
                if(!!this.$store.state.health.relationShipCode){
                    this.relationName = filter.hel_relationShip(this.$store.state.health.relationShipCode)
                }else{
                    this.relationName = "本人"
    //                this.$refs.checkIn.checked = true
                }
                //设置证件类型选择（区别海外版）
                if(this.$store.state.health.productDetail.icpProductCode == "ICPH000005" ||
                        this.$store.state.health.productDetail.icpProductCode == "ICPH000002" ||
                        this.$store.state.health.productDetail.icpProductCode == "ICPH000006")
                {
                    let arr = ['身份证']
                    this.cardTypeList1[0].values = this.cardTypeList2[0].values = arr
                }else{
                    let arr = ['身份证','护照','军人证','港澳台回乡证','出生证','户口本']
                    this.cardTypeList1[0].values = this.cardTypeList2[0].values = arr
                }
                //设置常驻地址(运动卫士没有)
                if(this.$store.state.health.productDetail.icpProductCode == "ICPH000004"||
                   this.$store.state.health.productDetail.icpProductCode == "ICPH000001"
                ){
                    this.place = false
                    this.$store.commit(healthMu.setapp,["","appProvinceCode"])
                    this.$store.commit(healthMu.setapp,["","appProvince"])
                    this.$store.commit(healthMu.setinsured,["","InsurProvince"])
                    this.$store.commit(healthMu.setinsured,["","InsurProvinceCode"])
                }

                document.body.scrollTop = 0;
            },
            checkPh(num){
                let flag;
                if(num){
                    let num3rd = num.toString().substr(0,3);
                    var arr = ["130","131","132","155","156","186","185","176","134","135","136","137","138","139","150","151","152","157","158","159","182","183","184","188","187","147","178","133","153","180","181","189","177"];
                    for(var i = 0 ; i< arr.length ; i++){
                        if(num3rd == arr[i]){
                            flag = true;
                            break;
                        }else{
                            flag = false;
                        }
                    }
                }
                return flag;
            },
            /**
             * 身份证15位编码规则：dddddd yymmdd xx p
             * dddddd：地区码
             * yymmdd: 出生年月日
             * xx: 顺序类编码，无法确定
             * p: 性别，奇数为男，偶数为女
             * <p />
             * 身份证18位编码规则：dddddd yyyymmdd xxx y
             * dddddd：地区码
             * yyyymmdd: 出生年月日
             * xxx:顺序类编码，无法确定，奇数为男，偶数为女
             * y: 校验码，该位数值可通过前17位计算获得
             * <p />
             * 18位号码加权因子为(从右到左) Wi = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2,1 ]
             * 验证位 Y = [ 1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2 ]
             * 校验位计算公式：Y_P = mod( ∑(Ai×Wi),11 )
             * i为身份证号码从右往左数的 2...18 位; Y_P为脚丫校验码所在校验码数组位置
             *
             */
                EmitIdCodeValid(idCard) {
                if (idCard.length == 18) {
                    var a_idCard = idCard.split("");// 得到身份证数组
                    if (this.isValidityBrithBy18IdCard(idCard) && this.isTrueValidateCodeBy18IdCard(a_idCard)) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    Msg.alert("身份证位数不正确")
                    return false;
                }
            },
            /**
             * 验证18位数身份证号码中的生日是否是有效生日
             * @param idCard 18位数身份证字符串
             * @return
             */
            isValidityBrithBy18IdCard(idCard18){
                var year = idCard18.substring(6, 10);
                var month = idCard18.substring(10, 12);
                var day = idCard18.substring(12, 14);
                var temp_date = new Date(year, parseFloat(month) - 1, parseFloat(day));
                if (temp_date.getFullYear() != parseFloat(year) ||
                        temp_date.getMonth() != parseFloat(month) - 1 ||
                        temp_date.getDate() != parseFloat(day)) {
                    return false;
                } else {
                    return true;
                }
            },
            /**
             * 判断身份证号码为18位时最后的验证位是否正确
             * @param a_idCard 身份证号码数组
             * @return
             */
            isTrueValidateCodeBy18IdCard(a_idCard){
                var Wi = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1];// 加权因子
                var ValideCode = [1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2];// 身份证验证位值.10代表X
                var sum = 0; // 声明加权求和变量
                if (a_idCard[17].toLowerCase() == 'x') {
                    a_idCard[17] = 10;// 将最后位为x的验证码替换为10方便后续操作
                }
                for (var i = 0; i < 17; i++) {
                    sum += Wi[i] * a_idCard[i];// 加权求和
                }
                var valCodePosition = sum % 11;// 得到验证码所位置
                if (a_idCard[17] == ValideCode[valCodePosition]) {
                    return true;
                }
                else {
                    return false;
                }
            },
            /**
             * 判断身份证的出生日期
             * @param num 身份证号码字符串
             * @return
             */
            birthID(num){
                let year = num.substring(6, 10);
                var month = num.substring(10, 12);
                var day = num.substring(12, 14);
                return year + "" +month +day
            },
            /**
             * 判断身份证的性别
             * @param num 身份证号码字符串
             * @return
             */
            sexconfirm(num){
                let idBirth
                //console.log(num)
                if(num.length == 15){
                    idBirth = num.substr(14,1);
                }else{
                    idBirth = num.substr(16,1);
                }
                if(idBirth%2){//偶数为F
                    return "M"
                }else{
                    return "F"
                }
            },
            // 身份证正则校验
            checkIdNum(num){
                if(String(num).length==18){
                    var t=/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X|x)$/
                }else{
                    Msg.alert("身份证位数不正确")
                }
                var tet=new RegExp(t);
                return tet.test(num)
            },
            /**
             * 判断邮箱
             * @param email_address 邮箱地址
             * @return
             */
            checkEmail( email_address ){
                var regex = /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g;
                return regex.test( email_address )//test方法用于检测是否匹配正则
            },
            bodyScroll (event){
                event.preventDefault();
            },
            // 护照校验：
            checkPassport: function(value) {
                var v = value.replace(/(^\s+)|(\s+$)/g,"").replace(/\s/g,"");
                return (this.checkNumberAndChar(value) && v.length >= 3 && v.length <= 30);
            },
            checkNumberAndChar: function(val) {
                var reg = /^[A-Za-z0-9]+$/;
                return reg.test(val);
            },
            // 军人证：
            armymanId: function(value) {
                return (/((^[\u4e00-\u9fa5]{1}[\u5b57]{1}[\u7b2c]{1}[0-9]{5,14})+$)|((^[\u4e00-\u9fa5]{2}[\u5b57]{1}[\u7b2c]{1}[0-9]{5,14})+$)/.test(value));
            },
            //出生证校验
            checkBirthCard_emit: function (val) {
                return (/^[A-Z]{1}[0-9]{9}$/.test(val));
            },
            //港澳台回乡证
            checkHK: function (val) {
                val=val.replace(/\(/,"").replace(/\)/,"");
                return (/^[0-9A-Za-z]{8,30}$/.test(val));
            },
            //姓名正则
            checkName(val){
                return (isNaN(val));
            },
            isWeiXin (){
                var ua = window.navigator.userAgent.toLowerCase();
                if(ua.match(/MicroMessenger/i) == 'micromessenger'){
                    return true;
                }else{
                    return false;
                }
            }
        },
        computed:{
            ...mapState({
                detail_1:state=>state.health.detail_1,
                detail_2:state=>state.health.detail_2,
                //投保人生日范围
                start_1:function(state){
                    return new Date(new Date().getFullYear()-1 - state.health.productDetail.appAgeMax,new Date().getMonth(),
                            new Date().getDate())
                },
                end_1:function(state){

                    let timestamp = Date.parse(new Date(new Date().getFullYear()-state.health.productDetail.appAgeMin,
                            new Date().getMonth(),new Date().getDate()));
                    timestamp = timestamp - 1*24*60*60*1000
                    let year = new Date(timestamp).getFullYear(),
                            month = new Date(timestamp).getMonth(),
                            day = new Date(timestamp).getDate()
                    return new Date(year,month,day)
                },
                needSocialSecurity:state => state.health.needSocialSecurity,
                relationName(state){
                    return  filter.hel_relationShip(state.health.relationShipCode)
                }
            })
        },
        watch:{
            sexVisible2(){
                if(this.sexVisible2){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            sexVisible1(){
                if(this.sexVisible1){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            popupVisible1(){
                if(this.popupVisible1){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            popupVisible2(){
                if(this.popupVisible2){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            placeVisible1(){
                if(this.placeVisible1){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            placeVisible2(){
                if(this.placeVisible2){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            relaVisible(){
                if(this.relaVisible){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            },
            popstateListen(){
                var hashLocation = location.hash;
                var hashSplit = hashLocation.split('#/!/')[1]
                var hashName = hashSplit.split('?')[0];
                alert(hashName)
                if (hashName == 'enterInfo') {
                    location.href = sessionStorage.firstUrl;
                }else{
                    console.log('hashName != enterInfo')
                }
            }
        },
        mounted(){
            let _thatVue = this;
            if(sessionStorage.icpProductCode == 'ICPH000008'){//e生保后退操作
                if(sessionStorage.enterZNHB){
                    window.history.pushState(null,null, "#/!/test0003");
                    window.addEventListener("popstate", stateListen, false);
                }
            }
            //filter.historyGo(sessionStorage.icpProductCode);
            if(sessionStorage.enterZNHB == 'Y'){//从智能核保传过来
                sessionStorage._signMethod = this.$route.query.signMethod || '';
                sessionStorage._signature = this.$route.query.signature || '';
                sessionStorage._aiUndwrtResult = this.$route.query.undwrtDecideType || '';
                sessionStorage._aiUndwrtId = this.$route.query.uwMedicalId || '';
                sessionStorage._specialAgreement = this.$route.query.exclusiveAgreement || '';
                sessionStorage._outChannelOrderId = this.$route.query.outChannelOrderId || '';

                let stateObj = JSON.parse(sessionStorage.stateObj);
                this.$store.commit(healthMu.setState,stateObj);
                let that = this;
                setTimeout(function(){
                    that.mountedFunc();

                    //提交智能核保健康告知页
                    //SKAPP.onEvent("健康告知页", "提交健康告知",{
                        //icpProductCode:sessionStorage.icpProductCode,
                        //healthResult:"Y"
                    //});
                    var saleRecordId = that.$store.state.health.saleRecordId;
                    var submitData = {
                        saleRecordId: saleRecordId,
                        healthRecord: '{"P00500001":"Y"}',
                        healthResult: 'Y'
                    };
                    policyHealthRecord(submitData).then((data) => {
                        //默认核保通过
                    });


                },0);
            }else{
                this.mountedFunc()
            }
        },
        beforeDestroy(){
            document.body.removeEventListener('touchmove',this.bodyScroll,false);
            window.removeEventListener("popstate", stateListen, false);
        },
        beforeRouteLeave (to, from, next) {
            console.log(to)
            console.log(from);
            next();

        }

    }
function stateListen(){
    var hashLocation = location.hash;
    var hashSplit = hashLocation.split('#/!/')[1]
    var hashName = hashSplit.split('?')[0];
    if (hashName == 'enterInfo') {
        location.href = sessionStorage.firstUrl;
    }else{
        console.log('hashName != enterInfo')
    }
}
</script>