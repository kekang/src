<template>
    <div class="buycard">
        <div class="main">
            <section>
                <div class="name" :style="{color:fontColor}">{{productName}}</div>
            </section>
            <section class="payincharge">
                <div class="left">应付金额</div>
                <div class="right"><span class="blue" :style="{color: fontColor}">{{insuredCharge}}</span>元</div>
            </section>
            <!--<section class="platform">-->
                <!--<div class="platformtitle" :style="{color: fontColor}">选择支付平台</div>-->
                <!--<div>-->
                    <!--<div class="plattext" @click="pay1">-->
                        <!--<img class="platimg left" src="../../../../assets/images/health/pinganPay.png"/>-->
                        <!--<div class="left">平安付</div>-->
                        <!--<div class="platnext right"></div>-->
                    <!--</div>-->
                <!--</div>-->
            <!--</section>-->
        </div>
        <div class="next_button">
            <p @click="pay1" :style="{backgroundColor:fontColor}">确认支付</p>
        </div>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    .main-container{
    background-color:#E4E4E4;
    position: absolute;
    width: 100%;
    height: 100%;
}
    .name{
        margin-top: 1rem;
        height: 5rem;
        line-height: 5rem;
        background: #fff;
        color: #666;
        font-size: 1.7rem;
        font-weight: 400;
        padding-left: 2rem;
    }
    .buycard{
        background:#E4E4E4!important;
        width:100%
    }
    .main{
        width:100%
    }
    .blue{
        /*color: @iconfont;*/
    }
    .left{
        float:left
    }
    .right{
        float:right
    }
    .payincharge{
        margin-top:1rem;
        height:5rem;
        line-height:5rem;
        background:#fff;
        color:#666;
        font-size:1.5rem;
        padding: 0 2rem 0
    }
    .platform{
        width: 94%;
        margin: 1rem auto;
        border-radius: 8px;
        background-color:#f5f5f5;
        >.platformtitle{
            height:5rem;
            font-size:1.7rem;
            line-height:5rem;
            /*color:@iconfont;*/
            text-align:center
        }
    }
    .plattext{
        height:5rem;
        line-height:5rem;
        background-color:#fff;
        font-size:1.5rem;
        color:#666;
        border-bottom-right-radius: 8px;
        border-bottom-left-radius: 8px;
        position:relative
    }
    .platimg{
        height: 3rem;
        margin-top: 1rem;
        margin-left: 1.7rem;
        margin-right: 1.7rem;
    }
    .platnext{
        background:url("../../../../assets/images/health/arrow.png") no-repeat;
        margin-right: 1.7rem;
        height: 2rem;
        width: 2rem;
        position: absolute;
        right: -1rem;
        top: 1.5rem;
    }
    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
    }
    .next_button>p{
        width:95%;
        margin:0rem auto 0;
        height:4.5rem;
        line-height:4.5rem;
        background-color:@font-color-blue;
        border-radius:8px;
        color:#FFF;
        font-size:1.7rem;
        line-height:4.5rem;
        text-align:center;
    }

</style>
<script>
import {Msg}from "components";
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import { pay } from '../../apis/health.api'
import {changeColor} from "../../../../utils/skin"
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"

//import {PAD} from "../../../../utils/PAD"

export default
{
    data()
    {
        return {
            insuredCharge: sessionStorage.saleAmount,
            saleRecordId: sessionStorage.saleRecordId,
            setinsurePay: sessionStorage.setinsurePay,
            fontColor:"#2688c4",
            productName:sessionStorage.productName
        }
    }
,
    beforeMount(){
        if(this.$store.state.health.productDetail){
            sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
        }else{
            this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
        }
    },
    mounted()
    {
        this.fontColor = changeColor()
        //订单支付页
        SKAPP.onEvent("订单支付页", "进入订单支付页",{
            icpProductCode:sessionStorage.icpProductCode,
        });
    }
,
    components:{
    }
,
    methods: {
        pay1()
        {
            //提交确认订单
            SKAPP.onEvent("订单支付页", "提交确认订单",{
                icpProductCode:sessionStorage.icpProductCode,
            });
            pay({saleRecordId: this.saleRecordId}).then(
                ({body}) => {
                if (body.resultCode == "00000"){
                    //this.$router.push({name: 'cusPay'})

                    let url = body.payUrl + "?" + "sign_type="
                        + body.signType + "&" + "sign="
                        + body.sign + "&" + "return_url="
                        + body.returnUrl + "&" + "notify_url="
                        + body.notifyUrl+ '&goods_desc='+body.goodsDesc
                            + '&channel_order_no='+body.channelOrderNo
                            + '&channel_id='+body.channelId
                            + '&total_fee='+body.totalFee;
//                    url = url.replace('+',"2B%")
                    console.log(url);
                    window.location.href = url;
                }
                else
                {
                    Msg.alert(filter.resultCode(body))
                }
            }
        )
        }
    },
    beforeDestroy(){
        //判断是否需要跳回首页
        if(!this.$store.state.health.productDetail){
            this.$router.push({name:"productDetail"})
        }
    },
}

</script>
