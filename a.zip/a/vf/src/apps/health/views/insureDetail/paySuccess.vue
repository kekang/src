<template>
    <div class="complete">
        <div class="main">
            <section class="payincharge">
                <div class="left"><p class="success" :style="{color:fontColor}"></p></div>
                <div class="right">
                    <div class="sucTop">尊敬的客户，您的保单<span class="blue" :style="{color:fontColor}">投保成功</span></div>
                    <div class="sucBot">您可在平安官网www.pingan.com.cn验证</div>
                </div>
            </section>
            <section class="payincharge" style="padding:0;width:100%;" v-if="hasH5">
                <iframe style="width:100%;border:0" scrolling=no src=""></iframe>
            </section>
    <!--        <section class="platform">
                <div class="platformtitle">保单信息</div>
                <div>
                    <div class="plattext">
                        <div class="left">保单号</div>
                        <div class="right">{{}}</div>
                    </div>
                </div>
            </section>-->
            <div class="next_button" v-if="partnerCode == 'CZBX18' && callback">
                <p @click="back"  :style="{backgroundColor:fontColor}"><span id="s"></span>s后自动返回</p>
            </div>
        </div>
    </div>
</template>
<script>
//import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import {changeColor} from "../../../../utils/skin"
//import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"

export default{
    data () {
        return {
            fontColor:"#2688c4",
            partnerCode:sessionStorage.partnerCode,
            hasH5:true,//是否嵌套h5页面
            h5url:'',//h5 url
            callback:false
        }
    },
    beforeMount(){
        //if(this.$store.state.health.productDetail){
            //sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
        //}else{
           // this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
        //}
    },
    mounted(){
        this.fontColor = changeColor()
        //SKAPP.onEvent("支付成功页", "进入支付成功页",{
            //icpProductCode:sessionStorage.icpProductCode
        //});
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "支付成功页",{
            "支付成功页":'支付成功'
        });
        this.callback = !!sessionStorage.callBackUrl;
        if(this.partnerCode == 'CZBX18' &&　this.callback){
            let s = 10
            function showtime(){
                document.getElementById('s').innerHTML = s;
                if(s>0){
                    s = s-1;
                }
                if(s == 0){
                    window.location.href = sessionStorage.callBackUrl
                }
            }
            clearInterval(settime);
            var settime = setInterval(function(){
                showtime();
            },1000);
        }
        //嵌套h5处理
        console.log(this.$route.query.h5)
        if(this.$route.query.h5 && this.$route.query.h5 != 'null'){
            this.h5url = this.$route.query.h5;
            var frame = document.getElementsByTagName('iframe')[0];
            frame.setAttribute('src',this.h5url);
            setTimeout(function(){
                var win = frame.contentWindow,
                doc = win.document,
                html = doc.documentElement,
                body = doc.body;
                // 获取高度
                var height = document.body.clientHeight-document.getElementsByTagName('section')[1].offsetTop;
                var height_2 = frame.contentDocument.documentElement.offsetHeight
                height = height > height_2 ? height : height_2;
                frame.setAttribute('height', height);
            },1000);
        }else{
            this.hasH5 = false;
        }
    },
    beforeDestroy(){
        //判断是否需要跳回首页
        //if(!this.$store.state.health.productDetail){
            //this.$router.push({name:"productDetail"})
        //}
    },
    methods:{
        back(){
            window.location.href = sessionStorage.callBackUrl
        }
    }
}
</script>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";

    .main-container{
    background-color:#E4E4E4;
    position: absolute;
    width: 100%;
    height: 100%;
}
    .complete{
        background:#E4E4E4!important;
         width:100%
    }
    .main{
        width:100%
    }
    .blue{
        /*color:@iconfont*/
    }
    .left{
        float:left
    }
    .right{
        float:right
    }
    img{
        height:6rem;
    }
    .success{
        height:6rem;
    }
    .success:before{
        font-family: "health" !important;
        font-style: normal;
        /*color: @iconfont;*/
        position: absolute;
        content: "\e606";
        left: 0;
        font-size: 6rem;
        top:-1.5rem;
        position: relative;
    }
    .payincharge{
        height: 10rem;
        width: 100%;
        background: #fff;
        margin-top: 1rem;
        padding: 2rem 2.5rem;
    }
    .sucTop{
        font-size: 1.7rem;
        color: #666;
        text-align: center;
        margin-top: 1rem;
    }
    .sucBot{
        color:#797979;
        font-size:1.3rem;
        text-align:center
    }
    .platform{
        width: 94%;
        margin: 2rem auto;
        border-radius: 8px;
        background-color:#f5f5f5;
        >.platformtitle{
        height:5rem;
        font-size:1.7rem;
        line-height:5rem;
        color:#2688c4;
        text-align:center
        }
    }
    .plattext{
        height:5rem;
        line-height:5rem;
        background-color:#fff;
        font-size:1.7rem;
        padding: 0 2rem 0;
        border-bottom-right-radius: 8px;
        border-bottom-left-radius: 8px;
    }

    .platnext{
        margin-right: 1.7rem;
    }
    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
    >p{
         width:95%;
         margin:0rem auto 0;
         height:4.5rem;
         line-height:4.5rem;
         background-color:@font-color-blue;
         border-radius:5px;
         color:#FFF;
         font-size:1.7rem;
         line-height:4.5rem;
         text-align:center;
     }
    }
</style>
