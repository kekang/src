<template>
    <section v-bind:class="{info_box_hidden: !arrow}" class="info_box">
        <div class="info_box_head" @click="spread" :style="{color:fontColor}">受益人信息</div>
        <p class="arrow" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div class="info_box_text">
            <div class="left">受益人</div>
            <div class="right">法定</div>
        </div>
    </section>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import {changeColor} from "../../../../utils/skin"

export default{
    data(){
        return{
            arrow:true,
            fontColor:"#2688c4"
        }
    },
    mounted(){
        this.fontColor = changeColor()
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        }
    },
    computed: {
        ...mapState({
            detail_2:state=>state.health.detail_2
})
}
}
</script>
<style scoped lang="less">
    @import "../../../../styles/insureDetail.less";
</style>
