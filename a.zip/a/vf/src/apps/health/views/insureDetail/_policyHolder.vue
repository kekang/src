<template>
    <section  v-bind:class="{info_box_hidden: !arrow}" class="info_box">
        <div class="info_box_head"  @click="spread" :style="{color:fontColor}">投保人信息</div>
        <p class="arrow" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div class="info_box_text">
            <div class="left">姓名</div>
            <div id="name_1" class="right">{{detail_1.appClientName}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件类型</div>
                <div id="type_1" class="right" >{{appIdType}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件号码</div>
                <div id="num_1" class="right">{{detail_1.appIdNo}}</div>
            </div>
            <div v-if="appGender" class="info_box_text">
                <div class="left">性别</div>
                <div id="sex_1" class="right">{{appGender}}</div>
            </div>
            <div v-if="detail_1.appBirthday" class="info_box_text">
                <div class="left">出生日期</div>
                <div id="date_1" class="right">{{detail_1.appBirthday}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">手机号</div>
                <div id="ph_1" class="right">{{detail_1.appMobile}}</div>
            </div>
            <div v-if="detail_1.appMail" class="info_box_text">
                <div class="left">邮箱</div>
                <div class="right unactive">{{detail_1.appMail}}</div>
            </div>
            <div class="info_box_text" v-if="place">
                <div class="left">常驻地址</div>
                <div class="right">{{detail_1.appProvince}}</div>
            </div>
        </section>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import {changeColor} from "../../../../utils/skin"
import filter from "../../../../utils/filter"


export default{
    data(){
        return{
            arrow:true,
            fontColor:"#2688c4",
            place:true
        }
    },
    mounted(){
        this.fontColor = changeColor();
        //设置常驻地址(运动卫士没有)
        if(this.$store.state.health.productDetail.icpProductCode == "ICPH000004"||
                this.$store.state.health.productDetail.icpProductCode == "ICPH000001"
        ){
            this.place = false
        }
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        }
    },
    computed: {
        ...mapState({
            detail_1:state=>state.health.detail_1,
            appIdType(state){
                return filter.hel_insurId(state.health.detail_1.appIdType)
            },
            appGender(state){
                return filter.hel_sex(state.health.detail_1.appGender[0])
            }
        })
    }
}
</script>
<style scoped lang="less">
    @import "../../../../styles/insureDetail.less";
</style>
