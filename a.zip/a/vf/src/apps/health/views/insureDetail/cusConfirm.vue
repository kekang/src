<template id = "#cunConfirm">
    <div>
        <!--保险内容-->
        <inContent></inContent>
        <!--投保人信息-->
        <policyHolder></policyHolder>
        <!--被保人信息-->
        <insured></insured>
        <!--受益人信息-->
        <beneficiary></beneficiary>
        <!--保障期限-->
        <insureLimit></insureLimit>
        <!--保费-->
        <insureCharge></insureCharge>
        <div class="next_button">
            <p @click="pay"  :style="{backgroundColor:fontColor}">订单支付</p>
        </div>
    </div>
</template>
<script>
import {Msg}from "components";
import inContent from './_inContent.vue'//保险内容
import policyHolder from './_policyHolder.vue'//投保人
import insured from './_insured.vue'//被保人
import beneficiary from './_beneficiary.vue'//受益人
import insureLimit from './_insureLimit.vue'//保障期限
import insureCharge from './_insureCharge.vue'//保费
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import { policyUndwrt,pay } from '../../apis/health.api'
import {changeColor} from "../../../../utils/skin"
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
import filter from "../../../../utils/filter"
//import {PAD} from "../../../../utils/PAD"


export default{
    data(){
        return{
            fontColor:"#2688c4",
            locked:false
        }
    },
    beforeMount(){
        if(this.$store.state.health.productDetail){
            sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
        }else{
            this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
        }
    },
    mounted(){
        document.body.scrollTop = 0;
        this.fontColor = changeColor()
        //进入保单预览页
        //SKAPP.onEvent("保单预览页", "进入保单预览页",{
            //icpProductCode:sessionStorage.icpProductCode,
        //});
    },
    components:{
        inContent:inContent,
        policyHolder:policyHolder,
        insured:insured,
        beneficiary:beneficiary,
        insureLimit:insureLimit,
        insureCharge:insureCharge,

    },
    methods: {
        pay(){
            if(!this.locked){
                this.locked = true;
                //提交订单
                //SKAPP.onEvent("保单预览页", "提交订单",{
                    //icpProductCode:sessionStorage.icpProductCode,
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "信息确认页面",{
                    "订单支付":'支付'
                });
                let obj = {
                    saleRecordId:this.saleRecordId,
                    //saleAmount:this.$store.state.health.saleAmount,
                    aiUndwrtId:sessionStorage._aiUndwrtId,
                    aiUndwrtResult:sessionStorage._aiUndwrtResult,
                    signature:sessionStorage._signature,
                    signMethod:sessionStorage._signMethod,
                    specialAgreement:sessionStorage._specialAgreement,
                    outChannelOrderId:sessionStorage._outChannelOrderId
                }
                policyUndwrt(obj).then(({body}) => {
                    if(body.resultCode == "00000"){

                        sessionStorage.saleAmount = this.$store.state.health.saleAmount
                        sessionStorage.saleRecordId = this.$store.state.health.saleRecordId
                        sessionStorage.setinsurePay = this.$store.state.health.setinsurePay

                        //this.$router.push({name: 'cusPay'})
                        pay({saleRecordId: sessionStorage.saleRecordId}).then(({body}) => {
                            if (body.resultCode == "00000"){
                                //SKAPP.onEvent("保单信息预览", "跳转支付",{
                                    //icpProductCode:sessionStorage.icpProductCode
                                //});
                                let url = body.payUrl + "?" + "sign_type="
                                    + body.signType + "&" + "sign="
                                    + body.sign + "&" + "return_url="
                                    + body.returnUrl + "&" + "notify_url="
                                    + body.notifyUrl+ '&goods_desc='+body.goodsDesc
                                        + '&channel_order_no='+body.channelOrderNo
                                        + '&channel_id='+body.channelId
                                        + '&total_fee='+body.totalFee;
                                console.log(url);
                                window.location.href = url;
                            }else{
                                this.locked = false;
                                Msg.alert(filter.resultCode(body))
                            }
                        });


                    }else{
                        this.locked = false;
                        Msg.alert(filter.resultCode(body))
                    }
                });
            }
        }
    },
    computed: {
        ...mapState({
            insureBirthday:state=>state.health.insureBirthday,
            saleRecordId:state=>state.health.saleRecordId,
            Undwr:state=>state.health.Undwr
        })
    },
    beforeRouteEnter (to, from, next) {
        // 在渲染该组件的对应路由被 confirm 前调用
        // 不！能！获取组件实例 `this`
        // 因为当钩子执行前，组件实例还没被创建
        console.log('beforeRouteEnter');
        //sessionStorage.enterZNHB = '';
        next()
    },
    beforeDestroy(){
        //判断是否需要跳回首页
        if(!this.$store.state.health.productDetail){
            this.$router.push({name:"productDetail"})
        }
    }

}
</script>
<style scoped lang="less">
    @import "../../../../styles/vars.less";

    .fix{
        height: 7.5rem;
        background-color: #f9f9f9;
    }
    .main-container{
        background-color:#E4E4E4;
        position: absolute;
        width: 100%;
        min-height: 100%;
    }

    .next_button{
        position:fixed;
        bottom:0;
        width:100%;
        height:6.5rem;
        background-color:rgba(0,0,0,0.3);
        padding-top: 1rem;
            >p{
                width:95%;
                margin:0rem auto 0;
                height:4.5rem;
                line-height:4.5rem;
                background-color:@font-color-blue;
                border-radius:5px;
                color:#FFF;
                font-size:1.7rem;
                line-height:4.5rem;
                text-align:center;
            }
    }

</style>
