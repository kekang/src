<template>
    <div class="complete">
        <div class="main">
            <section class="payincharge">
                <div class="left"><p class="success" :style="{color:fontColor}"></p></div>
                <div class="right">
                    <div class="sucTop">尊敬的客户，您的保单<span class="blue" :style="{color:fontColor}">投保成功</span></div>
                    <div class="sucBot">您可在平安官网www.pingan.com.cn验证</div>
                </div>
            </section>
            <section class="payincharge" style="padding:0;width:100%" v-if="hasH5">
                <iframe style="width:100%;border:0" scrolling=no src=""></iframe>
            </section>

        </div>
        <div class="active">
            <section >
                <img class="code" src="../../../../assets/images/healthCode/code.png"/>
                <p>扫码关注酷保云</p><p>领取现金红包</p>
            </section>
        </div>
    </div>
</template>
<script>
//import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import {changeColor} from "../../../../utils/skin"
import {Msg,Loading} from 'components'
//import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"


export default{
    data () {
        return {
            fontColor:"#2688c4",
            hasH5:true,//是否嵌套h5页面
            h5url:'',//h5 url
            //gPath : window.location.origin+"/icp_yl_dmz/";
            //gPath : "http://iicp.pingan.com.cn/icp_yl_dmz/";
        }
    },
    beforeMount(){
        //if(this.$store.state.health.productDetail){
            //sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
        //}else{
            //this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
        //}
    },
    mounted(){
        this.fontColor = changeColor()
        alert(sessionStorage.vn)
        alert(sessionStorage.icpProductCode)
        //SKAPP.onEvent("支付成功页", "进入支付成功页",{
            //icpProductCode:sessionStorage.icpProductCode
        //});
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "支付成功页",{
            "支付成功页":'支付成功'
        });
        //嵌套h5处理
        console.log(this.$route.query.h5)
        if(this.$route.query.h5 && this.$route.query.h5 != 'null'){
            this.h5url = this.$route.query.h5;
            var frame = document.getElementsByTagName('iframe')[0];
            frame.setAttribute('src',this.h5url);
            setTimeout(function(){
                var win = frame.contentWindow,
                doc = win.document,
                html = doc.documentElement,
                body = doc.body;
                // 获取高度
                var height = document.body.clientHeight-document.getElementsByTagName('section')[1].offsetTop;
                var height_2 = frame.contentDocument.documentElement.offsetHeight
                height = height > height_2 ? height : height_2;
                frame.setAttribute('height', height);
            },1000);
        }else{
            this.hasH5 = false;
        }

    },
    methods:{
    }
}
</script>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";

    .main-container{
    background-color:#E4E4E4;
    position: absolute;
    width: 100%;
    height: 100%;
}
    .complete{
        background:#E4E4E4!important;
         width:100%
    }
    .main{
        width:100%
    }
    .blue{
        /*color:@iconfont*/
    }
    .left{
        float:left
    }
    .right{
        float:right
    }
    img{
        height:6rem;
    }
    .success{
        height:6rem;
    }
    .success:before{
        font-family: "health" !important;
        font-style: normal;
        /*color: @iconfont;*/
        position: absolute;
        content: "\e606";
        left: 0;
        font-size: 6rem;
        top:-1.5rem;
        position: relative;
    }
    .payincharge{
        height: 10rem;
        width: 100%;
        background: #fff;
        margin-top: 1rem;
        padding: 2rem 2.5rem;
    }
    .sucTop{
        font-size: 1.7rem;
        color: #666;
        text-align: center;
        margin-top: 1rem;
    }
    .sucBot{
        color:#797979;
        font-size:1.3rem;
        text-align:center
    }
    .platform{
        width: 94%;
        margin: 2rem auto;
        border-radius: 8px;
        background-color:#f5f5f5;
        >.platformtitle{
        height:5rem;
        font-size:1.7rem;
        line-height:5rem;
        color:#2688c4;
        text-align:center
        }
    }
    .plattext{
        height:5rem;
        line-height:5rem;
        background-color:#fff;
        font-size:1.7rem;
        padding: 0 2rem 0;
        border-bottom-right-radius: 8px;
        border-bottom-left-radius: 8px;
    }

    .platnext{
        margin-right: 1.7rem;
    }
.code{
    width: 40%;
    height: auto;
    margin: 8rem 30% 2rem;
}
.active {
    width: 100%;
    position:relative;

    >section>p{
        font-size:1.7rem;
        font-weight:400;
        color:#666;
        text-align:center
    }
}
</style>
