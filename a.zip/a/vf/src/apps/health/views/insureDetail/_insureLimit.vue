<template>
    <section  v-bind:class="{info_box_hidden: !arrow}" class="info_box">
        <div class="info_box_head"  @click="spread" :style="{color:fontColor}">保障期限</div>
        <p class="arrow" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div class="info_box_text">
            <div class="left">自</div>
            <div class="right">{{limitDate}} 零时起</div>
        </div>
        <div class="info_box_text">
            <div class="left">至</div>
            <div class="right">{{deadline}} 二十四时止</div>
        </div>
        <!--
        <div class="info_box_text">
            <div class="left">共</div>
            <div class="right">{{}}天</div>
        </div>
        -->
    </section>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import {changeColor} from "../../../../utils/skin"

export default{
    data(){
        return{
            arrow:true,
            limitDate:"",
            deadline:"",
            fontColor:"#32BCFD"
        }
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        },
        dataHandle: function (date) {
            var s = date.split('-');
            var yy = parseInt(s[0]),
                mm = parseInt(s[1]),
                dd = parseInt(s[2]);
            if (mm < 10) {
                mm = '0' + mm;
            };
            if (dd < 10) {
                dd = '0' + dd;
            };
            return s = yy + '-' + mm + '-' + dd;
        },
    },
    computed: {
        ...mapState({
            startDate:state=>state.health.effDate,
            insurePeriod:state=>state.health.insurePeriod,
//            limitDate:state=>state.health.detail_2
            //this.$store.dispatch('Search', event.target.innerText);
            //this.$store.commit('setinsureBirthday',this.time)
        })
    },
    mounted(){
        this.fontColor = changeColor()
        var date = this.$store.state.health.effDate,timeline = this.$store.state.health.insurePeriod,yy,mm,dd,
            timetype = this.$store.state.health.insurePeriodType,
//            timetype = "D",
            y = parseInt(date.substr(0,4)),
            m = parseInt(date.substr(4,2)),
            d = parseInt(date.substr(6,2));
        var limitDate = date?y+"-"+m+"-"+d:""
        this.limitDate = this.dataHandle(limitDate);
            if(timetype == "D"){
                //日期为“日”
                var str = y+"/"+m+'/'+ d,
                    date = new Date(str),
                    time = date.getTime(),
                    newTime = 24*60*60*1000*(timeline-1) + time,
                    newDate = new Date(newTime);
                yy = newDate.getFullYear();
                mm = newDate.getMonth()+1;
                dd = newDate.getDate();
                var deadline = date?yy+"-"+mm+"-"+dd:"";
                this.deadline = this.dataHandle(deadline);

            }else{
                //日期为“年月”
                if(timetype == "Y"){
                    timeline = 12*timeline
                }
                yy = Math.floor(timeline/12)+y;
                mm = timeline%12+m;
                dd = d-1;
                if(dd == 0){
                    mm -= 1;
                    if(mm==0){
                        mm = 12;
                        yy-= 1;
                        dd == 31;
                    }else if(mm == 2){
                        if((yy%4)==0){
                            dd = 29
                        }else{
                            dd = 28
                        }
                    }else if(mm==1||mm==3||mm==5||mm==7||mm==8||mm==10||mm==12){
                        dd = 31
                    }else{
                        dd= 30
                    }
                }
                var deadline = date?yy+"-"+mm+"-"+dd:"";
                this.deadline = this.dataHandle(deadline);
                //this.deadline = "-"
            }

    }
}
</script>
<style  scoped lang="less">
    @import "../../../../styles/insureDetail.less";
</style>
