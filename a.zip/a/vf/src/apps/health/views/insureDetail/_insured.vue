<template>
    <section v-bind:class="{info_box_hidden: !arrow}" class="info_box">
        <div class="info_box_head"  @click="spread" :style="{color:fontColor}">被保人信息</div>
        <p class="arrow" v-bind:class="{arrow_up: !arrow}" :style="{color:fontColor}"></p>
        <div class="info_box_text">
            <div class="left">姓名</div>
            <div id="name_2" class="right unactive">{{detail_2.insurClientName}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">与投保人关系</div>
                <div  id="relation" class="right">{{relationShip}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件类型</div>
                <div  id="type_2" class="right">{{insurIdType}}</div>
            </div>
            <div class="info_box_text">
                <div class="left">证件号码</div>
                <div class="right unactive">{{detail_2.insurIdNo}}</div>
            </div>
            <div v-if="insurGender" class="info_box_text">
                <div class="left">性别</div>
                <div class="right unactive">{{insurGender}}</div>
            </div>
            <div v-if="detail_2.insurBirthday" class="info_box_text">
                <div class="left">出生日期</div>
                <div id="num_2" class="right unactive">{{detail_2.insurBirthday}}</div>
            </div>
            <!--<div class="info_box_text">
                <div class="left">手机号</div>
                <div id="ph_2" class="right unactive">{{detail_2.insurMobile}}</div>
            </div>
            <div v-if="detail_2.insurMail" class="info_box_text">
                <div class="left">邮箱</div>
                <div class="right unactive">{{detail_2.insurMail}}</div>
            </div>-->
            <div class="info_box_text" v-if="place">
                <div class="left">常住地址</div>
                <div class="right">{{detail_2.InsurProvince}}</div>
            </div>
        </section>
</template>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
import {changeColor} from "../../../../utils/skin"
import filter from "../../../../utils/filter"

export default{
    data(){
        return{
            arrow:true,
            fontColor:"#2688c4",
            place:true
        }
    },
    mounted(){
        this.fontColor = changeColor();
        //设置常驻地址(运动卫士没有)
        if(this.$store.state.health.productDetail.icpProductCode == "ICPH000004"||
                this.$store.state.health.productDetail.icpProductCode == "ICPH000001"
        ){
            this.place = false
        }
    },
    methods: {
        spread(){
            if(!!this.arrow){
                this.arrow = false;
            }else{
                this.arrow = true
            }
        }
    },
    computed: {
        ...mapState({
            detail_2:state=>state.health.detail_2,
            relationShip(state){
                return filter.hel_relationShip(state.health.relationShipCode)
            },
            insurIdType(state){
                return filter.hel_insurId(state.health.detail_2.insurIdType)
            },
            insurGender(state){
                return filter.hel_sex(state.health.detail_2.insurGender[0])
            }
            //this.$store.dispatch('Search', event.target.innerText);
            //this.$store.commit('setinsureBirthday',this.time)
        })
    }
}
</script>
<style scoped lang="less">
    @import "../../../../styles/insureDetail.less";
</style>
