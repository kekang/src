<template>
    <!-- 隐藏页 投保须知 -->

    <div class="insurance_noticeE">
<p style="text-align:center"><strong><span style="font-size: 21px;
    line-height: 150%;
    font-family: 微软雅黑;">理赔须知</span></strong></p>
<p style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">理赔指引</span></strong></p>
<p style="width:90%;margin:auto"><img style="width:100%;" src="../../../../assets/images/healthCode/H707_3_2.png"/></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size:1.5rem;">该产品的理赔方式可以分为事后理赔和直接结算两种。其中，直接结算仅限在优选直接结算医院中使用。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size:1.5rem;"></span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">1、<span style="font-weight:normal;font-stretch:normal;font-size:9px;"></span></span></strong><strong><span style="font-size:1.5rem;">事后理赔</span></strong></p>
<p style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">1.1 </span></strong><strong><span style="font-size:1.5rem;">线上快速理赔（微信端“平安健康生活”或“平安健康APP”）：</span></strong></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><strong><span style="font-size:1.5rem;">&nbsp;适用对象：“</span></strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">医保+”门诊版。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><strong><span style="font-size:1.5rem;">&nbsp;适用医院：</span></strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">中国大陆二级及以上公立医院。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size:1.5rem;"><span style="display:inline-block;width:8px;height:border-radius:50%;background:rgb(0,0,0);"></span><strong><span style="font-size:1.5rem;">&nbsp;适用责任：</span></strong><span style="font-size:1.5rem;">普通门急诊事后理赔适用该服务。住院责任、特殊门诊责任、住院前后门急诊责任等不适用该服务</span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">。</span></span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">&nbsp;使用规则：</span><span style="font-size: 1.5rem;"><span style="font-stretch: normal;font-size:9px;">&nbsp;</span></span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">单次理赔申请账单金额不超过2000元，保单年度内累计赔付不超过8000元。超过该限额可转线下常规理赔申请。年度赔付限额以门诊责任为限，请参考您选择的保障方案。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">&nbsp;使用流程：</span><span style="font-size:1.5rem;">微信端“平安健康生活”线上理赔流程指引：</span></p>
<p style="width:90%;margin:auto"><img style="width: 100%" src="../../../../assets/images/healthCode/H707_3_4.png"/></p>
<p style="width:90%;margin:auto"><span style="font-size:1.5rem;">注：1、若您之前没有平安一账通账户，使用微信理赔前需通过PC端注册平安一账通。详情可咨询95511-7或平安销售人员。2、同一个分单下被保险人之间可以代为申请。</span></p>
<p style="width:90%;margin:auto"><span style=""></span></p>
<p style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">快速理赔所需资料（拍照上传）：</span></strong></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size:1.5rem;">点击上传理赔所需材料：</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size:1.5rem;">&nbsp;身份证原件；</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size:1.5rem;">&nbsp;费用发票原件及费用明细；</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size:1.5rem;">&nbsp;病历/处方/住院小结；</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size:1.5rem;">&nbsp;银行卡照片（子女可提供监护人银行账户）；</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size:1.5rem;">&nbsp;关系证明（子女理赔时需出具）</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size:1.5rem;">&nbsp;其他因案件特殊而需要额外提供的资料。</span></p>
<p style="width:90%;margin:auto"><span style=""></span></p>
<p style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">1.2 </span></strong><strong><span style="font-size:1.5rem;">线下常规理赔</span></strong></p>
<p style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">理赔流程：</span></strong></p>
<p style="width:90%;margin:auto"><strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">第一步：</span></strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">登陆平安健康险官网（</span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">http://www.pingan.com</span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">），下载打印理赔申</span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';">请书并填写。</span></p>
<p style="width:90%;margin:auto"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">申请书上须有被保险人签名。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size: 1.5rem;"><span><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">&nbsp;若多个被保险人一起申请，需每人分别填写理赔申请书。</span></span></span></p>
<p style="width:90%;margin:auto"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">&nbsp; &nbsp; 下载路径：平安官网→平安保险→健康保险→理赔专区→常用表格及文件→事后理赔医疗理赔申请书（双语）2014版</span></p>
<p style="width:90%;margin:auto"><strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">第二步：</span></strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">准备材料：</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">1.<span style="font-stretch: normal;font-size:9px;"></span></span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">被保险人、申请人有效身份证件（复印件）</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">2.</span><span style="text-indent:19px;font-size:1.5rem;font-family:'微软雅黑','sans-serif';"><span style="font-stretch: normal;font-size:9px;">&nbsp;</span></span><span style="text-indent:19px;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">新生儿或未成年人出险，需提供与申请人的关系证明（复印件）</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">3.</span><span style="font-family: '微软雅黑','sans-serif';font-size:1.5rem;text-indent:19px;">病历资料，包括诊断证明、病理及其他各项检查检验报告（复印件）</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">4.<span style="font-stretch: normal;font-size:9px;"></span></span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">银行账户信息：包括开户行、户名、账号（复印件）</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size:1.5rem;">5.<span style="font-stretch: normal;font-size:9px;"></span></span><span style="font-size:1.5rem;">医疗费用发票（原件）及费用明细清单</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">6.<span style="font-stretch: normal;font-size:9px;"></span></span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">当保险金作为被保险人遗产时，必须提供可证明合法继承权的相关权利文件（原件）</span></p>
<p class="MsoListParagraph" style="margin-left:0;text-indent:24px"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">&nbsp; &nbsp; &nbsp; 7.<span style="font-stretch: normal;font-size:9px;"></span></span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">其他因案件特殊而需要额外提供的资料</span></p>
<p style="width:90%;margin:auto"><strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">第三步：</span></strong><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif'">将理赔申请书及理赔材料邮寄到各机构处（邮费由您负担）。</span></p>
<p style="width:90%;margin:auto"><br /></p>
<table cellspacing="0" cellpadding="0" width="577" style="width:90%;margin:auto;">
<tbody>
<tr style="height:16px" class="firstRow">
<td width="78" valign="top" style="border:1px solid;padding:0px 7px"><p style="text-align:center;line-height:27px"><strong><span style="font-size:1.6rem;">机构</span></strong></p></td>
<td width="312" valign="top" style="border-top-color: windowtext;border-right-color:border-bottom-color:border-width:1px;border-style:solid;padding:0px 7px;\"height="16"><p style="text-align:center;line-height:27px"><strong><span style="font-size:1.6rem;">地址</span></strong></p></td>
<td width="76" valign="top" style="border-top-color: windowtext;border-right-color:border-bottom-color:border-width:1px;border-style:solid;padding:0px 7px;\"height="16"><p style="text-align:center;line-height:27px"><strong><span style="font-size:1.6rem;">联系人</span></strong></p></td>
<td width="111" valign="top" style="border-top-color: windowtext;border-right-color:border-bottom-color:border-width:1px;border-style:solid;padding:0px 7px;\"height="16"><p style="text-align:center;line-height:27px"><strong><span style="font-size:1.6rem;">电话</span></strong></p></td>
</tr>
<tr style="height:30px">
<td width="78" style="border-right-color:windowtext;border-bottom-color:border-left-color:border-width:1px;border-style:solid;padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">北京分公司</span></p></td>
<td width="312" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">北京市西城区金融街23号平安大厦610</span></p></td>
<td width="76" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">保单服务岗</span></p></td>
<td width="111" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">010-59733218</span></p></td>
</tr>
<tr style=";height:30px">
<td width="78" style="border-right-color:windowtext;border-bottom-color:border-left-color:border-width:1px;border-style:solid;padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">上海分公司</span></p></td>
<td width="312" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">上海市静安区常熟路8号8-1门9楼健康险理赔受理中心</span></p></td>
<td width="76" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p><span style="font-size:1.5rem;">保单服务岗</span></p></td>
<td width="111" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">021-20662854</span></p></td>
</tr>
<tr style=";height:30px">
<td width="78" style="border-right-color:windowtext;border-bottom-color:border-left-color:border-width:1px;border-style:solid;padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">广东分公司</span></p></td>
<td width="312" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">广州市天河区体育东路160号平安大厦18楼</span></p></td>
<td width="76" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p><span style="font-size:1.5rem;">保单服务岗</span></p></td>
<td width="111" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:150%"><span style="font-size:1.5rem;line-height:150%;">020-38262753</span></p></td>
</tr>
<tr style=";height:30px">
<td width="78" valign="top" style="border-right-color:windowtext;border-bottom-color:border-left-color:border-width:1px;border-style:solid;padding:0px 7px;"><p style="line-height:27px"><span style="font-size:1.5rem;">深圳分公司</span></p></td>
<td width="312" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:27px"><span style="font-size:1.5rem;">深圳市福田区八卦三路301号平安大厦健康险深分</span></p></td>
<td width="76" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:27px"><span style="font-size:1.5rem;">保单服务岗</span></p></td>
<td width="111" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;"><p style="line-height:27px"><span style="font-size:1.5rem;">0755-82057332</span></p></td>
</tr>
<tr style=";height:27px">
<td width="78" valign="top" style="border-right-color:windowtext;border-bottom-color:border-left-color:border-width:1px;border-style:solid;padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">江苏分公司</span></p></td>
<td width="312" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">江苏省南京市玄武区长江路188号德基大厦12楼D座</span></p></td>
<td width="76" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">保单服务岗</span></p></td>
<td width="111" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">025-85496000</span></p></td>
</tr>
<tr style=";height:27px">
<td width="78" valign="top" style="border-right-color:windowtext;border-bottom-color:border-left-color:border-width:1px;border-style:solid;padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">浙江分公司</span></p></td>
<td width="312" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">浙江杭州密渡桥路1号浙商时代大厦B座706室</span></p></td>
<td width="76" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">保单服务岗</span></p></td>
<td width="111" valign="top" style="border-style:solid;border-bottom-color:windowtext;border-width:1px;border-right-color:padding:0px 7px;\"height="27"><p style="line-height:27px"><span style="font-size:1.5rem;">0571-87228141</span></p></td>
</tr>
</tbody>
</table>
<p style="width:90%;margin:auto"><span style="font-size:1.5rem;">温馨提示：为避免邮件丢失，建议您复印留存一份理赔资料，并保留快递单。</span><br /></p>
<p style="width:90%;margin:auto"><span style=""></span></p>
<p style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">注意事项</span></strong></p>
<p style="vertical-align:baseline;width:90%;margin:auto"><span style="font-size:1.5rem;">1.</span><span style="font-size:1.5rem;">我们在接收到您的材料后将尽快处理，预计15个工作日内审核完毕。</span></p>
<p style="width:90%;margin:auto;vertical-align:baseline;"><span style="font-size:1.5rem;">2.</span><span style="font-size:1.5rem;">首次投保或非连续投保本保险时，被保险人因疾病需要住院治疗或指定门诊治疗的，自本合同生效之日起30日为等待期。被保险人在等待期内发生的保险事故，我们不承担给付保险金的责任。续保或者因意外伤害进行治疗的无等待期。</span></p>
<p style="width:90%;margin:auto;vertical-align:baseline;"><span style="font-size:1.5rem;">3.</span><span style="font-size:1.5rem;">我们会对您投保时的健康告知进行核实，若不符合实际情况，可能影响您的赔付结论。</span></p>
<p style="width:90%;margin:auto;vertical-align:baseline;"><span style="font-size:1.5rem;">4.</span><span style="font-size:1.5rem;">申请理赔过程中，若需要您补充其他材料等情况，烦请您予以配合，以便我们尽快完成理赔。</span></p>
<p style="width:90%;margin:auto;vertical-align:baseline;"><span style="font-size:1.5rem;">5.</span><span style="font-size:1.5rem;">若您对理赔结果有异议，可拨打95511-7进行咨询。</span></p>
<p style="width:90%;margin:auto;vertical-align:baseline;"><span style="font-size:1.5rem;"><br /></span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;">2、<span style="font-weight:normal;font-stretch:normal;font-size:9px;"></span></span></strong><strong><span style="font-size:1.5rem;">直接结算</span></strong></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><strong><span style="font-size:1.5rem;"><span style="display:inline-block;width:8px;height:border-radius:50%;background:rgb(0,0,0);"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">&nbsp;适用对象：</span><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';"><span style="font-size:1.5rem;">“</span><span style="font-size:1.5rem;"></span></span></span></strong><span style="font-size:1.5rem;"><span style="font-size: 1.5rem;font-family:'微软雅黑','sans-serif';"><span style="font-size:1.5rem;">医保+”住院版和“医保+”门诊版。</span></span></span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">&nbsp;适用医院：</span><span style="font-size:1.5rem;"><span style="font-size:1.5rem;">优选直接结算医院普通住院部（医院清单见单独附件“优选直接结算医院”）。</span></span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">&nbsp;适用责任：</span><span style=";font-size:1.5rem;">住院责任。不包含住院前后门急诊责任、特殊门诊责任和普通门诊责任。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">&nbsp;直接结算服务凭证：</span><span style="font-size:1.5rem;">直接结算担保函（平安发出）</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">&nbsp;使用规则：</span></p>
<p style="width:90%;margin:auto">&nbsp;<strong><span style="font-size:1.5rem;">A&nbsp;</span></strong><strong><span style="font-size:1.5rem;">若投保时选择“无常住地医保”方案：</span></strong></p>
<p style="width:90%;margin:auto"><span style="font-size:1.5rem;">客户进行预授权申请，<strong><span style="color:#C00000">无需先行进行医保卡结算，</span></strong>平安审核通过后给医院发送担保函；</span></p>
<p style="width:90%;margin:auto">&nbsp;<strong><span style="font-size:1.5rem;">B&nbsp;</span></strong><strong><span style="font-size:1.5rem;">若投保时选择“有常住地医保”方案：</span></strong></p>
<p style="width:90%;margin:auto"><span style="font-size:1.5rem;">客户进行预授权申请，<strong><span style="color:#C00000">需先行进行医保卡结算，</span></strong>平安审核通过后给医院发送担保函。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight:bold;font-size:1.5rem;font-family:'微软雅黑','sans-serif';">关于保障范围外费用的还款</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto">&nbsp;<strong><span style="font-size:1.5rem;">A&nbsp;</span></strong><span style="font-size:1.5rem;">直接结算的服务可在优选直接结算网络中使用，是指患者在住院前免交押金、住院之后免交医疗费用，院后免理赔申请的流程统称。直接结算的使用规则和流程详见“理赔须知“。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto">&nbsp;<strong><span style="font-size:1.5rem;">B&nbsp;</span></strong><span style="font-size:1.5rem;">平安承担的直结结算金额不代表最终保险公司应承担的赔付责任金额。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto">&nbsp;<strong><span style="font-size:1.5rem;">C&nbsp;</span></strong><strong><span style="font-size:1.5rem;">直接结算的金额与保险公司应承担的金额的差额属于您应承担的金额，</span></strong><span style="font-size:1.5rem;">对于您承担的金额，您可致电95511-7联系平安客服人员进行确认，通过手机银行、网银、银行转账或进入微信公众号“平安健康生活”进行还款。</span></p>
<p class="MsoListParagraph" style="width:90%;margin:auto"><span style="font-size:1.5rem;font-family:Wingdings">l&nbsp;<span style=""font-stretch: normal;font-size:9px;line-height:normal;"></span></span><strong><span style="font-size:1.5rem;">使用流程</span></strong></p>
<p style="width:90%;margin:auto"><img style="width:100%" src="../../../../assets/images/healthCode/H707_3_3.png"/></p>
<p style="width:50%;border:1pxdashed#000;margin-left:10%;border-radius:8px">预授权<span style="color:red">申请材料</span>：<br />1门诊病历复印件/照片<br />2若选择“有常住地医保”方案，提供医保卡扫描件</p>
    </div>
</template>
<style lang="less" scoped>
    .insurance_noticeE{
    h2{font-size:1.8rem;line-height:2.5rem;}
    p,li{font-size:1.6rem;line-height:2rem;margin-top:1.5rem;}
    .indetails{
        text-align:center;
    }
    table {
        border-collapse: collapse;
        //font-size: 1.4rem;
        text-align: center;
    }
    td,th{
        border:1px solid #000;
    }
    }
</style>
