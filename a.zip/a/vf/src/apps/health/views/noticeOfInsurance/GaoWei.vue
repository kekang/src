<template>
    <!-- 隐藏页 高危职业 -->
    <div class="insurance_noticeGW">
        <div class="contanier">
            <div class="p-types">
                <table style="border-collapse:collapse;">
                    <caption class="title">高危职业种类表</caption>
                    <tbody>
                    <tr class="top firstRow">
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">分类</span></td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;" width="0"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">职业</span></td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">农牧渔业</span></td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">猛兽饲养工(动物园)、有毒动物饲养工（蛇、蝎子、蜈蚣等）、捕鱼人(内陆)、捕鱼人(沿海)养殖工人(沿海)、远洋渔船船员、近海渔船船员</span>
                        </td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">木材森林业</span></td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">伐木工人、锯木工人、运材车辆之司机及押运人员、起重机之操作人员、装运工人、挂钩工人、锯木工人、木材搬运工人、森林防火人员、拖拉机驾驶员、联合收割机驾驶员、农用运输车驾驶员、农用机械操作及修理人员、沼气工程施工人员</span>
                        </td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">矿业采掘业</span></td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">矿工、采掘工、爆破工、工人、海上所有作业人员、潜水人员、采石业工人、采砂业工人、陆上油矿开采技术员、油气井清洁保养修护工、钻勘设备安装换修保养工、钻油井工人</span>
                        </td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"> 交通运输业</span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><p><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">陆运</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：铁牛车驾驶、混凝土预拌车驾驶员、机动三轮车夫、货车司机、随车工人、搬运工人、装卸工人、矿石车司机、随车工人、工程卡车司机、随车人</span><span
                                style="font-family: 微软雅黑, sans-serif; font-size: 1.3rem;">员</span></p>
                            <p><span style="font-family: 微软雅黑, sans-serif; font-size: 1.3rem;">液化、氧化油罐车司机、随车工人、铁路货运、铁路搬运工人</span>
                            </p>
                            <p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></p>
                            <p><strong><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">客货轮（沿海）：</span></strong><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">船长、水手长、水手、铜匠、木匠、泵匠、电机师、厨师、服务生、实习生、游览船/小气艇之驾驶及工作人员、救难船员</span>
                            </p>
                            <p><strong><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">客货轮（内河）：</span></strong><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">船长、水手长、水手、铜匠、木匠、泵匠、电机师、厨师、服务生、实习生</span>
                            </p>
                            <p><strong><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">客货轮（远洋）所有随船人员</span></strong>
                            </p>
                            <p><strong><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">空运：</span></strong><span
                                    style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">民航机飞行人员、机上服务员、直升机飞行人员</span>
                            </p></td>
                    </tr>
                    <tr>
                        <td width="115" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;" rowspan="7"
                            colspan="1"><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">建筑工程</span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">建筑公司</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：钢骨结构工人、鹰架架设工人、铁工、焊工、建筑工程机械操作员、金属门窗装修工人、拆屋、迁屋工人、凿岩工、装饰装修工（室外）（基础装修至毛坯）</span>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><p><strong><span
                                style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">铁路公路铺设</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：现场勘测人员（山区）、工程机械操作员、工程车辆驾驶员、铺设工人(山地)、维护工人、电线架设及维护工人、高速公路工程人员(含美化人员)</span>
                        </p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">筑路、养护工、铁路舟桥工、道岔制修工</span>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">造修船业</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：工人、拆船工人</span>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">电梯、升降机</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：安装工人、电梯、升降机修理及维护工人</span>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" colspan="4" rowspan="1"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">装璜</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：室内装璜人员(不含木工、油漆工)、室外装璜人员、金属门窗制造、装修工人</span>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" colspan="4" rowspan="1"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><p><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">安装玻璃幕墙工人、钢结构安装工、中央空调系统安装及维护人员</span>
                        </p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">地质探测员（山区）、地质探测员（海上）、海湾港口工程人员、水坝工程人员、挖井工程人员、桥梁工程人员、隧道工程人员、潜水工作人员、爆破工作人员、挖泥船工人</span>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">测绘工程</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：海洋测绘工程技术人员（海上作业）</span>
                        </td>
                    </tr>
                    <tr class="firstRow">
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">制造加工维修业</span></span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;" width="0"><p><strong><span
                                style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">冶金业</span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：高炉原料工、高炉炉前工、高炉运转工、炼钢原料工、炼钢工、炼钢浇铸工</span>
                        </p>
                            <p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">练钢准备工、铁合金电炉冶炼工、火法冶炼工、烟气制酸工、酸洗工、金属材热处理工、焊管工、金属挤压工、铸轧工、铸管工、硬质合金成型工</span>
                            </p>
                            <p><strong><span style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">机械制造维修业</span></strong><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：车床工、车床工(全自动)、车工、铣工、磨工、镗工、钻床工、组合机床工、加工中心操作工、拉床、锯床工、弹性元件制造工、铸造、锻造工、冲压工</span>
                            </p>
                            <p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">剪切工、焊工、金属热处理工、粉末冶金处理工、涂装工、电切削工、锅炉设备装配工、有关高压电之工作人员、铁心叠装工</span>
                            </p>
                            <p><strong><span
                                    style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">电机业</span></strong><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：有关高压电之工作人员</span>
                            </p>
                            <p><strong><span style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">水泥业(包括水泥、石膏、石灰、陶器)</span></strong><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：水泥生产制造工、采掘工、爆破工、石灰焙烧工、加气混凝土制品工、装饰石材生产工、石棉制品工、金刚石制品工</span>
                            </p>
                            <p><strong><span
                                    style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">化工业</span></strong><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：液化气体制造工、防腐蚀工、油制气工、炼焦工,焦炉机车司机、煤制气工</span>
                            </p>
                            <p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">煤气储运工、硫酸铵生产工、过磷酸铵生产工、硫酸生产工、硝酸生产工、盐酸生产工、磷酸生产工、纯碱生产工、烧碱生产工、氟化盐生产工、缩聚磷酸盐生产工、高频等离子工、气体深冷分离工,制氧工、工业气体液化工、二氧化硫制造工、脂肪烃生产工、橡胶生产工、化纤聚合工、其他有毒物品生产工、火药炸药业人员、烟花爆竹业人员</span>
                            </p>
                            <p><span
                                    style="font-size: 1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">铁路车辆制造装修工</span>
                            </p>
                            <p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">制浆备料工、制浆设备操作工、制浆废液回收利用工、木制家具制造工人、木制家具修理工人、金属家具制造工人、金属家具修理工人、家用空调、太阳能热水器安装与维修、焊接工、冲床工、剪床工、铣床工、铸造工、车床工(全自动)、车床工(其他)、玻璃加工工</span>
                            </p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span>
                        </td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">出版广告业</span></span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">战地记者、广告招牌架设人员、霓虹光管安装及维修人员</span></span>
                        </td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">娱乐业</span></span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">武打演员、特技演员、广播电视天线工、救生员、动物园驯兽师、高空杂技、飞车、飞人演员</span></span>
                        </td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">文教机构</span></span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">飞行训练教官及学员、特殊运动班学生（拳击、摔跤、跆拳道等）、武术学校学生</span></span>
                        </td>
                    </tr>
                    <tr>
                        <td width="116" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">公共事业</span></span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><p><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">通信系统供电设备、空调设备安装维护人员、电台天线维护人员、光缆铺设人员、高压线路带电检修工、变压器检修工、变电设备检修工、变电设备安装工、牵引电力线路安装维护工、维修电工、电力设施架设人员、电力高压电工程设施人员、水泵或提水站的维修人员、河道清淤的工人</span><span
                                style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></p></td>
                    </tr>
                    <tr>
                        <td width="115" valign="top"
                            style="word-break: break-all; border-width: 1px; border-style: solid;" rowspan="1"
                            colspan="1"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">服务业</span></span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">液化燃气零售店负责人及工作人员、高楼外部清洁工、烟囱清洁工</span><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></td>
                    </tr>
                    <tr>
                        <td colspan="1" valign="top" align="null"
                            style="word-break: break-all; border-width: 1px; border-style: solid;" width="115"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">公检法等执法检查机关</span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><p><strong><span
                                style="font-size:1.3rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></strong>
                        </p>
                            <p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">刑警、警务特警、防暴警察、武警、防毒防化防核抢险员、一般事故抢险员</span>
                            </p><span style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">消防队队员、火灾瞭望观察员（直升机）</span><span
                                    style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></td>
                    </tr>
                    <tr>
                        <td colspan="1" valign="top" align="null"
                            style="word-break: break-all; border-width: 1px; border-style: solid;" width="115"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">军人</span></td>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">特种兵(海军陆战队、伞兵、水兵、爆破兵、蛙人、化学兵、负有布雷爆破任务之工兵、情报单位负有特殊任务者)、空军飞行官兵、空军海洋巡弋舰艇及潜艇官兵、前线军人、军校学生及入伍受训新兵</span><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></td>
                    </tr>
                    <tr>
                        <td colspan="1" valign="top" align="null"
                            style="word-break: break-all; border-width: 1px; border-style: solid;" width="115"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">职业运动&nbsp;</span></span>
                        </td>
                        <td valign="top" rowspan="1" colspan="4" width="0"
                            style="word-break: break-all; border-width: 1px; border-style: solid;"><strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></strong><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">滑雪人员、曲棍球球员、冰上曲棍球球员、橄榄球球员、摔跤运动员、职业拳击运动员、业余拳击运动员、马术运动员</span><span
                                style="font-size:1.3rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;"></span></td>
                    </tr>
                    </tbody>
                </table>
                <p><br></p></div>
        </div>

    </div>
</template>
<style lang="less" scoped>
    .insurance_noticeGW {
        padding: 0.5rem;

    h2 {
        font-size: 1.6rem;
        line-height: 2rem;
    }

    p {
        font-size: 1.6rem;
        line-height: 2rem;
        margin-top: 0.5rem;
    }

    .title {
        text-align: center;
        font-size: 1.8rem;
        line-height: 2rem;
        font-weight: 600;
    }

    .bold {
        font-weight: bold;
    }

    ol li {
        margin-bottom: 0.3rem
    }

    ol {
        padding-left: 0.8rem
    }

    table {
        margin: 0 auto;
        text-algin: center;
        font-size: 1.6rem;
    }
    }
</style>
<script>
    import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
    export default{
         beforeMount(){
            if(this.$store.state.health.productDetail){
                sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
            }else{
                this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
            }
        },
        mounted(){
            document.body.scrollTop = 0;
        }
    }
</script>
