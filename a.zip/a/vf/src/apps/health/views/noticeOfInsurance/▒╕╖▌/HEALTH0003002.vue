<template>
<!--  第三页 投保告知  -->
    <div class="health_notice">
        <h2>本人自愿投保，特告知以下事项：</h2>
        <div class="wrap">
            <div class="question">被保人是否仍在从事以下职业：<br>
                1、农牧业(糖厂技工，联合收割机驾驶员，农用机械操作及修理人员，农用运输车驾驶员，驯养人员，沼气工程施工人员) <br> 
                2、木材加工业(防腐剂工人，木材储藏槽工人，合板制造工人，山林管理人员，山地造林人员（不涉及砍伐作业），设备安装、调试、检修人员，锯木工人，木材搬运工) <br> 
                3、道路运输业(出租车，救护车司机，客运车司机及服务员) <br> 
                4、铁路运输业(电机检修工，铁路维护及修路工，通信工，修护厂技工，搬运工人，货运工人) <br> 
                5、航空运输业(行李货运搬运工人，清仓工，理货员，清洁工（站外、航空大厦外），飞机修护人员，跑道维护工，飞机洗刷人员，机械员，加添燃料人员) <br> 
                6、制造(制造工，包装工人，修理工，装配工，塑料制品制造工人，陶瓷、木炭制造工，砖、瓦生产工，保温吸音材料制造工，装饰石材生产工，人工合成制品工，耐火制品制造工，古建琉璃工，搪瓷胚体制做工，备煤筛焦工，焦炉调温工，化肥生产工，橡胶制品生产工，湿纺远液制造工，化纤制品制造工，有机合成工，农药生物测试试验工，燃料制造工，研磨分散工，试剂制造工，涂料合成树脂工，制漆配色调制工，感光及磁性材料制造工，暗盒制造工，废片、白银回收工，压缩机工，电池制造（技师），化学化工流程工艺操作工人，冷作钣金工，电镀工，磨具制造工，仪器仪表原件制造工，装配工，钳工，汽轮机，内燃机装配工，电机装配工，变压器、互感器装配工，高低压电器装配工，电焊机装配工，电炉装配工，车床工，铣工，磨工，镗工，弹性元件制造工，锻造工，冲压工，剪切工，焊工，金属热处理工，粉末冶金处理工，涂装工，电切削工，锅炉设备装配工，铁心叠装工) <br>

                7、维修业(维修保养工人（汽车、摩托车），试车人员，汽车（拖拉机）装配工，电机车装配工，摩托车装配工，助力车，印染工人，造纸工，宣纸书画纸制作工，纸箱制做工，纸盒制做工，木制家具修理工人，金属家具修理工人，猪屠宰加工工，牛羊屠宰加工工，家电（空调、洗衣机等）制造装配工，玻璃溶化工，玻璃制板及玻璃成型工，玻璃加工工，玻璃纤维制品工，玻璃钢制品工，石英玻璃制品加工工，玻璃搬运工，机械产品检验工人，家用器具及家电维修工人，制浆备料工，制浆设备操作工，制浆废液回收利用工，冲床工，剪床工，铣床工，铸造工，车床工，焊接工，家具制造工人出版广告业：装订工，印刷工，广告招牌架设人员，霓虹光管安装及维修人员) <br> 
                8、出版广告业(装订工，印刷工，广告招牌架设人员，霓虹光管安装及维修人员) <br> 
                9、娱乐业(机械工，电工，救生员) <br> 
                10、文化教育(机动车驾驶学员，体校，杂技，军警校学生) <br> 
                11、电力水力燃气事业(发电厂电动机修理工，水轮机检修工，水电自动装置检修工，电气试验员，继电保护员，电力装置维护修理工，装表核算收费员，装表接电工，电能计量装置检修工，变电设备安装工，变配电室值班电工，常用电机检修工，自来水管装修人员，燃气输送站设备检修工，送货员，变电设备检修工，维修电工，电力设施架设人员，水泵或提水站的维修人员，河道清淤的工人、负责人及工作人员) <br>

                 12、零售批发业(肉贩，搬运人员，安装工人) <br>
                  13、服务业(道路清洁工，垃圾车司机及随车工人，垃圾分类工人，物业维修人员（含物业电工）) <br> 
                  14、公检法机关(交通警察，缉私人员) <br>
                   15、职业运动(职业运动员，国家注册运动员) <br> 
                   16、科学研究(野外科研人员（不含海上作业）)<br></div>
            <div class="ans" id="check1" >
                <p><i @click='change'  ref="is" class="point" eq="0" v-bind:class="{'current': check1[0]}"></i><span>是</span></p>
                <p><i @click='change'  ref="not" class="point" eq="1" v-bind:class="{'current': check1[1]}"></i><span>否</span></p>
            </div>
        </div>
        <div class="wrap ps">
            <p>本人声明上述内容均属真实，如有隐瞒或不实告知，本人愿意承担由此带来的法律后果。</p>
        </div>
        <div class="footer">
            <div class="btn" ref="Button" @click="next">下一步</div>
        </div>
    </div>
</template>
<script>
let change = "#2688c4"
import {Msg, Loading} from 'components'
import {mapState,productDetail,mapGetters,mapMutations,mapActions} from 'vuex'
import {policyHealthRecord} from '../../apis/health.api'
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
import filter from "../../../../utils/filter"
//import {PAD} from "../../../../utils/PAD"

export default{
    data () {
        return {
            check1: [false,false],
           
        }
    },
    mounted(){
        //健康告知页
        SKAPP.onEvent("健康告知页", "进入健康告知页",{
            icpProductCode:sessionStorage.icpProductCode,
            insureNotice:this.$store.state.health.insureNotice
        });

        document.body.scrollTop = 0;
        switch (sessionStorage.col){
            case "B2":
                change = "#4285F6"
                break
            case "Y1":
                change = "#D8A161"
                break
            case "O1":
                change = "#FF6000"
                break
            case "R1":
                change = "#F76B6C"
                break
            case "R2":
                change = "#F11B33"
                break
            default:
                change = "#2688c4"
                break;
        }
        this.$refs.Button.style.backgroundColor = change;
        if (this.$store.state.health.select[0]) {
            this.$refs.is.style.backgroundColor = ""
            this.$refs.not.style.backgroundColor = ""
            this.check1[1] = true
            this.$refs.not.style.backgroundColor=change
        }
    },
    methods: {
    
        next: function () {

            //提交健康告知页
            SKAPP.onEvent("健康告知页", "提交健康告知",{
                icpProductCode:sessionStorage.icpProductCode,
                healthResult:"N"
            });

            if (this.$store.state.health.select[0]) {

                //提交健康告知页
                SKAPP.onEvent("健康告知页", "提交健康告知",{
                    icpProductCode:sessionStorage.icpProductCode,
                    healthResult:"Y"
                });

                var saleRecordId = this.$store.state.health.saleRecordId;
                var submitData = {
                    saleRecordId: saleRecordId,
                    healthRecord: '{"H80400001":"N"}',
                    healthResult: 'Y'
                };
                policyHealthRecord(submitData).then((data) => {
                    if (data.data.resultCode === '00000') {
                        //成功跳转
                        this.$router.push({
                            name: 'customerInfo'
                        });
                    }else{
                        Msg.alert(filter.resultCode(data.body))
                    };
                });
            }else{
            Msg.toast('您的健康告知未通过')
            };
        },
        change: function (e) {
            this.check = [false,false];
            this.check[event.target.getAttribute('eq')] = true;
            this.$refs.is.style.backgroundColor = ""
            this.$refs.not.style.backgroundColor = ""
            e.target.style.backgroundColor=change
            this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
        },
    }
}
</script>
<style lang="less" scoped>
@import "../../../../styles/vars.less";
.health_notice{
    padding-bottom:1.6rem;
h2{font-size:1.8rem;line-height:3rem;font-weight:bold;padding:1.2rem;border-bottom: 1px solid #ececec;}
.wrap{
    overflow: hidden;
    border-bottom: 1px solid #ececec;
    position: relative;
}
.question{
    font-size: 1.6rem;
    line-height: 2.3rem;
    padding: 1.5rem 1.2rem;
    float: left;
    color: #666;
    width: 70%;
}
.ans{
    float: left;
    position: absolute;
    top: 50%;
    right: 2rem;
    transform: translateY(-50%);
    -webkit-tap-highlight-color:rgba(0,0,0,0);
}
.ans p{
    float: left;
    font-size: 1.6rem;
    padding: 1.5rem 0;
    line-height: 2.3rem;
    margin-right: 0.15rem;
}
.ans p:first-child{
    margin-right: 1rem;
}
.ans p i{
    width: 1.8rem;
    height: 1.8rem;
    border-radius: 50%;
    display: inline-block;
    border: 1px solid #ccc;
    margin-right: 0.4rem;
    vertical-align: middle;
    position: relative;
    bottom: 1px;
    box-shadow: 0 0 0px 3px #FFF inset!important;
}


.ans p i{
    position: relative;
}
.ans p i:before {
    content: '';
    position: absolute;
    top: -10px; right: -10px;
    bottom: -10px; left: -5px;
}

.ans p i.current{
    background-color: @iconfont;
    box-shadow: 0 0 0px 3px #FFF inset!important;
}

.ps{
    font-size: 1.6rem;
    line-height: 2.3rem;
    padding: 1.5rem 1.2rem 6rem 1.2rem;
}
.first_load{
    background-color: transparent !important;
    box-shadow: none !important;
}
.weui_cell {
    padding: 5px 10px;
    color: #999;
}
.footer{
    z-index: 3;
    width: 100%;
    position: fixed;
    bottom: 0;
    left:0;
    padding-left: 1rem;
    padding-right: 1rem;
    padding-top: 1rem;
    padding-bottom: 1rem;
    background-color: rgba(0, 0, 0, 0.3);
}
.btn{
    width: 100%;
    height: 4.5rem;
    background-color: @iconfont;
    border: none;
    color: #ffffff;
    line-height: 4.5rem;
    font-size: 2rem;
    border-radius: 8px;
    text-align:center

}
.weui_cell{
    padding-left: 30px;
    font-size: 1.6rem;
}
.ps{
    font-weight:700;
    text-indent:2em;
}
.alert{

}
}
</style>