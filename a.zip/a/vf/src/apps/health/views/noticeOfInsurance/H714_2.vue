<template>
    <div class="H714 insurance_noticeE">
        <p class="indetails">重要声明</strong>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "></span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">投保须知</span>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">1.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">平安健康保险股份有限公司最近季度综合偿付能力充足率为147.83%，最近一期风险综合评级为B，满足监管对偿付能力充足率的要求。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">2.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">本保险由平安健康保险股份有限公司承保，本公司在北京、上海、天津、广东、深圳、江苏、浙江、辽宁（除大连）地区设有分支机构。被保险人的常住地需在上述地区。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">3.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">我们提供平安付等第三方支付平台，以便您完成保费支付。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">4.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">我们为您提供电子保单，根据《中华人民共和国合同法》第十一条规定，数据电文是合法的合同表现形式，电子保单和纸质保单具有同等法律效力。保单承保后，电子保单会发送到您预留的电子邮箱。请您查阅电子保单时仔细阅读关于“责任免除“的相关条款。若因邮箱录入错误导致您的个人信息泄露，我司不承担责任。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">5.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">合同生效日为我们收取保险费并签发保险合同的次日零时起，并载明于电子保单上。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">6.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">保险期间一年，在保险销售期间，续保时我们不会因为被保险人的健康状况变化或者使用保险情况而终止被保险人续保或者单独调整保费。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">7.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">如您需要发票，请通过拨打95511-7或发邮件至<span
                style="text-decoration:underline; ">pub_health_online@pingan.com.cn</span>联系我们，我们将为您安排快递货到付款，邮费由您承担。其他任何疑问，也可通过上述两种方式与我们联系。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">8.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39; ">保单承保后，您可通过平安健康险官方网站或关注公众微信号“平安健康生活“获取更多服务。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39; "><span
                style="font-size: 1.8rem; line-height: 18px; font-family: 微软雅黑, sans-serif; ">9.<span
                style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;; ">&nbsp;</span></span><span
                style="font-size: 1.8rem; line-height: 18px; font-family: 微软雅黑, sans-serif; "><span
                style="font-size:1.5rem;font-family:&#39;微软雅黑&#39;,sans-serif ">就医绿通服务价值25元。</span></span></span></p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">10.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39; ">解除合同：</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">保单承保次日起，有10日的犹豫期，在此期间，您若提出解除本主险合同，我们将无息退还您所支付的全部保险费。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">犹豫期后，若您申请解除合同会遭受一定损失，我们退还您未满期净保费。</span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">净保险费指不包含公司营业费用、佣金等其他费用的保险费，计算公式为保险费×（1-35％）。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">未满期净保险费的计算分两种情况：</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">（1）您为被保险人首次投保或非连续投保本保险的：</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">如果保险经过日数≤等待期日数，未满期净保险费=净保险费；</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">如果保险经过日数＞等待期日数，未满期净保险费=净保险费×[1－(保险经过日数-等待期日数) / （保险期间的日数-等待期日数）]，经过日数不足1日的按1日计算。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">（2）您为被保险人连续投保本保险的：</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">未满期净保险费=净保险费×（1－保险经过日数/ 保险期间的日数），经过日数不足1日的按1日计算。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">投保声明：</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">1.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">本人已完整阅读并理解投保须知、保障方案及保险条款。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">2.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">本人所提供的信息均属实，如有不实告知，贵公司有权依法解除保险合同，并对合同解除前发生的保险事故不承担保险责任。</span>
        </p>
        <p class="MsoListParagraph " style="margin: auto;padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">3.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; "><span
                style="font-size:1.5rem;font-family:&#39;微软雅黑&#39;,sans-serif ">本人授权平安集团，除法律另有规定之外，将本人提供给平安集团的信息、享受平安集团服务产生的信息（包括本单证签署之前提供和产生的信息）以及平安集团根据本条约定查询、收集的信息，用于平安集团及其因服务必要委托的合作伙伴为本人提供服务、推荐产品、开展市场调查与信息数据分析。本人授权平安集团，除法律另有规定之外，基于为本人提供更优质服务和产品的目的，向平安集团因服务必要开展合作的伙伴提供、查询、收集本人的信息。为确保本人信息的安全，平安集团及其合作伙伴对上述信息负有保密义务，并采取各种措施保证信息安全。本条款自本单证签署时生效，具有独立法律效力，不受合同成立与否及效力状态变化的影响。本条所称“平安集团”是指中国平安保险（集团）股份有限公司及其直接或间接控股的公司，以及中国平安保险（集团）股份有限公司直接或间接作为其单一最大股东的公司。如您不同意上述授权条款的部分或全部，可致电客服热线95511取消或变更授权。</span></span>
        </p>
        <p class="MsoListParagraph " style="margin: auto; padding-left:1.5rem;padding-right:1.5rem;; "><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">4.<span
                style="font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39; "> </span></span><span
                style="font-size:1.5rem;line-height:2rem;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39; ">本人同意贵公司通过手机（包括手机短信）、E-mail适时提供保险信息服务。</span>
        </p>
    </div>
</template>

<style lang="less">
    @charset "utf-8";
    @import "../../../../styles/notice.less";

    .H714 {
        padding:0.3rem;
        h2{font-size:1.5rem;line-height:3rem;font-weight:600}
        p>strong>span{font-size:2rem;line-height:3rem;font-weight:600}
        p{font-size:1.6rem;line-height:2.5rem;margin-top:0.5rem;}
        th,.tips{
            font-size: 1.6rem;
            line-height:5rem;
            font-weight: bold;
        }
         .p-details ul li{
            font-size:1.5rem
        }
    }
</style>
