<template>
    <!-- 理赔流程 -->
<div class="H754_3 insurance_noticeE">
<h2 class="indetails">理赔须知</h2>
<h2 class="tips" style="line-height: 4rem">口腔保健服务流程：</h2>
<p><span >第一步：</span><span >致电平安健康险95511-7，提前2-3天进行口腔保健服务预约。</span><span ></span></p>
<p><span >第二步：</span><span >健康险坐席48小时内向客户确认预约时间，如预约时间有问题，诊所将联系客户修改预约时间。预约成功后，客户将收到确认短信。</span><span ></span></p>
<p><span >第三步：</span><span >客户就诊时需出示健康险电子保单、身份证和短信验证码，诊所验证客户身份（身份证号码和预约信息一致）后，客户可使用服务。</span></p>
<p>&nbsp;</p>
<p><span >口腔保健服务：</span><span >必需在平安健康险齿科网络服务供应商平安万家诊所提供诊所内使用。此项服务在有效期内使用次数为1次，同时口腔保健服务内所有项目需1次内使用完毕。</span><span ></span></p>
<p><span >齿科诊所列表可在平安万家诊所网页内查询。网址为：</span></p>
<p><a href="https://m.pinganwj.com/product/booking/findClinic.do?prdId=3e73ca2a-2a8e-45d8-9b4f-356a54422d5a&amp;source=jkx"><span style="font-size:14px;font-family:'Calibri',sans-serif"></span></a><a href="https://m.pinganwj.com/product/booking/findClinic.do?prdId=3e73ca2a-2a8e-45d8-9b4f-356a54422d5a&amp;source=jkx">&quot;https://m.pinganwj.com/product/booking/findClinic.do?prdId=3e73ca2a-2a8e-45d8-9b4f-356a54422d5a&amp;source=jkx&quot;</a></p>
<p><span >齿科折扣项目：被保险人凭电子保单到齿科诊所可享受指定服务项目的折扣，折扣为诊所原价的</span>85<span >折。</span></p>
<h2 class="tips">意外牙科治疗保险金：</h2>
<p>1. <span >意外牙科治疗保险金自每次事故发生后48小时内在指定医疗机构就诊，无免赔额，100%给付，累计给付5000元为限。我们在接收到您的材料后将尽快处理，预计15个工作日内审核完毕。</span><span ></span></p>
<p>2. <span >索赔资料指引：</span></p>
<p><span >第一步：登陆平安健康险官网（</span>&quot;http://health.pingan.com/&quot;<span >），下载理赔申请书并填写。</span></p>
<p><span style="font-family: Wingdings;">&nbsp;<span style="font-stretch: normal;font-size: 9px;font-family: 'Times New Roman'">&nbsp;&nbsp; </span></span><span >申请书上须有被保险人签名。若被保险人为未成年人，则由监护人代签。</span></p>
<p><span style="font-family: Wingdings;">&nbsp;<span style="font-stretch: normal;font-size: 9px;font-family: 'Times New Roman'">&nbsp;&nbsp; </span></span><span >若多个被保险人一起申请，需每人分别填写理赔申请书。</span></p>
<p><span >第二步：材料准备</span></p>
<p>1.<span >被保险人、申请人有效身份证件（复印件）</span></p>
<p>2.<span ></span><span >出险人/受益人身份证或户籍证明（如出险人/受益人未满18周岁则需要提供监护人身份证明，同时需提交与其监护人间的关系证明，另身份证件需为有效证件。</span><span ></span></p>
<p>3.<span >病历资料，包括诊断证明、病理及其他各项检查检验报告（原件）</span></p>
<p>4.<span >医疗费用发票（原件）及费用明细清单</span></p>
<p>5.<span >银行账户信息：包括开户行、户名、账号（复印件）</span></p>
<p>6.<span >申请授权第三方代为领取理赔金仅限于连带被保险人之间，并需同时提供双方身份证明材料复印件。授权双方需在理赔申请书委托人、被委托人处签字。</span></p>
<p>7.<span >所能提供的与确认保险事故的性质、原因等有关的其它证明和资料（原件）</span></p>
<p>8.<span >当保险金作为被保险人遗产时，必须提供可证明合法继承权的相关权利文件（原件）</span></p>
<p><span >第三步：请将理赔申请书及理赔材料邮寄到如下地址（邮费由您负担）：</span></p>
<p><strong><span ></span></strong></p>
<table cellspacing="0" cellpadding="0">
<tbody>
<tr class="firstRow">
<td width="85" valign="top" style="border: 1px solid windowtext; padding: 0px 7px;"><p><strong><span style="font-size:12px;font-family:'微软雅黑',sans-serif">机构</span></strong></p></td>
<td width="283" valign="top" style="border-top-color: windowtext; border-right-color: windowtext; border-bottom-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><strong><span style="font-size:12px;font-family:'微软雅黑',sans-serif">地址</span></strong></p></td>
<td width="95" valign="top" style="border-top-color: windowtext; border-right-color: windowtext; border-bottom-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><strong><span style="font-size:12px;font-family:'微软雅黑',sans-serif">联系人</span></strong></p></td>
<td width="132" valign="top" style="border-top-color: windowtext; border-right-color: windowtext; border-bottom-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><strong><span style="font-size:12px;font-family:'微软雅黑',sans-serif">电话</span></strong></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">北京分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">北京市西城区金融街23号平安大厦610</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">010-59733218</span></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">上海分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">上海市静安区常熟路8号8-1门9楼健康险理赔受理中心</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">021-20662854</span></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">天津分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">天津河西区马场道59号平安大厦B座12层</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">022-58581077</span></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">广东分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">广州市天河区体育东路160号平安大厦18楼</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">020-38262753</span></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">深圳分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">深圳市福田区八卦三路301号平安大厦健康险深分</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">0755-82057332</span></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">辽宁分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">沈阳市沈河区北京街银河国际大厦A座910室</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">024-31973630</span></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">江苏分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">江苏省南京市玄武区长江路188号德基大厦12楼D座</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">025-85496000</span></p></td>
</tr>
<tr>
<td width="85" valign="top" style="border-right-color: windowtext; border-bottom-color: windowtext; border-left-color: windowtext; border-width: 1px; border-style: solid; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">浙江分公司</span></p></td>
<td width="283" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">浙江杭州密渡桥路1号浙商时代大厦B座706室</span></p></td>
<td width="95" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">保单服务岗</span></p></td>
<td width="132" valign="top" style="border-style: solid; border-bottom-color: windowtext; border-width: 1px; border-right-color: windowtext; padding: 0px 7px;"><p><span style="font-size:12px;font-family:'微软雅黑',sans-serif">0571-87228141</span></p></td>
</tr>
</tbody>
</table>
<h2 class="tips" style="line-height: 4rem">注意事项：</h2>
<p>1.口腔保健服务使用前需提交预约，服务预约成功后，口腔医疗机构才能提供服务。</p>
<p><span >2.合同生效前发生的意外伤害事故导致被保险人接受牙科治疗的，不属于合同的保障范围。</span></p>
<p>3.<span >审核中，若需要您补充其他材料等情况，烦请您予以配合，以便我们尽早完成理赔。</span></p>
<p>4.<span >若您对理赔结果有异议，可拨打</span>95511-7<span >进行咨询。</span></p>
<p class="MsoListParagraph" style="margin-left:24px;text-indent:0">&nbsp;</p>
<p class="MsoListParagraph" style="margin-left:24px;text-indent:0">&nbsp;</p>
<p><br /></p>
</div>
</template>
<style lang="less" scoped>
@import "../../../../styles/notice.less";
@charset "utf-8";
.H754_3{
    font-size: 1.7rem;
    width: 95%;
    margin: 0 auto;
    font-family: "微软雅黑";
    table {
        width: 100%;
    }
    tbody tr td:nth-child(1) {
        width: 17.6%;
        text-align: center;
        padding-left: 0.8rem;
    }
    tbody tr td:nth-child(2) {
        width: 38.7%;
        text-align: center;
    }
    tbody tr td:nth-child(3) {
        width: 18.6%;
        text-align: center;
    }
    tbody tr td:nth-child(4) {
        width: 25%;
        text-align: center;
    }
    >p {
        >a{
            word-break: break-word;
        }
        font-family: "Microsoft YaHei";
        /*text-indent: 2em;*/
    }
    .pro{
        padding:10px 15px 45px 15px;
        background:#fff;
        line-height:1.8;
    }
    .pro .p-indetails{
        margin: 10px 0;
        font-weight: 600;
        font-size: 0.45rem;
    }
    .pro table,.pro tr,.pro td,.pro th{
        border:1px solid #999;
        border-collapse:collapse;
    }
    strong{
        font-weight:700;
    }
}

</style>
