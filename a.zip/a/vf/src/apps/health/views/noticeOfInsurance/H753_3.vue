<template>
    <!-- 隐藏页 投保须知 -->
    <div class="H753_3 insurance_notice insurance_noticeE">
        <h1 class="indetails">理赔须知</h1>
        <h2 class="tips">一、理赔流程</h2>
        <p style="line-height:1.6rem;padding-left:0;"><span
                style="font-family: 微软雅黑, sans-serif; line-height: 1.6rem; text-indent: 0; font-size: 1.6rem;">第一步：致电平安健康险95511-7</span>
        </p>
        <p style="line-height:1.6rem;padding-left:0;"><span
                style="font-family: 微软雅黑, sans-serif; line-height: 1.6rem; text-indent: 0; font-size: 1.6rem;">第二步：准备材料：</span>
        </p>
        <ul style="list-style-type: disc; padding-left:0;">
            <li><p class="MsoListParagraph" style="margin-left:0;line-height:1.6rem"><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>1、被保险人、申请人有效身份证件（复印件）</span>
            </p></li>
            <li><p class="MsoListParagraph" style="margin-left:0;line-height:1.6rem"><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>2、新生儿或未成年人出险，需提供与申请人的关系证明（复印件）</span>
            </p></li>
            <li><p class="MsoListParagraph" style="margin-left:0;line-height:1.6rem"><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;">  </span>3、病历资料，包括诊断证明、病理及其他各项检查检验报告（原件）</span>
            </p></li>
            <li><p class="MsoListParagraph" style="margin-left:0;line-height:1.6rem"><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>4、医疗费用发票（原件）及费用明细清单</span>
            </p></li>
            <li><p class="MsoListParagraph" style="margin-left:0;line-height:1.6rem"><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>5、所能提供的与确认保险事故的性质、原因等有关的其它证明和资料（原件）</span>
            </p></li>
            <li><p class="MsoListParagraph" style="margin-left:0;line-height:1.6rem"><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>6、当保险金作为被保险人遗产时，必须提供可证明合法继承权的相关权利文件（原件）</span>
            </p></li>
        </ul>
        <p class="MsoListParagraph" style="padding-left:0;line-height:1.6rem"><span style="font-size: 1.6rem;"><span
                style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"></span><span
                style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif; line-height: 1.6rem; text-align: justify;">第三步：经第三方服务商审核后，符合海外就诊条件的客户，由第三方服务商与客户联系，安排海外行程。</span></span>
        </p>
        <p style="padding-left:0;line-height:1.6rem"><span style="font-family: 微软雅黑, sans-serif; font-size: 1.6rem;">海外发生的符合条款规定的各项费用，在保额内，由第三方服务商垫付。</span>
        </p>
        <h2 class="tips">二、第三方服务商Best Doctors简介</h2>
        <p style="line-height:1.6rem;padding-left:0;text-indent: 2em;"><span
                style="font-size: 1.6rem; line-height: 1.8rem; font-family: 微软雅黑, sans-serif;">Best Doctors是1989 年由两位哈佛医学教授发起，拥有超过50,000位专家的全球医疗服务提供商。专家团队每两年由同领域业内人士互相投选，具备资深的临床和学术经验。全球最顶尖的3-5％专家被收纳在数据库内，含盖40专业，450分科。</span>
        </p>
        <p style="line-height:1.6rem;padding-left:0;text-indent: 2em;"><span
                style="font-size: 1.6rem; line-height: 1.6rem; font-family: 微软雅黑, sans-serif;">Best Doctors目前在70 个国家，为3000万客户提供服务，为客户进入世界知名的医院提供便捷的渠道。</span>
        </p>
        <h2 class="tips">三、注意事项</h2>
        <ul style="list-style-type: disc;">
            <li><p class="MsoListParagraph" style=""><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>我们在接收到您的材料后将尽快处理，预计15个工作日内审核完毕。</span>
            </p></li>
            <li><p class="MsoListParagraph" style=""><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>被保险人在推荐医院名单中选定接受国外治疗的医院后，授权的第三方服务商将进行必要的部署和医疗安排以确保被保险人能够入院，并提供只对该医院有效的初步医疗诊断证明。</span>
            </p></li>
            <li><p class="MsoListParagraph" style=";text-indent:0;line-height: 1.6rem"><span
                    style="font-family: 微软雅黑, sans-serif; font-size: 1.6rem;">非初步医疗诊断证明指定的医院产生的费用不属于赔付范围；</span></p></li>
            <li><p class="MsoListParagraph" style=";text-indent:0;line-height: 1.6rem"><span
                    style="font-family: 微软雅黑, sans-serif; font-size: 1.6rem;">初步医疗诊断证明作出之前发生的费用不属于赔付范围。</span></p></li>
            <li><p class="MsoListParagraph" style=";text-indent:0;line-height: 1.8rem"><span
                    style="font-family: 微软雅黑, sans-serif; font-size: 1.6rem;">授权的第三方服务商根据被保险人当时的健康状况给出推荐医院名单和初步医疗诊断证明；由于被保险人的健康状况随时可能变化，推荐医院名单和初步医疗诊断证明的有效期为3个月。在推荐医院名单给出之后的3个月内，被保险人未选择医院，或在初步医疗诊断证明给出的3个月内，被保险人未在指定医院进行治疗的，授权的第三方服务商将根据被保险人此时的健康状况重新给出名单和证明。</span>
            </p></li>
            <li><p class="MsoListParagraph" style=""><span
                    style="font-size: 1.6rem; font-family: 微软雅黑, sans-serif;"><span
                    style="font-stretch: normal; font-size: 9px; line-height: normal; font-family: &#39;Times New Roman&#39;;"> &nbsp;</span>我们会对您投保时的健康告知进行核实，若不符合实际情况，可能影响您的赔付结论。</span>
            </p></li>
        </ul>
        <p><br></p>
    </div>
</template>
<style lang="less">
@import "../../../../styles/notice.less";
.H753_3{
    padding:1.5rem;
    h2{font-size:1.6rem;line-height:1.6rem;}
    p{font-size:1.6rem;line-height:2rem;
        /*margin-top:1.5rem;*/
    }
.indetails{
        text-align:center;
    }
    table {
        border-collapse: collapse;
        font-size: 1.4rem;
        text-align: center;
    }
    ul>li>p{
        text-indent:2em
    }
    td,th{
        border:1px solid #000;
    }
}
</style>
