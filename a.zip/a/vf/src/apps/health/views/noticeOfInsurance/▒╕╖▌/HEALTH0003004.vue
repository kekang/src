<template>
<!--  第三页 投保告知 海外 -->
    <div class="health_notice" >
        <h2>本人自愿投保，特告知以下事项：</h2>
        <div class="wrap">
        <div class="question">对于以下任何病症，被保险人目前或过去10年是否接受过治疗，随诊，监测、诊断分析、医生提示需进一步检查、体检提示异常、或有任何相关症状：<br>
                1、癌症或任何类型的恶性肿瘤，包括霍奇金病；<br>
                2、脑部、颅骨或脊髓内出现的任何类型的肿瘤或囊肿或颅内动脉瘤；<br>
                3、白血病或需要任何治疗超过一个月时间的血液疾病（如贫血、淋巴瘤、骨髓瘤、凝血障碍、血友病或血管出血性疾病）；<br>
                4、癌前肿瘤或原位癌，包括但不限于乳腺/妇科、膀胱或前列腺肿瘤；<br>
                5、任何心脏疾病（如心肌梗死、心绞痛、动脉瘤、心肌病、心脏瓣膜疾病、心脏杂音或风湿热病）；<br>
                6、中风或脑溢血；<br>
                7、任何类型的糖尿病</div>
            <div class="ans" id="check1" >
                <p><i @click='change' eq="0"  ref="is" class="point" v-bind:class="{'current': check1[0]}"></i><span>是</span></p>
                <p><i @click='change' eq="1"  ref="not" class="point" v-bind:class="{'current': check1[1]}"></i><span>否</span></p>
            </div>
        </div>
        
        <div class="wrap ps">
        <p style="font-weight:700">投保人应在对所有被保险人健康状况充分了解的基础上履行如实告知义务。投保人承诺完全知晓所有被保险人健康状况。若被保险人健康状况与上述告知内容不符：
                （1）本公司有权不同意承保。（2）若发生保险事故，本公司不承担赔偿或给付保险金的责任，并有权不退还保险费。</p>
                <br/>
            
        </div>
        <div class="footer">
            <div class="btn" ref="Button" @click="next">下一步</div>
        </div>
    </div>
   
</template>
<script>
let change = "#2688c4"
import {Msg, Loading} from 'components'
import {mapState,productDetail,mapGetters,mapMutations,mapActions} from 'vuex'
import {policyHealthRecord} from '../../apis/health.api'
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
import filter from "../../../../utils/filter"
//import {PAD} from "../../../../utils/PAD"

export default{

    data () {
        return {
            check1: [false,false],
            healthRecord:'',
        }
    },
    mounted(){
        document.body.scrollTop = 0;
        //健康告知页
        SKAPP.onEvent("健康告知页", "进入健康告知页",{
            icpProductCode:sessionStorage.icpProductCode,
            insureNotice:this.$store.state.health.insureNotice
        });

        switch (sessionStorage.col){
            case "B2":
                change = "#4285F6"
                break
            case "Y1":
                change = "#D8A161"
                break
            case "O1":
                change = "#FF6000"
                break
            case "R1":
                change = "#F76B6C"
                break
            case "R2":
                change = "#F11B33"
                break
            default:
                change = "#2688c4"
                break;
        }
        this.$refs.Button.style.backgroundColor = change;
        if (this.$store.state.health.select[0]) {
            this.$refs.is.style.backgroundColor = ""
            this.$refs.not.style.backgroundColor = ""
            this.check1[1] = true
            this.$refs.not.style.backgroundColor=change
        }
    },
    methods: {
        next: function () {

            //提交健康告知页
            SKAPP.onEvent("健康告知页", "提交健康告知",{
                icpProductCode:sessionStorage.icpProductCode,
                healthResult:"N"
            });

            if (this.$store.state.health.select[0]) {

                //提交健康告知页
                SKAPP.onEvent("健康告知页", "提交健康告知",{
                    icpProductCode:sessionStorage.icpProductCode,
                    healthResult:"Y"
                });

                var saleRecordId = this.$store.state.health.saleRecordId;

                var submitData = {
                    saleRecordId: saleRecordId,
                    healthRecord: '{"H75300001":"Y"}',
                    healthResult: 'Y'
                    };
                policyHealthRecord(submitData).then((data) => {
                    if (data.data.resultCode === '00000') {
                        //成功跳转
                        this.$router.push({
                            name: 'customerInfo'
                        });
                    }else{
                        Msg.alert(filter.resultCode(data.body))
                    };
                });
            }else{
                Msg.toast('您的健康告知未通过')
            };
        },
        change: function (e) {
            this.check = [false,false];
            this.check[event.target.getAttribute('eq')] = true;
            this.$refs.is.style.backgroundColor = ""
            this.$refs.not.style.backgroundColor = ""
            e.target.style.backgroundColor=change
            this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
        },
    }
}
</script>
<style lang="less" scoped>
@import "../../../../styles/vars.less";
.health_notice{
    padding-bottom:1.6rem;
h2{font-size:1.8rem;line-height:3rem;font-weight:bold;padding:1.2rem;border-bottom: 1px solid #ececec;}
.wrap{
    overflow: hidden;
    border-bottom: 1px solid #ececec;
    position: relative;
}
.question{
    font-size: 1.6rem;
    line-height: 2.3rem;
    padding: 1.5rem 1.2rem;
    float: left;
    color: #666;
    width: 70%;
}
.ans{
    float: left;
    position: absolute;
    top: 50%;
    right: 2rem;
    transform: translateY(-50%);
    -webkit-tap-highlight-color:rgba(0,0,0,0);
}
.ans p{
    float: left;
    font-size: 1.6rem;
    padding: 1.5rem 0;
    line-height: 2.3rem;
    margin-right: 0.15rem;
}
.ans p:first-child{
    margin-right: 1rem;
}
.ans p i{
    width: 1.8rem;
    height: 1.8rem;
    border-radius: 50%;
    display: inline-block;
    border: 1px solid #ccc;
    margin-right: 0.4rem;
    vertical-align: middle;
    position: relative;
    bottom: 1px;
    box-shadow: 0 0 0px 3px #FFF inset!important;
}


.ans p i{
    position: relative;
}
.ans p i:before {
    content: '';
    position: absolute;
    top: -10px; right: -10px;
    bottom: -10px; left: -5px;
}

.ans p i.current{
    background-color: @iconfont;
    box-shadow: 0 0 0px 3px #FFF inset!important;
}

.ps{
    font-size: 1.6rem;
    line-height: 2.3rem;
    padding: 1.5rem 1.2rem 6rem 1.2rem;
}
.first_load{
    background-color: transparent !important;
    box-shadow: none !important;
}
.weui_cell {
    padding: 5px 10px;
    color: #999;
}
.footer{
    z-index: 3;
    width: 100%;
    position: fixed;
    bottom: 0;
    left:0;
    padding-left: 1rem;
    padding-right: 1rem;
    padding-top: 1rem;
    padding-bottom: 1rem;
    background-color: rgba(0, 0, 0, 0.3);
}
.btn{
    width: 100%;
    height: 4.5rem;
    background-color: @iconfont;
    border: none;
    color: #ffffff;
    line-height: 4.5rem;
    font-size: 2rem;
    border-radius: 8px;
    text-align:center

}
.weui_cell{
    padding-left: 30px;
    font-size: 1.6rem;
}
.ps{
    font-weight:700;
    text-indent:2em;
}
.alert{

}
}
</style>