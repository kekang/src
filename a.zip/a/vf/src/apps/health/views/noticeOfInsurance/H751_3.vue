<template>
    <!-- 隐藏页 投保须知 -->

<div class="insurance_noticeE">
    <div class="contanier">
    <div class="product_details">
    <h1 class="indetails">理赔须知</h1>
    <h2 class="tips">一、理赔流程</h2>
<p class="p-details p-d" style="margin-top: 0rem">第一步：登陆平安健康险官网（http://health.pingan.com），下载理赔申请书并填写。</p>
    <p class="p-details p-d p-second">第二步：准备材料：</p>
<p class="p-details p-c">1.被保险人、申请人有效身份证件（复印件）<br />2.新生儿或未成年人出险，需提供与申请人的关系证明（复印件）<br />3.病历资料，包括诊断证明、病理及其他各项检查检验报告（原件）<br />4.医疗费用发票（原件）及费用明细清单<br />5.银行账户信息：包括开户行、户名、账号（复印件）<br />6.申请授权第三方代为领取理赔金仅限于连带被保险人之间，并需同时提供双方身份证明材料复印件。授权双方需在理赔申请书委托人、被委托人处签字。<br />7.若存在第三方先行赔付的情况，需提供第三方结算分割单原件及与之对应的发票复印件。</br>8.所能提供的与确认保险事故的性质、原因等有关的其它证明和资料（原件）<br />9.当保险金作为被保险人遗产时，必须提供可证明合法继承权的相关权利文件（原件）<br /></p>
<p class="p-details p-d p-second">第三步：请将理赔申请书及理赔材料邮寄到如下地址（邮费由您负担）：</p>
<table border="1" cellspacing="0" class="p-form">
    <thead>
    <tr class="top firstRow">
    <th class="topIn1">邮寄地址</th>
    <th class="topIn2">接收人</th>
    <th class="topIn3">电话</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td>上海市浦东新区上丰路1288号2号楼3楼</td>
    <td>平安健康险上海理赔作业中心</td>
    <td>021-38636792</td>
    </tr>
    </tbody>
    </table>
    <p class="p-details p-d p-second p-t">如您当前所在地为以下列表所示城市，可将理赔申请材料邮寄或送至相应机构</p>
<table class="p-form" border="1" cellspacing="0">
    <thead>
    <tr class="top firstRow">
    <th class="topInA">机构</th>
    <th>地址</th>
    <th class="topInC">联系人</th>
    <th class="topIn3">电话</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td>北京分公司</td>
    <td>北京市西城区金融街23号平安大厦610</td>
    <td>保单服务岗</td>
    <td>010-59733218</td>
    </tr>
    <tr>
    <td>上海分公司</td>
    <td>上海市静安区常熟路8号8-1门9楼健康险理赔受理中心</td>
<td>保单服务岗</td>
<td>021-20662854</td>
</tr>
<tr>
<td>天津分公司</td>
<td>天津河西区马场道59号平安大厦B座12层</td>
<td>保单服务岗</td>
<td>022-58581077</td>
</tr>
<tr>
<td>广东分公司</td>
<td>广州市天河区体育东路160号平安大厦18楼</td>
<td>保单服务岗</td>
<td>020-38262753</td>
</tr>
<tr>
<td>深圳分公司</td>
<td>深圳市福田区八卦三路301号平安大厦健康险深分</td>
<td>保单服务岗</td>
<td>0755-82057332</td>
</tr>
<tr>
<td>辽宁分公司</td>
<td>沈阳市沈河区北京街银河国际大厦A座910室</td>
<td>保单服务岗</td>
<td>024-31973630</td>
</tr>
<tr>
<td>江苏分公司</td>
<td>江苏省南京市中山东路218号长安国际507</td>
<td>保单服务岗</td>
<td>025-85496000</td>
</tr>
<tr>
<td>浙江分公司</td>
<td>浙江杭州密渡桥路1号浙商时代大厦B座706室</td>
<td>保单服务岗</td>
<td>0571-87228141</td>
</tr>
</tbody>
</table>
<h3 class="p-details p-c p-w">温馨提示：为避免邮件丢失，建议您复印留存一份理赔资料，并保留快递单。</h3>
<h2 class="tips">二、注意事项</h2>
<ol class="p-details p-c p-w">
    <li style="margin-top: 0rem">我们在接收到您的材料后将尽快处理，预计15个工作日内审核完毕。</li>
<li style="margin-top: 0.5rem">首次投保或非连续投保本保险时，被保险人因疾病需要住院治疗或接受指定门诊治疗的，自本合同生效之日起30日为等待期。被保险人在等待期内发生的保险事故，我们不承担给付保险金的责任。续保或者因意外伤害进行治疗的无等待期。</li>
<li style="margin-top: 0.5rem">本险种有效期1年，投保前确诊的疾病我司不承担保险责任。</li>
<li style="margin-top: 0.5rem">我们会对您投保时的健康告知进行核实，若不符合实际情况，可能影响您的赔付结论。</li>
<li style="margin-top: 0.5rem">审核中，若需要您补充其他材料等情况，烦请您予以配合，以便我们尽早完成理赔。</li>
<li style="margin-top: 0.5rem">若您对理赔结果有异议，可拨打95511-7进行咨询。</li>
</ol>
</div>
</div>
</div>
</template>
<style lang="less" scoped>
@import "../../../../styles/notice.less";
.insurance_noticeE{
    padding:1.5rem;
    h2{font-size:1.8rem;line-height:2.5rem;}
    p,li{font-size:1.6rem;line-height:2rem;margin-top:1.5rem;}
.indetails{
        text-align:center;
    }
    table {
        border-collapse: collapse;
        font-size: 1.4rem;
        text-align: center;
    }
    td,th{
        border:1px solid #000;
    }
}
</style>
