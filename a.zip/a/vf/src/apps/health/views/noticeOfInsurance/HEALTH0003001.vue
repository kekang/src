<template>
    <div class="healthInform">
        <header ref="Title">健康告知</header>
        <!--投保人确认被保险人没有以下情况-->
        <div class="healthTitle">投保人确认被保险人是否有以下情况：</div>
        <section>
            <ol class="list">
                <li>1、过去2年内投保人身保险或健康保险时，被保险公司拒保、延期、加费或者附加条件承保。</li>
                <li>2、目前从事高危职业。</br>
                    <div>
                        <p class="danDetail">被保险人是否正在从事以下行业（点击分类名可查看详情）：</p>
                    </div>
                    <highrisk :fnt="scroll"></highrisk>
                </li>

                <li>3. 目前或过往患有下列疾病或症状：<br>
                    良/恶性肿瘤、白血病、高血压、糖尿病、冠心病/冠状动脉狭窄、心肌梗死、风湿性心脏病、心功能不全二级以上、脑梗死/脑出血、肾炎、肾功能不全、肾/输尿管结石、肝炎、肝硬化、再生障碍性贫血、系统性红斑狼疮、类风湿性关节炎、帕金森氏病、癫痫、精神病、肺结核、慢性阻塞性肺病、瘫痪、慢性胆囊炎、胆石症、胆囊息肉、下肢静脉曲张、甲亢、甲状腺结节、传导性耳聋、胃/十二指肠溃疡、椎间盘突出症、克罗恩病（节段性肠炎）、先天性疾病、心肌病、慢性支气管炎、溃疡性结肠炎、痛风性关节炎、滥用药物史、酗酒史（酗酒是指平均每日酒精摄取量超过60克（男性）或40克（女性），每10克酒精摄取量相当于1杯（330ml）啤酒或半杯（150ml）葡萄酒或者45ml白酒）。
                </li>
                <li>
                    4. 过去1年内存在下列症状：反复头痛、晕厥、胸痛、气急、紫绀、持续反复发热、抽搐、不明原因皮下出血点、咯血、反复呕吐、进食梗噎感或吞咽困难、呕血、浮肿、腹痛、黄疸（新生儿黄疸已治愈的除外）、便血、血尿、蛋白尿、肿块、消瘦（体重减轻5公斤以上）、职业病、酒精中毒、其他药品中毒、智能障碍、五官/脊柱/胸廓/四肢/手指/足趾缺损/畸形或功能障碍。
                </li>
                <li>
                    5. 被保险人过去1年内有健康检查结果异常（如血液、超声、影像、内镜、病理检查）或长期服药（有规律的服药超过1个月）；过去2年曾住院（不包括剖腹产/顺产/急性鼻炎/急性胃肠炎/急性肺炎/急性上呼吸道感染住院）或有医生提出进一步复查、治疗或手术建议的。
                </li>
                <li>
                    6. 女性被保险人：被保险人目前在妊娠过程中，或有医生或体检医师告知过被保险人有乳腺囊肿/结节、卵巢囊肿、宫外孕、子宫内膜异位、子宫肌腺症、子宫肌瘤、宫颈炎、阴道炎、盆腔炎、月经失调。
                </li>
                <li>7. 2周岁以下被保险人：出生时体重低于2.5公斤，或有早产、窒息或缺氧史、发育迟缓、脑瘫的情况。</li>

            </ol>
        <div class="button">
            <div @click='change' eq="0"  ref="is" class="point" >是</div>
        <div @click='change' eq="1"  ref="not" class="point" >否</div>
        </div>
        </section>
        <section>
            <h2 class="wrap ps">
                投保人应在对所有被保险人健康/职业状况充分了解的基础上履行如实告知义务。投保人承诺完全知晓所有被保险人健康/职业状况。若被保险人健康/职业状况与上述告知内容不符：<br>（1）本公司有权不同意承保。（2）若发生保险事故，本公司不承担赔偿或给付保险金的责任，并有权不退还保险费。
            </h2>
        </section>
        <div class="footer">
            <div class="btn" ref="Button" @click="next">下一步</div>
        </div>
    </div>
</template>
<script>
    let change = "#2688c4"
    import {Msg, Loading, } from 'components'
    import {mapState,productDetail,mapGetters,mapMutations,mapActions} from 'vuex'
    import {policyHealthRecord} from '../../apis/health.api'
    import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
    import highrisk from '../../../../components/high-risk/index'
    import filter from "../../../../utils/filter"

    export default{
    data () {
    return {
    check: [false,false],
    toastFlag: false,
    toastMes: '',
    loadingFlag: false,
    alertMes: '',
    alertSubMes: '',
    alertFlag: false,
    fontColor:change
}
},
        beforeMount(){
            if(this.$store.state.health.productDetail){
                sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
            }else{
                this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
            }
        },
    components:{
    highrisk
},
    mounted(){
    //健康告知页
    //SKAPP.onEvent("健康告知页", "进入健康告知页",{
    //icpProductCode:sessionStorage.icpProductCode,
    //insureNotice:this.$store.state.health.insureNotice
//});
    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
        "进入健康告知页":'健康告知页'
    });
    document.body.scrollTop = 0;
    switch (sessionStorage.col){
    case "B2":
    change = "#4285F6"
    break
    case "Y1":
    change = "#D8A161"
    break
    case "O1":
    change = "#FF6000"
    break
    case "R1":
    change = "#F76B6C"
    break
    case "R2":
    change = "#F11B33"
    break
    default:
    change = "#2688c4"
    break;
}
    this.$refs.Button.style.backgroundColor = change;
    this.$refs.Title.style.color = change;
        if (this.$store.state.health.select[0]){
            this.$refs.not.style.backgroundColor = change;
            this.$refs.not.style.borderColor = change;
            this.$refs.not.style.color = "#fff";
        }else if(this.$store.state.health.select[0]===false){
            this.$refs.is.style.backgroundColor = change;
            this.$refs.is.style.borderColor = change;
            this.$refs.is.style.color = "#fff";
        }
},
    methods: {
    scroll(e){
    if(e){
    document.getElementsByTagName("body")[0].style.overflow="hidden"
}else{
    document.getElementsByTagName("body")[0].style.overflow="scroll"
}
},
    change: function (e) {
    this.check = [false, false];
    this.check[event.target.getAttribute('eq')] = true;
    this.$refs.is.style.backgroundColor = ""
    this.$refs.not.style.backgroundColor = ""
    this.$refs.is.style.color = "#666"
    this.$refs.not.style.color = "#666"
    this.$refs.is.style.borderColor = "#666"
    this.$refs.not.style.borderColor = "#666"
    e.target.style.backgroundColor = change
    e.target.style.borderColor = change
    e.target.style.color = "#fff"
    this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
},
    next(){
    //提交健康告知页
    //SKAPP.onEvent("健康告知页", "提交健康告知",{
    //icpProductCode:sessionStorage.icpProductCode,
    //healthResult:"N"
//});

    if (this.$store.state.health.select[0]) {

    //提交健康告知页
    //SKAPP.onEvent("健康告知页", "提交健康告知",{
    //icpProductCode:sessionStorage.icpProductCode,
    //healthResult:"Y"
//});
    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
        "提交健康告知":'否'
    });

    var saleRecordId = this.$store.state.health.saleRecordId;
    var submitData = {
    saleRecordId: saleRecordId,
    healthRecord: '{"H70400001":"Y","H70400002":"Y"}',
    healthResult: 'Y'
};
    policyHealthRecord(submitData).then((data) => {
    if (data.data.resultCode === '00000'){
    //成功跳转
    this.$router.push({
    name: 'customerInfo'
});
}else{

    Msg.alert(filter.resultCode(data.body))
};
})
} else {
    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
        "提交健康告知":'是'
    });
    Msg.toast('您的健康告知未通过')
};
}
}
}
</script>
<style lang="less" scoped>
    .healthInform{
    .list{
    margin:0 1rem 0;
    font-size:1.3rem;
    color:#666
}
    .list>li{
    margin-bottom:1rem
}
    header{
    font-size:1.7rem;
    text-align:center;
    margin:1.5rem 0
}
    .healthTitle{
    font-size:1.3rem;
    color:#000;
    margin:0 1rem
}
    .danDetail{
    font-size:1.2rem;
    color:#32BCFD;
    margin:1.5rem 1rem
}
    .button{
    width: 22rem;
    height: 2.2rem;
    margin: 1.5rem auto;
    >div{
    width: 10rem;
    margin: 0 0.4rem;
    display: inline-block;
    text-align: center;
    color: #666;
    border: 1px solid #666;
    border-radius: 2rem;
    line-height: 2.2rem;
    font-size: 1.3rem;
}
}
    h2{
    border-top: 1px solid #ccc;
    font-size: 1.3rem;
    padding: 1.5rem 1rem;
    margin-bottom:6.5rem
}
    .footer{
    z-index: 3;
    width: 100%;
    position: fixed;
    bottom: 0;
    left:0;
    padding-left: 1rem;
    padding-right: 1rem;
    padding-top: 1rem;
    padding-bottom: 1rem;
    background-color: rgba(0, 0, 0, 0.3);
}
    .btn{
    width: 100%;
    height: 4.5rem;
    border: none;
    color: #ffffff;
    line-height: 4.5rem;
    font-size: 2rem;
    border-radius: 8px;
    text-align:center

}
}
</style>