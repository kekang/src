<template >
    <!-- 隐藏页 投保须知 -->
    <div id="H751_1" class="noticeInsurance insurance_noticeHW">
    <div class="p-b-20">
    <div class="info-box">
    <p class="title" bold style="margin-top:1.5rem;">平安抗癌卫士医疗保险条款及费率表</p>
<p style="text-align:center;">保监会报备文号：平保健发〔2015〕148号-4</p>
</div>
<div class="info-box">
    <p class="i-d-t">在本条款中，“您”指投保人，“我们”、“本公司”均指平安健康保险股份有限公司。</p>
</div>
<div class="info-box">
    <p class="i-d-h">1,您与我们的合同</p>
<hr />
<p class="i-d-t">1.1合同构成：<br />本保险条款、电子保险单或其他保险凭证、电子投保书、与保险合同有关的投保文件、合法有效的声明、批注、批单、附加险合同、其他书面或电子协议都是您与我们之间订立的保险合同的构成部分。“平安抗癌卫士医疗保险合同”以下简称为“本主险合同”。</p>
<p class="i-d-t">1.2合同成立与生效：<br />您提出保险申请、我们同意承保，本主险合同成立.本主险合同自我们同意承保、收取首期保险费并签发电子保险单开始生效，具体生效日以电子保险单所载的日期为准。本主险合同生效日以后每年的对应日是保单周年日。如果当月无对应的同一日，则以该月最后一日作为对应日。</p>
<p class="i-d-t">1.3投保年龄：<br />指投保时被保险人的年龄，投保年龄以<strong>周岁</strong>（见7.1）计算，本主险合同接受的投保年龄为0周岁至55周岁，最高可续保至85周岁，投保时被保险人为0周岁的，应当为出生满28日且已健康出院的婴儿。</p>
<p class="i-d-t">1.4犹豫期：<br style="white-space:normal;" />自您签收本主险合同次日起，有10日的犹豫期。在此期间请您认真审视本主险合同，如果您认为本主险合同与您的需求不相符，您可以在此期间提出解除本主险合同，我们将无息退还您所支付的全部保险费。 解除本主险合同时，您需要填写申请书，并提供您的保险合同及<strong>有效身份证件</strong>（见7.2）。自我们收齐上述申请材料时起，本主险合同即被解除，合同解除前发生的保险事故我们不承担保险责任。</p>
<p class="i-d-t">1.5保险期间和续保：<br />本主险合同的保险期间为1年，具体起讫日期以电子保险单所载的日期为准。若您选择了自动续保方式，每一保险期间届满之前，若我们未收到您不再继续投保的申请，经我们审核同意并按续保时对应的费率收取保险费后本主险合同将延续有效。新续保的合同自期满日起生效，保险期间为1年。经审核后，若我们不接受续保的，我们会在本主险合同保险期间届满之前通知您。</p>
</div>
<div class="info-box">
    <p class="i-d-h">2,我们提供的保障</p>
<hr />
<p class="i-d-t">2.1保险金额<br />本主险合同的<strong>保险金额</strong>（见7.3）由您在投保时与我们约定，并在电子保险单上载明。</p>
<p class="i-d-t">2.2保险责任<br />在本主险合同有效期内，我们承担如下保险责任：<br />等待期：<span style="background:#dddddd"">您为被保险人首次投保或非连续投保本保险时，自本主险合同生效日起90日为等待期。<br />在等待期内，被保险人经<strong>医院</strong>（见7.4）确诊初次发生<strong>癌症</strong>（见7.5，含<strong>原位癌</strong>（见7.7））的，我们不承担给付保险金的责任，并向您返还所交保险费，本主险合同终止。</span>您为被保险人连续投保本保险的，无等待期。<br />如果在等待期后发生<strong>保险事故</strong>（见7.8），我们承担下列保险责任：<br />癌症确诊费用保险金：被保险人经医院确诊初次发生癌症（含原位癌），对于其<strong>癌症确诊之日</strong>（见7.9）前30日内在医院门急诊或<strong>住院</strong>（见7.10）期间发生的与确诊癌症相关的<strong>医疗必需</strong>（见7.11）的医疗费用，<span style="background:#dddddd"">我们在扣除被保险人按照<strong>社会医疗保险</strong>（见7.12）或公费医疗的有关规定取得的医疗费用补偿后，乘以下表对应的给付比例给付癌症确诊费用保险金。</span><br /></p>
<table border="1" style="bgcolor:#DDDDDD">
    <tbody>
    <tr class="firstRow">
    <td align="center" style="border-width:1px;border-style:solid;">给付条件</td>
<td align="center" style="border-width:1px;border-style:solid;">给付比例</td>
</tr>
<tr>
<td align="left" style="border-width:1px;border-style:solid;">被保险人已从社会医疗保险或公费医疗获得费用补偿</td>
<td align="center" style="border-width:1px;border-style:solid;">100%</td>
</tr>
<tr>
<td align="left" style="border-width:1px;border-style:solid;">被保险人未从社会医疗保险或公费医疗获得费用补偿</td>
<td align="center" style="border-width:1px;border-style:solid;">90%</td>
</tr>
</tbody>
</table>
<p class="i-d-t">与确诊癌症相关的医疗费用包括：<br />（1）医生诊疗费：指被保险人门急诊期间发生的主诊医生或会诊医生的劳务费用，包括挂号费。<br />（2）检查检验费：指门急诊或住院发生的以诊断癌症为目的，采取必要的医学手段进行检查及检验而发生的合理的医疗费用，包括X光费、心电图费、B超费、脑电图费、内窥镜费、肺功能仪费、分子生化检验费和血、尿、便常规检验费等。</p>
<p class="i-d-t">癌症治疗费用保险金：被保险人经医院确诊初次发生癌症（含原位癌），对于其癌症确诊之日后在医院门急诊或住院期间发生的与治疗癌症相关的医疗必需的医疗费用，<span style="background:#dddddd"">我们在扣除被保险人按照社会医疗保险或公费医疗的有关规定取得的医疗费用补偿后，乘以下表对应的给付比例给付癌症治疗费用保险金。</span><br /></p>
<table border="1" style="bgcolor:#DDDDDD">
    <tbody>
    <tr class="firstRow">
    <td align="center" style="border-width:1px;border-style:solid;">给付条件</td>
<td align="center" style="border-width:1px;border-style:solid;">给付比例</td>
</tr>
<tr>
<td align="left" style="border-width:1px;border-style:solid;">被保险人已从社会医疗保险或公费医疗获得费用补偿</td>
<td align="left" style="border-width:1px;border-style:solid;">100%</td>
</tr>
<tr>
<td align="left" style="border-width:1px;border-style:solid;">被保险人未从社会医疗保险或公费医疗获得费用补偿</td>
<td align="left" style="border-width:1px;border-style:solid;">90%</td>
</tr>
</tbody>
</table>
<p class="i-d-t">与治疗癌症相关的医疗费用包括：<br />（1）床位费：住院期间实际发生的、不高于标准单人病房（或私人病房）的住院床位费（<span style="background:#dddddd"">不包括套房、家庭病床</span>）。未满18周岁的被保险人在住院治疗期间，我们根据合同约定给付其合法监护人（限一人）在医院留宿发生的加床费；或女性被保险人在住院治疗期间，我们根据合同约定给付其一周岁以下哺乳期婴儿在医院留宿发生的加床费。<br />（2）护理费：住院期间根据医嘱所示的护理等级确定的护理费用。<br />（3）检查检验费：门急诊或住院期间实际发生的，以诊断疾病为目的，采取必要的医学手段进行检查及检验而发生的合理的医疗费用，包括X光费、心电图费、B超费、脑电图费、内窥镜费、肺功能仪费、分子生化检验费和血、尿、便常规检验费等。<br />（4）治疗费：指门诊或住院期间以治疗癌症为目的，发生的合理的医疗器械使用费，以及消耗品的费用，包括注射费、护理费、抢救费、清创缝合、换药、雾化吸入、鼻饲管置管、胃肠减压、洗胃、物理降温、坐浴、冷热湿敷、引流管冲洗、灌肠、导尿、肛管排气、输血费、输氧费，针对癌症的非浸入性治疗费用如伽玛刀、射频、聚焦超声治疗，<strong>化学疗法</strong>（见7.13）、<strong>内分泌疗法</strong>（见7.14）、<strong>放射疗法</strong>（见7.15）、<strong>免疫疗法</strong>（见7.16）、<strong>靶向疗法</strong>（见7.17）。<br />（5）药品费：指门急诊或住院期间实际发生的合理且必要的由医生开具的具有国家药品监督管理部门核发的药品批准文号或者进口药品注册证书、医药产品注册证书的国产或进口药品的费用，包含治疗癌症过程中使用的<strong>抗呕吐药物</strong>（见7.18）、<strong>抗排斥药物</strong>（见7.19）。<br />（6）医生费：包括外科医生、麻醉师、内科医生、专科医生的费用。<br />（7）手术费：包括干细胞、骨髓、器官移植（若被保险人为受体，则被保险人和移植当天捐献者的手术费用都包含）和治疗癌症所需的外科手术费用。指住院期间为治疗癌症、挽救生命而施行的手术产生的合理医疗费用，包括手术室费、恢复室费、麻醉费、手术监测费、手术辅助费、材料费、一次性用品费、术中用药费、手术设备费。<br />癌症治疗手术后导致需要人造乳房或面部重建的，此项费用也在手术费用保障范围内。<br />（8）重症监护病房床位费：住院期间出于医学必要被保险人需在重症监护病房进行合理且必要的医疗而产生的床位费。<br />重症监护病房指配有中心监护台、心电监护仪及其它监护抢救设施、相对封闭管理的单人或多人监护病房，包括重症加强护理病房（ICU）、冠心病重症加强护理病房（CCU）、呼吸疾病重症加强护理病房（RCU）、神经疾病重症加强护理病房（NICU）、急诊重症加强护理病房（RICU）等。<br />（9）中医治疗费用：以治疗癌症为目的发生的合理且必需的中医治疗、中成药、中草药费用。</p>
<p class="i-d-t">最高给付金额：<span style="background:#dddddd"">在一个保单年度内，被保险人不论一次或多次在医院进行治疗，我们均按上述约定给付各项保险金，但各项保险金的累计给付金额以被保险人的保险金额为限，累计给付金额达到保险金额时，本保单年度我们对被保险人的保险责任终止。<br />如您为被保险人连续投保本保险，每一个保单年度内保险金累计给付金额以保险金额为限，且多个保单年度内保险金累计给付金额以保险金额的五倍为限。连续投保的多个保单年度内保险金累计给付金额达到保险金额的五倍时，我们不再承担保险责任，本主险合同终止。<br />您为被保险人首次投保或非连续投保本保险的，如被保险人在等待期后经医院确诊初次发生癌症，我们承担保险责任直至保险期间届满，本主险合同终止且不接受续保。但保险期间届满时被保险人治疗癌症仍未结束或癌症转移的，我们将继续承担保险责任至癌症确诊之日起满一年止。保险期间内及保险期间届满后累计给付金额以保险金额为限。</span></p>
<p class="i-d-t">补偿原则：对于上述各项保险金，若被保险人已从其它途径（包括社会医疗保险、公费医疗、工作单位、本公司在内的任何商业保险机构等）取得补偿，<span style="background:#dddddd"">我们将按上述约定的赔偿范围、给付比例及保险金额计算并给付保险金，且最高给付金额不超过被保险人实际发生的医疗费用扣除其所获补偿后的余额。</span></p>
<p class="i-d-t">2.3责任免除<br /><span style="background:#dddddd"">在下列期间发生的或下列情形导致的癌症治疗医疗费用支出、以及如下列明的费用支出，我们不承担给付保险金的责任：<br />（1）投保人对被保险人的故意杀害、故意伤害；<br />（2）被保险人故意自伤、故意犯罪或者抗拒依法采取的刑事强制措施；<br />（3）被保险人主动吸食或注射<strong>毒品</strong>（见7.20）；<br />（4）被保险人感染<strong>艾滋病病毒或患艾滋病</strong>（见7.21）期间；<br />（5）核爆炸、核辐射或核污染；<br />（6）被保险人在本主险合同生效前所患或出现的癌症、症状、体征，但我们在承保时已知晓并做出书面认可的不在此限；<br />（7）任何<strong>职业病</strong>（见7.22）、先天性畸形、先天性恶性肿瘤（<strong>BRCA1/BRCA2</strong>基因突变家族性乳腺癌，遗传性非息肉病性结直肠癌，肾母细胞瘤即<strong>Wilms</strong>瘤，李-佛美尼综合症即<strong>Li-Fraumeni</strong>综合征）、<strong>遗传性疾病（见7.23）</strong>或染色体异常（依照世界卫生组织《疾病和有关健康问题的国际统计分类》（<strong>ICD-10</strong>）确定）引起的医疗费用；<br />（8）接种预防癌症的疫苗，进行基因测试以鉴定癌症的遗传性，接受实验性医疗，采取未经科学或医学认可的医疗手段；<br />（9）由于<strong>医疗事故</strong>（见7.24）引起的医疗费用；<br />（10）滋补类中草药，即以提高人体免疫力为主要用途的单味使用的中草药及成药，包括但不限于人参、阿胶、鹿角胶、龟鹿二仙胶、龟板胶、鳖甲胶、马宝、珊瑚、玳瑁、冬虫夏草、藏红花、羚羊、犀角、牛黄、麝香、鹿茸、铁皮枫斗。<br />发生上述第（1）项情形导致被保险人发生癌症的，本主险合同终止，我们向受益人退还本主险合同的未满期<strong>净保险费</strong>（见7.25）。<br />发生上述第（2）至（7）项情形导致被保险人发生癌症的，本主险合同终止，我们向您退还本主险合同的未满期净保险费。</span></p>
</div>
<div class="info-box">
    <p class="i-d-h">3,如何申请领取保险金</p>
<hr />
<p class="i-d-t">3.1受益人<br />除另有约定外，本主险合同的受益人为被保险人本人。</p>
<p class="i-d-t">3.2保险事故通知<br/>请您或受益人在知道保险事故发生后10日内通知我们。<span style="background:#dddddd"">如果您或受益人故意或者因重大过失未及时通知，致使保险事故的性质、原因、损失程度等难以确定的，我们对无法确定的部分，不承担给付保险金的责任，</span>但我们通过其他途径已经及时知道或者应当及时知道保险事故发生或者虽未及时通知但不影响我们确定保险事故的性质、原因、损失程度的除外。</p>
<p class="i-d-t">3.3保险金申请<br />在申请保险金时，请按照下列方式办理：<br/>保险金申请所需材料:<br />由受益人填写保险金给付申请书，并提供下列证明和资料：<br />（1）保险合同；<br />（2）受益人的有效身份证件；<br />（3）医院出具的附有病理显微镜检查、血液检验及其它科学方法检验报告的疾病诊断证明书；<br />（4）医院出具的入出院证明或门诊证明；<br />（5）医院出具的医疗诊断书及住院或门诊发生医疗费用的原始凭证、医疗费用结算清单、病历（若施行手术还需提供手术费用的原始凭证）；<br />（6）检查检验报告及药品明细和处方；<br />（7）所能提供的与确认保险事故的性质、原因等有关的其他证明和资料。<br />以上证明和资料不完整的，我们将及时一次性通知受益人补充提供有关证明和资料。</p>
<p class="i-d-t">3.4保险金的给付<br />我们在收到保险金给付申请书及上述有关证明和资料后，将在5日内作出核定；情形复杂的，在30日内作出核定。对属于保险责任的，我们在与受益人达成给付保险金的协议后10日内，履行给付保险金义务；若我们在收到保险金给付申请书及上述有关证明和资料后第30日仍未作出核定，除支付保险金外，我们将从第31日起按超过天数赔偿受益人因此受到的利息损失。如我们要求投保人、被保险人或者受益人补充提供有关证明和资料的，上述30日期间会扣除投保人、被保险人或者受益人补充提供有关证明和资料期间，扣除期间自我们作出的通知到达投保人、被保险人或者受益人之日起，至投保人、被保险人或者受益人按照通知要求补充提供的有关证明和资料到达保险人之日止。利息按照我们公示的利率按单利计算，且保证该利率不低于中国人民银行公布的同期金融机构人民币活期存款基准利率。对不属于保险责任的，我们自作出核定之日起3日内向受益人发出拒绝给付保险金通知书并说明理由。我们在收到受益人的保险金给付申请书及有关证明和资料之日起60日内，对给付保险金的数额不能确定的，根据已有证明和资料可以确定的数额先予支付；我们最终确定给付保险金的数额后，将支付相应的差额。</p>
<p class="i-d-t">3.5诉讼时效<br />受益人向我们请求给付保险金的诉讼时效期间为2年，自其知道或者应当知道保险事故发生之日起计算。</p>
</div>
<div class="info-box">
    <p class="i-d-h">4,如何支付保险费</p>
<hr />
<p class="i-d-t">4.1保险费的支付<br />本主险合同的费率按照被保险人年龄和所选计划确定。</p>
<p class="i-d-t">4.2宽限期<br />本主险合同一年期满时，若我们同意续保，则自期满日起60日为宽限期。宽限期内发生保险事故的，我们仍承担保险责任，但在给付保险金时会扣减您欠交的保险费。如果您宽限期结束之后仍未支付保险费，则我们自宽限期满的次日零时起不再承担保险责任。</p>
<p class="i-d-t">4.3保险费率调整<br />您的保费会随着您的年龄增长而上升。同时，我们每年都会检视费率，使其反映我们的整体理赔经验和医疗通胀等在内的一系列因素。我们将根据本主险合同计算费率所用的计算基础与实际情况的偏差程度，决定保险费率是否调整及调整幅度。本保险的费率调整针对所有被保险人，或同一投保年龄、同一投保区域等某一类人群的被保险人。如果您不同意费率调整，可以申请解除合同。自我们收到解除合同申请书时起，本主险合同终止，我们向您退还本主险合同的未满期净保险费。我们进行保险费率调整后，您须按调整后续保当时的保险费率支付续期保险费，保险费率调整前您已经支付的保险费不受影响。</p>
</div>
<div class="info-box">
    <p class="i-d-h">5,如何解除保险合同</p>
<hr />
<p class="i-d-t">5.1您解除合同的手续及风险<br />您可以申请解除本主险合同，自您提交解除合同申请的次日零时起，本主险合同终止。我们会在30日内向您退还本主险合同的未满期净保险费。您申请解除合同会遭受一定损失。</p>
</div>
<div class="info-box">
    <p class="i-d-h">6,其他需要关注的事项</p>
<hr />
<p class="i-d-t">6.1明确说明与如实告知<br />订立本主险合同时，我们会向您说明本主险合同的内容，对本主险合同中免除我们责任的条款，我们在订立合同时会在电子投保书、电子保险单或其他保险凭证上作出足以引起您注意的提示，并对该条款的内容以书面或口头形式向您作出明确说明，未作提示或者明确说明的，该条款不产生效力。我们会就您和被保险人的有关情况提出询问，您应当如实告知。如果您故意或者因重大过失未履行前款规定的如实告知义务，足以影响我们决定是否同意承保或者提高保险费率的，我们有权解除本主险合同。<span style="background:#dddddd"">如果您故意不履行如实告知义务，对于本主险合同解除前发生的保险事故，我们不承担给付保险金的责任，并不退还保险费。如果您因重大过失未履行如实告知义务，对保险事故的发生有严重影响的，对于本主险合同解除前发生的保险事故，我们不承担给付保险金的责任，但会退还保险费。</span>我们在合同订立时已经知道您未如实告知的情况的，我们不得解除合同；发生保险事故的，我们承担给付保险金的责任。</p>
<p class="i-d-t">6.2年龄或性别错误<br />您在申请投保时，应将与有效身份证件相符的被保险人的出生日期和性别在投保单上填明，如果发生错误按照下列方式办理：<br />（1）您申报的被保险人年龄不真实，并且其真实年龄不符合本主险合同约定投保年龄限制的，我们有权解除合同，并向您退还本主险合同的未满期净保险费。<br />（2）您申报的被保险人年龄或性别不真实，致使您实付保险费少于应付保险费的，我们有权更正并要求您补交保险费。<span style="background:#dddddd"">若已经发生保险事故，在给付保险金时按实付保险费和应付保险费的比例给付。</span><br />（3）您申报的被保险人年龄或性别不真实，致使您实付保险费多于应付保险费的，我们会将多收的保险费退还给您。</p>
<p class="i-d-t">6.3合同内容变更<br />本主险合同有效期内，经您与我们协商一致，可以变更本主险合同的有关内容，变更本主险合同的，应当由我们在电子保险单或者其他保险凭证上批注或者附贴批单，或者由您与我们订立变更的书面协议。您通过我们同意或者认可的网站等互联网渠道提出对本主险合同进行变更，视为您的书面申请，您向我们在线提交的电子信息与您向我们提交的书面文件具有相同的法律效力。</p>
<p class="i-d-t">6.4联系方式变更<br />为了保障您的合法权益，您的电话或电子邮箱等联系方式变更时，请及时以书面形式或双方认可的其他形式通知我们。若您未以书面形式或双方认可的其他形式通知我们，我们按本主险合同载明的最后电话或电子邮箱发送的有关通知，均视为已送达给您。</p>
<p class="i-d-t">6.5效力终止<br />当发生下列情形之一时，本主险合同效力终止：<br />（1）被保险人身故；<br />（2）续保时被保险人年满86周岁；<br />（3）本主险合同中列明的其他合同解除的情形。<br /></p>
<p class="i-d-t">6.6争议处理<br />本主险合同履行过程中，双方发生争议不能协商解决的，可以达成仲裁协议通过仲裁解决，也可依法直接向有管辖权的法院提出诉讼。</p>
</div>
<div class="info-box">
    <p class="i-d-h">7,释义</p>
<hr />
<p class="i-d-t">7.1周岁<br />指按<strong>有效身份证件</strong>（见7.2）中记载的出生日期计算的年龄，自出生之日起为零周岁，每经过一年增加一岁，不足一年的不计。</p>
<p class="i-d-t">7.2有效身份证件<br />指由政府主管部门规定的证明其身份的证件，如：居民身份证、按规定可使用的有效护照、军官证、警官证、士兵证等证件。</p>
<p class="i-d-t">7.3保险金额<br />指我们承担相应赔偿或者给付保险金责任的最高限额。</p>
<p class="i-d-t">7.4医院<br />指中华人民共和国境内（港、澳、台地区除外）合法经营的二级以上（含二级）公立医院，<span style="background:#dddddd"">不包括以康复、护理、疗养、戒酒、戒毒或者类似功能为主要功能的医疗机构。</span></p>
<p class="i-d-t">7.5癌症<br />即恶性肿瘤，指被保险人初次发生符合下列定义的恶性肿瘤，该疾病应当由<strong>专科医生</strong>（见7.6）明确诊断。<br />恶性肿瘤指恶性细胞不受控制的进行性增长和扩散，浸润和破坏周围正常组织，可以经血管、淋巴管和体腔扩散转移到身体其他部位的疾病。经病理学检查结果明确诊断，临床诊断属于世界卫生组织《疾病和有关健康问题的国际统计分类》（ICD-10）的恶性肿瘤范畴，其中包含：<br />（1）原位癌；<br />（2）相当于Binet分期方案A期程度的慢性淋巴细胞白血病；<br />（3）相当于Ann Arbor分期方案I期程度的何杰金氏病；<br />（4）皮肤癌(不包括恶性黑色素瘤及已发生转移的皮肤癌)；<br />（5）TNM分期为T1N0M0期或者更轻分期的前列腺癌。</p>
<p class="i-d-t">7.6专科医生<br />专科医生应当同时满足以下四项资格条件：<br />（1）具有有效的中华人民共和国《医师资格证书》；<br />（2）具有有效的中华人民共和国《医师执业证书》，并按期到相关部门登记注册；<br />（3）具有有效的中华人民共和国主治医师或主治医师以上职称的《医师职称证书》；<br />（4）在二级或二级以上医院的相应科室从事临床工作三年以上。</p>
<p class="i-d-t">7.7原位癌<br />指恶性细胞局限于上皮内尚未穿破基底膜浸润周围正常组织的癌细胞新生物。原位癌必须经对固定活组织的组织病理学检查明确诊断。</p>
<p class="i-d-t">7.8保险事故<br />指保险合同约定的保险责任范围内的事故。</p>
<p class="i-d-t">7.9癌症确诊之日<br />指被保险人经手术治疗或病理检查确诊癌症的，以手术病理取材或病理活检取材日期为癌症确诊日期；被保险人未经手术治疗但后续行放射性疗法或化学药物性疗法的，以首次放疗或化疗日期为癌症确诊日期。</p>
<p class="i-d-t">7.10住院<br />指被保险人因疾病而入住医院的正式病房进行治疗，并正式办理入出院手续，<span style="background:#dddddd"">不包括入住门诊观察室、家庭病床、挂床住院或其他不合理的住院。</span>挂床住院指办理正式住院手续的被保险人，在住院期间每日非24小时在床、在院。具体表现包括在住院期间连续若干日无任何治疗，只发生护理费、诊疗费、床位费等情况。</p>
<p class="i-d-t">7.11医疗必需<br />满足以下条件的医学治疗、服务或药品为医学上必需：<br />（1）对病人疾病或伤害的诊断或治疗是适当的、基本的；<br />（2）提供安全、充分、适当的诊断和治疗必须的护理，但不超过一定的范围、持续时间或强度、级别；<br />（3）医师开具的处方以及与在当地被广泛认可的医疗专业水平一致的治疗；<br />（4）不是主要为病人、家庭、医生或其他提供治疗的人员的舒适和方便而设的项目；<br />（5）不属于对病人的学术教育或专业培训的一部分；<br />（6）非试验性或研究性的。</p>
<p class="i-d-t">7.12社会医疗保险<br />本主险合同所称的社会医疗保险包括城镇职工基本医疗保险、城镇居民基本医疗保险、新型农村合作医疗、医疗救助等政府举办的基本医疗保障项目。</p>
<p class="i-d-t">7.13化学疗法<br />指利用化学药物阻止癌细胞的增殖、浸润、转移，直至杀灭癌细胞的一种治疗方式。</p>
<p class="i-d-t">7.14内分泌疗法<br />指用药物抑制激素生成和激素反应，杀死癌细胞或抑制癌细胞的生长。</p>
<p class="i-d-t">7.15放射疗法<br />指利用放射线照射患病部位，攻击癌细胞的疗法。</p>
<p class="i-d-t">7.16免疫疗法<br />指现代生物技术手段激发自身免疫系统来对抗肿瘤的新型治疗方法。</p>
<p class="i-d-t">7.17靶向疗法<br />是在细胞分子水平上，针对已经明确的致癌位点来设计相应的治疗药物，利用具有一定特异性的载体,将药物或其它杀伤肿瘤细胞的活性物质选择性地运送到肿瘤部位攻击癌细胞的疗法。靶向治疗的药物需具有国家药品监督管理部门核发的药品批准文号或者进口药品注册证书、医药产品注册证书。</p>
<p class="i-d-t">7.18抗呕吐药物<br />治疗癌症过程中因化疗或放疗出现呕吐的药物。</p>
<p class="i-d-t">7.19抗排斥药物<br />因患癌症而进行器官移植，骨髓移植或干细胞移植之后，使用免疫抑制剂抑制机体免疫反应，此类抑制免疫排斥药物称为抗排斥药物。</p>
<p class="i-d-t">7.20毒品<br />指中华人民共和国刑法规定的鸦片、海洛因、甲基苯丙胺（冰毒）、吗啡、大麻、可卡因以及国家规定管制的其他能够使人形成瘾癖的麻醉药品和精神药品，但不包括由医生开具并遵医嘱使用的用于治疗疾病但含有毒品成分的处方药品。</p>
<p class="i-d-t">7.21感染艾滋病病毒或患艾滋病<br />艾滋病病毒指人类免疫缺陷病毒，英文缩写为HIV。艾滋病指人类免疫缺陷病毒引起的获得性免疫缺陷综合征，英文缩写为AIDS。在人体血液或其它样本中检测到艾滋病病毒或其抗体呈阳性，没有出现临床症状或体征的，为感染艾滋病病毒；如果同时出现了明显临床症状或体征的，为患艾滋病。</p>
<p class="i-d-t">7.22职业病<br />指企业、事业单位和个体经济组织的劳动者在职业活动中，因接触粉尘、放射性物质和其他有毒、有害物质等因素而引起的疾病。职业病的认定需遵循《中华人民共和国职业病防治法》中的相关规定及鉴定程序。</p>
<p class="i-d-t">7.23遗传性疾病<br />指生殖细胞或受精卵的遗传物质（染色体和基因）发生突变或畸变所引起的疾病，通常具有由亲代传至后代的垂直传递的特征。</p>
<p class="i-d-t">7.24医疗事故<br />指医疗机构及其医务人员在医疗活动中，违反医疗卫生管理法律、行政法规、部门规章和诊疗护理规范及常规，过失造成患者人身损害的事故。</p>
<p class="i-d-t">7.25净保险费<br />净保险费指不包含公司营业费用、佣金等其他费用的保险费。其计算公式为保险费&times;（1-35％）。<br />未满期净保险费的计算分两种情况：<br />（1）您为被保险人首次投保或非连续投保本保险的：<br />如果保险经过日数≤等待期日数，未满期净保险费=净保险费；<br />如果保险经过日数＞等待期日数，未满期净保险费=净保险费&times;[1－(保险经过日数-等待期日数)/（保险期间的日数-等待期日数）]，经过日数不足1日的按1日计算。<br />（2）您为被保险人连续投保本保险的：<br />未满期净保险费=净保险费&times;（1－保险经过日数/保险期间的日数），经过日数不足1日的按1日计算。</p>
</div>
<div class="footer" style="display:none;">
    <button type="button" class="btn" btn-block" btn-cancel"" onclick="history.go(-1)">返回上一页</button>
</div>
</div>
<p>
<!--保险费率表--></p>
<div class="p-b-20">
    <div class="info-box">
    <p class="title" bold"">平安抗癌卫士医疗保险费率表</p>
</div>
<div class="info-box">
    <p class="i-d-h">一、每万元保险金额费率：</p>
<br />
<p class="i-d-t" style="text-align:right;">单位：人民币元&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<table border="1" style="width:90%"" align="center">
<tbody>
<tr class="firstRow">
    <td align="center" style="border-width:1px;border-style:solid;"><strong>年龄</strong></td>
<td align="center" style="border-width:1px;border-style:solid;"><strong>男</strong></td>
<td align="center" style="border-width:1px;border-style:solid;"><strong>女</strong></td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>0</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">27.9</td>
<td align="center" style="border-width:1px;border-style:solid;">30.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>1</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">24.6</td>
<td align="center" style="border-width:1px;border-style:solid;">25.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>2</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">21.8</td>
<td align="center" style="border-width:1px;border-style:solid;">21.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>3</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">19.2</td>
<td align="center" style="border-width:1px;border-style:solid;">18.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>4</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">17.0</td>
<td align="center" style="border-width:1px;border-style:solid;">16.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>5</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">15.2</td>
<td align="center" style="border-width:1px;border-style:solid;">14.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>6</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">13.7</td>
<td align="center" style="border-width:1px;border-style:solid;">12.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>7</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">12.6</td>
<td align="center" style="border-width:1px;border-style:solid;">11.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>8</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">11.8</td>
<td align="center" style="border-width:1px;border-style:solid;">11.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>9</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">11.4</td>
<td align="center" style="border-width:1px;border-style:solid;">10.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>10</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">11.3</td>
<td align="center" style="border-width:1px;border-style:solid;">11.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>11</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">11.4</td>
<td align="center" style="border-width:1px;border-style:solid;">11.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>12</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">11.7</td>
<td align="center" style="border-width:1px;border-style:solid;">11.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>13</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">12.1</td>
<td align="center" style="border-width:1px;border-style:solid;">12.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>14</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">12.6</td>
<td align="center" style="border-width:1px;border-style:solid;">12.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>15</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">13.1</td>
<td align="center" style="border-width:1px;border-style:solid;">13.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>16</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">13.6</td>
<td align="center" style="border-width:1px;border-style:solid;">14.4</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>17</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">14.1</td>
<td align="center" style="border-width:1px;border-style:solid;">15.4</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>18</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">14.6</td>
<td align="center" style="border-width:1px;border-style:solid;">16.6</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>19</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">15.2</td>
<td align="center" style="border-width:1px;border-style:solid;">18.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>20</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">15.8</td>
<td align="center" style="border-width:1px;border-style:solid;">19.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>21</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">16.5</td>
<td align="center" style="border-width:1px;border-style:solid;">21.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>22</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">17.3</td>
<td align="center" style="border-width:1px;border-style:solid;">24.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>23</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">18.4</td>
<td align="center" style="border-width:1px;border-style:solid;">27.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>24</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">19.7</td>
<td align="center" style="border-width:1px;border-style:solid;">30.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>25</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">21.2</td>
<td align="center" style="border-width:1px;border-style:solid;">34.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>26</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">23.0</td>
<td align="center" style="border-width:1px;border-style:solid;">38.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>27</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">25.2</td>
<td align="center" style="border-width:1px;border-style:solid;">43.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>28</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">27.6</td>
<td align="center" style="border-width:1px;border-style:solid;">48.4</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>29</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">30.2</td>
<td align="center" style="border-width:1px;border-style:solid;">54.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>30</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">33.1</td>
<td align="center" style="border-width:1px;border-style:solid;">60.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>31</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">36.2</td>
<td align="center" style="border-width:1px;border-style:solid;">67.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>32</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">39.7</td>
<td align="center" style="border-width:1px;border-style:solid;">75.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>33</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">43.4</td>
<td align="center" style="border-width:1px;border-style:solid;">82.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>34</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">47.6</td>
<td align="center" style="border-width:1px;border-style:solid;">91.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>35</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">52.5</td>
<td align="center" style="border-width:1px;border-style:solid;">99.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>36</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">58.0</td>
<td align="center" style="border-width:1px;border-style:solid;">109.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>37</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">64.5</td>
<td align="center" style="border-width:1px;border-style:solid;">120.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>38</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">71.9</td>
<td align="center" style="border-width:1px;border-style:solid;">132.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>39</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">80.3</td>
<td align="center" style="border-width:1px;border-style:solid;">145.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>40</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">90.2</td>
<td align="center" style="border-width:1px;border-style:solid;">159.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>41</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">101.9</td>
<td align="center" style="border-width:1px;border-style:solid;">174.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>42</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">115.5</td>
<td align="center" style="border-width:1px;border-style:solid;">189.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>43</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">131.2</td>
<td align="center" style="border-width:1px;border-style:solid;">205.4</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>44</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">149.1</td>
<td align="center" style="border-width:1px;border-style:solid;">221.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>45</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">169.1</td>
<td align="center" style="border-width:1px;border-style:solid;">236.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>46</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">191.3</td>
<td align="center" style="border-width:1px;border-style:solid;">250.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>47</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">215.7</td>
<td align="center" style="border-width:1px;border-style:solid;">263.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>48</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">242.2</td>
<td align="center" style="border-width:1px;border-style:solid;">277.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>49</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">270.6</td>
<td align="center" style="border-width:1px;border-style:solid;">290.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>50</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">300.8</td>
<td align="center" style="border-width:1px;border-style:solid;">303.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>51</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">332.7</td>
<td align="center" style="border-width:1px;border-style:solid;">316.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>52</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">366.1</td>
<td align="center" style="border-width:1px;border-style:solid;">330.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>53</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">401.1</td>
<td align="center" style="border-width:1px;border-style:solid;">344.4</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>54</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">437.9</td>
<td align="center" style="border-width:1px;border-style:solid;">358.6</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>55</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">476.5</td>
<td align="center" style="border-width:1px;border-style:solid;">373.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>56</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">517.2</td>
<td align="center" style="border-width:1px;border-style:solid;">388.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>57</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">560.1</td>
<td align="center" style="border-width:1px;border-style:solid;">405.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>58</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">605.0</td>
<td align="center" style="border-width:1px;border-style:solid;">423.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>59</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">651.4</td>
<td align="center" style="border-width:1px;border-style:solid;">443.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>60</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">699.1</td>
<td align="center" style="border-width:1px;border-style:solid;">465.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>61</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">747.5</td>
<td align="center" style="border-width:1px;border-style:solid;">491.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>62</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">796.8</td>
<td align="center" style="border-width:1px;border-style:solid;">520.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>63</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">847.3</td>
<td align="center" style="border-width:1px;border-style:solid;">552.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>64</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">900.0</td>
<td align="center" style="border-width:1px;border-style:solid;">588.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>65</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">956.3</td>
<td align="center" style="border-width:1px;border-style:solid;">627.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>66</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1128.0</td>
<td align="center" style="border-width:1px;border-style:solid;">730.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>67</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1214.1</td>
<td align="center" style="border-width:1px;border-style:solid;">778.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>68</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1297.7</td>
<td align="center" style="border-width:1px;border-style:solid;">830.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>69</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1389.1</td>
<td align="center" style="border-width:1px;border-style:solid;">883.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>70</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1499.5</td>
<td align="center" style="border-width:1px;border-style:solid;">934.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>71</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1602.3</td>
<td align="center" style="border-width:1px;border-style:solid;">989.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>72</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1710.7</td>
<td align="center" style="border-width:1px;border-style:solid;">1047.3</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>73</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1806.9</td>
<td align="center" style="border-width:1px;border-style:solid;">1096.6</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>74</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">1904.5</td>
<td align="center" style="border-width:1px;border-style:solid;">1146.4</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>75</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2002.7</td>
<td align="center" style="border-width:1px;border-style:solid;">1196.5</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>76</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2101.0</td>
<td align="center" style="border-width:1px;border-style:solid;">1246.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>77</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2198.9</td>
<td align="center" style="border-width:1px;border-style:solid;">1296.7</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>78</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2279.7</td>
<td align="center" style="border-width:1px;border-style:solid;">1332.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>79</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2358.1</td>
<td align="center" style="border-width:1px;border-style:solid;">1367.0</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>80</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2440.5</td>
<td align="center" style="border-width:1px;border-style:solid;">1405.9</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>81</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2521.1</td>
<td align="center" style="border-width:1px;border-style:solid;">1445.1</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>82</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2600.1</td>
<td align="center" style="border-width:1px;border-style:solid;">1485.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>83</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2665.9</td>
<td align="center" style="border-width:1px;border-style:solid;">1522.2</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>84</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2731.0</td>
<td align="center" style="border-width:1px;border-style:solid;">1560.8</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;"><strong>85</strong></td>
<td align="center" style="border-width:1px;border-style:solid;">2796.5</td>
<td align="center" style="border-width:1px;border-style:solid;">1601.5</td>
</tr>
</tbody>
</table>
<p class="i-d-t">注1：56-85周岁的费率仅适用于续保；<br />注2：根据相关监管规定及合同约定，我们可能对费率进行调整。如我们对费率进行调整，被保险人适用的费率以调整后的费率为准。<br /></p>
</div>
<p>
<!--保额折扣因子表--></p>
<div class="info-box">
    <p class="i-d-h">二、保额折扣因子：</p>
<table border="1" style="width:90%"" align="center">
<tbody>
<tr class="firstRow">
    <td align="center" style="border-width:1px;border-style:solid;"><strong>保额</strong></td>
<td align="center" style="border-width:1px;border-style:solid;"><strong>折扣系数</strong></td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">1万</td>
<td align="center" style="border-width:1px;border-style:solid;">100%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">2万</td>
<td align="center" style="border-width:1px;border-style:solid;">100%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">3万</td>
<td align="center" style="border-width:1px;border-style:solid;">95%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">4万</td>
<td align="center" style="border-width:1px;border-style:solid;">90%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">5万</td>
<td align="center" style="border-width:1px;border-style:solid;">85%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">6万</td>
<td align="center" style="border-width:1px;border-style:solid;">80%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">7万</td>
<td align="center" style="border-width:1px;border-style:solid;">75%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">8万</td>
<td align="center" style="border-width:1px;border-style:solid;">70%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">9万</td>
<td align="center" style="border-width:1px;border-style:solid;">65%</td>
</tr>
<tr>
<td align="center" style="border-width:1px;border-style:solid;">10万及以上</td>
<td align="center" style="border-width:1px;border-style:solid;">60%</td>
</tr>
</tbody>
</table>
</div>
<p><br /></p>
</div>
<p><br /></p>


</div>
</template>
<style lang="less" scoped>
@charset "utf-8";
@import "../../../../styles/notice.less";
#H751_1{
    .i-d-h,.title{
        font-weight:600
    }
    .i-d-t>p{
        text-indent:2em
    }
    .baseline{
        vertical-align: baseline
    }
    padding:0.5rem;
    h2{font-size:1.6rem;line-height:2.2rem;}
    p{font-size:1.5rem;line-height:2.2rem;margin-top:0.3rem;}
}
</style>
