<template>
<div class="healthInform">
<header ref="Title">健康告知</header>
<div class="healthTitle">投保人确认被保险人是否存在以下情况：</div>
<section>
<ol class="list">
<li>
对于以下任何病症，被保险人目前或过去10年是否接受过治疗，随诊，监测、诊断分析、医生提示需进一步检查、体检提示异常、或有任何相关症状：<br>
1、癌症或任何类型的恶性肿瘤，包括霍奇金病；<br>
2、脑部、颅骨或脊髓内出现的任何类型的肿瘤或囊肿或颅内动脉瘤；<br>
3、白血病或需要任何治疗超过一个月时间的血液疾病（如贫血、淋巴瘤、骨髓瘤、凝血障碍、血友病或血管出血性疾病）；<br>
4、癌前肿瘤或原位癌，包括但不限于乳腺/妇科、膀胱或前列腺肿瘤；<br>
5、任何心脏疾病（如心肌梗死、心绞痛、动脉瘤、心肌病、心脏瓣膜疾病、心脏杂音或风湿热病）；<br>
6、中风或脑溢血；<br>
7、任何类型的糖尿病
</li>
</ol>
<div class="button">
<div @click='change' eq="0"  ref="is" class="point" >是</div>
<div @click='change' eq="1"  ref="not" class="point" >否</div>
</div>
</section>
<section>
<h2 class="wrap ps">
投保人应在对所有被保险人健康/职业状况充分了解的基础上履行如实告知义务。投保人承诺完全知晓所有被保险人健康/职业状况。若被保险人健康/职业状况与上述告知内容不符：<br>（1）本公司有权不同意承保。（2）若发生保险事故，本公司不承担赔偿或给付保险金的责任，并有权不退还保险费。
</h2>
</section>
<div class="footer">
<div class="btn" ref="Button" @click="next">下一步</div>
</div>
</div>
</template>
<script>
let change = "#2688c4"
import {Msg, Loading, } from 'components'
import {mapState,productDetail,mapGetters,mapMutations,mapActions} from 'vuex'
import {policyHealthRecord} from '../../apis/health.api'
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
import highrisk from '../../../../components/high-risk/index'
import filter from "../../../../utils/filter"
export default{
    data () {
        return {
            check: [false,false],
            toastFlag: false,
            toastMes: '',
            loadingFlag: false,
            alertMes: '',
            alertSubMes: '',
            alertFlag: false,
            fontColor:change
        }
    },
     beforeMount(){
        if(this.$store.state.health.productDetail){
            sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
        }else{
            this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
        }
    },
    components:{
        highrisk
    },
    mounted(){
        //健康告知页
        //SKAPP.onEvent("健康告知页", "进入健康告知页",{
            //icpProductCode:sessionStorage.icpProductCode,
            //insureNotice:this.$store.state.health.insureNotice
        //});
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
            "进入健康告知页":'健康告知页'
        });
        document.body.scrollTop = 0;
        switch (sessionStorage.col){
            case "B2":
                change = "#4285F6"
                break
            case "Y1":
                change = "#D8A161"
                break
            case "O1":
                change = "#FF6000"
                break
            case "R1":
                change = "#F76B6C"
                break
            case "R2":
                change = "#F11B33"
                break
            default:
                change = "#2688c4"
                break;
        }
        this.$refs.Button.style.backgroundColor = change;
        this.$refs.Title.style.color = change;
        if (this.$store.state.health.select[0]){
            this.$refs.not.style.backgroundColor = change;
            this.$refs.not.style.borderColor = change;
            this.$refs.not.style.color = "#fff";
        }else if(this.$store.state.health.select[0]===false){
            this.$refs.is.style.backgroundColor = change;
            this.$refs.is.style.borderColor = change;
            this.$refs.is.style.color = "#fff";
        }
    },
    methods: {
        scroll(e){
            if(e){
                document.getElementsByTagName("body")[0].style.overflow="hidden"
            }else{
                document.getElementsByTagName("body")[0].style.overflow="scroll"
            }
        },
        change: function (e) {
            this.check = [false, false];
            this.check[event.target.getAttribute('eq')] = true;
            this.$refs.is.style.backgroundColor = ""
            this.$refs.not.style.backgroundColor = ""
            this.$refs.is.style.color = "#666"
            this.$refs.not.style.color = "#666"
            this.$refs.is.style.borderColor = "#666"
            this.$refs.not.style.borderColor = "#666"
            e.target.style.backgroundColor = change
            e.target.style.borderColor = change
            e.target.style.color = "#fff"
            this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
        },
        next(){
            //提交健康告知页
            //SKAPP.onEvent("健康告知页", "提交健康告知",{
                //icpProductCode:sessionStorage.icpProductCode,
                //healthResult:"N"
            //});

            if (this.$store.state.health.select[0]) {

                //提交健康告知页
                //SKAPP.onEvent("健康告知页", "提交健康告知",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //healthResult:"Y"
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
                    "提交健康告知":'否'
                });
                var saleRecordId = this.$store.state.health.saleRecordId;
                var submitData = {
                    saleRecordId: saleRecordId,
                    healthRecord: '{"H75300001":"Y"}',
                    healthResult: 'Y'
                };
                policyHealthRecord(submitData).then((data) => {
                    if (data.data.resultCode === '00000'){
                    //成功跳转
                    this.$router.push({
                        name: 'customerInfo'
                    });
                }else{
                    Msg.alert(filter.resultCode(data.body))
                };
            })
        } else {
            SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
                "提交健康告知":'是'
            });
            Msg.toast('您的健康告知未通过')
        };
    }
},
computed: {
...mapState({
        sex:state=>state.health.sex
})
}
}
</script>
<style lang="less" scoped>
.healthInform{
.list{
        margin:0 1rem 0;
        font-size:1.3rem;
        color:#666
    }
.list>li{
        margin-bottom:1rem
    }
    header{
        font-size:1.7rem;
        text-align:center;
        margin:1.5rem 0
    }
.healthTitle{
        font-size:1.3rem;
        color:#000;
        margin:0 1rem
    }
.danDetail{
        font-size:1.2rem;
        color:#32BCFD;
        margin:1.5rem 1rem
    }
.button{
        width: 22rem;
        height: 2.2rem;
        margin: 1.5rem auto;
    >div{
            width: 10rem;
            margin: 0 0.4rem;
            display: inline-block;
            text-align: center;
            color: #666;
            border: 1px solid #666;
            border-radius: 2rem;
            line-height: 2.2rem;
            font-size: 1.3rem;
        }
    }
    h2{
        border-top: 1px solid #ccc;
        font-size: 1.3rem;
        padding: 1.5rem 1rem;
        margin-bottom:6.5rem
    }
.footer{
        z-index: 3;
        width: 100%;
        position: fixed;
        bottom: 0;
        left:0;
        padding-left: 1rem;
        padding-right: 1rem;
        padding-top: 1rem;
        padding-bottom: 1rem;
        background-color: rgba(0, 0, 0, 0.3);
    }
.btn{
        width: 100%;
        height: 4.5rem;
        border: none;
        color: #ffffff;
        line-height: 4.5rem;
        font-size: 2rem;
        border-radius: 8px;
        text-align:center

    }
}
</style>