<template>
    <!-- 隐藏页 投保须知 -->
    <div class="noticeInsurance">
          <div>
            <h4 class="al_center" style="font-size:2rem">平安个人综合意外伤害保险条款</h4>
            <h5 class="al_center">保监会报备文号：平保健发〔2016〕23号</h5>
            <div>在本条款中，“您”指投保人，“我们”、“本公司”均指平安健康保险股份有限公司。</div>
        </div>
        <div>
            <h4>一. 您与我们的合同 </h4>
            <p>
                </p><div>1.1 合同构成</div>
                <div class="pdl-16">
                    <div class="indent_2">本保险条款、电子保险单或其他保险凭证、电子投保书、与保险合同有关的投保文件、合法有效的声明、批注、批单、附加险合同、其他书面或电子协议都是您和我们之间订立的保险合同的构成部分。</div>
                    <div class="indent_2">“平安个人综合意外伤害保险合同”以下简称为“本主险合同”。</div>
                </div>
            <p></p>
            <p>
                </p><div>1.2 合同成立与生效 </div>
                <div class="pdl-16">
                    <div class="indent_2">您提出保险申请、我们同意承保，本主险合同成立。</div>
                    <div class="indent_2">本主险合同自我们同意承保、收取首期保险费并签发电子保险单开始生效，具体生效日以电子保险单所载的日期为准。</div>
                </div>
            <p></p>
            <p>
                </p><div>1.3 投保年龄</div>
                <div class="pdl-16">
                    <div class="indent_2">指投保时被保险人的年龄，投保年龄以<b>周岁</b>（见7.1）计算，本主险合同接受的投保年龄为0周岁至65周岁，投保时被保险人为0周岁的，应当为出生满28日且已健康出院的婴儿。</div>
                </div>
            <p></p>
            <p>
                </p><div>1.4 保险期间</div>
                <div class="pdl-16">
                    <div class="indent_2">本主险合同的保险期间最长为1年。具体起讫日期以电子保险单所载的日期为准。</div>
                </div>
            <p></p>
        </div>
        <div>
            <h4>二. 我们提供的保障 </h4>
            <p>
                </p><div>2.1 保险金额</div>
                <div class="pdl-16">
                    <div class="indent_2">本主险合同的各项保险责任的保险金额由您在投保时与我们约定并在电子保险单上载明。</div>
                </div>
            <p></p>
            <p>
                </p><div>2.2 未成年人身故保险金限制</div>
                <div class="pdl-16">
                    <div class="indent_2">为未成年子女投保的人身保险，因被保险人身故给付的保险金总和不得超过国务院保险监督管理机构规定的限额，身故给付的保险金额总和约定也不得超过前述限额。</div>
                </div>
            <p></p>
            <p>
                </p><div>2.3 保险责任</div>
                <div class="pdl-16">
                    <div class="indent_2">本主险合同的保险责任分为基本责任和可选责任。</div>
                    <div class="indent_2">您可以单独投保基本责任，也可以在投保基本责任的基础上增加一项或多项可选责任，但不能单独投保可选责任。</div>
                    <div class="indent_2">
                        在本主险合同有效期内，我们承担如下保险责任：
                        <p>
                            </p><div class="indent_0"><b>基本责任</b></div>
                            <div class="indent_0">（1）意外伤残保险金</div>
                            <div>被保险人因遭受<b>意外伤害</b>（见7.3），并自该意外伤害发生之日起180日内造成<b>《人身保险伤残评定标准及代码》</b>（见7.4，以下简称“伤残评定标准”） 所列伤残条目，我们按意外身故保险金额乘以该处伤残的伤残等级所对应的保险金给付比例（见下表）给付意外伤残保险金。如自意外伤害发生之日起180日内治疗仍未结束的，则按该意外伤害发生之日起第180日的身体情况进行伤残评定。</div>
                            <div>当同一保险事故造成多处伤残时，首先对各处伤残程度分别进行评定，如果几处伤残等级不同，以最重的伤残等级作为最终的评定结论；如果两处或两处以上伤残等级相同，伤残等级在原评定基础上最多晋升一级，最高晋升至第一级。对于同一部位和性质的伤残，不适用以上晋级规则。</div>
                            <table cellspacing="0" class="static-tb">
                                <tbody><tr>
                                    <th>伤残等级</th>
                                    <th>1级</th>
                                    <th>2级</th>
                                    <th>3级</th>
                                    <th>4级</th>
                                    <th>5级</th>
                                </tr>
                                <tr>
                                    <th><span class="bgc_ddd">给付比例</span></th>
                                    <th><span class="bgc_ddd">100%</span></th>
                                    <th><span class="bgc_ddd">90%</span></th>
                                    <th><span class="bgc_ddd">80%</span></th>
                                    <th><span class="bgc_ddd">70%</span></th>
                                    <th><span class="bgc_ddd">60%</span></th>
                                </tr>
                            </tbody>
                            </table>
                            <br>
                            <table cellspacing="0" class="static-tb">
                                <tbody><tr>
                                    <th>伤残等级</th>
                                    <th>6级</th>
                                    <th>7级</th>
                                    <th>8级</th>
                                    <th>9级</th>
                                    <th>10级</th>
                                </tr>
                                <tr>
                                    <th><span class="bgc_ddd">给付比例</span></th>
                                    <th><span class="bgc_ddd">50%</span></th>
                                    <th><span class="bgc_ddd">40%</span></th>
                                    <th><span class="bgc_ddd">30%</span></th>
                                    <th><span class="bgc_ddd">20%</span></th>
                                    <th><span class="bgc_ddd">10%</span></th>
                                </tr>
                            </tbody></table>
                            <div><span class="bgc_ddd">意外伤残保险金以意外身故保险金额为限，累计给付的意外伤残保险金的总额达到意外身故保险金额时，本主险合同终止。</span></div>
                            <div class="indent_0">（2）意外身故保险金</div>
                            <div>被保险人因遭受意外伤害，并自该意外伤害发生之日起180日内身故的，我们按意外身故保险金额给付意外身故保险金，本主险合同终止</div>
                            <div><span class="bgc_ddd">若被保险人身故前本主险合同已有意外伤残保险金给付，则给付意外身故保险金时应扣除已给付的意外伤残保险金。</span></div>
                        <p></p>
                        <p>
                            </p><div class="indent_0"><b>可选责任</b></div>
                            <div class="indent_0">（1）意外医疗保险金 </div>
                            <div>被保险人因遭受意外伤害在<b>医院</b>（见7.5）进行治疗，对于每次事故发生之日起180日内因该意外伤害而实际支出的、合理且必要的住院或门诊急诊<b>医疗费用</b>（见7.6），<span class="bgc_ddd">我们在扣除被保险人按照社会医疗保险或公费医疗的有关规定取得的医疗费用补偿及免赔额100元后，按如下给付比例给付意外医疗保险金。</span></div>
                            <table cellspacing="0" class="static-tb">
                                <tbody><tr>
                                    <th>给付条件</th>
                                    <th>医疗费用（包含社保范围内医疗费用和社保范围外医疗费用）给付比例</th>
                                </tr>
                                <tr>
                                    <td>被保险人已从社会医疗保险或公费医疗获得费用补偿
                                    </td>
                                    <td class="al_center">100%</td>
                                </tr>
                                <tr>
                                    <td><span class="bgc_ddd">被保险人未从社会医疗保险或公费医疗获得费用补偿</span></td>
                                    <td class="al_center"><span class="bgc_ddd">70%</span></td>
                                </tr>
                            </tbody></table>
                            <div>意外医疗保险金累计给付达到意外医疗保险金额时，本项保险责任终止。</div>
                            <div><span class="bgc_ddd">我们在本主险合同保险责任范围内给付意外医疗保险金，但若被保险人已从其它途径（包括社会医疗保险、公费医疗、工作单位、本公司在内的任何商业保险机构等）取得补偿，我们给付的金额不超过该被保险人发生的合理且必要的住院或门诊急诊医疗费用扣除其所获补偿后的余额。</span></div>
                            <div class="indent_0">（2）意外骨折保险金 </div>
                            <div>被保险人因遭受意外伤害在医院进行治疗，经医院确诊<b>骨折</b>(见7.8)的，我们按照意外骨折保险金额给付意外骨折保险金，本项保险责任终止。</div>
                            <div class="indent_0">（3）猝死保险金 </div>
                            <div>被保险人因突发急性病<b>猝死</b>（见7.9），我们按猝死保险金额给付猝死保险金，本主险合同终止。</div>
                        <p></p>
                    </div>
                </div>
            <p></p>
            <p>
                </p><div>2.4 责任免除</div>
                <div class="pdl-16">
                    <div class="indent_0"><span class="bgc_ddd">（一）因下列情形之一导致被保险人伤残、身故、猝死或骨折的，或者造成被保险人医疗费用支出的，我们不承担给付保险金责任：</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（1）投保人对被保险人的故意杀害、故意伤害；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（2）被保险人故意自伤、故意犯罪、抗拒依法采取的刑事强制措施或自杀，</span>但被保险人自杀时为无民事行为能力人的除外；</div>
                    <div class="indent_2"><span class="bgc_ddd">（3）被保险人殴斗、醉酒，主动吸食或注射<b>毒品</b>（见7.10）；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（4）被保险人<b>酒后驾驶</b>（见7.11）、<b>无合法有效驾驶证驾驶</b>（见7.12），或驾驶<b>无有效行驶证</b>（见7.13）的<b>机动车</b>（见7.14）；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（5）恐怖袭击、战争、军事冲突、暴乱或武装叛乱；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（6）核爆炸、核辐射或核污染；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（7）被保险人因妊娠（含宫外孕）、流产、分娩（含剖宫产）导致的伤害；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（8）被保险人因<b>医疗事故</b>（见7.15）、药物过敏或精神和行为障碍（依照世界卫生组织《疾病和有关健康问题的国际统计分类》（ICD-10）确定）导致的伤害；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（9）被保险人未遵医嘱，私自使用药物，但按使用说明的规定使用<b>非处方药</b>（见7.16）不在此限；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（10）细菌或病毒感染</span>（因意外伤害导致的伤口发生感染者除外）；</div>
                    <div class="indent_2"><span class="bgc_ddd">（11）被保险人从事<b>潜水</b>（见7.17）、跳伞、<b>攀岩</b>（见7.18）、蹦极、驾驶滑翔机或滑翔伞、<b>探险</b>（见7.19）、摔跤、<b>武术比赛</b>（见7.20）、<b>特技表演</b>（见7.21）、赛马、赛车等高风险运动。</span></div>
                    <div class="indent_2"><span class="bgc_ddd">发生上述第（1）项情形导致被保险人身故的，本主险合同终止，我们向受益人退还本主险合同的未满期<b>净保险费</b>（见7.22）。若投保人与受益人为同一人且没有其他受益人的情况下，则向被保险人的继承人退还本主险合同的未满期净保险费。</span></div>
                    <div class="indent_2"><span class="bgc_ddd">发生上述其他情形导致被保险人身故的，本主险合同终止，我们向您退还本主险合同的未满期净保险费。</span></div>
                    <div class="indent_0"><span class="bgc_ddd">（二）除上述第（一）项列明的情形外，因下列情形造成医疗费用支出的，我们不承担给付意外医疗保险金的责任：</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（1）被保险人因疾病而非意外伤害进行治疗；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（2）耐用医疗设备（指各种康复设备、矫形支具以及其他耐用医疗设备）的购买或租赁；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（3）椎间盘突出症（包括椎间盘膨出、椎间盘突出、椎间盘脱出、游离型椎间盘等类型）。</span></div>
                    <div class="indent_0"><span class="bgc_ddd">（三）除上述第（一）项列明的情形外，对于如下情形的骨折，我们不承担给付意外骨折保险金的责任：</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（1）被保险人<b>病理性骨折</b>(见7.23)（包含因骨质疏松导致的骨折）；</span></div>
                    <div class="indent_2"><span class="bgc_ddd">（2）被保险人于本主险合同生效日前五年内已存在或发生过骨折，在本主险合同有效期内同一块骨再次发生的骨折。</span></div>
                </div>
            <p></p>
        </div>
        <div>
            <h4>三. 如何申请领取保险金 </h4>
            <p>
                </p><div>3.1 受益人</div>
                <div class="pdl-16">
                    <div class="indent_2">您或者被保险人可指定一人或多人为本主险合同身故保险金（包括意外身故保险金和猝死保险金）的受益人。</div>
                    <div class="indent_2">身故保险金受益人为多人时，可以确定受益顺序和受益份额；如果没有确定份额，各受益人按照相等份额享有受益权。</div>
                    <div class="indent_2">被保险人为无民事行为能力人或限制民事行为能力人的，可以由其监护人指定受益人。</div>
                    <div class="indent_2">您或者被保险人可以变更身故保险金受益人并书面通知我们。我们收到变更受益人的书面通知后，在电子保险单或其他保险凭证上批注或附贴批单。</div>
                    <div class="indent_2">您在指定和变更身故保险金受益人时，必须经过被保险人同意。</div>
                    <div class="indent_2">被保险人身故后，有下列情形之一的，保险金作为被保险人的遗产，由我们依照《中华人民共和国继承法》的规定履行给付保险金的义务：</div>
                    <div>（1）没有指定身故保险金受益人，或者身故保险金受益人指定不明无法确定的；</div>
                    <div>（2）身故保险金受益人先于被保险人身故，没有其他身故保险金受益人的；</div>
                    <div>（3）身故保险金受益人依法丧失受益权或者放弃受益权，没有其他身故保险金受益人的。</div>
                    <div class="indent_2">身故保险金受益人与被保险人在同一事件中身故，且不能确定身故先后顺序的，推定受益人身故在先。</div>
                    <div class="indent_2">身故保险金受益人故意造成被保险人身故、伤残、疾病的，或者故意杀害被保险人未遂的，该受益人丧失受益权。</div>
                    <div class="indent_2">除另有约定外，意外伤残保险金、意外医疗保险金和意外骨折保险金的受益人皆为被保险人本人。</div>
                </div>
            <p></p>
            <p>
                </p><div>3.2 保险事故通知</div>
                <div class="pdl-16">
                    <div class="indent_2">请您、被保险人或受益人在知道保险事故发生后10日内通知我们。</div>
                    <div class="indent_2"><span class="bgc_ddd">如果您、被保险人或受益人故意或者因重大过失未及时通知，致使保险事故的性质、原因、损失程度等难以确定的，我们对无法确定的部分，不承担给付保险金的责任，</span>但我们通过其他途径已经及时知道或者应当及时知道保险事故发生或者虽未及时通知但不影响我们确定保险事故的性质、原因、损失程度的除外。</div>
                    <div class="indent_2"><span class="bgc_ddd">被保险人应在本主险合同中约定的医院就诊，若因急诊未在约定的医院就诊的，应在3日内通知我们，并在病情好转后及时转入约定的医院。</span></div>
                </div>
            <p></p>
            <p>
                </p><div>3.3 保险金申请</div>
                <div class="pdl-16">
                    <div class="indent_2">在申请保险金时，请按照下列方式办理：</div>
                    <div class="indent_0"><b>意外伤残保险金申请</b></div>
                    <div class="indent_2">由意外伤残保险金受益人填写保险金给付申请书，并提供下列证明和资料：</div>
                    <div>（1）保险合同；</div>
                    <div>（2）受益人的有效身份证件；</div>
                    <div>（3）由双方认可的医疗机构或有资质的鉴定机构根据《人身保险伤残评定标准及代码》出具的被保险人伤残程度的资料或身体伤残程度评定书；</div>
                    <div>（4）所能提供的与确认保险事故的性质、原因及伤害程度等有关的其他证明和资料。</div>
                    <div class="indent_2">以上证明和资料不完整的，我们将及时一次性通知受益人补充提供有关证明和资料。</div>
                    <div><b>意外身故保险金申请</b></div>
                    <div class="indent_2">由意外身故保险金受益人填写保险金给付申请书，并提供下列证明和资料：</div>
                    <div>（1）保险合同；</div>
                    <div>（2）受益人的有效身份证件；</div>
                    <div>（3）国家卫生行政部门认定的医疗机构、公安部门或其他相关机构出具的被保险人死亡证明；</div>
                    <div>（4）所能提供的与确认保险事故的性质、原因等有关的其他证明和资料。</div>
                    <div class="indent_2">保险金作为被保险人遗产时，必须提供可证明合法继承权的相关权利文件。</div>
                    <div class="indent_2">以上证明和资料不完整的，我们将及时一次性通知受益人补充提供有关证明和资料。</div>
                    <div><b>猝死保险金申请</b></div>
                    <div class="indent_2">由猝死保险金受益人填写保险金给付申请书，并提供下列证明和资料：</div>
                    <div>（1）保险合同；</div>
                    <div>（2）受益人的有效身份证件；</div>
                    <div>（3）国家卫生行政部门认定的医疗机构或其他相关机构出具的被保险人疾病诊断证明和死亡证明；</div>
                    <div>（4）所能提供的与确认保险事故的性质、原因等有关的其他证明和资料。</div>
                    <div class="indent_2">保险金作为被保险人遗产时，必须提供可证明合法继承权的相关权利文件。</div>
                    <div class="indent_2">以上证明和资料不完整的，我们将及时一次性通知受益人补充提供有关证明和资料。</div>
                    <div><b>意外医疗保险金或意外骨折保险金申请</b></div>
                    <div class="indent_2">由意外医疗保险金/意外骨折保险金受益人填写保险金给付申请书，并提供下列证明和资料：</div>
                    <div>（1）保险合同；</div>
                    <div>（2）受益人的有效身份证件；</div>
                    <div>（3）医院出具的医疗诊断书、医疗病历或出院小结、检查检验报告及药品明细处方；</div>
                    <div>（4）医院出具的医疗费用原始凭证和医疗费用结算清单（被保险人享有社会医疗保险或公费医疗保障的，需包含按社会医疗保险或公费医疗有关规定取得医疗费用补偿的证明）；</div>
                    <div>（5）所能提供的与确认保险事故的性质、原因等有关的其他证明和资料。</div>
                    <div class="indent_2">以上证明和资料不完整的，我们将及时一次性通知受益人补充提供有关证明和资料。</div>
                </div>
            <p></p>
            <p>
                </p><div>3.4 保险金的给付</div>
                <div class="pdl-16">
                    <div class="indent_2">我们在收到保险金给付申请书及上述有关证明和资料后，将在5日内作出核定；情形复杂的，在30日内作出核定。</div>
                    <div class="indent_2">对属于保险责任的，我们在与受益人达成给付保险金的协议后10日内，履行给付保险金义务；若我们在收到保险金给付申请书及上述有关证明和资料后第30日仍未作出核定，除支付保险金外，我们将从第31日起按超过天数赔偿受益人因此受到的利息损失。如我们要求投保人、被保险人或者受益人补充提供有关证明和资料的，上述30日期间会扣除投保人、被保险人或者受益人补充提供有关证明和资料期间，扣除期间自我们作出的通知到达投保人、被保险人或者受益人之日起，至投保人、被保险人或者受益人按照通知要求补充提供的有关证明和资料到达保险人之日止。利息按照我们公示的利率按单利计算，且保证该利率不低于中国人民银行公布的同期金融机构人民币活期存款基准利率。</div>
                    <div class="indent_2">对不属于保险责任的，我们自作出核定之日起3日内向受益人发出拒绝给付保险金通知书并说明理由。</div>
                    <div class="indent_2">我们在收到受益人的保险金给付申请书及有关证明和资料之日起60日内，对给付保险金的数额不能确定的，根据已有证明和资料可以确定的数额先予支付；我们最终确定给付保险金的数额后，将支付相应的差额。</div>
                </div>
            <p></p>
        </div>
        <div>
            <h4>四. 如何支付保险费 </h4>
            <p>
                </p><div>4.1 保险费的支付</div>
                <div class="pdl-16">
                    <div class="indent_2">本主险合同的保险费按照您和我们约定的各项保险责任的保险金额和约定的费率标准确定。</div>
                </div>
            <p></p>
        </div>
        <div>
            <h4>五. 如何解除保险合同</h4>
            <p>
                </p><div>5.1 合同解除</div>
                <div class="pdl-16">
                    <div class="indent_2">您可以申请解除本主险合同，自您提交解除合同申请的次日零时起，本主险合同终止。我们会在30日内向您退还本主险合同的未满期净保险费。</div>
                    <div class="indent_2"><span class="bgc_ddd">您申请解除合同会遭受一定损失。</span></div>
                </div>
            <p></p>
        </div>
        <div>
            <h4>六. 其他需要关注的事项 </h4>
            <p>
                </p><div>6.1 明确说明与如实告知</div>
                <div class="pdl-16">
                    <div class="indent_2">订立本主险合同时，我们会向您说明本主险合同的内容，对本主险合同中免除我们责任的条款，我们在订立合同时会在电子投保书、电子保险单或其他保险凭证上作出足以引起您注意的提示，并对该条款的内容以书面或口头形式向您作出明确说明，未作提示或者明确说明的，该条款不产生效力。</div>
                    <div class="indent_2">我们会就您和被保险人的有关情况提出询问，您应当如实告知。</div>
                    <div class="indent_2">如果您故意或者因重大过失未履行前款规定的如实告知义务，足以影响我们决定是否同意承保或者提高保险费率的，我们有权解除本主险合同。</div>
                    <div class="indent_2"><span class="bgc_ddd">如果您故意不履行如实告知义务，对于本主险合同解除前发生的保险事故，我们不承担给付保险金的责任，并不退还保险费。</span></div>
                    <div class="indent_2"><span class="bgc_ddd">如果您因重大过失未履行如实告知义务，对保险事故的发生有严重影响的，对于本主险合同解除前发生的保险事故，我们不承担给付保险金的责任，但会退还保险费。</span></div>
                    <div class="indent_2">我们在合同订立时已经知道您未如实告知的情况的，我们不得解除合同；发生保险事故的，我们承担给付保险金的责任。</div>
                </div>
            <p></p>
            <p>
                </p><div>6.2 年龄错误</div>
                <div class="pdl-16">
                    <div class="indent_2">您在申请投保时，应将与有效身份证件相符的被保险人的出生日期在电子投保单上填明，如果发生错误按照下列方式办理：</div>
                    <div class="indent_2">您申报的被保险人年龄不真实，并且其真实年龄不符合本主险合同约定投保年龄限制的，我们有权解除合同，并向您退还本主险合同的未满期净保险费。</div>
                </div>
            <p></p>
            <p>
                </p><div>6.3 合同内容变更</div>
                <div class="pdl-16">
                    <div class="indent_2">本主险合同有效期内，经您与我们协商一致，可以变更本主险合同的有关内容，变更本主险合同的，应当由我们在电子保险单或者其他保险凭证上批注或者附贴批单，或者由您与我们订立变更的书面协议。</div>
                    <div class="indent_2">您通过我们同意或者认可的网站等互联网渠道提出对本主险合同进行变更，视为您的书面申请，您向我们在线提交的电子信息与您向我们提交的书面文件具有相同的法律效力。</div>
                </div>
            <p></p>
            <p>
                </p><div>6.4 职业或工种的确定与变更</div>
                <div class="pdl-16">
                    <div class="indent_2">我们将按照事先公布的职业分类表确定被保险人的职业分类，您可以通过我们的网站、服务热线或服务场所工作人员查询到此表。</div>
                    <div class="indent_2">被保险人变更其职业或工种时，您或被保险人应于10日内以书面形式通知我们。</div>
                    <div class="indent_2"><span class="bgc_ddd">被保险人所变更的职业或者工种依照我们职业分类在本主险合同拒保范围内的，自我们接到通知之日起，本主险合同终止，我们将无息退还未满期净保险费。</span></div>
                    <div class="indent_2"><span class="bgc_ddd">被保险人的职业或工种变更之后而未依前项约定通知我们而发生保险事故的，如被保险人职业或工种变更之后在本主险合同拒保范围内，我们不承担给付保险金责任。</span></div>
                </div>
            <p></p>
            <p>
                </p><div>6.5 联系方式变更</div>
                <div class="pdl-16">
                    <div class="indent_2">为了保障您的合法权益，您的电话或电子邮箱等联系方式变更时，请及时以书面形式或双方认可的其他形式通知我们。若您未以书面形式或双方认可的其他形式通知我们，我们按本主险合同载明的最后电话或电子邮箱发送的有关通知，均视为已送达给您。</div>
                </div>
            <p></p>
            <p>
                </p><div>6.6 争议处理</div>
                <div class="pdl-16">
                    <div class="indent_2">本主险合同履行过程中，双方发生争议不能协商解决的，可以达成仲裁协议通过仲裁解决，也可依法直接向有管辖权的法院提起诉讼。</div>
                </div>
            <p></p>
        </div>
        <div>
            <h4>七. 释义 </h4>
            <p>
                </p><div>7.1 周岁</div>
                <div class="pdl-16">
                    <div class="indent_2">指按<b>有效身份证件</b>（见7.2）中记载的出生日期计算的年龄，自出生之日起为零周岁，每经过一年增加一岁，不足一年的不计。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.2 有效身份证件</div>
                <div class="pdl-16">
                    <div class="indent_2">指由政府主管部门规定的证明其身份的证件，如：居民身份证、按规定可使用的有效护照、军官证、警官证、士兵证等证件。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.3 意外伤害</div>
                <div class="pdl-16">
                    <div class="indent_2">指遭受外来的、突发的、非本意的、非疾病的使身体受到伤害的客观事件。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.5 医院</div>
                <div class="pdl-16">
                    <div class="indent_2">指中华人民共和国境内（港、澳、台地区除外）合法经营的二级以上（含二级）公立医院的普通部，<span class="bgc_ddd">不包含其中的特需医疗、外宾医疗、干部病房。</span></div>
                </div>
            <p></p>
            <p>
                </p><div>7.6 医疗费用</div>
                <div class="pdl-16">
                    <div class="indent_2">指被保险人在医院门急诊或者住院期间发生的医疗费用，包括：</div>
                    <div>（1）床位费</div>
                    <div class="indent_2">指被保险人住院期间使用的医院床位的费用。</div>
                    <div>（2）药品费</div>
                    <div class="indent_2">指门急诊或住院期间实际发生的合理且必要的由医生开具的具有国家药品监督管理部门核发的药品批准文号或者进口药品注册证书、医药产品注册证书的国产或进口药品的费用。</div>
                    <div class="indent_2"><span class="bgc_ddd">药品费中不包含中草药费用。</span></div>
                    <div>（3）医生诊疗费</div>
                    <div class="indent_2">指被保险人门、急诊期间发生的主诊医生或会诊医生的劳务费用，包括挂号费。</div>
                    <div>（4）治疗费</div>
                    <div class="indent_2">指门急诊或住院期间以治疗疾病为目的，提供必要的医学手段而发生的合理的治疗者的技术劳务费和医疗器械使用费，以及消耗品的费用，包括注射费、机疗费、理疗费、输血费、输氧费、体外反搏费等。</div>
                    <div class="indent_2"><span class="bgc_ddd">本项责任不包含如下费用：<b>物理治疗、中医理疗及其他特殊疗法</b>（见7.7）费用，门诊肾透析、门诊恶性肿瘤的电疗、化疗或放疗发生的费用。</span></div>
                    <div>（5）护理费</div>
                    <div class="indent_2">指住院期间根据医嘱所示的护理等级确定的护理费用。</div>
                    <div>（6）检查检验费</div>
                    <div class="indent_2">指门急诊或住院期间实际发生的、以诊断疾病为目的，采取必要的医学手段进行检查及检验而发生的合理的医疗费用，包括X光费、心电图费、B超费、脑电图费、内窥镜费、肺功能仪费、分子生化检验费和血、尿、便常规检验费等。</div>
                    <div>（7）手术费</div>
                    <div class="indent_2">指当地卫生行政部门规定的手术项目的费用。包括手术费、麻醉费、手术监测费、手术材料费、术中用药费、手术设备费；<span class="bgc_ddd">若因器官移植而发生的手术费用，不包括器官本身的费用和获取器官过程中的费用。</span></div>
                    <div>（8）救护车使用费</div>
                    <div class="indent_2">指为抢救生命由急救中心派出的救护车费用及医院转诊过程中的医院用车费。</div>
                    <div class="indent_2"><span class="bgc_ddd">救护车的使用仅限于同一城市中的医疗运送。</span></div>
                </div>
            <p></p>
            <p>
                </p><div>7.7 物理治疗、中医理疗及其他特殊疗法</div>
                <div class="pdl-16">
                    <div class="indent_2">物理治疗是指应用人工物理因子（如光、电、磁、声等）来治疗疾病，具体疗法包括电疗、光疗、磁疗、热疗等；</div>
                    <div class="indent_2">中医理疗是指以治疗疾病为目的，被保险人接受由具有相应资格的医生实施的针灸治疗、推拿治疗、拔罐治疗或刮痧治疗；</div>
                    <div class="indent_2">其他特殊疗法包括顺势治疗、职业疗法及语音治疗。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.8 骨折</div>
                <div class="pdl-16">
                    <div class="indent_2">指以意外伤害事故为直接原因导致骨的完整性及连续性的破坏且相应骨的完全断裂，包括发生于椎体的压缩性骨折，<span class="bgc_ddd">不包括骨的不完全断裂（如骨裂）。</span></div>
                    <div class="indent_2"></div>
                </div>
            <p></p>
            <p>
                </p><div>7.9 猝死</div>
                <div class="pdl-16">
                    <div class="indent_2">指突然发生急性病症，且在病症发生后6小时内死亡。该急性病症是被保险人在本主险合同生效之前未曾接受诊疗且在合同的有效期间内突然发生的，<span class="bgc_ddd">但被保险人由于下列疾病或因下列任一情形所导致的猝死，不在合同的保障范围之内：</span></div>
                    <div><span class="bgc_ddd">（1）被保险人患精神病、先天性疾病（包括先天性畸形）、遗传性疾病、性传播疾病；</span></div>
                    <div><span class="bgc_ddd">（2）任何获取移植器官或者捐献器官的行为；</span></div>
                    <div><span class="bgc_ddd">（3）化学污染；</span></div>
                    <div><span class="bgc_ddd">（4）在主合同生效前已存在的任何疾病或症状；</span></div>
                    <div><span class="bgc_ddd">（5）慢性疾病的急性发作。</span></div>
                </div>
            <p></p>
            <p>
                </p><div>7.10 毒品</div>
                <div class="pdl-16">
                    <div class="indent_2">指中华人民共和国刑法规定的鸦片、海洛因、甲基苯丙胺（冰毒）、吗啡、大麻、可卡因以及国家规定管制的其他能够使人形成瘾癖的麻醉药品和精神药品，但不包括由医生开具并遵医嘱使用的用于治疗疾病但含有毒品成分的处方药品。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.11 酒后驾驶</div>
                <div class="pdl-16">
                    <div class="indent_2">指经检测或鉴定，发生事故时车辆驾驶人员每百毫升血液中的酒精含量达到或超过一定的标准，公安机关交通管理部门依据《道路交通安全法》的规定认定为饮酒后驾驶或醉酒后驾驶。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.12 无合法有效驾驶证驾驶</div>
                <div class="pdl-16">
                    <div class="indent_2">指下列情形之一：</div>
                    <div>（1）没有取得驾驶资格；</div>
                    <div>（2）驾驶与驾驶证准驾车型不相符合的车辆；</div>
                    <div>（3）持审验不合格的驾驶证驾驶；</div>
                    <div>（4）持学习驾驶证学习驾车时，无教练员随车指导，或不按指定时间、路线学习驾车。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.13 无有效行驶证</div>
                <div class="pdl-16">
                    <div class="indent_2">指下列情形之一：</div>
                    <div>（1）未取得行驶证；</div>
                    <div>（2）机动车被依法注销登记的；</div>
                    <div>（3）未依法按时进行或通过机动车安全技术检验。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.14 机动车</div>
                <div class="pdl-16">
                    <div class="indent_2">指以动力装置驱动或者牵引，上道路行驶的供人员乘用或者用于运送物品以及进行工程专项作业的轮式车辆。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.15 医疗事故</div>
                <div class="pdl-16">
                    <div class="indent_2">指医疗机构及其医务人员在医疗活动中，违反医疗卫生管理法律、行政法规、部门规章和诊疗护理规范、常规，过失造成患者人身损害的事故。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.16 非处方药</div>
                <div class="pdl-16">
                    <div class="indent_2">指在使用药品当时，由国务院药品监督管理部门公布的，不需要凭执业医师和执业助理医师处方，消费者可以自行判断、购买和使用的药品。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.17 潜水</div>
                <div class="pdl-16">
                    <div class="indent_2">指使用辅助呼吸器材在江、河、湖、海、水库、运河等水域进行的水下运动。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.18 攀岩</div>
                <div class="pdl-16">
                    <div class="indent_2">指攀登悬崖、楼宇外墙、人造悬崖、冰崖、冰山等运动。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.19 探险</div>
                <div class="pdl-16">
                    <div class="indent_2">指明知在某种特定的自然条件下有失去生命或使身体受到伤害的危险，而故意使自己置身其中的行为，如：江河漂流、登山、徒步穿越沙漠或人迹罕至的原始森林等活动。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.20 武术比赛</div>
                <div class="pdl-16">
                    <div class="indent_2">指两人或两人以上对抗性柔道、空手道、跆拳道、散打、拳击等各种拳术及使用器械的对抗性比赛。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.21 特技表演</div>
                <div class="pdl-16">
                    <div class="indent_2">指进行马术、杂技、驯兽等表演。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.22 净保险费</div>
                <div class="pdl-16">
                    <div class="indent_2">指不包含公司营业费用、佣金等其他费用的保险费。其计算公式为“保险费×（1-35%）”。</div>
                    <div class="indent_2">未满期净保险费＝净保险费×（1－保险经过日数 / 保险期间的日数），经过日数不足1日的按1日计算。</div>
                </div>
            <p></p>
            <p>
                </p><div>7.23 病理性骨折</div>
                <div class="pdl-16">
                    <div class="indent_2">指骨质已有病变，破坏了骨骼原来的正常结构，从而失去原来的坚固性，并在正常活动或轻微外力作用下发生的骨折。</div>
                </div>
            <p></p>
        </div>
        <div>
            <h4 class="al_center">平安个人综合意外伤害保险费率表</h4>
        </div>
        <div style="margin-top:30px">
            <div class="al_center">基本责任（每万元保额）</div>
            <div class="al_right fs_12">单位：人民币元</div>
            <table cellspacing="0" class="static-tb td-center">
                <tbody><tr>
                    <td>年龄</td>
                    <td>费率</td>
                </tr>
                <tr>
                    <td>0-5</td>
                    <td>8.3</td>
                </tr>
                <tr>
                    <td>6-60</td>
                    <td>6.6</td>
                </tr>
                <tr>
                    <td>61-65</td>
                    <td>8.6</td>
                </tr>
            </tbody></table>
        </div>
        <div tyle="margin-top:30px">
            <div class="al_center">意外医疗责任</div>
            <div class="al_right fs_12">单位：人民币元</div>
            <table cellspacing="0" class="static-tb td-center">
                <tbody><tr>
                    <td>年龄\保额</td>
                    <td>5000</td>
                    <td>10000</td>
                    <td>20000</td>
                    <td>30000</td>
                </tr>
                <tr>
                    <td>0-5</td>
                    <td>74</td>
                    <td>166</td>
                    <td>244</td>
                    <td>291</td>
                </tr>
                <tr>
                    <td>6-60</td>
                    <td>59</td>
                    <td>133</td>
                    <td>195</td>
                    <td>233</td>
                </tr>
                <tr>
                    <td>61-65</td>
                    <td>77</td>
                    <td>173</td>
                    <td>254</td>
                    <td>303</td>
                </tr>
            </tbody></table>
        </div>
        <div style="margin-top:30px">
            <div class="al_center">意外骨折责任（每百元保额）</div>
            <div class="al_right fs_12">单位：人民币元</div>
            <table cellspacing="0" class="static-tb td-center">
                <tbody><tr>
                    <td>年龄</td>
                    <td>费率</td>
                </tr>
                <tr>
                    <td>0-5</td>
                    <td>6.2</td>
                </tr>
                <tr>
                    <td>6-60</td>
                    <td>5</td>
                </tr>
                <tr>
                    <td>61-65</td>
                    <td>6.5</td>
                </tr>
            </tbody></table>
        </div>
        <div style="margin-top:30px">
            <div class="al_center">猝死责任（每万元保额）</div>
            <div class="al_right fs_12">单位：人民币元</div>
            <table cellspacing="0" class="static-tb td-center">
                <tbody><tr>
                    <td>年龄</td>
                    <td>费率</td>
                </tr>
                <tr>
                    <td>0-5</td>
                    <td>6.2</td>
                </tr>
                <tr>
                    <td>6-60</td>
                    <td>5</td>
                </tr>
                <tr>
                    <td>61-65</td>
                    <td>6.5</td>
                </tr>
            </tbody></table>
        </div>
        <div style="margin-top:30px">
            <div class="al_center">保障期间费率调整因子</div>
            <table cellspacing="0" class="static-tb td-center">
                <tbody><tr>
                    <td>保障期间</td>
                    <td>费率调整因子</td>
                </tr>
                <tr>
                    <td>1天</td>
                    <td>1%</td>
                </tr>
                <tr>
                    <td>7天</td>
                    <td>5%</td>
                </tr>
                <tr>
                    <td>30天</td>
                    <td>15%</td>
                </tr>
                <tr>
                    <td>6个月</td>
                    <td>60%</td>
                </tr>
                <tr>
                    <td>1年</td>
                    <td>100%</td>
                </tr>
            </tbody></table>
        </div>
    </div>
</template>
<style lang="less" scoped>
    @charset "utf-8";
    @import "../../../../styles/notice.less";
    .noticeInsurance{
        padding:0.5rem;
        padding-left:1rem;
        padding-right:1rem;
        font-size:1.5rem;
        h2{font-size:1.8rem;line-height:3rem;}
        p{font-size:1.6rem;line-height:2.5rem;margin-top:0.5rem;}
        .bgc_ddd{
            background:#ddd;
        }
        .al_center{
            text-align:center;
            line-height: 3.5rem;
        }
        .al_left{
            text-align:left;
        }
        .al_right{
            text-align:right;
        }
        .fs_12{
            font-size:12px;
        }
        h4{
            font-weight: 700;
            font-size: 1.5rem;
            line-height: 2rem;
        } 
        .indent_2{
            text-indent:2em;
            table th{
                text-indent: 0;
                padding: 0.5rem;
            }
        }
        table{
            margin:0 auto;
            text-algin: center;
        } 
        td,th{
            border:1px solid #000;
        }
        .static-tb>tbody>tr>td{
            border:1px solid
        }
        .td-center>tbody>tr>td{
            padding:0.5rem;
        }
    }
</style>
