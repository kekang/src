<template>
<!-- 隐藏页 投保须知 -->
    <div class="insurance_noticeE">
       <h3 class="al_center">重要声明</h3>
        <div>
            <h4>投保须知：</h4>
            <ol class="statement">
          <li class="indent_2">1、平安健康保险股份有限公司最近季度综合偿付能力充足率为205.96%，最近一期风险综合评级为B，满足监管对偿付能力充足率的要求。</li>
      <li class="indent_2">2、本保险由平安健康保险股份有限公司承保。</li>
                <li class="indent_2">3、我们提供网银、支付宝等第三方支付平台，以便您完成保费支付。</li>
                <li class="indent_2">4、保单形式：我们为您提供电子保单，根据《中华人民共和国合同法》第十一条规定，数据电文是合法的合同表现形式，电子保单和纸质保单具有同等法律效力。保单承保后，我们会将电子保单发送到您预留的电子邮箱。请您查阅电子保单时仔细阅读关于“责任免除“的相关条款。若因邮箱录入错误导致您的个人信息泄露，我司不承担责任。</li>
                <li class="indent_2">5、如您需要发票服务，请通过拨打95511-7或发邮件至pub_health_online@pingan.com.cn联系我们，我们将为您安排快递货到付款，邮费由您承担。其他任何疑问，也可通过上述两种方式与我们联系。</li>
                <li class="indent_2">6、<span class="bgc_ddd">本计划不承保高风险运动，高风险运动包括但不限于潜水、跳伞、攀岩、蹦极、驾驶滑翔机或滑翔伞、探险、摔跤、武术比赛、特技表演、赛马、赛车等。</span></li>
                <li class="indent_2">7、<span class="bgc_ddd">如被保险人在保险有效期内发生职业变化，以其出险时实际从事的职业类别为准，出险时职业类别超过保单规定的最高职业类别限制的，因此事故导致的意外伤残、身故和医疗费用为除外责任。</span></li>
                <li class="indent_2">8、本产品指定医院为符合条款要求的医院，<span class="bgc_ddd">除了北京平谷区所有医院。请注意：北京市平谷区所有医院的就医均不给予理赔。</span></li>
                <li class="indent_2">9、保单承保后，您可通过平安健康险官方网站或关注公众微信号“平安健康生活“获取更多服务。</li>
                <li class="indent_2">10、解除合同：<span class="bgc_ddd">本产品无犹豫期</span>。若您申请解除合同会遭受一定损失。我们按照如下公式计算应退费用
解除合同退费＝当前有效的保险责任所对应的保险费×0.65×（1－保险经过日数/保险期间的日数），经过日数不足1日的按1日计算。
</li>

            </ol>
        </div>
        <div>
            <h4>投保声明：</h4>
            <ol class="statement">
                <li class="indent_2">1、本人已完整阅读并理解以上投保须知。</li>
                <li class="indent_2">2、本人所提供的信息均属实，如有不实告知，贵公司有权依法解除保险合同，并对合同解除前发生的保险事故不承担保险责任。</li>
                <li class="indent_2">3、本人授权平安集团，除法律另有规定之外，将本人提供给平安集团的信息、享受平安集团服务产生的信息（包括本单证签署之前提供和产生的信息）以及平安集团根据本条约定查询、收集的信息，用于平安集团及其因服务必要委托的合作伙伴为本人提供服务、推荐产品、开展市场调查与信息数据分析。本人授权平安集团，除法律另有规定之外，基于为本人提供更优质服务和产品的目的，向平安集团因服务必要开展合作的伙伴提供、查询、收集本人的信息。为确保本人信息的安全，平安集团及其合作伙伴对上述信息负有保密义务，并采取各种措施保证信息安全。本条款自本单证签署时生效，具有独立法律效力，不受合同成立与否及效力状态变化的影响。本条所称“平安集团”是指中国平安保险（集团）股份有限公司及其直接或间接控股的公司，以及中国平安保险（集团）股份有限公司直接或间接作为其单一最大股东的公司。如您不同意上述授权条款的部分或全部，可致电客服热线95511取消或变更授权。</li>
                <li class="indent_2">4、本人同意贵公司通过手机（包括手机短信）、E-mail适时提供保险信息服务。</li>
            </ol>
        </div>
    </div>
</template>
<style lang="less" scoped>
    @import "../../../../styles/notice.less";
    .insurance_noticeE{
        font-size:1.5rem;
         padding:0.3rem;
        padding-left:1.2rem;
        padding-top:1.2rem;
        padding-right:1.2rem;
        h2{font-size:1.8rem;line-height:0.6rem;}
        p{font-size:1.5rem;line-height:0.6rem;margin-top:0.1rem;}
        h4{
            font-weight:700;
            font-size:1.8rem;
            line-height:2.2rem;
        }
        h3{
            text-align:center;
            font-size:2rem;
            font-weight:700;
            line-height:2.5rem;
        }
        .indent_2{
            text-indent:2em;
        }
        .bgc_ddd{
            background:#ddd;
        }
        li{
            margin-left:0.2rem;
        }
    }
</style>
