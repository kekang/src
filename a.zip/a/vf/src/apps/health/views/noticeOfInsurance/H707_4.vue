<template>
    <!-- 隐藏页 投保须知 -->

    <div class="insurance_noticeE">
        <p style="text-align:center">
            <strong><span style="font-size:1.8rem;padding-top: 2rem;font-weight: 500;">优选直接结算医院网络</span></strong>
        </p>
        <p class="MsoListParagraph" style="margin: auto;width: 90%;padding-top: 2rem;"><span style="font-family: '微软雅黑','sans-serif'">为了优化客户就医流程，提高保险保障效率，平安在保障范围内医疗机构中筛选优质医疗资源，并逐步在其中实现创新服务的提供：</span></p>
        <p class="MsoListParagraph" style="margin: auto;width: 90%"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight: bold; font-family: 微软雅黑, sans-serif;">&nbsp;优选直接结算医院：</span><span style="font-family:'微软雅黑','sans-serif'">平安选择区域内医疗资源好、居民认可程度高、医保评级高的医疗机构，深化与其的合作深度，实现患者在优选直接结算医院普通住院部的直接结算服务，简化患者就医流程，减轻患者财务压力。</span></p>
        <p class="MsoListParagraph" style="margin: auto;width: 90%"><span style="font-family:'微软雅黑','sans-serif'">&nbsp;</span></p>
        <p style="margin: auto;width: 90%"><strong><span style="font-family:'微软雅黑','sans-serif'">附：优选直接结算医院网络列表</span></strong></p>
        <table cellpadding="0" border="1" style="border-collapse: collapse;width: 90%;margin: auto;text-align: center;" width="-112">
        <tbody>
        <tr width="100%" class="firstRow">
        <td style="border: solid #000000 1px;width:9%;" colspan="1"><span style="font-weight: bold;font-family: 微软雅黑, 'Microsoft YaHei';">区域</span></td>
        <td style="border: solid #000000 1px;width:9%;" colspan="1"><span style="font-weight: bold;font-family: 微软雅黑, 'Microsoft YaHei';">城市</span></td>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-weight: bold;font-family: 微软雅黑, 'Microsoft YaHei';">推荐医院名称(3A为三级甲等医院,3B为三级乙等医院)</span></td>
        <td style="border: solid #000000 1px;" colspan="1"><span style="font-weight: bold;font-family: 微软雅黑, 'Microsoft YaHei';">地址</span></td>
        </tr>
        <tr>
        <td rowspan="4" style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-family: 微软雅黑, 'Microsoft YaHei';">广东</span></td>
        <td style="border: solid #000000 1px;" colspan="1" rowspan="4"><span style="font-family: 微软雅黑, 'Microsoft YaHei';">深圳</span></td>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-family: 微软雅黑, 'Microsoft YaHei';">深圳市第二人民医院 3A</span></td>
        <td style="border: solid #000000 1px;" colspan="1"><span style="font-family: 微软雅黑, 'Microsoft YaHei';">广东省深圳市福田区笋岗西路3002号</span></td>
        </tr>
        <tr>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-size: 12px; font-family: 微软雅黑, 'Microsoft YaHei';">深圳市福田区人民医院 3B</span></td>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-size: 12px; font-family: 微软雅黑, 'Microsoft YaHei';">广东省深圳市深南中路3025号</span></td>
        </tr>
        <tr>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-size: 12px; font-family: 微软雅黑, 'Microsoft YaHei';">深圳市南山区人民医院（深圳市第六人民医院）3A</span></td>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-size: 12px; font-family: 微软雅黑, 'Microsoft YaHei';">广东省深圳市南山区桃园路89号</span></td>
        </tr>
        <tr>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-size: 12px; font-family: 微软雅黑, 'Microsoft YaHei';">南方医科大学深圳医院3A</span></td>
        <td style="border: 1px solid rgb(0, 0, 0); word-break: break-all;" colspan="1"><span style="font-size: 12px; font-family: 微软雅黑, 'Microsoft YaHei';">广东省深圳市宝安区新湖路1333号</span></td>
        </tr>
        </tbody>
        </table>

</div>
</template>
<style lang="less" scoped>
    .insurance_noticeE{
        /*padding:1.5rem;*/
    h2{font-size:1.8rem;line-height:2.5rem;}
    p,li{font-size:1.6rem;line-height:2rem;margin-top:1.5rem;}
    .indetails{
        text-align:center;
    }
    table {
        border-collapse: collapse;
        //font-size: 1.4rem;
        text-align: center;
    }
    td,th{
        border:1px solid #000;
    }
    }
</style>
