<template>
    <!-- 隐藏页 投保须知 -->

    <div class="insurance_noticeE">

        <h2 style=";text-align:center;line-height:150%;font-family:'微软雅黑','sans-serif'">产品服务告知书</h2>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'"></span></strong></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size: 1.5rem; font-family: 微软雅黑, sans-serif;">尊敬的客户：</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="font-size: 1.5rem; font-family: 微软雅黑, sans-serif;">感谢您选择平安健康保险股份有限公司的保险产品！</span></p>
        <p style="width: 90%;margin: auto"><span style="font-size: 1.5rem; font-family: 微软雅黑, sans-serif;">该产品包含多个计划，每个计划所能享受的服务内容不同。为方便您更好地认识和使用该产品，保护您的合法权益，请您认真阅读以下内容：</span></p>
        <p style="white-space: normal; text-align: center;"><strong><span style="font-size: 14px; line-height: 21px; font-family: 微软雅黑, sans-serif;">平安健康保险24小时客户服务热线：95511-7（中文）</span></strong></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;line-height:150%;font-family:'微软雅黑','sans-serif'">一、</span></strong><strong><span style="font-size:1.5rem;line-height: 150%;font-family:'微软雅黑','sans-serif'">产品使用概览</span></strong></p>
        <p style="width: 90%;margin: auto"><br /></p>
        <p style=" width: 90%;margin: auto;"><img src="../../../../assets/images/healthCode/H707_3_1.png" /></p>
        <p><span style="font-size:1.5rem;line-height:150%;font-family:'微软雅黑','sans-serif'">&nbsp;</span></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif';font-weight:600">【特色服务项目】</span></strong></p>
        <table style="border-collapse: collapse;width: 90%;margin: auto;">
        <tbody>
        <tr class="firstRow">
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: bold;">服务项目</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: bold;">大病版</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: bold;">住院版</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: bold;">门诊版</th>
        </tr>
        <tr>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">住院直接结算</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">不提供</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">提供</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">提供</th>
        </tr>
        <tr>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">手机快速理赔</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">不提供</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">不提供</th>
        <th style="border-width: 1px; padding: 8px;border-style: solid;font-weight: 100;">提供</th>
        </tr>
        </tbody>
        </table>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif';font-weight:600">【保单】</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'">线上投保该产品仅提供电子保单。请您在投保界面中填写邮箱地址，平安会在保单生效后将电子保单发送至您提供的电子邮箱。</span></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif';font-weight:600">【发票】</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'">若您需要产品发票，</span><a href="mailto:%E5%8F%AF%E5%8F%91%E9%80%81%E9%82%AE%E4%BB%B6%E8%87%B3%E4%B8%93%E5%B1%9E%E9%82%AE%E7%AE%B1pub_health_online@pingan.com.cn%E6%88%96%E8%87%B4%E7%94%B595511-7"><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif';color:windowtext;text-underline:none">可发送邮件至专属邮箱pub_health_online@pingan.com.cn</span><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif';color:windowtext;text-underline:none">或致电95511-7</span></a><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'">索取，我们会安排专人受理并将发票快递到您的指定地址；邮寄采用顺丰快递、到付方式。</span></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif';font-weight:600">【手机快速理赔】</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'">关注微信公众号“平安健康生活”或下载平安健康APP，小额门诊费用可通过拍照方式进行快速理赔，详情见“理赔须知”。</span></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif';font-weight:600">【直接结算】</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight: bold; font-family: 微软雅黑, sans-serif;">&nbsp;直接结算的服务可在优选直接结算网络中使用，是指患者在住院前免交押金、住院之后免交医疗费用，院后免理赔申请的流程统称。直接结算的使用规则和流程详见“理赔须知”。</span></p>
        <p style="width: 90%;margin: auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-weight: bold; font-family: 微软雅黑, sans-serif;">&nbsp;平安健康险出具的预授权通知单仅为财务担保凭证，具体住院安排以院方实际情况为准。</span></p>
        <p style="width: 90%;margin: auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:red;"></span><strong><span style="font-size:1.5rem;font-family: '微软雅黑','sans-serif';color:red">&nbsp;直结结算中的担保金额不代表最终保险公司应承担的赔付责任金额。对于应由您个人承担但平安先行垫付的费用，需要您事后偿还，届时平安客服人员会与您沟通。</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'">&nbsp;对于偿还的金额，您可致电95511-7联系平安客服人员进行确认，通过银行柜面、网上银行转账或进入公众号“平安健康生活”进行清偿。</span></p>
        <p style="width: 90%;margin: auto"><span style="font-size:10px;font-family:'微软雅黑','sans-serif'">&nbsp;</span></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;line-height:150%;font-family:'微软雅黑','sans-serif'">二、</span></strong><strong><span style="font-size:1.5rem;line-height: 150%;font-family:'微软雅黑','sans-serif'">重要联系方式</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style=" font-family: 微软雅黑, sans-serif;">&nbsp;在使用本产品时遇到任何问题，您都可以随时联系：</span></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'">平安健康险24小时服务热线： 95511 转 7</span></strong></p>
        <p style="width: 90%;margin: auto"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#000;"></span><span style=" font-family: 微软雅黑, sans-serif;">&nbsp;欢迎联系我们，提出您的宝贵意见：</span></p>
        <p style="width: 90%;margin: auto"><strong><span style="font-size:1.5rem;font-family:'微软雅黑','sans-serif'">项目经理邮箱：dept_pahgpro@pingan.com.cn</span></strong></p>
        <p><br /></p>
    </div>
</template>
<style lang="less" scoped>
//@import "../../../../styles/notice.less";
    .insurance_noticeE{
    h2{font-size:1.8rem;line-height:3.5rem;font-weight:600;text-align:center;padding-top: 2rem;}
    p,li{font-size:1.5rem;line-height:2rem;margin-top:1.5rem;}
    .indetails{
        text-align:center;
    }
    img{
        width:100%
    }
    table {
        border-collapse: collapse;
        //font-size: 1.5rem;
        text-align: center;
    }
    td,th{
        border:1px solid #000;
    }
    }
</style>
