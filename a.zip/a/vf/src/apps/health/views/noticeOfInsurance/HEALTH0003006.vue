<template>
<!--  母婴卫士投保告知  -->

<div class="health_notice">
    <h2>本人自愿投保，特告知以下事项：</h2>
<div class="wrap">
    <div class="question">
    您是否患有或曾患有恶性葡萄胎、妊娠高血压？
</div>
<div class="ans" id="check1">
    <p><i @click='clickchange1' eq="0"  ref="is1" ></i><span>是</span></p>
    <p><i @click='clickchange1' eq="1"  ref="not1"></i><span>否</span></p>
    </div>
    </div>
    <div class="wrap">
    <div class="question">
    妊娠期检查中，您是否被告知胎儿患有或被怀疑患有先天性畸形或发育异常？
</div>
<div class="ans" id="check2">
    <p><i @click='clickchange2' eq="2" ref="is2"></i><span>是</span></p>
    <p><i @click='clickchange2' eq="3" ref="not2"></i><span>否</span></p>
    </div>
    </div>

    <div class="wrap ps">
    <p>投保人应在对所有被保险人健康/职业状况充分了解的基础上履行如实告知义务。投保人承诺完全知晓所有被保险人健康/职业状况。若被保险人健康/职业状况与上述告知内容不符：
（1）本公司有权不同意承保。（2）若发生保险事故，本公司不承担赔偿或给付保险金的责任，并有权不退还保险费。</p>
</div>
<div class="footer">
    <div class="btn" ref="Button" @click="next">下一步</div>
    </div>
    </div>

    </template>
    <script>
    let change = "#2688c4"
import {Msg, Loading} from 'components'
import {mapState,productDetail,mapGetters,mapMutations,mapActions} from 'vuex'
import {policyHealthRecord} from '../../apis/health.api'
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
import filter from "../../../../utils/filter"
//import {PAD} from "../../../../utils/PAD"

export default{
    data () {
        return {
        }
    },
    mounted(){
        document.body.scrollTop = 0;

        //健康告知页
        //SKAPP.onEvent("健康告知页", "进入健康告知页",{
            //icpProductCode:sessionStorage.icpProductCode,
            //insureNotice:this.$store.state.health.insureNotice
        //});
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
            "进入健康告知页":'健康告知页'
        });
        switch (sessionStorage.col){
            case "B2":
                change = "#4285F6"
                break
            case "Y1":
                change = "#D8A161"
                break
            case "O1":
                change = "#FF6000"
                break
            case "R1":
                change = "#F76B6C"
                break
            case "R2":
                change = "#F11B33"
                break
            default:
                change = "#2688c4"
                break;
        }
        this.$refs.Button.style.backgroundColor = change;
        if (this.$store.state.health.select[0]) {
            this.$refs.is1.style.backgroundColor = ""
            this.$refs.not1.style.backgroundColor = ""
            this.$refs.not1.style.backgroundColor=change
        }
        if (this.$store.state.health.select[1]) {
            this.$refs.is2.style.backgroundColor = ""
            this.$refs.not2.style.backgroundColor = ""
            this.$refs.not2.style.backgroundColor=change
        }
    },
    methods: {
        next: function () {

            //提交健康告知页
            //SKAPP.onEvent("健康告知页", "提交健康告知",{
                //icpProductCode:sessionStorage.icpProductCode,
                //healthResult:"N"
            //});

            if (this.$store.state.health.select[0] && this.$store.state.health.select[1]) {

                //提交健康告知页
                //SKAPP.onEvent("健康告知页", "提交健康告知",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //healthResult:"Y"
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
                    "提交健康告知":'否'
                });
                var saleRecordId = this.$store.state.health.saleRecordId;
                var submitData = {
                    saleRecordId: saleRecordId,
                    healthRecord: '{"H752F0001":"Y","H752F0002":"Y"}',
                    healthResult: 'Y'
                };
                policyHealthRecord(submitData).then((data) => {
                    if (data.data.resultCode === '00000') {
                        //成功跳转
                        this.$router.push({
                            name: 'customerInfo'
                        });
                    }else{
                        Msg.alert(filter.resultCode(data.body))
                    };
                });
            }else{
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "健康告知页面",{
                    "提交健康告知":'是'
                });
                Msg.toast('您的健康告知未通过')
            };
        },
        //clickchange: function (value) {
        //    event.target.classList.remove('first_load');
        //    if (event.target.className != 'current') {
        //        this[event.currentTarget.id] = !this[event.currentTarget.id];
        //    }
        //},
        clickchange1: function (e) {
            this.$refs.is1.style.backgroundColor = ""
            this.$refs.not1.style.backgroundColor = ""
            e.target.style.backgroundColor=change
            this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
        },
        clickchange2: function (e) {
            this.$refs.is2.style.backgroundColor = ""
            this.$refs.not2.style.backgroundColor = ""
            e.target.style.backgroundColor=change
            this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
        }
    }
}

</script>
<style lang="less" scoped>
@import "../../../../styles/vars.less";
.health_notice{
    padding-bottom:1.6rem;
    h2{font-size:1.8rem;line-height:3rem;font-weight:bold;padding:1.2rem;border-bottom: 1px solid #ececec;}
.wrap{
        overflow: hidden;
        border-bottom: 1px solid #ececec;
        position: relative;
    }
.question{
        font-size: 1.6rem;
        line-height: 2.3rem;
        padding: 1.5rem 1.2rem;
        float: left;
        color: #666;
        width: 70%;
    }
.ans{
        float: left;
        position: absolute;
        top: 50%;
        right: 2rem;
        transform: translateY(-50%);
        -webkit-tap-highlight-color:rgba(0,0,0,0);
    }
.ans p{
        float: left;
        font-size: 1.6rem;
        padding: 1.5rem 0;
        line-height: 2.3rem;
        margin-right: 0.15rem;
    }
.ans p:first-child{
        margin-right: 1rem;
    }
.ans p i{
        width: 1.8rem;
        height: 1.8rem;
        border-radius: 50%;
        display: inline-block;
        border: 1px solid #ccc;
        margin-right: 0.4rem;
        vertical-align: middle;
        position: relative;
        bottom: 1px;
        box-shadow: 0 0 0px 3px #FFF inset!important;
    }


.ans p i{
        position: relative;
    }
.ans p i:before {
        content: '';
        position: absolute;
        top: -10px; right: -10px;
        bottom: -10px; left: -5px;
    }

.ans p i.current{
        background-color: @iconfont;
        box-shadow: 0 0 0px 3px #FFF inset!important;
    }

.ps{
        font-size: 1.6rem;
        line-height: 2.3rem;
        padding: 1.5rem 1.2rem 6rem 1.2rem;
    }
.first_load{
        background-color: transparent !important;
        box-shadow: none !important;
    }
.weui_cell {
        padding: 5px 10px;
        color: #999;
    }
.footer{
        z-index: 3;
        width: 100%;
        position: fixed;
        bottom: 0;
        left:0;
        padding-left: 1rem;
        padding-right: 1rem;
        padding-top: 1rem;
        padding-bottom: 1rem;
        background-color: rgba(0, 0, 0, 0.3);
    }
.btn{
        width: 100%;
        height: 4.5rem;
        background-color: @iconfont;
        border: none;
        color: #ffffff;
        line-height: 4.5rem;
        font-size: 2rem;
        border-radius: 8px;
        text-align:center

    }
.weui_cell{
        padding-left: 30px;
        font-size: 1.6rem;
    }
.ps{
        font-weight:700;
        text-indent:2em;
    }
.alert{

    }
}
</style>