<template>
<!-- 隐藏页 投保须知 -->
<div class="insurance_noticeE">
<p style=";text-align:center"><span class="tips" style="font-size:21px;line-height:150%;font-family:'微软雅黑'">重要声明</span></p>
<p style="margin:auto;width:90%"><strong><span class="tips" style="line-height:150%;font-family:'微软雅黑'">保险人声明：</span></strong></p>
<p style="margin:auto;width:90%"><span style="line-height:150%;font-family:'微软雅黑'">1.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">平安健康保险股份有限公司最近季度综合偿付能力充足率为147.38%，最近一期风险综合评级为B，满足监管对偿付能力充足率的要求。</span></p>
<p style="margin:auto;width:90%"><span style="line-height:150%;font-family:'微软雅黑'">2.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">本保险由平安健康保险股份有限公司承保，本公司在北京、上海、广东（除深圳）、深圳、浙江、江苏地区设有分支机构。被保险人的常住地需在上述地区。大病版、住院版、门诊版的服务保障可在中国大陆范围内提供。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">3.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">我们为您提供电子保单，根据《中华人民共和国合同法》第十一条规定，数据电文是合法的合同表现形式，电子保单和纸质保单具有同等法律效力。保单承保后，电子保单会发送到您预留的电子邮箱。请您查阅电子保单时仔细阅读关于“责任免除“的相关条款。若因邮箱录入错误导致您的个人信息泄露，我司不承担责任。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">4.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">本保险分为“有医保”方案和“无医保”方案。若以“有医保”身份购买本保险，但在二级或二级以上公立医院普通部接受治疗时，未先行使用医保卡进行结算的，我司按应赔付金额的60%赔付。门诊版中的普通门急诊责任（不包含特殊门诊）不受此限制。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">5.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">合同生效日为我们收取保险费并签发保险合同的次日零时起，并载明于电子保单上。</span></p>
<p style="width:90%;margin:auto;line-height:150%"><span style="line-height:150%;font-family:'微软雅黑'">6.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">平安对每年会检视该产品费率，并拥有调整费率的权利。产品费率会统一调整，不会单独针对个人进行费率调整。</span></p>
<p style="width:90%;margin:auto;line-height:150%"><span style="line-height:150%;font-family:'微软雅黑'">7.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">平安保留对产品保障责任、投保规则、除外责任等条款内容更新的权利。</span></p>
<p style="width:90%;margin:auto;line-height:150%"><span style="line-height:150%;font-family:'微软雅黑'">8.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">若该产品停售，被保险人续保选择更新后的产品，个人终身保额的剩余保额会自动计算在新产品保单中。更新产品的信息平安会提前发布。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">9.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">如您需要发票，请拨打95511-7或发邮件至pub_health_online@pingan.com.cn联系我们，我们将为您安排快递货到付款，邮费由您承担。其他任何疑问，也可通过上述两种方式与我们联系。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">10.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">保单承保后，您可通过平安健康险官方网站或关注微信公众号“平安健康生活“获取更多服务。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">11.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">解除合同：本产品犹豫期为10天，在此期间，您若主动提出解除本主险合同，我们将无息退还您所支付的全部保险费。犹豫期后，若您申请解除合同或终止某被保险人的保障，将会遭受一定损失。我们按照如下公式退还您未满期净保费。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">未满期净保费=（保单剩余天数/365） * 保单保费*（1-35%），经过日数不足1日的按1日计算。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">净保险费指投保人所支付的保险费扣除每张保险单平均承担的本公司各项费用（含营业费用、各项税金、保险保障基金等）后的余额。净保费=保费&times;（1-35%）。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">12.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">直接结算服务仅在优选直接结算医院普通住院部可用。优选直接结算医院介绍见附件“优选医院”。直接结算服务使用前，需要向健康险公司申请预授权，经预授权审核通过后方可享受直接结算服务，可致电客服热线95511-7或登录微信“平安健康生活”进行申请。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">13.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">我们提供微信、支付宝、银行卡等第三方支付平台，以便您完成保费支付。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">&nbsp;</span></p>
<p style="width:90%;margin:auto"><strong><span class="tips" style="line-height:150%;font-family:'微软雅黑'">投保声明：</span></strong></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">1.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">本人已完整阅读并理解投保须知、保障方案、保险条款等相关材料。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">2.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">本人所提供的信息均属实，如有不实告知，贵公司有权依法解除保险合同，并对合同解除前发生的保险事故不承担保险责任。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">3.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">本人授权贵公司可以从任何单位、组织和个人就有关保险事宜查询、索取与本人有关的资料和证明，贵公司对个人资料承担保密义务。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">4.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">本人授权平安集团，除法律另有规定之外，将本人提供给平安集团的信息、享受平安集团服务产生的信息（包括本单证签署之前提供和产生的信息）以及平安集团根据本条约定查询、收集的信息，用于平安集团及其因服务必要委托的合作伙伴为本人提供服务、推荐产品、开展市场调查与信息数据分析。本人授权平安集团，除法律另有规定之外，基于为本人提供更优质服务和产品的目的，向平安集团因服务必要开展合作的伙伴提供、查询、收集本人的信息。为确保本人信息的安全，平安集团及其合作伙伴对上述信息负有保密义务，并采取各种措施保证信息安全。本条款自本单证签署时生效，具有独立法律效力，不受合同成立与否及效力状态变化的影响。本条所称“平安集团”是指中国平安保险（集团）股份有限公司及其直接或间接控股的公司，以及中国平安保险（集团）股份有限公司直接或间接作为其单一最大股东的公司。如您不同意上述授权条款的部分或全部，可致电客服热线95511取消或变更授权。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">5.<span style="font-stretch:normal;font-size:9px;line-height: normal;"></span></span><span style="line-height:150%;font-family:'微软雅黑'">本人同意贵公司通过手机（包括手机短信、微信等）、E-mail适时提供保险信息服务。</span></p>
<p style="width:90%;margin:auto"><span style="line-height:150%;font-family:'微软雅黑'">&nbsp;</span></p>
<p><br /></p>
</div>
</template>
<style lang="less">
@import "../../../../styles/notice.less";
    .insurance_noticeE{
        padding:0.3rem;
        h2{font-size:1.8rem;line-height:3rem;}
        p{font-size:1.6rem;line-height:2.5rem;margin-top:0.5rem;}
        th,.tips{
            font-size: 1.6rem;
            line-height:5rem;
            font-weight: bold;
        }
        .p-details ul li{
            font-size:1.5rem
        }
    }
</style>
