<template>
<!--  第三页 投保告知  -->

    <div class="health_notice">
        <h2>本人自愿投保，特告知以下事项：</h2>
        <div class="wrap">
        <div class="question">
            1、过去2年内投保人身保险或健康保险时，被保险公司拒保、延期、加费或者附加条件承保。<br>
            2、被保险人过去1年内有健康检查结果异常（如血液、超声、影像、内镜、病理检查）；过去2年曾住院（不包括剖腹产/顺产/鼻炎/急性胃肠炎/肺炎/上呼吸道感染住院）<br>
            3、目前或过往患有下列疾病或症状：
            良/恶性肿瘤、白血病、3级以上高血压（收缩压大于180mmHg，舒张压大于110mmHg）、糖尿病、冠心病/冠状动脉狭窄、心肌梗死、风湿性心脏病、心功能不全二级以上、脑梗死/脑出血、肾炎、肾功能不全、肾/输尿管结石、肝炎、肝硬化、再生障碍性贫血、系统性红斑狼疮、类风湿性关节炎、帕金森氏病、癫痫、精神病、肺结核、慢性阻塞性肺病、瘫痪、慢性胆囊炎、胆石症、胆囊息肉、下肢静脉曲张、甲亢、甲状腺结节、传导性耳聋、胃/十二指肠溃疡、椎间盘突出症、乳腺囊肿/结节、克罗恩病（节段性肠炎）、先天性疾病。<br>
            4、过去1年内存在下列症状：反复头痛、晕厥、胸痛、气急、紫绀、持续反复发热、抽搐、不明原因皮下出血点、咯血、反复呕吐、进食梗噎感或吞咽困难、呕血、浮肿、腹痛、黄疸（新生儿黄疸且已治愈的除外）、便血、血尿、蛋白尿、肿块、消瘦（体重减轻5公斤以上）、职业病、酒精中毒、其他药品中毒、智能障碍、五官/脊柱/胸廓/四肢/手指/足趾缺损/畸形或功能障碍。<br>
            5、2周岁以下被保险人：出生时体重低于2.5公斤，有早产/窒息/发育迟缓/脑瘫。
        </div>
            <div class="ans" id="check1">
                <p><i @click='clickchange1' eq="0"  ref="is1" ></i><span>是</span></p>
                <p><i @click='clickchange1' eq="1"  ref="not1"></i><span>否</span></p>
            </div>
        </div>
        <div class="wrap">
            <div class="question">
                目前从事高危职业（点击查询<span style="color:#2688c4;" @click="gaowei">《高危职业表》</span>  ）。
            </div>
            <div class="ans" id="check2">
                <p><i @click='clickchange2' eq="2" ref="is2"></i><span>是</span></p>
                <p><i @click='clickchange2' eq="3" ref="not2"></i><span>否</span></p>
            </div>
        </div>
       
        <div class="wrap ps">
            <p>投保人应在对所有被保险人健康/职业状况充分了解的基础上履行如实告知义务。投保人承诺完全知晓所有被保险人健康/职业状况。若被保险人健康/职业状况与上述告知内容不符：
                （1）本公司有权不同意承保。（2）若发生保险事故，本公司不承担赔偿或给付保险金的责任，并有权不退还保险费。</p>
        </div>
        <div class="footer">
            <div class="btn" ref="Button" @click="next">下一步</div>
        </div>
    </div>
    
</template>
<script>
let change = "#2688c4"
import {Msg, Loading} from 'components'
import {mapState,productDetail,mapGetters,mapMutations,mapActions} from 'vuex'
import {policyHealthRecord} from '../../apis/health.api'
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
import filter from "../../../../utils/filter"
//import {PAD} from "../../../../utils/PAD"

export default{
    data () {
        return {
        }
    },
    mounted(){
        //健康告知页
        SKAPP.onEvent("健康告知页", "进入健康告知页",{
            icpProductCode:sessionStorage.icpProductCode,
            insureNotice:this.$store.state.health.insureNotice
        });

        document.body.scrollTop = 0;
        switch (sessionStorage.col){
            case "B2":
                change = "#4285F6"
                break
            case "Y1":
                change = "#D8A161"
                break
            case "O1":
                change = "#FF6000"
                break
            case "R1":
                change = "#F76B6C"
                break
            case "R2":
                change = "#F11B33"
                break
            default:
                change = "#2688c4"
                break;
        }
        this.$refs.Button.style.backgroundColor = change;
        if (this.$store.state.health.select[0]) {
            this.$refs.is1.style.backgroundColor = ""
            this.$refs.not1.style.backgroundColor = ""
            this.$refs.not1.style.backgroundColor=change
        }
        if (this.$store.state.health.select[1]) {
            this.$refs.is2.style.backgroundColor = ""
            this.$refs.not2.style.backgroundColor = ""
            this.$refs.not2.style.backgroundColor=change
        }
    },
    methods: {
        next: function () {
            //提交健康告知页
            SKAPP.onEvent("健康告知页", "提交健康告知",{
                icpProductCode:sessionStorage.icpProductCode,
                healthResult:"N"
            });

            if (this.$store.state.health.select[0] && this.$store.state.health.select[1]) {

                //提交健康告知页
                SKAPP.onEvent("健康告知页", "提交健康告知",{
                    icpProductCode:sessionStorage.icpProductCode,
                    healthResult:"Y"
                });

                var saleRecordId = this.$store.state.health.saleRecordId;
                var submitData = {
                    saleRecordId: saleRecordId,
                    healthRecord: '{"H70400001":"Y","H70400002":"Y"}',
                    healthResult: 'Y'
                };
                policyHealthRecord(submitData).then((data) => {
                    if (data.data.resultCode === '00000') {
                        //成功跳转
                        this.$router.push({
                            name: 'customerInfo'
                        });
                    }else{
                        Msg.alert(filter.resultCode(data.body))
                    };
                });
            }else{
                Msg.toast('您的健康告知未通过')
            };
        },
        //clickchange: function (value) {
        //    event.target.classList.remove('first_load');
        //    if (event.target.className != 'current') {
        //        this[event.currentTarget.id] = !this[event.currentTarget.id];
        //    }
        //},
        clickchange1: function (e) {
            this.$refs.is1.style.backgroundColor = ""
            this.$refs.not1.style.backgroundColor = ""
            e.target.style.backgroundColor=change
            this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
        },
        clickchange2: function (e) {
            this.$refs.is2.style.backgroundColor = ""
            this.$refs.not2.style.backgroundColor = ""
            e.target.style.backgroundColor=change
            this.$store.commit(healthMu.setSelect,event.target.getAttribute('eq'))
        },
        gaowei: function () {
            this.$router.push({
                    name: 'GaoWei'
                });
            }
        }
    }

</script>
<style lang="less" scoped>
@import "../../../../styles/vars.less";
.health_notice{
    padding-bottom:1.6rem;
h2{font-size:1.8rem;line-height:3rem;font-weight:bold;padding:1.2rem;border-bottom: 1px solid #ececec;}
.wrap{
    overflow: hidden;
    border-bottom: 1px solid #ececec;
    position: relative;
}
.question{
    font-size: 1.6rem;
    line-height: 2.3rem;
    padding: 1.5rem 1.2rem;
    float: left;
    color: #666;
    width: 70%;
}
.ans{
    float: left;
    position: absolute;
    top: 50%;
    right: 2rem;
    transform: translateY(-50%);
    -webkit-tap-highlight-color:rgba(0,0,0,0);
}
.ans p{
    float: left;
    font-size: 1.6rem;
    padding: 1.5rem 0;
    line-height: 2.3rem;
    margin-right: 0.15rem;
}
.ans p:first-child{
    margin-right: 1rem;
}
.ans p i{
    width: 1.8rem;
    height: 1.8rem;
    border-radius: 50%;
    display: inline-block;
    border: 1px solid #ccc;
    margin-right: 0.4rem;
    vertical-align: middle;
    position: relative;
    bottom: 1px;
    box-shadow: 0 0 0px 3px #FFF inset!important;
}


.ans p i{
    position: relative;
}
.ans p i:before {
    content: '';
    position: absolute;
    top: -10px; right: -10px;
    bottom: -10px; left: -5px;
}

.ans p i.current{
    background-color: @iconfont;
    box-shadow: 0 0 0px 3px #FFF inset!important;
}

.ps{
    font-size: 1.6rem;
    line-height: 2.3rem;
    padding: 1.5rem 1.2rem 6rem 1.2rem;
}
.first_load{
    background-color: transparent !important;
    box-shadow: none !important;
}
.weui_cell {
    padding: 5px 10px;
    color: #999;
}
.footer{
    z-index: 3;
    width: 100%;
    position: fixed;
    bottom: 0;
    left:0;
    padding-left: 1rem;
    padding-right: 1rem;
    padding-top: 1rem;
    padding-bottom: 1rem;
    background-color: rgba(0, 0, 0, 0.3);
}
.btn{
    width: 100%;
    height: 4.5rem;
    background-color: @iconfont;
    border: none;
    color: #ffffff;
    line-height: 4.5rem;
    font-size: 2rem;
    border-radius: 8px;
    text-align:center

}
.weui_cell{
    padding-left: 30px;
    font-size: 1.6rem;
}
.ps{
    font-weight:700;
    text-indent:2em;
}
.alert{

}
}
</style>