<template>
<!-- 隐藏页 投保须知 -->
    <div class="insurance_noticeE">
        <h3 class="al_center" >理赔须知</h3>
        <div>
            <h4>理赔流程</h4>
            <div>
                <div>第一步：登陆平安健康险官网（http://health.pingan.com），下载理赔申请书并填写。</div>
                <div>路径如下：平安健康险官网→服务中心→常用表格及文件→事后理赔医疗理赔申请书（双语）2014版</div>
            </div>
            <div>
                第二步：您需要准备如下材料：
                <ol class="claimNotice">
                    <li>被保险人、申请人有效身份证件（复印件）</li>
                    <li>未成年人出险，需提供与申请人的关系证明（复印件）</li>
                    <li>病历资料，包括诊断证明、病理及其他各项检查检验报告（原件）</li>
                    <li>银行帐户信息：包括开户行、户名、账号（复印件）</li>
                    <li>所能提供的与确认保险事故的性质、原因等有关的其它证明和资料（原件）</li>
                    <li>当保险金作为被保险人遗产时，必须提供可证明合法继承权的相关权利文件（原件）</li>
                </ol>
            </div>
            <div>
                第三步：请将理赔申请书及理赔材料邮寄到如下地址（邮费由您负担）：
                <table cellspacing="0" class="static-tb">
                    <tbody><tr>
                        <th>邮寄地址</th>
                        <th>接收人</th>
                        <th>电话</th>
                    </tr>
                    <tr>
                        <td>上海市浦东新区上丰路1288号2号楼3楼</td>
                        <td>平安健康险上海理赔作业中心</td>
                        <td>021-38636792</td>
                    </tr>
                </tbody></table>
            </div>
        </div>
        <div>
            <h4>您需要注意的事项</h4>
           <ol class="claimNotice">
                <li>我们在接收到您的材料后将尽快处理，预计15个工作日内审核完毕。</li>
                <li>本险种有效期根据合同约定，在投保前确诊的疾病我司不承担保险责任。</li>
                <li>我们会对您投保时的健康告知进行核实，若不符合实际情况，可能影响您的赔付结论。</li>
                <li>理赔审核中，若需要您补充其他材料等情况，烦请您予以配合，以便我们尽早完成理赔。</li>
                <li>若您对理赔结果有异议，可拨打95511进行咨询。</li>
            </ol>
        </div>
    </div>
</template>
<style lang="less" scoped>
    .insurance_noticeE{
        padding:0.5rem;
        padding-left:1rem;
        padding-top:1rem;
        padding-right:1rem;
        font-size:1.5rem;

        h2,h3{font-size:1.8rem;line-height:2.2rem;}
        p{font-size:1.5rem;line-height:2rem;margin-top:0.5rem;}
        .bgc_ddd{
            background:#ddd;
        }
        .al_center{
            text-align:center;
        }
        .al_left{
            text-align:left;
        }
        .al_right{
            text-align:right;
        }
        .fs_12{
            font-size:12px;
        }
        .static-tb{
            text-align: center;
        }
        h4{
            font-weight:700;
            font-size:1.5rem;
        }

        ol{
            li{
                text-indent:2em;
            }
        }
        table{
            margin:0 auto;
            text-algin: center;
        }
        td,th{
            border:1px solid #000;
        }

    }
</style>
