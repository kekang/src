<template>
    <div class="product">
        <header>
            <ul @click="product">
                <li :style="{color:productCol}">
                    <p ref="arrowCon1" :style="{color:productCol}" id="pro" >
                    产品详情
                        <span :style="{color :fontColor}"></span>
                    </p>
                </li>
                <li  :style="{color:productCla}" >
                    <p ref="arrowCon2" :style="{color:productCla}" id="claim">
                    理赔流程
                        <span ref="arrowCon2"  :style="{color :fontColor}"></span>
                    </p>
                </li>
                <li :style="{color:productQue}">
                    <p ref="arrowCon3" :style="{color:productQue}" id="questions">
                    常见问题
                        <span :style="{color :fontColor}" ref="arrowCon3"></span>
                    </p>
                </li>
            </ul>
        </header>
        <!--产品详情-->
    <article class="productDetail" v-show="productDetail1">
        <section class="productDetailTitle">
            <p v-for="detail in details">{{detail}}</p>
        </section>
        <section class="productDetailContent">
            <table class="tablePeo">
                <tr>
                    <td class="forPeople1">
                        <span class="iconPeople" :style="{color :fontColor}"></span>
                        <span class="forPeople">适用人群</span>
                    </td>
                    <td class="forPeopleCon">
                        <span>{{productDetail.qualifiedCrowd}}</span>
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <td class="period">
                    <span class="iconPeriod" :style="{color :fontColor}"></span>
                    <span class="insurPeriod">保险期限</span>
                    </td>
                    <td class="forPeopleCon">
                    <span>{{period}}个月</span>
                    </td>
                </tr>
            </table>
        </section>
    </article>
        <!--理赔流程-->
    <article class="claimProcess" v-show="claimProcess">
        <section class="productDetailTitle special">
            <p>平安将为您提供7*24小时理赔服务。当您发生保险事故后，请按照以下流程申请理赔</p>
        </section>
        <section class="claimProcess1">
            <p class="tel icon icon-lipei" :style="{color : fontColor}">
                <span class="time-line-line1" :style="{backgroundColor:fontColor}"></span>
                <span class="telTil" :style="{color : fontColor}">拨打95511报案</span>
                <span class="telCon">拨打平安全国统一报案电话95511</span>
            </p>
            <p class="adv icon icon-lipei3" :style="{color : fontColor}">
                <span class="time-line-line1" :style="{backgroundColor:fontColor}"></span>
                <span class="advTil" :style="{color : fontColor}">理赔相关资讯</span>
                <span class="telCon">专业人员将协助指导办理理赔</span>
            </p>
            <p class="send icon icon-lipei2" :style="{color : fontColor}">
                <span class="time-line-line1" :style="{backgroundColor:fontColor}"></span>
                <span class="sendTil" :style="{color : fontColor}">寄送理赔材料</span>
                <span class="telCon">准备好相关证明和票据，寄送至指定地点</span>
            </p>
            <p class="exa icon icon-lipei1" :style="{color : fontColor}">
                <span class="exaTil" >审核</span>
                <span class="telCon">确实保险责任范围的事故并在有效期范围内赔付结案，支付赔款</span>
            </p>
        </section>
    </article>
        <!--常见问题-->
    <article class="question" v-show="question">
        <section class="productDetailContent special">
            <p class="qus" v-for="item of quesAns">
                <span class="qusTil" :style="{color : fontColor}" v-html="'Q:'+item.question"></span>
                <span class="qusCon"  v-html="item.answer"></span>
            </p>
        </section>
    </article>
    </div>
</template>
<style scoped lang="less">
@import "../../../../styles/vars.less";
@import "../../../../assets/iconfonts/health/iconfont.css";

.time-line-line1{

    position: absolute;
    left: 3.8rem;
    height: 4rem;
    width: 1px;
    /*background: @iconfont;*/
    top:3.5rem
}
.arrow{
    height: 5rem;

}
.arrow:before{
    font-family: "health" !important;
    font-size: 0.98rem;
    font-style: normal;
    position: absolute;
    content: "\e60a";
    left: 0;
    top: 1.7rem;
}
.arrow1{
    height: 5rem;
    font-size: 10px
}
.arrow1:before{
    font-family: "health" !important;
    /*font-size: 0.98rem;*/
    font-style: normal;
    position: absolute;
    content: "\e60b";
    left: 0;
    top: 1.7rem;
    font-size: 10px
}
/*I5*/
@media screen and (min-width: 320px) and (max-width: 350px) {
.arrow:before,.arrow1:before {font-size: 8px}
}
@media screen and (min-width: 350px) and (max-width: 375px) {
    .arrow:before,.arrow1:before {font-size: 9px}
}
/*I6*/
@media screen and (min-width: 375px) and (max-width: 414px) {
.arrow:before,.arrow1:before {font-size: 10px}
}
/*I6P*/
@media screen and (min-width: 414px) and (max-width: 568px) {
.arrow:before,.arrow1:before {font-size: 11px}
}
/*横屏*/
@media screen and (min-width: 569px) and (max-width: 667px) {
.arrow:before,.arrow1:before {font-size: 17px}
}
@media screen and (min-width: 667px) and (max-width: 737px) {
.arrow:before,.arrow1:before {font-size: 18px}
}
/*Ipad*/
@media screen and (min-width: 737px){
.arrow:before,.arrow1:before {font-size: 19px}
}
.product{
    background-color: @background-color-white;
}
header{
    height:4.5rem;
>ul{
    >li{
            width: 33.33%;
            font-size: 1.7rem;
            float: left;
            text-align: center;
            height:4.5rem;
            line-height: 4.5rem;
            overflow: hidden;
            >p{
                position: relative;
             }
        }
    }
}
.forPeople1{
    padding-left: 2rem;
    line-height: 4.5rem;
    font-size: 1.5rem;
    /*background: url(../../../../assets/images/health/forPeople.png) no-repeat 2rem center;*/
    /*background-size: 2.7rem 2.7rem;*/
    border-bottom: 1px dashed @font-color-grey;
    width: 38%;
    /* margin-left: 1rem; */
    white-space: nowrap;

>.forPeople{
        margin-left: 1.5rem;
        margin-right: 1.5rem;
    }
>span{
        color: @font-color-black;
    }
}
.iconPeople,.iconPeriod{
    display: inline-block;
    top: .5rem;
    position: relative;
}
.iconPeople:before{
    font-family: "health" !important;
    font-size: 2.7rem;
    font-style: normal;
    /*color: @iconfont;*/
    position: relative;
    content: "\e607";
}
.iconPeriod:before{
    font-family: "health" !important;
    font-size: 2.7rem;
    font-style: normal;
    /*color: @iconfont;*/
    position: relative;
    content: "\e604";
}

.period{
    padding-left: 2rem;
    line-height: 4.5rem;
    font-size: 1.5rem;
    width: 38%;
    /* margin-left: 1rem; */
    white-space: nowrap;
>.insurPeriod{
        margin-left: 1.5rem;
        margin-right: 1.5rem;
    }
>span{
        color: @font-color-black;
    }
}
.forPeopleCon{
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
    font-size: 1.5rem;
    padding-right: 2rem;
}
.forPeopleCon>span{
    color:#666666
}
table{
    width: 100%;
}
.tablePeo{
    border-bottom: 1px dashed @font-color-grey;
}
.claimProcess{
    position: relative;
}
.productDetail,.claimProcess{
>.productDetailTitle{
        padding-left: 2rem;
        font-size: 1.5rem;
        color:@font-color-black;
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
        padding-right: 2rem;
    }
>.productDetailContent{
        border-top: 1px dashed @font-color-grey;
    >p{
            height:4.5rem;
            padding-left: 2rem;
            line-height: 4.5rem;
            font-size: 1.5rem;
        >.forPeople{
                margin-left: 4.2rem;
                margin-right: 1.5rem;
            }
        >span{
                color: @font-color-black;
            }
        }
    >p:last-child{
            border-bottom: none;
        }
    >.period{
            background: url(../../../../assets/images/health/period.png) no-repeat 2rem center;
            background-size: 2.7rem 2.7rem;
        >.insurPeriod{
                margin-left: 4.2rem;
                margin-right: 1.5rem;
            }
        }
    }

}
.icon{
    font-size: 3.6rem;
    font-style: normal;
    color: @iconfont;
    position: relative;
}
.icon-lipei:before {
    content: "\e601";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}
.icon-lipei3:before {
    content: "\e605";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}
.icon-lipei2:before {
    content: "\e603";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}
.icon-lipei1:before {
    content: "\e602";
    position: absolute;
    margin-left: 2rem;
    top:-0.8rem;
    font-family: "health" !important;
}

.telTil,.advTil,.sendTil,.exaTil{
    margin-bottom: 1rem;
    display: block;
    margin-left: 7.1rem;
    font-size:1.7rem;
    /*color:@font-color-blue;*/
    margin-top: 1.5rem;
}
.telCon{
    /*margin-bottom: 1.5rem;*/
    display: block;
    margin-left: 7.1rem;
    font-size: 1.5rem;
    color: #666666;
    margin-right: 2rem;
}
.claimProcess1{
    padding-bottom: 1.5rem;
}
.claimProcess,.question {
>.special {
        padding-bottom: 0;
    }
}
.question{
>.productDetailContent{
        padding-top: 1.5rem;
        /*padding-bottom: 1.5rem;*/
    }
}
.qus{
    margin-right: 2rem;
    margin-left: 2rem;
    padding-bottom:1.5rem;
>.qusTil{
        display: block;
        font-size: 1.5rem;
        /*color:@font-color-blue ;*/
        margin-bottom: 1rem;
    }
>.qusCon{
        display: block;
        font-size: 1.5rem;
        color: #666666;
    }
}
</style>
<script>
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
import {changeColor} from "../../../../utils/skin"
import {quesAndAns} from "../../../../utils/quesAndAns.js"
//import "../../../../utils/PAD"

let change = "#2688c4",lineChange = "#bcbcbc"
export default{
    data(){
        return{
            productDetail1:true,
            claimProcess:false,
            question:false,
            productCol:"#2688c4",
            productCla:"#bcbcbc",
            productQue:"#bcbcbc",
            fontColor:"#2688c4",
        }
    },
    updated(){
        if(this.productDetail){
            if(this.productDetail.askedQuestions){
                this.quesAns = quesAndAns()[this.productDetail.askedQuestions]
            }else{
                this.quesAns = quesAndAns().QA00030000
            }
        }
    }

    ,
    mounted(){
        change = changeColor()
        this.productCol = change
        this.productCla = lineChange
        this.productQue = lineChange
        this.fontColor = changeColor()
        this.productCol = changeColor()
        this.$refs.arrowCon1.children[0].className = "arrow"
        this.$refs.arrowCon2.children[0].className = "arrow1"
        this.$refs.arrowCon3.children[0].className = "arrow1"
        //浏览产品详情
        //SKAPP.onEvent("产品详情页", "浏览产品详情",{
            //icpProductCode:sessionStorage.icpProductCode,
        //});
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
            "浏览产品":"产品详情"
        });
    },
    methods:{
        product(e){
            let target = e.target
            if(target.nodeName == "SPAN"){
                target = target.parentNode
            }
            switch(target.id){
                case"pro":
                    //内容切换
                    this.productDetail1 = true;
                    this.claimProcess = false;
                    this.question = false;
                    //箭头切换
                    this.$refs.arrowCon1.children[0].className = "arrow"
                    this.$refs.arrowCon2.children[0].className = "arrow1"
                    this.$refs.arrowCon3.children[0].className = "arrow1"
                    //线条颜色
                    this.productCol = change
                    this.productCla = lineChange
                    this.productQue = lineChange
                    //浏览产品详情
                    //SKAPP.onEvent("产品详情页", "浏览产品详情",{
                        //icpProductCode:sessionStorage.icpProductCode,
                    //})
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "浏览产品":"产品详情"
                    });;
                    break;
                case"claim":
                    this.productDetail1 = false;
                    this.claimProcess = true;
                    this.question = false;
                    this.$refs.arrowCon1.children[0].className = "arrow1"
                    this.$refs.arrowCon2.children[0].className = "arrow"
                    this.$refs.arrowCon3.children[0].className = "arrow1"
                    this.productCol = lineChange
                    this.productCla = change
                    this.productQue = lineChange
                    //浏览理赔流程
                    //SKAPP.onEvent("产品详情页", "浏览理赔流程",{
                        //icpProductCode:sessionStorage.icpProductCode,
                    //});
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "浏览产品":"理赔流程"
                    });
                    break;
                case"questions":
                    this.productDetail1 = false;
                    this.claimProcess = false;
                    this.question = true;
                    this.$refs.arrowCon1.children[0].className = "arrow1"
                    this.$refs.arrowCon2.children[0].className = "arrow1"
                    this.$refs.arrowCon3.children[0].className = "arrow"
                    this.productCol = lineChange
                    this.productCla = lineChange
                    this.productQue = change
                    //浏览常见问题
                    //SKAPP.onEvent("产品详情页", "浏览常见问题",{
                        //icpProductCode:sessionStorage.icpProductCode,
                    //});
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "浏览产品":"常见问题"
                    });
                    break;
            }
        }
    },
    computed: {
    ...mapState({
            productDetail:state=>state.health.productDetail,
            details:state=>state.health.details,
            period(state){
                switch(state.health.productDetail.insurePeriodType){
                    case"Y":
                        return state.health.productDetail.insurePeriod*12
                    case"M":
                        return state.health.productDetail.insurePeriod
                    case"D":
                        return parseInt(state.health.productDetail.insurePeriod/30)
                }
            }
    }),
}

}
</script>
