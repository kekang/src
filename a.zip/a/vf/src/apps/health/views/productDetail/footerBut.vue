<template>
    <div>
        <section class="service">
            <p>
                <input type="checkbox" class="HP-ui-input-group-radio" name="4" id="check-0" hidden ref="checkbox" @click="check">
                <label for="check-0" :style="{color : fontColor}"></label>
                <span style="color:#666666">我已阅读并同意</span>
                <span @click="skip1('service')" class="serviceContext">《投保须知和保险条款内容》</span>
            </p>
        </section>
        <div class="footPrice">
            <p class="price">
                <i @click="kefu" class="iconfont icon-kefu" :style="{color:fontColor}"></i>
                <span>优惠价：￥<span class="priceNum" :style="{color:fontColor}">{{saleAmount}}</span></span>
            </p>
            <p class="buy" :style="{backgroundColor:fontColor}" @click="skip('select')">
                <span >立即投保</span>
            </p>
        </div>
    </div>
</template>
<style lang="less" scoped>
    @import "../../../../styles/vars.less";
    @import "../../../../assets/kefu/iconfont.css";
    .service{
        height: 4.5rem;
        line-height: 4.5rem;
        margin-top: 1rem;
        background-color: #e4e4e4;
        padding-bottom: 12rem;
        >p{
             height: 4.5rem;
             line-height: 4.5rem;
             padding-left: 2rem;
             font-size: 1.5rem;
             background-color: @background-color-white;
            .serviceContext{
                color: @font-color-blue;
            }
        }
    }
    footer{
        height: 6.5rem;
        position: fixed;
        bottom: 0;
        width: 100%;
    }
    .footPrice{
        padding: 1rem 1rem;
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 6.5rem;
        float: left;
        background-color: rgba(0, 0, 0, 0.3);

        >.price{
             border-bottom-left-radius: 0.8rem;
             border-top-left-radius: 0.8rem;
             padding-left: 1rem;
             height: 4.5rem;
             line-height: 4.3rem;
            float:left;
             width: 65%;/*58*/
             display: inline-block;
             font-size: 1.7rem;
             color:@font-color-black;
             background-color: @background-color-white;
             float: left;
            >i{
                font-size: 2.2rem;
                margin-right: 1.5rem;
                margin-left: .5rem;
            }
         }
        >.buy{
             height: 4.5rem;
             line-height: 4.5rem;
             width: 35%;/*42*/
             float:left;
             display: inline-block;
             /*background-color: @font-color-blue;*/
             border-radius: 0.8rem;
             border-top-left-radius: 0rem;
             border-bottom-left-radius: 0rem;
             color: @font-color-white;
             text-align: center;
             font-size: 1.7rem;
         }
    }
    .priceNum{
        color:@font-color-blue
    }
    .HP-ui-input-group-radio +label{
        -webkit-appearance: none;
        background-color: #fafafa;
        border: 1px solid @font-color-grey;
        padding: 0.7rem;
        display: inline-block;
        border-radius:0.4rem;
        position: relative;
        top:3px
    }

    .HP-ui-input-group-radio+label{
        background-color: #fff;
        border: 1px solid @font-color-grey;
        position: relative;
    }
    .HP-ui-input-group-radio+label::before {
        content: '';
        position: absolute;
        top: -15px;
        right: -15px;
        bottom: -15px;
        left: -15px;
    }
    .HP-ui-input-group-radio:checked+label:before{
        font-family: "health" !important;
        content: "\e63a";
        /*color: @iconfont;*/
        width: 1.5rem;
        height: 1.1rem;
        position: absolute;
        top: -1.5rem;
        text-shadow: 0px;
        font-size: 1.5rem;
        left: 0px;
        font-size: 15px;
    }

    @media screen and (min-width: 320px) and (max-width: 350px) {
        .HP-ui-input-group-radio:checked+label:before{top: -13px;font-size: 12px;}
    }
</style>
<script>
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import {Msg,Loading} from 'components'
    import { policyInquiry,ahPolicyInsure,policyHealthRecord} from '../../apis/health.api.js'
    import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
    import * as healthAc from "../../vuex/actionTypes/health.action.types"
    import {changeColor} from "../../../../utils/skin"
    import filter from "../../../../utils/filter"

    export default{
        data(){
            return{
                lock:false,
                context:"",
                fontColor:"#2688c4",
                model:true
            }
        },
        mounted(){
            this.fontColor = changeColor();

        },
        methods: {
            kefu(){
                location.href = 'https://ziker-talk.yun.pingan.com/appIm/?msgInfo=&channel=APPIM&authorizerAppid=appimc283aec44342e0a&eid=b3db08dad71ec8b41b6e7253fe86076c';
            },
            skip () {
                if (this.lock) {

                    let dutyMore = []
                    for(let i =0;i<this.$store.state.health.duty.dutys.length;i++){
                        dutyMore.push({combinedDutyId:this.$store.state.health.duty.dutys[i].combinedDutyId})
                    }

                    //立即投保
                    //SKAPP.onEvent("产品详情页", "提交立即投保",{
                        //icpProductCode:this.$store.state.health.productDetail.icpProductCode,
                    //});
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "立即投保按钮":'立即投保'
                    });

                    let _obj = {
                        idProductCombined: this.$store.state.health.idProductCombined,
                        icpProductCode: this.$store.state.health.icpProductCode,
                        dutys: dutyMore,
                        saleAmount: this.$store.state.health.saleAmount,
                        partnerCode: sessionStorage.partnerCode,
                        //userId: sessionStorage.userId,
                        effDate: this.$store.state.health.effDate,
                        saleRecordId: this.$store.state.health.saleRecordId,
                        dataSource: this.$store.state.health.dataSource
                        //remark: sessionStorage.remark
                    };
                    if(sessionStorage.userId) _obj.userId = sessionStorage.userId;
                    if(sessionStorage.remark) _obj.remark = sessionStorage.remark;
                    ahPolicyInsure(_obj).then(
                            (msg) => {
                                if (msg.body.resultCode == "00000") {
                                    this.$store.commit(healthMu.setSaleRecordId, msg.body)
                                    sessionStorage.saleRecordId = msg.body.saleRecordId
                                    if (this.$store.state.health.productDetail.hasHealth == "Y") {
                                        this.$router.push({name: this.$store.state.health.insureNotice})
                                    } else {
                                        let healthNotice = {
                                            ICPH000009:{
                                                saleRecordId: this.$store.state.health.saleRecordId,
                                                healthRecord: '{"H75400001":"Y"}',
                                                healthResult: 'Y'
                                            },
                                            ICPH000010:{
                                                saleRecordId: this.$store.state.health.saleRecordId,
                                                healthRecord: '{"H75400001":"Y"}',
                                                healthResult: 'Y'
                                            }
                                        }

                                        for(let i in healthNotice){
                                            if(sessionStorage.icpProductCode == i){
                                                policyHealthRecord(healthNotice[i]).then((data) => {
                                                    if (data.data.resultCode === '00000') {
                                                    this.$router.push({name: "customerInfo"})
                                                }else{
                                                    Msg.alert(filter.resultCode(data.body))
                                                };
                                            })
                                            }
                                        }



                                    }
                                }else {
                                    Msg.alert(filter.resultCode(msg.body))
                                }
                            }
                    )
                } else {
                    Msg.alert('请先勾选投保须知')
                }
            },
            skip1(){
                this.$router.push({'name':"noticeNav"})
            },
            check(event){
                this.lock = event.target.checked;
                if(this.lock){
                    //勾选投保须知
                    //SKAPP.onEvent("产品详情页", "同意投保须知",{
                        //icpProductCode:this.$store.state.health.productDetail.icpProductCode,
                    //});
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "同意投保须知":"同意"
                    });
                }else{
                    SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                        "同意投保须知":"不同意"
                    });
                }
            }
        },
        computed: {
            ...mapState({
                saleAmount:state=>state.health.saleAmount
            }),
        }
    }
</script>
