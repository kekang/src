<template>
    <div class="protection">
        <header>
            <p :style="{color:fontColor}">保障计划</p>
        </header>
        <article>
            <section class="protectionCon">
                <ul>
                    <li>
                        <span>被保人</span>
                        <span @click="choosesex" class="sextype">{{sexChoose}}</span>
                        <popup v-model="popupVisible" position="bottom">
                            <div class="showBar">
                                <span class="cancle" @click="cancle" :style="{color : fontColor}">取消</span>
                                <span class="confirm" @click="confirmSex" :style="{color : fontColor}">确认</span>
                            </div>
                            <div class="page-picker-wrapper">
                                <picker :slots="dataSlots" @change="onValuesChange" :valueKey="personName">
                                </picker>
                            </div>
                        </popup>
                    </li>
                    <li v-if="needInsurBirthday">
                        <span>出生日期</span>
                        <span @click="openBirth" class="sextype">{{time}}</span>
                    </li>
                    <li>
                        <span>生效日期</span>
                        <span @click="openDataEff" class="sextype">{{effTime}}</span>
                        <datetime-picker
                                ref="picker"
                                type="date"
                                :startDate= "start"
                                :endDate="end"
                                v-model="startDate1"
                                @confirm="handleConfirm"
                                :TPick="TPick"
                        >
                        </datetime-picker>
                        <datetime-picker
                                ref="pickerEff"
                                type="date"
                                :startDate= "startEff"
                                :endDate="endEff"
                                @confirm="handleConfirmEff"
                        >
                        </datetime-picker>
                    </li>
                    <li style="background: none" v-if="needSocialSecurity">
                        <span>社保</span>
                        <p class="society">
                            <span class="hasSociety" ref="hasSociety" @click="society('Y')">有</span>
                            <span class="noSociety" ref="noSociety" @click="society('N')"
                                  style="color:#666666;background-color: #BCBCBC;">无</span>
                        </p>
                    </li>
                </ul>
            </section>
            <section class="protectionType">
                <div>
                    <ul class="special1">
                        <li v-for="(item,index) of dutys" :style="{ width : comWith }"
                            class="special" ref="special">
                            <span @click="combined" :id="index" ref="change">{{item.combinedName}}</span>
                            <i :id="index" ref="isSelected" class="isSelected"></i>
                        </li>
                    </ul>
                </div>
                <div v-for="(item,index) of duty">
                    <ul>
                        <li id="dutyName" @click="combinedCon" :data-id="index" ref="changeCon">
                            <p class="arrow" :data-id="index">
                                <span :data-id="index" style="color:#666">{{item.dutyName}}</span>
                                <span :data-id="index" class="arrowCon">{{item.amountName}}</span>
                            </p>
                            <p class="undwrt" v-show="range" :data-id="index">{{undwrtRange}}</p>
                        </li>
                    </ul>
                </div>
            </section>
        </article>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";

    article{
        background-color: @background-color-white;
    }
    .society{
        float: right;
        margin-right: 1rem;
    }

    .hasSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        margin-right: 1rem;
        border-radius: 4px;
    }
    .noSociety{
        color: white;
        background-color: rgb(50, 188, 253);
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        padding-left: 1.1rem;
        padding-right: 1.1rem;
        border-radius: 4px;
    }
    .showBar{
        height: 40px;
        border-bottom: solid 1px #eaeaea;
    }
    .cancle{
        display: inline-block;
        font-size: 16px;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: left;
    }
    .confirm{
        display: inline-block;
        font-size: 16px;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: right;
    }
    .protection{
        margin-top: 1rem;
        margin-left:1rem;
        margin-right:1rem;
        border-radius:0.8rem;
    >header{
         height: 4.5rem;
         background-color:@background-color-light;
         line-height:4.5rem;
         border-top-left-radius: 0.8rem;
         border-top-right-radius: 0.8rem;
    >p{
         font-size: 1.7rem;
         /*color:@font-color-blue;*/
         text-align: center;
     }
    };
    >article{
         border-bottom-right-radius: 0.8rem;
         border-bottom-left-radius: 0.8rem;
     }
    }
    .protectionCon{
    >ul{
    >li{
         height: 4.5rem;
         line-height: 4.5rem;
         font-size: 1.5rem;
         padding-left: 1rem;
         border-bottom: 1px dashed @font-color-grey;
         background: url(../../../../assets/images/health/arrow.png) no-repeat right 0.6rem center;
         background-size: 1.1rem 1.1rem;
    >span{
         color: #666666;
     }
    }
    }
    }
    .protectionType{
    /*height:4.5rem;*/
    >div{
    >ul{
         overflow:hidden;
    >li{
         /*width: 33%;*/
         font-size: 1.5rem;
         float: left;
         text-align: center;
         /*height:4.5rem;*/
         line-height: 4.5rem;
     }
    }
    }
    >div:last-child{
    >ul>li>p{
         border-bottom: none;
     }
    >ul>li>p:last-child{
         border-top: 1px dashed @font-color-grey;
     }
    }
    }
    .special{
        border-bottom: 1px solid @font-color-grey;
    >span{
         width: 100%;
         display: inline-block;
         color: @font-color-grey;
     }
    }
    .special1>li:first-child{
        border-bottom: 1px solid @font-color-blue;
    >span{
     }
    }
    .sextype{
        float: right;
        text-align: right;
        margin-right: 2.6rem;
        /*width: 30%;*/
        position: relative;
    }
    .sextype::before {
        content: '';
        position: absolute;
        top: 0px; right: -2.6rem;
        bottom: 0px; left: 0px;
    }
    #dutyName{
        /*height: 4.5rem;*/
        /*width: 100%;*/
        text-align: left;
        /*margin-left: 1rem;*/
        float: none;
    >li{
    >p{
         color:#666666;
     }
    }
    }
    .undwrt{
        border-bottom: 1px dashed @font-color-grey;
        line-height: 2rem;
        padding-right: 1rem;
        padding-left: 1rem;
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
        font-size: 1.3rem;
        color: #797979;
    }
    .arrow{
        height: 4.5rem;
        line-height: 4.5rem;
        background: url(../../../../assets/images/health/arrow.png) no-repeat right 0.6rem center;
        background-size: 1.1rem 1.1rem;
        /*margin-right: 0.6rem;*/
        padding-left: 1rem;
        border-bottom: 1px dashed #BCBCBC;
    }
    .arrow-b{
        height: 4.5rem;
        line-height: 4.5rem;
        background: url(../../../../assets/images/health/arrow1.png) no-repeat right 0.6rem center;
        background-size: 1.1rem 1.1rem;
        /*margin-right: 0.6rem;*/
        padding-left: 1rem;
        border-bottom: 1px dashed #BCBCBC;
    }
    .arrowCon{
        float: right;
        margin-right: 2.6rem;
        color: #666666;
    }
    .isSelected{
        width: 100%;
        display: none;
        height: 2px;
        background-color: @font-color-blue;
        margin-bottom: -3px;
    }
</style>
<script>

    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
    import * as healthAc from "../../vuex/actionTypes/health.action.types"
    import {changeColor} from "../../../../utils/skin"
    import filter from "../../../../utils/filter"
    import { policyInquiry} from '../../apis/health.api.js'
    import {DateFormat} from '../../../../utils/tool'


    export default{
        data(){
            return{
                startDate1:new Date(),
                TPick:"end",

                personProducts:[],
                popupVisible:false,
                undwrtRange:"",
                range:false,
                comWith:"",
                dataSlots: [
                    {
                        flex: 1,
                        values: [],
                        className: 'slot1',
                        textAlign: 'center',
                        defaultIndex:0
                    }
                ],
                defIndex:"0",
                flag:0,
                fontColor:"#2688c4",
                flagColor : 0,
                flagSwipe:0,
                flagDuty:0,
                visible:false,
                flagSociety:true
            }
        },
        components:{
            datetimePicker,
            picker,
            popup
        },
        mounted(){
            this.fontColor = changeColor();
        },
        updated:function () {
            //换颜色，烂代码
            if(this.flagColor == 0){
                if(this.$refs.changeCon){
                    this.$refs.change[0].style.color = this.fontColor
                }
                if(this.$refs.special){
                    this.$refs.special[0].style.borderBottomColor = this.fontColor
                    this.$refs.isSelected[0].style.backgroundColor = this.fontColor
                    this.flagColor ++;
                }
            }
            //改变社保颜色
            if(this.$refs.hasSociety && this.flagSociety){
                this.$refs.hasSociety.style.backgroundColor=this.fontColor
                this.flagSociety= false
            }
            //设置初始社保颜色
            if(this.$refs.hasSociety && this.$refs.noSociety){
                switch(this.$store.state.health.hasSocialSecurity){
                    case "Y":
                        this.$refs.noSociety.style.color ="#666666"
                        this.$refs.noSociety.style.backgroundColor ="#BCBCBC"
                        this.$refs.hasSociety.style.backgroundColor = this.fontColor
                        this.$refs.hasSociety.style.color = "white"
                        break;
                    case "N":
                        this.$refs.hasSociety.style.color ="#666666"
                        this.$refs.hasSociety.style.backgroundColor ="#BCBCBC"
                        this.$refs.noSociety.style.backgroundColor = this.fontColor
                        this.$refs.noSociety.style.color = "white"
                        break;
                }
            }
            //设置初始责任选择
            if(this.$refs.special && this.$refs.changeCon && this.flagDuty == 0){
                this.flagDuty ++
                this.$refs.special[0].children[0].style.color = "#BCBCBC"
                this.$refs.special[0].style.borderBottomColor = "#BCBCBC"
                this.$refs.special[0].style.fontWeight = "normal"
                this.$refs.isSelected[0].style.display = "none"

                for(let i=0;i<this.$store.state.health.dutys.length;i++){
                    if(this.$store.state.health.duty.combinedOrder == this.$store.state.health.dutys[i].combinedOrder){
                        this.$refs.special[i].children[0].style.color = this.fontColor
                        this.$refs.special[i].style.borderBottomColor = this.fontColor
                        this.$refs.special[i].style.fontWeight = "bold"
                        this.$refs.isSelected[i].style.display = "block"
                        this.$refs.isSelected[i].style.backgroundColor = this.fontColor
                    }
                }
            }
        },

        methods:{
            onValuesChange(picker, values) {
                this.sexType = values[0];
            },
            confirm(values){
                this.popupVisible = false;
            },
            confirmSex(){

                let Index;
                //values暂时不支持数组对象
                for(let i = 0;i<this.dataSlots[0].values.length;i++){
                    if(this.sexType == this.dataSlots[0].values[i])
                        Index = i;
                }
                this.$store.commit(healthMu.setSexZH,this.$store.state.health.crowd[Index].personName)
                this.$store.commit(healthMu.setSex,this.$store.state.health.crowd[Index].gender)

                if(this.$store.state.health.crowd[Index].insType[0].defaultValue){
                    this.$store.commit(healthMu.setAge,this.$store.state.health.crowd[Index].insType[0].defaultValue)
                }else{
                    this.$store.commit(healthMu.setAge,this.$store.state.health.crowd[Index].personMinAge)
                }
                //重置设置生日
                if(this.$store.state.health.age == 0){
                    let birthTime = Date.parse(new Date(new Date().getFullYear(),
                            new Date().getMonth(),
                            new Date().getDate()))
                    let newBirth = birthTime - 28*(60*60*24*1000)

                    let comBirth = DateFormat(new Date(newBirth),"yyyyMMdd")
                    this.$store.commit(healthMu.setinsureBirthday,comBirth)
                }else{

                    let timestamp = Date.parse(new Date(new Date().getFullYear()-this.$store.state.health.age,
                            new Date().getMonth(),new Date().getDate()));
                    timestamp = timestamp - 1*24*60*60*1000

                    let comBirth = DateFormat(new Date(timestamp),"yyyyMMdd")

                    this.$store.commit(healthMu.setinsureBirthday,comBirth)
                }
                //重置dutys
                //根据选择的人群，选择套餐
                this.$store.commit(healthMu.setPersonProduct,Index)
                //重置duty
                this.$store.commit(healthMu.setDuty,0)

                //最小最大年龄改变了
                this.$store.commit(healthMu.seteffAge,this.$store.state.health.effDate)

                //动态计算宽度
                if(this.$store.state.health.personProduct){
                    let numlength = this.$store.state.health.personProduct.length
                    let test = parseInt(1/numlength*100)
                    this.comWith = test + '%'
                }

                //重置责任
                this.$refs.special[0].children[0].style.color = this.fontColor
                this.$refs.special[0].style.borderBottomColor = this.fontColor
                this.$refs.special[0].style.fontWeight = "bold"
                this.$refs.special[0].children[0].style.fontWeight = "bold"
                this.$refs.isSelected[0].style.display = "block"
                this.$refs.isSelected[0].style.backgroundColor = this.fontColor

                for(let i = 1;i< this.$store.state.health.dutys.length ; i++){
                    if(this.$refs.special[i]){
                        this.$refs.special[i].children[0].style.color = "#BCBCBC"
                        this.$refs.special[i].style.borderBottomColor = "#BCBCBC"
                        this.$refs.special[i].style.fontWeight = "normal"
                        this.$refs.isSelected[i].style.display = "none"
                    }
                }

                this.popupVisible = false
                this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
                //重置时间选择器插件
                this.flag = 0;
                this.TPick = "end"
                //选择人群埋点
                //SKAPP.onEvent("产品详情页", "选择人群",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //idPersonType:this.$store.state.health.crowd[Index].idPersonType
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "选择人群":this.$store.state.health.crowd[Index].idPersonType
                });
            },
            cancle(){
                this.popupVisible = false
            },
            openDataEff(){
                this.$refs.pickerEff.open();
            },
            openBirth(){
                if(this.flag == 0){
                    this.startDate1 = this.end;
                }
                this.TPick = "start"
                this.$refs.picker.open();
                this.flag++
            },
            choosesex(){
                this.dataSlots[0].values = this.chooseSex;
                this.popupVisible = true
            },
            handleConfirm(confirm){

                let insureBirthday = DateFormat(confirm,"yyyyMMdd")

                let timestampBirth = Date.parse(confirm)

                let age = filter.jsGetAge(new Date(timestampBirth),new Date())

                this.$store.commit(healthMu.setinsureBirthday,insureBirthday)
                this.$store.commit(healthMu.setAge,age)

                this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
                //选择生日埋点
                //SKAPP.onEvent("产品详情页", "选择生日",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //insureBirthday:insureBirthday
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "选择生日":insureBirthday.indexOf('-') > -1 ? insureBirthday.substring(0,7) : insureBirthday.substring(0,6)
                });

            },
            handleConfirmEff(confirm){

                let effDateCom = DateFormat(confirm,"yyyyMMdd")
                this.$store.commit(healthMu.seteffDate,effDateCom);
                this.$store.commit(healthMu.seteffAge,effDateCom);
                //this.effTime = year + '-' + month + "-" + day;
                this.$store.commit(healthMu.setNewtime,Date.parse(confirm))

                this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
                //选择有效期
                //SKAPP.onEvent("产品详情页", "选择生效日",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //effDate:this.effDateCom
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "选择生效日":effDateCom.indexOf('-') > -1 ? effDateCom.substring(0,7) : effDateCom.substring(0,6)
                });
            },
            combined(event){
                let change = this.fontColor;
                for(let i = 0;i<this.$refs.change.length;i++){
                    if(event.target.id == i){
                        this.$refs.change[i].style.color=change;
                        this.$refs.change[i].parentElement.style.borderBottomColor = change;
                        this.$refs.special[i].style.fontWeight = "bold"
                        this.$refs.isSelected[i].style.display = "block"
                        this.$refs.isSelected[i].style.backgroundColor = this.fontColor
                    }else{
                        this.$refs.change[i].style.color="#bcbcbc";
                        this.$refs.change[i].parentElement.style.borderBottomColor = "#bcbcbc"
                        this.$refs.special[i].style.fontWeight = "normal"
                        this.$refs.isSelected[i].style.display = "none"

                    }
                }
                this.$store.commit(healthMu.setcombinedName,this.$store.state.health.dutys[event.target.id])
                this.$store.commit(healthMu.setDuty,event.target.id);

                this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
                //选择套餐
                //SKAPP.onEvent("产品详情页", "选择套餐",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //combinedName:this.$store.state.health.duty.combinedName,
                    //idProductCombined:this.$store.state.health.duty.idProductCombined
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "选择套餐":this.$store.state.health.duty.idProductCombined
                });
            },
            combinedCon(event){
                if (this.$refs.changeCon[event.target.dataset.id]) {
                    if (this.$refs.changeCon[event.target.dataset.id].firstChild.className == "arrow-b") {
                        this.$refs.changeCon[event.target.dataset.id].firstChild.className = "arrow"
                    } else {
                        this.$refs.changeCon[event.target.dataset.id].firstChild.className = "arrow-b"
                    }
                    let dutyItemsNum = this.$store.state.health.duty.dutys[event.target.dataset.id].dutyId//获取编号
                    for (let i in this.$store.state.health.dutyItems) {
                        if (i == dutyItemsNum) {
                            this.$refs.changeCon[event.target.dataset.id].children[1].innerHTML
                                    = this.$store.state.health.dutyItems[i].undwrtRange
                            if (this.$refs.changeCon[event.target.dataset.id].children[1].style.display == "block" ) {
                                this.$refs.changeCon[event.target.dataset.id].children[1].style.display = "none"
                            } else {
                                this.$refs.changeCon[event.target.dataset.id].children[1].style.display = "block"
                                //浏览责任描述
                                //SKAPP.onEvent("产品详情页", "浏览责任描述",{
                                    //icpProductCode:sessionStorage.icpProductCode,
                                    //dutyItemsNum: dutyItemsNum,
                                    //dutyName:this.$store.state.health.dutyItems[i].dutyName
                                //});
                                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                                    "浏览责任描述":dutyItemsNum
                                });
                            }
                        }
                    }
                }
            },
            //社保
            society(type){
                let target = event.target
                this.$store.commit(healthMu.setHasSocialSecurity,type)
                target.parentNode.children[0].style.color =
                        target.parentNode.children[1].style.color = "#666666"
                target.parentNode.children[0].style.backgroundColor =
                        target.parentNode.children[1].style.backgroundColor = "#BCBCBC"
                target.style.backgroundColor = this.fontColor
                target.style.color = "white"
                this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
                //选择社保
                //SKAPP.onEvent("产品详情页", "选择社保",{
                    //icpProductCode:sessionStorage.icpProductCode,
                    //hasSocialSecurity:type
                //});
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
                    "选择社保":type == 'Y' ? '有' : '无'
                });
            },
            bodyScroll (event){
                event.preventDefault();
            },
        },
        computed: {
            ...mapState({
                productDetail(state){
                    return state.health.productDetail
                },
                minAge:state=>state.health.minAge,
                personProduct(state){
                    if(state.health.personProduct){
                        let numlength = this.$store.state.health.personProduct.length
                        let test = parseInt(1/numlength*100)
                        this.comWith = test + '%'
                    }
                    return state.health.personProduct
                },
                dutys(state){
                    if(state.health.dutys){
                        let numlength = state.health.dutys.length
                        let test = parseInt(1/numlength*100)
                        this.comWith = test + '%'
                    }
                    return state.health.dutys
                },
                duty:state=>state.health.duty.dutys,
                time:function(state) {
                    let year = state.health.insureBirthday.substring(0,4),
                            month = state.health.insureBirthday.substring(4,6),
                            day = state.health.insureBirthday.substring(6,8)
                    return year +"-"+month+"-"+day
                },
                start:function () {
                    return new Date(this.$store.state.health.effMaxAge.substring(0,4) -
                            this.$store.state.health.effMaxAge.split(',')[1] - 1,
                            this.$store.state.health.effMaxAge.substring(4,6)-1,
                            parseInt(this.$store.state.health.effMaxAge.substring(6,8)))
                },
                end:function () {
                    return new Date(this.$store.state.health.effMinAge.substring(0,4),
                            this.$store.state.health.effMinAge.substring(4,6)-1,
                            this.$store.state.health.effMinAge.substring(6,8))
                },
                startEff:function () {
                    if(this.$store.state.health.productDetail.fixedEffDate){
                        return new Date(this.$store.state.health.productDetail.fixedEffDate.substring(0,4),
                                this.$store.state.health.productDetail.fixedEffDate.substring(5,7)-1,
                                this.$store.state.health.productDetail.fixedEffDate.substring(8,11))
                    }else{
                        return new Date(Date.parse(new Date())+
                                this.$store.state.health.productDetail.minEffDelay*(60*60*24*1000))
                    }
                },
                endEff:function () {
                    if(this.$store.state.health.productDetail.fixedEffDate){
                        return new Date(this.$store.state.health.productDetail.fixedEffDate.substring(0,4),
                                this.$store.state.health.productDetail.fixedEffDate.substring(5,7)-1,
                                this.$store.state.health.productDetail.fixedEffDate.substring(8,11))
                    }else {
                        return new Date(Date.parse(new Date())+
                                this.$store.state.health.productDetail.maxEffDelay*(60*60*24*1000))
                    }
                },
                chooseSex:function (state) {
                    return state.health.chooseSex
                },
                sexChoose:state => state.health.sexZH,
                needSocialSecurity(state){
                    return state.health.needSocialSecurity
                },
                needInsurBirthday(state){
                    return state.health.productDetail.needInsurBirthday == 'Y' ? true : false
                },
                effTime(state){
                    return this.$store.state.health.effDate.substring(0,4)+'-'+
                            this.$store.state.health.effDate.substring(4,6) + '-' +
                            this.$store.state.health.effDate.substring(6,8)
                },
            }),
        },
        watch:{
            popupVisible(){
                if(this.popupVisible){
                    document.body.addEventListener('touchmove',this.bodyScroll,false);
                }else{
                    document.body.removeEventListener('touchmove',this.bodyScroll,false);
                }
            }
        },
        beforeDestroy(){
            document.body.removeEventListener('touchmove',this.bodyScroll,false);
        }
    }
</script>