<template>
    <div>
    <div class="publicity" style="display:none" id="flay">
        <img :src="leaflet"  style="width: 100%;margin-bottom: 6rem;"/>
        <div class="footer">
            <div class="btn" ref="Button" @click="next">立即购买</div>
        </div>
    </div>
    <div class="healthIndex" style="display:none" id='details'>
        <headImg></headImg>
        <!--产品信息-->
        <product></product>
        <!--保障计划-->
        <protection></protection>
        <!--服务协议和提交按钮-->
        <footerBut></footerBut>
    </div>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";
    @import "../../../../assets/iconfonts/health/iconfont.css";
    .healthIndex{
        background-color: @background-color-dark;
    }
    body{
        background-color: @background-color-dark;
    }
    .publicity{
        background-color:#f9f9f9;
    }
    .footer{
        z-index: 3;
        width: 100%;
        position: fixed;
        bottom: 0;
        left:0;
        padding-left: 1rem;
        padding-right: 1rem;
        padding-top: 1rem;
        padding-bottom: 1rem;
        background-color: rgba(0, 0, 0, 0.3);
    }
    .btn{
        width: 100%;
        height: 4.5rem;
        background-color: @iconfont;
        border: none;
        color: #ffffff;
        line-height: 4.5rem;
        font-size: 2rem;
        border-radius: 8px;
        text-align:center

    }
</style>
<script>
    import product from './product.vue'
    import protection from './protection.vue'
    import headImg from './headImg.vue'
    import footerBut from './footerBut.vue'
    import {Msg,Loading} from 'components'
    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import { getAhProductDetail,policyInquiry,ahPolicyInsure,policyHealthRecord} from '../../apis/health.api.js'
    import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
    import * as healthAc from "../../vuex/actionTypes/health.action.types"
    import {changeColor} from "../../../../utils/skin"
    import filter from "../../../../utils/filter"

    export default{
        data(){
            return{
                context:"",
                model:true,
                leaflet:"",
                stateVal:''
            }
        },
        beforeMount(){
            //if(this.$store.state.health.productDetail){
                //sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
            //}else{
                //if(sessionStorage.stateObj) this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
            //}
            if(sessionStorage.enterZNHB == 'Y'){//从智能核保传过来
                if(this.$route.query.undwrtDecideType && this.$route.query.undwrtDecideType == 'H'){
                    this.$store.commit(healthMu.setSaleRecordId, {saleRecordId:""})
                }
            }
        },
        mounted(){
            if(this.$route.query.icpProductCode){
                sessionStorage.icpProductCode = this.$route.query.icpProductCode
                sessionStorage.partnerCode = this.$route.query.partnerCode
                if(this.$route.query.userId){sessionStorage.userId = this.$route.query.userId};
                if(this.$route.query.remark){sessionStorage.remark = this.$route.query.remark}
                if(this.$route.query.keyCode){sessionStorage.keyCode = this.$route.query.keyCode}
                if(this.$route.query.agencyNo){sessionStorage.agencyNo = this.$route.query.agencyNo}
            }
            document.body.scrollTop = 0;
            sessionStorage.firstUrl = location.href;
            if(this.$route.query.callBackUrl) sessionStorage.callBackUrl = decodeURIComponent(this.$route.query.callBackUrl)
            if(sessionStorage.productName){
                document.title = sessionStorage.productName
            }

            if(this.$store.state.health.productDetail && !this.$store.state.health.saleAmount){
                this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
            }

            if(!this.$store.state.health.productDetail){
                getAhProductDetail({
                    "icpProductCode":sessionStorage.icpProductCode,
                    "partnerCode":sessionStorage.partnerCode,
                    "dataSource":'H5',
                    "userId":sessionStorage.userId
                }).then((msg) =>{
                    if(msg.body.resultCode == "00000"){
                        this.$store.commit(healthMu.setProductDetail,msg.body)
                        this.$store.commit(healthMu.seteffAge,this.$store.state.health.effDate);
                        if(!!msg.body.leaflet && sessionStorage.partnerCode != 'CZBX18'){
                            this.leaflet = './static/img/' + msg.body.leaflet + '.jpg'
                            this.img = true
                            this.$refs.Button.style.backgroundColor = changeColor();
                            document.getElementById('flay').style.display = 'block';
                        }else{
                            document.getElementById('details').style.display = 'block';
                            this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
                        }
                        //this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
                    }
                    else{
                        Msg.alert(filter.resultCode(msg.body))
                    }
                })
            }else{
                document.getElementById('details').style.display = 'block';
            }
            if(sessionStorage.icpProductCode == 'ICPH000008'){//e生保后退操作
                if(sessionStorage.enterZNHB){
                    window.addEventListener("popstate", stateListen, false);
                }
            }
        },
        methods:{
            next(){
                SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "宣传页面",{
                    "立即购买按钮":"立即购买"
                });
                document.getElementById('flay').style.display = 'none';
                document.getElementById('details').style.display = 'block';
                document.getElementById('details').style.opacity = 0;
                var n = 0;
                var t = setInterval(function(){
                    n++;

                    if(n <101){
                        document.getElementById('details').style.opacity = n/100;
                    }else{
                        clearInterval(t);
                    }
                },2);
                //document.getElementById('details').style.display = 'block';
                this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health)
            },
            isWeiXin (){
                var ua = window.navigator.userAgent.toLowerCase();
                if(ua.match(/MicroMessenger/i) == 'micromessenger'){
                    return true;
                }else{
                    return false;
                }
            }
        },
        beforeDestroy(){
            window.removeEventListener("popstate", stateListen, false);
        },
        components:{
            product:product,
            protection:protection,
            Loading,
            datetimePicker,
            picker,
            popup,
            headImg,
            footerBut
        }
    }

function stateListen(){
    var hashLocation = location.hash;
    var hashSplit = hashLocation.split('#/!/')[1]
    var hashName = hashSplit.split('?')[0];
    if (hashName == 'enterInfo' || hashName == 'failCallBackVue') {
        var ua = window.navigator.userAgent.toLowerCase();
        if(ua.match(/MicroMessenger/i) == 'micromessenger'){
            WeixinJSBridge.call('closeWindow');
        }else{
            window.opener = null;
            window.open("about:blank", "_self");
            window.close();
            /*window.history.go(-(history.length-1));*/
        }
    }
}
</script>
