<template>
    <div class="headImg">
        <div class="shadeImg"></div>
        <img :src="imgUrl"/>
        <p class="productName">{{productDetail.productName}}</p>
        <p class="qualifiedCrowd">由{{productDetail.insurCompanyName}}承保</p>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/vars.less";

    .headImg{
        height: 20rem;
        position:relative;
        >img{
             width: 100%;
             height: 20rem;
         }
    }
    .shadeImg{
        width: 100%;
        height: 20rem;
        position: absolute;
        background-image: linear-gradient(rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.4) 100%);
    }
    .productName{
        position:absolute;
        top:7rem;
        font-size: 2.2rem;
        color:@font-color-white;
        width: 100%;
        text-align: center;
        font-weight: 800;
    }
    .qualifiedCrowd{
        position: absolute;
        font-size: 1.2rem;
        color: #ffffff;
        width: 100%;
        text-align: right;
        bottom: 1rem;
        right: 1rem;
    }
</style>
<script>
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'

    export default{
        data(){
            return{
            }
        },
        computed: {
            ...mapState({
                productDetail:state=>state.health.productDetail,
                imgUrl:function (state) {
                    if(state.health.productDetail.bigPictureLink){
                        return state.health.productDetail.bigPictureLink
                    }else{
                        return;
                    }
                }
            }),
        },

    }
</script>
