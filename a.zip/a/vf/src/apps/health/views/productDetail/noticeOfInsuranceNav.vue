<template>
    <div class="NoticeOfInsuranceNav">
        <div class="main">
        <!-- router -->
        <!-- 分组 -->
            <section>
                <div class="my_title" @click='NoticeOfInsurance1' :style="{borderLeftColor:fontColor}">保险条款</div>
                <div class="line"></div>
                
            </section>
            <section>
                <div class="my_title" @click='NoticeOfInsurance2' :style="{borderLeftColor:fontColor}">重要声明</div>
                <div class="line"></div>
                
            </section>
            <section>
                <div class="my_title" @click='NoticeOfInsurance3' :style="{borderLeftColor:fontColor}">理赔须知</div>
                <div class="line"></div>
                
            </section>
            <section>
            <div v-if="flag" class="my_title" @click='toList' :style="{borderLeftColor:fontColor}">齿科医疗机构列表</div>
            <div class="line"></div>

            </section>
            <section>
            <div v-if="flag_707" class="my_title" @click='NoticeOfInsurance4' :style="{borderLeftColor:fontColor}">优选直接结算医院</div>
            <div class="line"></div>

            </section>
            <section>
            <div v-if="flag_707" class="my_title" @click='NoticeOfInsurance5' :style="{borderLeftColor:fontColor}">个人产品服务告知书</div>
            <div class="line"></div>

            </section>

            
        </div>
        
    </div>
</template>
<script type="text/javascript">
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
//import "../../../../utils/PAD"

let change = "#2688c4"
switch (sessionStorage.col){
    case "B2":
        change = "#4285F6"
        break
    case "Y1":
        change = "#D8A161"
        break
    case "O1":
        change = "#FF6000"
        break
    case "R1":
        change = "#F76B6C"
        break
    case "R2":
        change = "#F11B33"
        break
    default:
        change = "#2688c4"
        break;
}
export default{
    components: {
        //Group,
        //Icon,
    },
    data () {
        return {
            buyNoticeLink:sessionStorage.buyNoticeLink,
            insureCode:"",
            flag:false,
            flag_707:false,
            fontColor:change
        };
    },
    beforeMount(){
        if(this.$store.state.health.productDetail){
            sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
        }else{
            this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
        }
    },
    mounted(){
        let buyNoticeLink = this.buyNoticeLink
       // 开发环境
       // E生保
        console.log(buyNoticeLink)
       if(buyNoticeLink == 'BUYNOTICE0003001'){
            this.insureCode = 'H704'
            // 安全保
       }else if(buyNoticeLink == 'BUYNOTICE0003002'){
            this.insureCode = 'H804A'
            // 运动险
       }else if(buyNoticeLink == 'BUYNOTICE0003003'){
            this.insureCode = 'H804Y'
            // 海外险
       }else if(buyNoticeLink == 'BUYNOTICE0003007'){
           this.insureCode = 'H751'
           //抗癌卫士
       }else if(buyNoticeLink == 'BUYNOTICE0003008'){
           this.insureCode = 'H752'
           //母婴卫士
       }else if(buyNoticeLink == 'BUYNOTICE0003004'){
            this.insureCode = 'H753'
       }else if(buyNoticeLink == 'BUYNOTICE0003005'){
           this.insureCode = 'H714'
           //e生保
       }else if(buyNoticeLink == 'BUYNOTICE0003006'){
           this.insureCode = 'H754'
           this.flag = true
           //洁牙保牙宝保
       }else if(buyNoticeLink == 'BUYNOTICE0004001'){
           this.insureCode = 'H707'
           this.flag_707 = true
           //医保+
       }
        //浏览投保须知
        //SKAPP.onEvent("产品详情页", "浏览投保须知",{
            //icpProductCode:this.$store.state.health.productDetail.icpProductCode,
            //buyNoticeLink:this.buyNoticeLink
        //});
        SKAPP.onEvent(sessionStorage.keyCode || (sessionStorage.icpProductCode+'_'+sessionStorage.partnerCode), "投保页面",{
            "浏览投保须知":'浏览投保须知'
        });
        if(!this.$store.state.health.saleAmount){
            sessionStorage.spec = true
        }
    },
    methods: {
        NoticeOfInsurance1: function () {
            if (this.insureCode) {
                this.$router.push({
                    name: this.insureCode + "_1"
                }); 
            };
        },
        NoticeOfInsurance2: function () {
            if (this.insureCode) {
                this.$router.push({
                    name: this.insureCode + "_2"
                }); 
            };
        },
        NoticeOfInsurance3: function () {
            if (this.insureCode) {
                this.$router.push({
                    name: this.insureCode + "_3"
                }); 
            };
        },
        toList:function(){
            sessionStorage.setItem("insureCode","BUYNOTICE0003006");
            window.location.href = "https://m.pinganwj.com/product/booking/findClinic.do?prdId=3e73ca2a-2a8e-45d8-9b4f-356a54422d5a&source=jkx";
        },
        NoticeOfInsurance4: function () {
            if (this.insureCode) {
                this.$router.push({
                    name: this.insureCode + "_4"
                });
            };
        },
        NoticeOfInsurance5: function () {
            if (this.insureCode) {
                this.$router.push({
                    name: this.insureCode + "_5"
                });
            };
        },
    },
}
</script>
<style lang="less" scoped>
.NoticeOfInsuranceNav{
    .main{
        width: 100%;
        font-size: 1.5rem;
        background: #f6f6f6;
    }
    .main .footer{
        height: 6rem;
        width: 100%;
        bottom: 0;
        background: #fff;
        border-top: 0;
    }
    .footer.fixPosition{
        position: fixed;
        border-top: 1px solid #ececec;
    }
    .my_title{
        border-left: 2px solid #4285F7;
        text-align: left;
        color: #666666;
        padding-left: 5px;
        padding-top: 1.1rem;
        padding-bottom: 1.1rem;
        /*margin-bottom: 1.1rem;*/
        font-size: 1.6rem;
    }
    .line{
        height: 1px;
        width: 100%;
        background: #ececec;
    }
}
</style>
