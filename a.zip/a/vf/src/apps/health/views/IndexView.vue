<template>
<div class="home-view">
    <div title="健康险"
         @click="skip('/!/productDetail?icpProductCode=ICPH000007&partnerCode=QDLM&userId=1223')">
        健康险
    </div>
</div>
</template>
<script>

export default {
    methods: {
        skip (path) {
            this.$router.push(path)
        },
    }
}
</script>
<style scoped>

    .home-view > div{
        height: 4rem;
        border-bottom: 1px solid #ddd;
        line-height: 4rem;
        font-size: 1.4rem;
        padding-left: 1rem !important;
    }
</style>
