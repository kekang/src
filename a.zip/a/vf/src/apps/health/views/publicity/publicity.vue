<template>
    <div>
        <div class="publicity" v-show="img">
            <img :src="leaflet"  style="width: 100%;margin-bottom: 6rem;"/>
            <div class="footer">
                <div class="btn" ref="Button" @click="next">立即购买</div>
            </div>
        </div>
        <div v-show="detail">
            <productdetail></productdetail>
        </div>
    </div>
</template>
<script>

    import {Msg,Loading} from 'components'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
    import { getAhProductDetail,policyInquiry,ahPolicyInsure,policyHealthRecord} from '../../apis/health.api.js'
    import * as healthMu from "../../vuex/mutationTypes/health.mutation.types"
    import * as healthAc from "../../vuex/actionTypes/health.action.types"
    import filter from "../../../../utils/filter"
    import {changeColor} from "../../../../utils/skin"
    import productdetail from '../productDetail/productDetail.vue'
    import "../../../../assets/images/health/test.jpg"
    import headerBack from "../../../../components/header/index"

    let change = "#2688c4"

    export default {
        data(){
            return{
                model:true,
                img:false,
                detail:false
            }
        },

        beforeMount(){

            //无痕浏览
            function isLocalStorageSupported() {
                var testKey = 'test',
                        storage = window.sessionStorage;
                try {
                    storage.setItem(testKey, 'testValue');
                    storage.removeItem(testKey);
                    return true;
                } catch (error) {
                    return false;
                }
            }
            if(!isLocalStorageSupported()){
                this.model = false
                return;
            }else{
                if(this.$route.query.col){
                    //换肤
                    switch (this.$route.query.col){
                        case "B2":
                            sessionStorage.col = "B2"
                            break
                        case "Y1":
                            sessionStorage.col = "Y1"
                            break
                        case "O1":
                            sessionStorage.col = "O1"
                            break
                        case "R1":
                            sessionStorage.col = "R1"
                            break
                        case "R2":
                            sessionStorage.col = "R2"
                            break
                        default:
                            sessionStorage.col = "B1"
                            break;
                    }
                }
                sessionStorage.spec = false
            }



            if(this.$store.state.health.productDetail){
                sessionStorage.stateObj = JSON.stringify(this.$store.state.health);
            }else{
                if(sessionStorage.stateObj) this.$store.commit(healthMu.setState,JSON.parse(sessionStorage.stateObj));
            }
            if(sessionStorage.enterZNHB == 'Y'){//从智能核保传过来

                if(this.$route.query.undwrtDecideType && this.$route.query.undwrtDecideType == 'H'){
                    this.$store.commit(healthMu.setSaleRecordId, {saleRecordId:""})
                }
            }

        },
        mounted(){
            sessionStorage.historyLen_1 = window.history.length;
            //所有内容都需要确定不是无痕浏览的环境后再执行
            if(!this.model){
                Msg.alert('抱歉，目前不支持无痕浏览模式')
                return;
            }
            if(this.$route.query.partnerCode){
                sessionStorage.icpProductCode = this.$route.query.icpProductCode
                sessionStorage.partnerCode = this.$route.query.partnerCode
                sessionStorage.keyCode = this.$route.query.keyCode
                if(this.$route.query.userId){sessionStorage.userId = this.$route.query.userId};
                if(this.$route.query.remark){sessionStorage.remark = this.$route.query.remark}
                if(this.$route.query.keyCode){sessionStorage.keyCode = this.$route.query.keyCode}


            }

            document.body.scrollTop = 0;
            //存本地
            sessionStorage.firstUrl = location.href;
            localStorage.partnerCode = sessionStorage.partnerCode
            if(this.$route.query.callBackUrl) localStorage.callBackUrl = decodeURIComponent(this.$route.query.callBackUrl)
            if(sessionStorage.productName){
                document.title = sessionStorage.productName
            }

            //没有宣传页
            if(!sessionStorage.leaflet && this.$store.state.health.productDetail){
                this.detail = true
            }else {
                if(this.$store.state.health.productDetail){
                    this.$refs.Button.style.backgroundColor = change = changeColor();
                    this.leaflet = './static/img/' + sessionStorage.leaflet + '.jpg'
                    this.img = true
                    return;
                }
                getAhProductDetail({
                    "icpProductCode":sessionStorage.icpProductCode,
                    "partnerCode":sessionStorage.partnerCode,
                    "userId":sessionStorage.userId
                }).then(
                        (msg) => {
                            if(msg.body.resultCode == "00000"){
                                //数据处理
                                this.$store.commit(healthMu.setProductDetail,msg.body)
                                this.$store.commit(healthMu.seteffAge,this.$store.state.health.effDate)
                                //宣传页
                                if(!!msg.body.leaflet && sessionStorage.partnerCode != 'CZBX18'){
                                    sessionStorage.leaflet = msg.body.leaflet
                                    this.img = true
                                    this.$refs.Button.style.backgroundColor = change = changeColor();
                                }else{
                                    sessionStorage.leaflet = ""
                                    this.detail = true
                                    this.$store.dispatch(healthAc.policyInquiry,this.$store.state.health);
                                    //进入产品详情页
                                    SKAPP.onEvent(sessionStorage.keyCode || "投保页面", "投保页面",{
                                        icpProductCode:sessionStorage.icpProductCode
                                    });
                                }
                            }
                            else{
                                Msg.alert(filter.resultCode(msg.body))
                            }
                        })
            }
            console.log(this.routes)
        },
        methods:{
            next(){
                sessionStorage.leaflet = false;
                SKAPP.onEvent(sessionStorage.keyCode || "宣传页面", "宣传页面",{
                    icpProductCode:sessionStorage.icpProductCode,
                    "立即购买按钮":"立即购买"
                });
                if(sessionStorage.stepNum) sessionStorage.stepNum = Number(sessionStorage.stepNum) + 1;
                this.$router.push({'name':"product"})
            }
            //ajax数据处理
//            productDetail(msg){
//                document.title = sessionStorage.productName = msg.body.productName;
//                sessionStorage.buyNoticeLink = msg.body.buyNoticeLink;
//                //健康告知
//                this.$store.commit(healthMu.insureNotice,msg.body.healthLink)
//                //条款
//                this.$store.commit(healthMu.serviceTerm,msg.body.buyNoticeLink)
//                //条款的pdf编号
//                if(msg.body.clauses[0]){
//                    sessionStorage.clauseLink = msg.body.clauses[0].clauseLink
//                    sessionStorage.clauseName = msg.body.clauses[0].clauseName
//                    sessionStorage.planCode = msg.body.clauses[0].planCode
//                }
//
//
//                //生效日
//                let timestamp = Date.parse(new Date()),newTime;
//
//                if(msg.body.fixedEffDate){
//                    newTime = Date.parse(new Date(msg.body.fixedEffDate.substring(0,4),
//                            msg.body.fixedEffDate.substring(5,7)-1,
//                            msg.body.fixedEffDate.substring(8,11)))
//                    this.$store.commit(healthMu.setNewtime,newTime);
//                }
//                else if(!msg.body.fixedEffDate && msg.body.minEffDelay ){
//                    newTime = timestamp+msg.body.minEffDelay*(60*60*24*1000)
//                    this.$store.commit(healthMu.setNewtime,newTime)
//                }
//                else{
//                    Msg.alert("生效日不能为空")
//                    return;
//                }
//
//                let newStamp =new Date(newTime)
//                let year = newStamp.getFullYear()
//                let month = newStamp.getMonth()+1
//                let day = newStamp.getDate()
//                if(month < 10){
//                    month = "0" + month
//                }
//                if(day < 10){
//                    day = "0" +day
//                }
//                let effDate = year + '' + month +day
//                this.$store.commit(healthMu.seteffDate,effDate)
//                //产品信息
//                this.$store.commit(healthMu.setProductDetail,msg.body)
//                //设置默认性别和人群名称
//                this.$store.commit(healthMu.setSex,this.$store.state.health.crowd[0].gender)
//                this.$store.commit(healthMu.setSexZH,this.$store.state.health.crowd[0].personName)
//                //设置默认套餐
//                for(let i=0;i<this.$store.state.health.personProduct.length;i++){
//                    if(this.$store.state.health.personProduct[i].idProductCombined
//                            == this.$store.state.health.productDetail.defaultShow.idProductCombined){
//                        this.$store.commit(healthMu.setDuty,i)
//                    }
//                }
//                this.$store.commit(healthMu.seteffAge,effDate)
//
//                if(msg.body.needSocialSecurity == "Y"){
//                    this.$store.commit(healthMu.setNeedSocialSecurity,true)
//                    this.$store.commit(healthMu.setHasSocialSecurity,"Y")
//                }
//            },
        },
        components:{
            productdetail
        },
        computed: {
            ...mapState({
                leaflet(state){
                    if(state.health.productDetail.leaflet){
                        let src = './static/img/' + state.health.productDetail.leaflet + '.jpg'
                        return src
                    }
                }
            }),
        },
        beforeRouteLeave (to, from, next) {
            console.log(to);
            console.log(from);
            next();
        }
}
</script>
<style scoped>
.publicity{
    background-color:#f9f9f9;
}
.footer{
    z-index: 3;
    width: 100%;
    position: fixed;
    bottom: 0;
    left:0;
    padding-left: 1rem;
    padding-right: 1rem;
    padding-top: 1rem;
    padding-bottom: 1rem;
    background-color: rgba(0, 0, 0, 0.3);
}
.btn{
    width: 100%;
    height: 4.5rem;
    background-color: @iconfont;
    border: none;
    color: #ffffff;
    line-height: 4.5rem;
    font-size: 2rem;
    border-radius: 8px;
    text-align:center

}
</style>
