<template >
    <div>
        <article style="margin-top: 1rem;">
            <section class="invoiceBox">
                <div>
                    <div class="inline detailLeft">企业证件类型</div>
                    <div class="inline detailRight" @click="chooseType(1)">{{companyInfo.orgCodeType | orgCodeType}}</div>
                    <div class="rightarrow" @click="chooseType(1)"></div>
                    <popup v-model="popupVisible1" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="insurePer(1,'N')" :style="{color:themeColor}">取消</span>
                            <span class="confirm" @click="insurePer(1,'Y')" :style="{color:themeColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="placeList1" @change="onValuesChange1">
                            </picker>
                        </div>
                    </popup>
                </div>
                <div>
                    <div class="inline detailLeft">企业证件号</div>
                    <input class="inline detailRight" v-model="companyInfo.organizationCode" placeholder="输入证件号" @input="detailAdd('organizationCode')" @blur="queryCompanyInfo">
                </div>

                <div>
                    <div class="inline detailLeft">行业类别</div>
                    <div class="inline detailRight" @click="chooseType(2)">{{companyInfo.industry || '请选择' | doLen}}</div>
                    <div class="rightarrow" @click="chooseType(2)"></div>
                    <popup v-model="popupVisible2" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="insurePer(2,'N')" :style="{color:themeColor}">取消</span>
                            <span class="confirm" @click="insurePer(2,'Y')" :style="{color:themeColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="placeList2" @change="onValuesChange2">
                            </picker>
                        </div>
                    </popup>
                </div>
                <div>
                    <div class="inline detailLeft">企业名称</div>
                    <input :disabled="hasOrganizationName" @input="detailAdd('organizationName')" v-model="companyInfo.organizationName" class="inline detailRight" placeholder="输入企业名" >
                </div>

                <div>
                    <div class="inline detailLeft">所在地</div>
                    <div class="inline detailRight" @click="chooseType(3)">{{companyInfo.provinceName | province}}{{companyInfo.cityName}}</div>
                    <div class="rightarrow"  @click="chooseType(3)"></div>
                    <popup v-model="popupVisible3" position="bottom">
                        <div class="showBar">
                            <span class="cancle" @click="insurePer(3,'N')" :style="{color:themeColor}">取消</span>
                            <span class="confirm" @click="insurePer(3,'Y')" :style="{color:themeColor}">确认</span>
                        </div>
                        <div class="page-picker-wrapper">
                            <picker :slots="addressSlots" @change="onValuesChange3">
                            </picker>
                        </div>
                    </popup>
                </div>
                <div>
                    <div class="inline detailLeft"></div>
                    <input id="address" v-if="isShowLabel" @input="detailAdd('addressDetail')" @blur="enterInput" v-model="companyInfo.addressDetail" class="inline detailRight"></input>
                    <label for="address" style="color:#999;display: inline-block;width:55%;line-height: 2.5rem" @click="enterInput" v-else>{{companyInfo.addressDetail || '联系地址'}}</label>
                </div>

                <div>
                    <div class="inline detailLeft">联系人姓名</div>
                    <input @input="detailAdd('orgContactPerson')" v-model="companyInfo.orgContactPerson" class="inline detailRight" placeholder="请输入姓名" >
                </div>
                <div>
                    <div class="inline detailLeft">联系人手机</div>
                    <input type="tel" @input="detailAdd('mobilePhone')" v-model="companyInfo.mobilePhone" class="inline detailRight" placeholder="请输入手机号码" maxlength="11">
                </div>
            </section>
        </article>
        <article class="next" @click="next">
            下一步
        </article>
    </div>
</template>
<style scoped lang="less">
    @import "../../../../styles/miniDetail.less";

    .inline{
        display: -webkit-inline-box;
    }
    .detailLeft{
        font-size: 1.5rem;
        width: 35%;
        color: #666;
    }
    .detailRight{
        font-size: 1.5rem;
        line-height: 4.5rem;
        border: none;
        width: 58%;
        font-family:"MicroSoft YaHei";
        margin-right:0;
        color: #999;
        background-color: #fff;
    }
    .invoiceBox{
        border-top:1px solid #eee;
        line-height:4.5rem;
        padding: 0 0.8rem 0 1.2rem;
        background-color:#FFFFFF;
        font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
        font-size: 1.5rem;
        color: #666666;
    }
    .invoiceBox>div{
        border-bottom:1px solid #eee
    }
    .invoiceBox>div:last-child{
        border-bottom:none
    }
    .rightarrow{
        float: right;
        width: 1.5rem;
        margin: 1.5rem -0.5rem 0 0.5rem;
        height: 1.8rem;
        background:url("../../../../assets/images/health/arrow.png") no-repeat;
        background-size: 1.6rem 1.6rem;
        position: relative;
    }
    .rightarrow:before{
        position: absolute;
        top: -15px;
        right: -10px;
        bottom: -15px;
        left: -20px;
    }
    .showBar{
        height: 40px;
        border-bottom: solid 1px #eaeaea;
    }
    .cancle{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: left;
    }
    .confirm{
        display: inline-block;
        font-size: 16px;
        color: @iconfont;
        width: 50%;
        text-align: center;
        line-height: 40px;
        float: right;
    }
    .next{
        width: 90%;
        margin: 1rem auto 1rem;
        line-height: 4.5rem;
        font-size: 1.5rem;
        color: #fff;
        border-radius: 4px;
        text-align: center;
        background-color: #FF6600;
    }
</style>
<script>
    import Vue from 'vue'
    import {Msg}from "components";
    import datetimePicker from '../../../../components/datetime-picker/index.js'
    import picker from '../../../../components/picker/index.js'
    import popup from '../../../../components/popup/index.js'
    import {mapState,mapGetters,mapMutations,mapActions} from 'vuex';
    import * as proMu from "../../vuex/mutationTypes/pro.mutation.types"
    import {findOrgInfo,recordOrganizationInfo,checkEmpAndOrgCity} from "../../apis/pro.api"
    import filter from "../../../../utils/filter"
    const address = {
        '北京市':['北京市'],
        '天津市':['天津市'],
        '河北省':["石家庄市","唐山市","秦皇岛市","邯郸市","邢台市","保定市","张家口市","承德市","沧州市","廊坊市","衡水市"],
        '山西省':["太原市","大同市","阳泉市","长治市","晋城市","朔州市","晋中市","运城市","忻州市","临汾市","吕梁市"],
        '内蒙古自治区':["呼和浩特市","包头市","乌海市","赤峰市","通辽市","鄂尔多斯市","呼伦贝尔市","巴彦淖尔市","乌兰察布市","兴安盟","锡林郭勒盟","阿拉善盟"],
        '辽宁省':["沈阳市","大连市","鞍山市","抚顺市","本溪市","丹东市","锦州市","营口市","阜新市","辽阳市","盘锦市","铁岭市","朝阳市","葫芦岛市"],
        '吉林省':["长春市","吉林市","四平市","辽源市","通化市","白山市","松原市","白城市","延边朝鲜族自治州"],
        '黑龙江省':["哈尔滨市","齐齐哈尔市","鸡西市","鹤岗市","双鸭山市","大庆市","伊春市","佳木斯市","七台河市","牡丹江市","黑河市","绥化市","大兴安岭地区"],
        '上海市':['上海市'],
        "江苏省":["南京市","无锡市","徐州市","常州市","苏州市","南通市","连云港市","淮安市","盐城市","扬州市","镇江市","泰州市","宿迁市"],
        "浙江省":["杭州市","宁波市","温州市","嘉兴市","湖州市","绍兴市","金华市","衢州市","舟山市","台州市","丽水市"],
        "安徽省":["合肥市","芜湖市","蚌埠市","淮南市","马鞍山市","淮北市","铜陵市","安庆市","黄山市","滁州市","阜阳市","宿州市","巢湖市","六安市","亳州市","池州市","宣城市"],
        "福建省":["福州市","厦门市","莆田市","三明市","泉州市","漳州市","南平市","龙岩市","宁德市"],
        "江西省":["南昌市","景德镇市","萍乡市","九江市","新余市","鹰潭市","赣州市","吉安市","宜春市","抚州市","上饶市"],
        "山东省":["济南市","青岛市","淄博市","枣庄市","东营市","烟台市","潍坊市","济宁市","泰安市","威海市","日照市","莱芜市","临沂市","德州市","聊城市","滨州市","菏泽市"],
        "河南省":["郑州市","开封市","洛阳市","平顶山市","安阳市","鹤壁市","新乡市","焦作市","濮阳市","许昌市","漯河市","三门峡市","南阳市","商丘市","信阳市","周口市","驻马店市"],
        "湖北省":["武汉市","黄石市","十堰市","宜昌市","襄阳市","鄂州市","荆门市","孝感市","荆州市","黄冈市","咸宁市","随州市","恩施土家族苗族自治州"],
        "湖南省":["长沙市","株洲市","湘潭市","衡阳市","邵阳市","岳阳市","常德市","张家界市","益阳市","郴州市","永州市","怀化市","娄底市","湘西土家族苗族自治州"],
        "广东省":["广州市","韶关市","深圳市","珠海市","汕头市","佛山市","江门市","湛江市","茂名市","肇庆市","惠州市","梅州市","汕尾市","河源市","阳江市","清远市","东莞市","中山市","潮州市","揭阳市","云浮市"],
        "广西壮族自治区":["南宁市","柳州市","桂林市","梧州市","北海市","防城港市","钦州市","贵港市","玉林市","百色市","贺州市","河池市","来宾市","崇左市"],
        "海南省":["海口市","三亚市"],
        "重庆市":["重庆市"],
        "四川省":["成都市","自贡市","攀枝花市","泸州市","德阳市","绵阳市","广元市","遂宁市","内江市","乐山市","南充市","眉山市","宜宾市","广安市","达州市","雅安市","巴中市","资阳市","阿坝藏族羌族自治州","甘孜藏族自治州","凉山彝族自治州"],
        "贵州省":["贵阳市","六盘水市","遵义市","安顺市","铜仁地区","黔西南布依族苗族自治州","毕节地区","黔东南苗族侗族自治州","黔南布依族苗族自治州"],
        "云南省":["昆明市","曲靖市","玉溪市","保山市","昭通市","丽江市","临沧市","楚雄彝族自治州","红河哈尼族彝族自治州","文山壮族苗族自治州","思茅市","西双版纳傣族自治州","大理白族自治州","德宏傣族景颇族自治州","怒江傈僳族自治州","迪庆藏族自治州"],
        "西藏自治区":["拉萨市","昌都地区","山南地区","日喀则地区","那曲地区","阿里地区","林芝地区"],
        "陕西省":["西安市","铜川市","宝鸡市","咸阳市","渭南市","延安市","汉中市","榆林市","安康市","商洛市"],
        "甘肃省":["兰州市","嘉峪关市","金昌市","白银市","天水市","武威市","张掖市","平凉市","酒泉市","庆阳市","定西市","陇南地区","临夏回族自治州","甘南藏族自治州"],
        "青海省":["西宁市","海东地区","海北藏族自治州","黄南藏族自治州","海南藏族自治州","果洛藏族自治州","玉树藏族自治州","海西蒙古族藏族自治州"],
        "宁夏回族自治区":["银川市","石嘴山市","吴忠市","固原市","中卫市"],
        "新疆维吾尔自治区":["乌鲁木齐市","克拉玛依市","吐鲁番地区","哈密地区","昌吉回族自治州","博尔塔拉蒙古自治州","巴音郭楞蒙古自治州","阿克苏地区","克孜勒苏柯尔克孜自治州","喀什地区","和田地区","伊犁哈萨克自治州","塔城地区","阿勒泰地区"],
        "台湾省":["台湾省"],
        "香港特别行政区":["香港特别行政区"],
        "澳门特别行政区":["澳门特别行政区"]
    };
    const zy = ["食品制造业","饮料制造业","纺织业","纺织服装、鞋、帽制造业","皮革、毛皮、羽毛(绒)及其制品业","印刷业和记录媒介的复制","文教体育用品制造业","通信设备、计算机及其他电子设备制造业","仪器仪表及文化、办公用机械制造业","电信和其他信息传输服务业","计算机服务业","软件业","批发业","零售业","住宿业","餐饮业","金融业","房地产业","租赁和商务服务业","居民服务和其他服务业","教育","公共管理和社会组织"];
    export default{
        data(){
            return{
                fontColor:"#ff6600",
                placeList1:[{
                    flex: 1,
                    values:["组织机构代码","社会信用代码","营业执照"]
                }],
                placeList2:[{
                    flex: 1,
                    values:zy
                }],
                addressSlots: [
                    {
                        flex: 1,
                        values: Object.keys(address),
                        className: 'slot1',
                        textAlign: 'center'
                    },{
                        flex: 1,
                        values: ['北京市'],
                        className: 'slot3',
                        textAlign: 'center'
                    }
                ],
                selected1:"组织机构代码",//选择值存储
                selected2:"食品制造业",
                selected3:"北京市|北京市",

                orgCode:"",
                creditCode:"",

                popupVisible1:false,
                popupVisible2:false,
                popupVisible3:false,

                isShowLabel:false
            }
        },
        components:{
            datetimePicker,
            picker,
            popup
        },
        updated(){
            console.log(132)
        },
        methods: {
            enterInput(){
                this.isShowLabel = !this.isShowLabel;
            },
            chooseType(num){
                if(num == '1'){
                    this['popupVisible' + num] = true;
                }else if(num == '2'){
                    if(this.hasIndustry){
                        return;
                    }
                    this['popupVisible' + num] = true;
                }else if(num == '3'){
                    if(this.hasProvinceName){
                        return;
                    }
                    this['popupVisible' + num] = true;
                }
            },
            insurePer(num,type){
                if(num == '1' && type == 'Y'){//企业证件类型
                    if(this.selected1 == '组织机构代码'){
                        this.$store.commit(proMu.setCompanyInfo,{orgCodeType:"1"});
                    }else if(this.selected1 == '社会信用代码'){
                        this.$store.commit(proMu.setCompanyInfo,{orgCodeType:"2"});
                    }else if(this.selected1 == '营业执照'){
                        this.$store.commit(proMu.setCompanyInfo,{orgCodeType:"3"});
                    }
                }else if(num == '2' && type == 'Y'){//行业类型
                    let code = this.getCodeOrName('getCode',this.selected2);
                    this.$store.commit(proMu.setCompanyInfo,{industryCode:code,industry:this.selected2});
                }else if(num == '3' && type == 'Y'){//所在地
                    let province = this.selected3.split('|')[0];
                    let city = this.selected3.split('|')[1];
                    let proCode = this.getCityPriCode('pri',province);
                    let cityCode = this.getCityPriCode('city',city);
                    let obj = {
                        provinceCode:proCode,
                        provinceName:province,
                        cityCode:cityCode,
                        cityName:city
                    }
                    this.$store.commit(proMu.setCompanyInfo,obj);
                }
                this['popupVisible' + num] = false
            },
            onValuesChange1(picker, values){
                this.selected1 = values[0];
            },
            onValuesChange2(picker, values){
                this.selected2 = values[0];
            },
            onValuesChange3(picker, values){
                picker.setSlotValues(1, address[values[0]]);
                this.selected3 = values[0] + '|' + values[1];
            },
            detailAdd(type){
                let obj = {};
                obj[type] = event.target.value;
                this.$store.commit(proMu.setCompanyInfo,obj);
            },
            queryCompanyInfo(){
                let code = event.target.value.replace(/(^\s+)|(\s+$)/g,"").replace(/\s/g,"");
                this.$store.commit(proMu.setCompanyInfo,{organizationCode:code});
                if(!code) return;
                if(this.$store.state.pro.companyInfo.orgCodeType == '1'){
                    this.orgCode = code;//303597350
                    this.creditCode = '';
                    this.findOrgInfo();
                }else if(this.$store.state.pro.companyInfo.orgCodeType == '2'){
                    this.orgCode = '';
                    this.creditCode = code;
                    this.findOrgInfo();
                }else if(this.$store.state.pro.companyInfo.orgCodeType == '3'){
                    //手动输入
                }
            },
            findOrgInfo(){
                findOrgInfo({
                    "orgCode":this.orgCode,
                    "creditCode":this.creditCode,
                    "partnerCode":sessionStorage.partnerCode,
                    "orgCodeType":this.$store.state.pro.companyInfo.orgCodeType
                }).then((msg) => {
                    if(msg.body.resultCode == "00000"){
                        if(msg.body.orgListInfo.length == 0) return;
                        let obj = msg.body.orgListInfo[0];
                        //根据行业code查对应中文
                        let name = this.getCodeOrName('getName',obj.industryCode);
                        obj.industry = name;
                        //可能存在企业名称为空的情况，这种情况下将法人姓名作为企业名称。
                        if(!obj.organizationName) obj.organizationName = obj.orgContactPerson;
                        this.$store.commit(proMu.setCompanyInfo,obj);
                        this.popupVisible1 = true;
                        this.popupVisible1 = false;//解决vuex数据同步了页面不更新的一个bug。。。

                        //处理disabled
                        this.$store.commit(proMu.setBill,{'hasIndustry':obj.industry ? true : false});
                        this.$store.commit(proMu.setBill,{'hasOrganizationName':obj.organizationName ? true : false});
                        this.$store.commit(proMu.setBill,{'hasProvinceName':obj.provinceCode ? true : false});
                    }else{
                        Msg.alert(filter.resultCode(msg.body))
                    }
                });
            },
            next(){
                if(!this.checkVal()) return;
                //this.recordOrganizationInfo();

                checkEmpAndOrgCity({
                    empno:sessionStorage.empno,
                    cityCode:this.$store.state.pro.companyInfo.cityCode,
                    partnerCode:sessionStorage.partnerCode
                }).then((msg) => {
                    if(msg.body.resultCode == "00000"){
                        this.recordOrganizationInfo();
                    }else{
                        Msg.alert('业务员和企业不在同一城市，请确认');
                        //this.recordOrganizationInfo();
                    }
                })

            },
            checkVal(){
                if(!this.$store.state.pro.companyInfo.organizationCode){
                    Msg.alert('请输入企业证件号');
                    return false;
                }
                if(!this.$store.state.pro.companyInfo.industryCode){
                    Msg.alert('请选择行业类别');
                    return false;
                }
                if(!this.$store.state.pro.companyInfo.organizationName){
                    Msg.alert('请输入企业名');
                    return false;
                }
                if(!this.$store.state.pro.companyInfo.cityCode){
                    Msg.alert('请选择城市');
                    return false;
                }
                if(!this.$store.state.pro.companyInfo.addressDetail){
                    Msg.alert('请输入联系地址');
                    return false;
                }
                if(!filter.check.checkName(this.$store.state.pro.companyInfo.orgContactPerson)){
                    Msg.alert('联系人不正确');
                    return false;
                }
                if(!this.$store.state.pro.companyInfo.mobilePhone){
                    Msg.alert('请输入联系人手机');
                    return false;
                }
                return true;
            },
            recordOrganizationInfo(){
                let obj = {
                    saleRecordId:this.$store.state.pro.companyInfo.saleRecordId,//AHO201704130000650
                    organizationName:this.$store.state.pro.companyInfo.organizationName,
                    industryCode:this.$store.state.pro.companyInfo.industryCode,
                    industry:this.$store.state.pro.companyInfo.industry,//行业名字
                    orgCodeType:this.$store.state.pro.companyInfo.orgCodeType,//企业证件类型
                    organizationCode:this.$store.state.pro.companyInfo.organizationCode,
                    provinceCode:this.$store.state.pro.companyInfo.provinceCode,
                    provinceName:this.$store.state.pro.companyInfo.provinceName,
                    cityCode:this.$store.state.pro.companyInfo.cityCode,
                    cityName:this.$store.state.pro.companyInfo.cityName,
                    addressDetail:this.$store.state.pro.companyInfo.addressDetail,
                    orgCodeMatuDate:this.$store.state.pro.companyInfo.orgCodeMatuDate,
                    creditCodeEffDate:this.$store.state.pro.companyInfo.creditCodeEffDate,
                    orgContactPerson:this.$store.state.pro.companyInfo.orgContactPerson,
                    mobilePhone:this.$store.state.pro.companyInfo.mobilePhone,
                    propertyType:this.$store.state.pro.companyInfo.propertyType || null || '04',
                    countyCode:"110108",
                    countyName:"海淀区"
                }
                recordOrganizationInfo(obj).then((msg) => {
                    if(msg.body.resultCode == "00000"){
                        console.log(JSON.stringify(msg.body))
                        this.$router.push({'name':"memberDetail"})
                    }else{
                        Msg.alert(filter.resultCode(msg.body))
                    }
                })
            },
            checkEmpAndOrgCity(){
                checkEmpAndOrgCity({
                    empno:sessionStorage.empno,
                    cityCode:this.$store.state.pro.companyInfo.cityCode,
                    partnerCode:sessionStorage.partnerCode
                }).then((msg) => {
                    if(msg.body.resultCode == "00000"){
                        return true;
                    }else{
                        return false;
                    }
                })
            },
            getCodeOrName(type,value){//行业
                if(!value) return;
                let obj = {
                    "C14":"食品制造业",
                    "C15":"饮料制造业",
                    "C17":"纺织业",
                    "C18":"纺织服装、鞋、帽制造业",
                    "C19":"皮革、毛皮、羽毛(绒)及其制品业",
                    "C23":"印刷业和记录媒介的复制",
                    "C24":"文教体育用品制造业",
                    "C40":"通信设备、计算机及其他电子设备制造业",
                    "C41":"仪器仪表及文化、办公用机械制造业",
                    "G60":"电信和其他信息传输服务业",
                    "G61":"计算机服务业",
                    "G62":"软件业",
                    "H63":"批发业",
                    "H65":"零售业",
                    "I66":"住宿业",
                    "I67":"餐饮业",
                    "J":"金融业",
                    "K":"房地产业",
                    "L":"租赁和商务服务业",
                    "O":"居民服务和其他服务业",
                    "P":"教育",
                    "S":"公共管理和社会组织"
                };
                if(type == 'getCode'){
                    let code = '';
                    for(let k in obj){
                        if(obj[k] == value){
                            code = k;
                            break;
                        }
                    }
                    return code;
                }else{//type == 'getName'

                    if(value.substring(0,1) == 'J' || value.substring(0,1) == 'K' || value.substring(0,1) == 'L' ||
                        value.substring(0,1) == 'O' || value.substring(0,1) == 'P' || value.substring(0,1) == 'S'){
                        value = value.substring(0,1)
                    }else{
                        value = value.substring(0,3)
                    }
                    return obj[value] || '其它';
                }
            },
            getCityPriCode(type,name){
                let objPri = {
                    '北京市':"110000",'天津市':"120000",'河北省':"130000",'山西省':"140000",'内蒙古自治区':"150000",
                     '辽宁省':"210000",'吉林省':"220000",'黑龙江省':"230000",'上海市':"310000","江苏省":"320000",
                     "浙江省":"330000","安徽省":"340000","福建省":"350000","江西省":"360000","山东省":"370000",
                     "河南省":"410000","湖北省":"420000","湖南省":"430000","广东省":"440000","广西壮族自治区":"450000",
                     "海南省":"460000","重庆市":"500000","四川省":"510000","贵州省":"520000","云南省":"530000",
                     "西藏自治区":"540000","陕西省":"610000","甘肃省":"620000","青海省":"630000","宁夏回族自治区":"640000",
                     "新疆维吾尔自治区":"650000","台湾省":"710000","香港特别行政区":"810000","澳门特别行政区":"820000"
                }
                let objCity = {
                    "北京市":"110000",
                    "天津市":"120000",
                    "石家庄市":"130100",
                    "唐山市":"130200",
                    "秦皇岛市":"130300",
                    "邯郸市":"130400",
                    "邢台市":"130500",
                    "保定市":"130600",
                    "张家口市":"130700",
                    "承德市":"130800",
                    "沧州市":"130900",
                    "廊坊市":"131000",
                    "衡水市":"131100",
                    "太原市":"140100",
                    "大同市":"140200",
                    "阳泉市":"140300",
                    "长治市":"140400",
                    "晋城市":"140500",
                    "朔州市":"140600",
                    "晋中市":"140700",
                    "运城市":"140800",
                    "忻州市":"140900",
                    "临汾市":"141000",
                    "吕梁市":"141100",
                    "呼和浩特市":"150100",
                    "包头市":"150200",
                    "乌海市":"150300",
                    "赤峰市":"150400",
                    "通辽市":"150500",
                    "鄂尔多斯市":"150600",
                    "呼伦贝尔市":"150700",
                    "巴彦淖尔市":"150800",
                    "乌兰察布市":"150900",
                    "兴安盟":"152200",
                    "锡林郭勒盟":"152500",
                    "阿拉善盟":"152900",
                    "沈阳市":"210100",
                    "大连市":"210200",
                    "鞍山市":"210300",
                    "抚顺市":"210400",
                    "本溪市":"210500",
                    "丹东市":"210600",
                    "锦州市":"210700",
                    "营口市":"210800",
                    "阜新市":"210900",
                    "辽阳市":"211000",
                    "盘锦市":"211100",
                    "铁岭市":"211200",
                    "朝阳市":"211300",
                    "葫芦岛市":"211400",
                    "长春市":"220100",
                    "吉林市":"220200",
                    "四平市":"220300",
                    "辽源市":"220400",
                    "通化市":"220500",
                    "白山市":"220600",
                    "松原市":"220700",
                    "白城市":"220800",
                    "延边朝鲜族自治州":"222400",
                    "哈尔滨市":"230100",
                    "齐齐哈尔市":"230200",
                    "鸡西市":"230300",
                    "鹤岗市":"230400",
                    "双鸭山市":"230500",
                    "大庆市":"230600",
                    "伊春市":"230700",
                    "佳木斯市":"230800",
                    "七台河市":"230900",
                    "牡丹江市":"231000",
                    "黑河市":"231100",
                    "绥化市":"231200",
                    "大兴安岭地区":"232700",
                    "上海市":"310000",
                    "南京市":"320100",
                    "无锡市":"320200",
                    "徐州市":"320300",
                    "常州市":"320400",
                    "苏州市":"320500",
                    "南通市":"320600",
                    "连云港市":"320700",
                    "淮安市":"320800",
                    "盐城市":"320900",
                    "扬州市":"321000",
                    "镇江市":"321100",
                    "泰州市":"321200",
                    "宿迁市":"321300",
                    "杭州市":"330100",
                    "宁波市":"330200",
                    "温州市":"330300",
                    "嘉兴市":"330400",
                    "湖州市":"330500",
                    "绍兴市":"330600",
                    "金华市":"330700",
                    "衢州市":"330800",
                    "舟山市":"330900",
                    "台州市":"331000",
                    "丽水市":"331100",
                    "合肥市":"340100",
                    "芜湖市":"340200",
                    "蚌埠市":"340300",
                    "淮南市":"340400",
                    "马鞍山市":"340500",
                    "淮北市":"340600",
                    "铜陵市":"340700",
                    "安庆市":"340800",
                    "黄山市":"341000",
                    "滁州市":"341100",
                    "阜阳市":"341200",
                    "宿州市":"341300",
                    "巢湖市":"341400",
                    "六安市":"341500",
                    "亳州市":"341600",
                    "池州市":"341700",
                    "宣城市":"341800",
                    "福州市":"350100",
                    "厦门市":"350200",
                    "莆田市":"350300",
                    "三明市":"350400",
                    "泉州市":"350500",
                    "漳州市":"350600",
                    "南平市":"350700",
                    "龙岩市":"350800",
                    "宁德市":"350900",
                    "南昌市":"360100",
                    "景德镇市":"360200",
                    "萍乡市":"360300",
                    "九江市":"360400",
                    "新余市":"360500",
                    "鹰潭市":"360600",
                    "赣州市":"360700",
                    "吉安市":"360800",
                    "宜春市":"360900",
                    "抚州市":"361000",
                    "上饶市":"361100",
                    "济南市":"370100",
                    "青岛市":"370200",
                    "淄博市":"370300",
                    "枣庄市":"370400",
                    "东营市":"370500",
                    "烟台市":"370600",
                    "潍坊市":"370700",
                    "济宁市":"370800",
                    "泰安市":"370900",
                    "威海市":"371000",
                    "日照市":"371100",
                    "莱芜市":"371200",
                    "临沂市":"371300",
                    "德州市":"371400",
                    "聊城市":"371500",
                    "滨州市":"371600",
                    "菏泽市":"371700",
                    "郑州市":"410100",
                    "开封市":"410200",
                    "洛阳市":"410300",
                    "平顶山市":"410400",
                    "安阳市":"410500",
                    "鹤壁市":"410600",
                    "新乡市":"410700",
                    "焦作市":"410800",
                    "濮阳市":"410900",
                    "许昌市":"411000",
                    "漯河市":"411100",
                    "三门峡市":"411200",
                    "南阳市":"411300",
                    "商丘市":"411400",
                    "信阳市":"411500",
                    "周口市":"411600",
                    "驻马店市":"411700",
                    "武汉市":"420100",
                    "黄石市":"420200",
                    "十堰市":"420300",
                    "宜昌市":"420500",
                    "襄阳市":"420600",
                    "鄂州市":"420700",
                    "荆门市":"420800",
                    "孝感市":"420900",
                    "荆州市":"421000",
                    "黄冈市":"421100",
                    "咸宁市":"421200",
                    "随州市":"421300",
                    "恩施土家族苗族自治州":"422800",
                    "长沙市":"430100",
                    "株洲市":"430200",
                    "湘潭市":"430300",
                    "衡阳市":"430400",
                    "邵阳市":"430500",
                    "岳阳市":"430600",
                    "常德市":"430700",
                    "张家界市":"430800",
                    "益阳市":"430900",
                    "郴州市":"431000",
                    "永州市":"431100",
                    "怀化市":"431200",
                    "娄底市":"431300",
                    "湘西土家族苗族自治州":"433100",
                    "广州市":"440100",
                    "韶关市":"440200",
                    "深圳市":"440300",
                    "珠海市":"440400",
                    "汕头市":"440500",
                    "佛山市":"440600",
                    "江门市":"440700",
                    "湛江市":"440800",
                    "茂名市":"440900",
                    "肇庆市":"441200",
                    "惠州市":"441300",
                    "梅州市":"441400",
                    "汕尾市":"441500",
                    "河源市":"441600",
                    "阳江市":"441700",
                    "清远市":"441800",
                    "东莞市":"441900",
                    "中山市":"442000",
                    "潮州市":"445100",
                    "揭阳市":"445200",
                    "云浮市":"445300",
                    "南宁市":"450100",
                    "柳州市":"450200",
                    "桂林市":"450300",
                    "梧州市":"450400",
                    "北海市":"450500",
                    "防城港市":"450600",
                    "钦州市":"450700",
                    "贵港市":"450800",
                    "玉林市":"450900",
                    "百色市":"451000",
                    "贺州市":"451100",
                    "河池市":"451200",
                    "来宾市":"451300",
                    "崇左市":"451400",
                    "海口市":"460100",
                    "三亚市":"460200",
                    "重庆市":"500000",
                    "成都市":"510100",
                    "自贡市":"510300",
                    "攀枝花市":"510400",
                    "泸州市":"510500",
                    "德阳市":"510600",
                    "绵阳市":"510700",
                    "广元市":"510800",
                    "遂宁市":"510900",
                    "内江市":"511000",
                    "乐山市":"511100",
                    "南充市":"511300",
                    "眉山市":"511400",
                    "宜宾市":"511500",
                    "广安市":"511600",
                    "达州市":"511700",
                    "雅安市":"511800",
                    "巴中市":"511900",
                    "资阳市":"512000",
                    "阿坝藏族羌族自治州":"513200",
                    "甘孜藏族自治州":"513300",
                    "凉山彝族自治州":"513400",
                    "贵阳市":"520100",
                    "六盘水市":"520200",
                    "遵义市":"520300",
                    "安顺市":"520400",
                    "铜仁地区":"522200",
                    "黔西南布依族苗族自治州":"522300",
                    "毕节地区":"522400",
                    "黔东南苗族侗族自治州":"522600",
                    "黔南布依族苗族自治州":"522700",
                    "昆明市":"530100",
                    "曲靖市":"530300",
                    "玉溪市":"530400",
                    "保山市":"530500",
                    "昭通市":"530600",
                    "丽江市":"530700",
                    "临沧市":"530900",
                    "楚雄彝族自治州":"532300",
                    "红河哈尼族彝族自治州":"532500",
                    "文山壮族苗族自治州":"532600",
                    "思茅市":"532700",
                    "西双版纳傣族自治州":"532800",
                    "大理白族自治州":"532900",
                    "德宏傣族景颇族自治州":"533100",
                    "怒江傈僳族自治州":"533300",
                    "迪庆藏族自治州":"533400",
                    "拉萨市":"540100",
                    "昌都地区":"542100",
                    "山南地区":"542200",
                    "日喀则地区":"542300",
                    "那曲地区":"542400",
                    "阿里地区":"542500",
                    "林芝地区":"542600",
                    "西安市":"610100",
                    "铜川市":"610200",
                    "宝鸡市":"610300",
                    "咸阳市":"610400",
                    "渭南市":"610500",
                    "延安市":"610600",
                    "汉中市":"610700",
                    "榆林市":"610800",
                    "安康市":"610900",
                    "商洛市":"611000",
                    "兰州市":"620100",
                    "嘉峪关市":"620200",
                    "金昌市":"620300",
                    "白银市":"620400",
                    "天水市":"620500",
                    "武威市":"620600",
                    "张掖市":"620700",
                    "平凉市":"620800",
                    "酒泉市":"620900",
                    "庆阳市":"621000",
                    "定西市":"621100",
                    "陇南地区":"622600",
                    "临夏回族自治州":"622900",
                    "甘南藏族自治州":"623000",
                    "西宁市":"630100",
                    "海东地区":"632100",
                    "海北藏族自治州":"632200",
                    "黄南藏族自治州":"632300",
                    "海南藏族自治州":"632500",
                    "果洛藏族自治州":"632600",
                    "玉树藏族自治州":"632700",
                    "海西蒙古族藏族自治州":"632800",
                    "银川市":"640100",
                    "石嘴山市":"640200",
                    "吴忠市":"640300",
                    "固原市":"640400",
                    "中卫市":"640500",
                    "乌鲁木齐市":"650100",
                    "克拉玛依市":"650200",
                    "吐鲁番地区":"652100",
                    "哈密地区":"652200",
                    "昌吉回族自治州":"652300",
                    "博尔塔拉蒙古自治州":"652700",
                    "巴音郭楞蒙古自治州":"652800",
                    "阿克苏地区":"652900",
                    "克孜勒苏柯尔克孜自治州":"653000",
                    "喀什地区":"653100",
                    "和田地区":"653200",
                    "伊犁哈萨克自治州":"654000",
                    "塔城地区":"654200",
                    "阿勒泰地区":"654300",
                    "台湾省":"710000",
                    "香港特别行政区":"810000",
                    "澳门特别行政区":"820000"
                }
                if(type == 'pri'){
                    return objPri[name];
                }else{
                    return objCity[name];
                }
            },
            bodyScroll (event){
                event.preventDefault();
            }
        },
        computed: {
            ...mapState({
                companyInfo:state => state.pro.companyInfo,
                hasIndustry:state => state.pro.hasIndustry,
                hasOrganizationName:state => state.pro.hasOrganizationName,
                hasProvinceName:state => state.pro.hasProvinceName
            })
        },
        mounted(){
            document.body.scrollTop = 0;
            this.fontColor = sessionStorage.fontColor;
            //人员信息录入页
            SKAPP.onEvent("人员信息录入页", "进入人员信息录入页",{
                icpProductCode:sessionStorage.icpProductCode,
            });
            //取数据
        },
        beforeDestroy(){
            document.body.removeEventListener('touchmove',this.bodyScroll,false);
        }
    }

//过滤器
Vue.filter( 'province' , function(value) {
    if(!value || value.length < 2) return '城市 ';
    if(value.indexOf('省') > -1){//展示所在地处理
        return value.split('省')[0] + ' ';
    }else if(value.indexOf('市') > -1){
        return value.split('市')[0] + ' ';
    }else{
        return value.substring(0,2) + ' ';
    }
});
Vue.filter( 'orgCodeType' , function(value) {
    if(!value || value == '1'){
        return '组织机构代码';
    }else if(value == '2'){
        return '社会信用代码';
    }else{
        return '营业执照';
    }
});
Vue.filter( 'doLen' , function(value) {
    if(value.length > 10){
        return value.substring(0,10) + '...';
    }
    return value;
});
</script>