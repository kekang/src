<template>
    <div>
        <div id="highRisk">

        </div>
        <div v-show="coverFlag" @click="closeBox" class="cover">

        </div>
        <div v-show="coverFlag" class="coverBox">
            <div class="boxKey">{{boxKey}}</div>
            <div class="boxValue">
                <p v-for="value in boxValue">{{value}}</p>
            </div>
            <div class="boxClose"@click="closeBox">关闭</div>
        </div>
    </div>

</template>

<script>
import {Msg}from "components";
import Vue from "vue"
export default{
    props: {
        //回调函数
        fnt:{
            type:Function,
            default:function(){
            }
        }
    },
    data () {
        return {
            coverFlag:false,
            html:"",
            boxKey:"",
            boxValue:"",
            msg:[{
                    "key":"农牧渔业",
                    "value":[
                        "有毒动物饲养工（蛇、蝎子、蜈蚣等）、捕鱼人(内陆、沿海)、养殖工人(沿海)、远洋渔船船员、近海渔船船员"
                    ]
                },{
                    "key":"木材森林业",
                    "value":[
                        "伐木工人、锯木工人、装运工人、挂钩工人、木材搬运工人"
                    ]
                },{
                    "key":"矿业采掘业",
                    "value":[
                        "矿工、采掘工、爆破工、海上作业人员、潜水人员、采石业工人、采砂业工人、陆上油矿开采技术员、油气井清洁保养修护工、钻勘设备安装换修保养工、钻油井工人、井下作业工"
                    ]
                },{
                    "key":"交通运输业",
                    "value":[
                        "陆运：混凝土预拌车驾驶员、搬运工人、装卸工人、矿石车司机及随车工人、铁路货运、铁路搬运工人",
                        "海运：救难船员、客货轮（远洋）所有随船人员",
                        "空运：民航机飞行人员、直升机飞行人员"
                    ]
                },{
                    "key":"建筑工程",
                    "value":[
                        "建筑公司：钢骨结构工人、鹰架架设工人、铁工、焊工、建筑工程机械操作员、拆屋、迁屋工人、凿岩工、装饰装修工（室外）（基础装修至毛坯）",
                        "铁路公路铺设：现场勘测人员（山区）、铺设工人(山地)、维护工人、电线架设及维护工人、高速公路工程人员(含美化人员)、铁路舟桥工",
                        "造修船业：拆船工人",
                        "装璜：室外装璜人员、金属门窗制造工人、金属门窗装修工人安装玻璃幕墙工人、钢结构安装工、中央空调系统安装及维护人员、电梯升降机安装工人（高空）、木制家具制造工人",
                        "测绘工程：海洋测绘工程技术人员（海上作业）、地质探测员（山区）、地质探测员（海上）、海湾港口工程人员、水坝工程人员、挖井工程人员、桥梁工程人员、隧道工程人员、潜水工作人员、爆破工作人员、挖泥船工人"
                    ]
                },{
                    "key":"制造加工维修业",
                    "value":[
                        "冶金业：高炉原料工、高炉炉前工、高炉运转工、炼钢原料工、炼钢工、炼钢浇铸工、炼钢准备工、铁合金电炉冶炼工、火法冶炼工、烟气制酸工、酸洗工、金属材热处理工、焊管工、金属挤压工、铸轧工、铸管工、硬质合金成型工",
                        "机械制造维修业：车床工、车工、铸造工、锻造工、冲压工、剪切工、金属热处理工、粉末冶金处理工、电切削工、锅炉设备装配工、铁心叠装工、铁路车辆制造装修工、制浆设备操作工、制浆废液回收利用工、焊接工、冲压工、剪床工、玻璃加工工",
                        "电机业：有关高压电之工作人员",
                        "水泥业(包括水泥、石膏、石灰、陶器)：水泥生产制造工、采掘工、爆破工、石灰焙烧工、加气混凝土制品工、装饰石材生产工、石棉制品工、金刚石制品工",
                        "化工业：防腐蚀工、油制气工、炼焦工、焦炉机车司机、煤制气工、煤气储运工、硫酸铵生产工、过磷酸铵生产工、硫酸生产工、硝酸生产工、盐酸生产工、磷酸生产工、纯碱生产工、烧碱生产工、氟化盐生产工、缩聚磷酸盐生产工、气体深冷分离工、制氧工、工业气体液化工、二氧化硫制造工、脂肪烃生产工、橡胶生产工、化纤聚合工、其他有毒物品生产工、火药炸药业制造人员、子弹制造人员、火工品制造人员、烟花爆竹业人员",
                    ]
                },{
                    "key":"出版广告业",
                    "value":[
                        "战地记者、广告招牌架设人员、霓虹光管安装及维修人员"
                    ]
                },{
                    "key":"娱乐业",
                    "value":[
                        "武打演员、特技演员、广播电视天线工、动物园驯兽师、高空杂技、飞车、飞人演员"
                    ]
                },{
                    "key":"文教机构",
                    "value":[
                        "飞行训练教官及学员、特殊运动班学生（拳击、摔跤、跆拳道等）、武术学校学生"
                    ]
                },{
                    "key":"公共事业",
                    "value":[
                        "电台天线维护人员、光缆铺设人员、高压线路带电检修工、变压器检修工、变电设备检修工、牵引电力线路安装维护工、电力设施架设人员、电力高压电工程设施人员"
                    ]
                },{
                    "key":"服务业",
                    "value":[
                        "高楼外部清洁工、烟囱清洁工"
                    ]
                },{
                    "key":"公检法等执法检查机关",
                    "value":[
                        "警务特勤、防暴警察、武警、防毒防化防核抢险员、一般事故抢险员、消防队队员"
                    ]
                },{
                    "key":"军人",
                    "value":[
                        "特种兵(海军陆站队、伞兵、水兵、爆破兵、蛙人、化学兵、负有布雷爆破任务之工兵、情报单位负有特殊任务者)、空军飞行官兵、空军海洋巡弋舰艇及潜艇官兵、前线军人、军校学生及入伍受训新兵"
                    ]
                },{
                    "key":"职业运动 ",
                    "value":[
                        "滑雪人员、橄榄球球员、摔跤运动员、职业拳击运动员、业余拳击运动员、马术运动员"
                    ]
                }]
        }
    },
    components:{

    },
    methods:{
        closeBox(){
            this.coverFlag=false;
            this.fnt(false)
        }
    },
    mounted(){
        console.log(this.msg[0])
        var length = this.msg.length,line = 3,row = Math.ceil(length/line),listFlag=false;
        for(let i = 0;i<row;i++){
            if(listFlag){
                break
            }
             //单行循环
            let index = i*line;this.html += '<div class="box" style="width:95%;' +
                                                                    'margin:0 auto">'
            for(let j = 0;j<line;j++){
                //列循环
                let eq = index+j;
                if(!this.msg[eq]){
                    listFlag = true;
                    break;
                }
                this.html += '<div class="box-list" eq="'+eq+'" style="display: inline-block;' +
                                                          'width: 30%;' +
                                                          'font-size:1.2rem;' +
                                                          'line-height:2.2rem;' +
                                                          'border:1px solid #666;' +
                                                          'text-align:center;' +
                                                          'white-space: nowrap;'+
                                                          'overflow: hidden;'+
                                                          'vertical-align: bottom;'+
                                                          'margin:0 1% 1rem 1%;' +
                                                          'text-overflow: ellipsis">'+this.msg[eq].key+'</div>'
            }
                this.html += '</div>'
        }
        document.getElementById("highRisk").innerHTML=this.html;
        let that = this
        for(let k = 0;k<length;k++){
            document.getElementsByClassName("box-list")[k].onclick=function(){
                console.log(that.msg[k].value)
                that.coverFlag = true;
                that.fnt(true)
                that.boxKey = that.msg[k].key;
                that.boxValue = that.msg[k].value
            }
        }

        //console.log(this)
        //var highRisk = Vue.extend({
        //    template:this.html
        //})
        //new highRisk().$mount("#highRisk")
    }

}


</script>
<style scoped>
    .box {
        width: 95%;
        margin: 0 auto;
    }
    .box-list {
        display: inline-block;
        width: 30%;
        font-size: 1.2rem;
        line-height: 2.2rem;
        border: 1px solid #666;
        text-align: center;
        margin: 0 1% 1rem 1%;
    }
    .cover{
        position:fixed;
        top:0;
        left:0;
        width:100%;
        height:100%;
        z-index:5;
        background-color:rgba(0,0,0,0.6)
    }
    .coverBox{
        position: fixed;
        top: 12%;
        left: 15%;
        width: 70%;
        min-height: 12rem;
        max-height: 79%;
        z-index:6;
        background-color: #fff;
    }
    .boxKey {
        margin: 1.5rem 1rem;
        font-size: 1.3rem;
        color: #000;
    }
    .boxValue {
        font-size: 1.3rem;
        color: #666;
        margin: 0 1rem 0;
        overflow: scroll;
        max-height: 35rem;
    }
    .boxClose{
        width:10rem;
        line-height:2.2rem;
        border:1px solid #666;
        border-radius:1.1rem;
        text-align:center;
        margin:1.5rem auto
    }
</style>