<template>
<transition name="pd-loading">
    <div class="pd-loading" v-show="show">
        <div class="pd-loading-wrapper">
            <!--<img src="../../assets/images/ajax-loader.gif">-->
            <img src="./ajax-loader.svg">
            <span class="pd-loading-text" v-if="text">{{text}}</span>
        </div>
    </div>
</transition>
</template>
<style lang="less">
.pd-loading-enter, .pd-loading-leave-active {
    opacity: 0;
}

.pd-loading {
    transition: opacity 0.3s linear;
    width: 100%;
    height: 100%;
    position: fixed;
    z-index: 100;
}

.pd-loading-wrapper {
    position: fixed;
    top: 40%;
    left: 50%;
    padding: 2rem;
    transform: translate(-50%, -50%);
    -webkit-transform: translate(-50%, -50%);
    text-align: center;
    background-color: rgba(0, 0, 0, 0.7);
    border-radius: .5rem;
    line-height: .1rem;

    img {
        width: 3.6rem;
    }

    .pd-loading-text {
        display: block;
        color: #fff;
        margin-top: 1.5rem;
        font-size: 1.4rem;
    }
}
</style>
<script>
export default {
    props: {
        text: String
    },
    data () {
        return {
            show: false
        }
    }
}
</script>
