import Loading from './ajax-loading/Loading'
import Msg from './Msg/Msg'

export {
    Loading,
    Msg,
}
