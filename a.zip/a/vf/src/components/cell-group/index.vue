<template>
    <div class="cell_group_container">
        <div>
            <cell iconIsRotate :title="title" :value="value" isLink :on-change="change">
                <span slot="img">
                    <slot name="img"></slot>
                </span>
            </cell>
        </div>
        <div class="group_con" :class="{'height_0': !no_height}">
            <group>
                <slot></slot>
            </group>
        </div>
    </div>
</template>
<script>
import cell  from '../cell'
import group  from '../group'
export default {
components: {
    cell,
    group
  },
  props: {
    title: String,
    value: String,
  },
  //本地数据
  data () {
    return {
        no_height: false
    }
  },
  //进入页面加载
  mounted () {

  },
  //方法
  methods: {
    change (data) {
    this.no_height = data;
    }
  }
}
</script>

<style lang="less" scoped >
.cell_group_container{
    .group_con{
        overflow: hidden;
        transition: all 1s;
        border-top: 1px solid #ccc;
    }
    .height_0{
        height:0;
    }

}
</style>

