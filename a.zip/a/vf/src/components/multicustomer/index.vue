<template>
    <div class="multicustomer">
        <div>
            <div class="info_box_head" :style="{color:fontColor}">投保人信息</div>
            <!--姓名-->
            <div class="info_box_text">
                <div class="left">姓名</div>
                <input name="name" id="name_1" placeholder="请填写真实姓名" class="rightblank right">
            </div>
            <!--证件类型-->
            <div class="info_box_text">
                <div class="left">证件类型</div>
                <div >
                    <div class="rightarrow" ></div>
                    <div name="type" id="type_1" class="right"></div>
                </div>
                <popup v-model="popupType" name="popupType" position="bottom">
                    <div class="showBar">
                        <span class="cancle" @click="cancleType" :style="{color:fontColor}">取消</span>
                        <span class="confirm" @click="confirmType" :style="{color:fontColor}">确认</span>
                    </div>
                    <div class="page-picker-wrapper">
                        <picker :slots="cardTypeList"  name="pickerType" @change="onValuesChange">
                        </picker>
                    </div>
                </popup>

            </div>
            <!--证件号码-->
            <div class="info_box_text">
                <div class="left">证件号码</div>
                <input name="num" id="num_1" placeholder="请填写有效证件号码" class="right rightblank" />
            </div>
            <!--性别-->
            <div class="info_box_text">
                <div class="left">性别</div>
                <div>
                    <div class="rightarrow" ></div>
                    <div name="type"  id="sex_1" class="right" ref="sex_1"></div>
                </div>
            </div>
            <!--出生日期-->
            <div class="info_box_text">
                <div class="left">出生日期</div>
                <div>
                    <div class="rightarrow" ></div>
                    <span name="birth" id="birth_1" class="right"></span>
                </div>
                <!--<datetime-picker>
                    <!--ref="picker1"
                    type="date"
                    :startDate= "start_1"
               ``     :endDate="end_1"
                    @confirm="dateConfirm_1"
                    :TPick="TPick"-->
                </datetime-picker>-->
            </div>
            <!--手机号-->
            <div class="info_box_text">
                <div class="left">手机号</div>
                <input maxlength="11" name="ph" id="ph_1" type="tel"  placeholder="请填写手机号" class="right rightblank"/>
            </div>
            <!--邮件-->
            <div class="info_box_text mail">
                <div class="left leftMail">邮件</div>
                <input name="ph" placeholder="请填写邮箱" class="right rightblank rightMail"/>
            </div>
        </div>
        <div>
            <button>确认</button>
            <button>取消</button>
        </div>
    </div>
</template>
<style scoped>
.left{
    float:left;
}
.right{
    float: right;
    /*width: 20rem;*/
    text-align: right;
    height: 4.3rem;
}

.info_box{
    width:95%;
    margin:1.0rem auto;
    border-radius:8px
}
input {
    border: none;
    line-height: 4.3rem;
    margin-top: 1px;
    text-align: right;
    font-size: 1.5rem;
    font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
    color: #666666;
    background-color:#fff
}
.info_box_text{
    height:4.5rem;
    line-height:4.5rem;
    padding: 0 0.8rem 0 1.2rem;
    background-color:#FFFFFF;
    font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
    font-size: 1.5rem;
    color: #666666;
    border-bottom:1px dashed #aaa;
}
.info_box_name{
    width:60%
}
.info_box:nth-child(2){
    padding-bottom:6.5rem;
}
.info_box_text:last-child{
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
    border-bottom:0;
}
.info_box_head{
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    text-align:left;
    padding: 0 0 0 1rem;
    height:4.5rem;
    line-height:4.5rem;
    background-color:@background-color-light;
    font-family: Arial, "Microsoft YaHei", Helvetica, sans-serif;
    font-size: 1.7rem;
    color: @iconfont;
}
.showBar{
    height: 40px;
    border-bottom: solid 1px #eaeaea;
}
.cancle{
    display: inline-block;
    font-size: 16px;
    color: @iconfont;
    width: 50%;
    text-align: center;
    line-height: 40px;
    float: left;
}

.next_button{
    position:fixed;
    bottom:0;
    width:100%;
    height:6.5rem;
    background-color:rgba(0,0,0,0.3);
    padding-top: 1rem;
}
.next_button>p{
    width:95%;
    margin:0rem auto 0;
    height:4.5rem;
    line-height:4.5rem;
    background-color:@font-color-blue;
    border-radius:8px;
    color:#FFF;
    font-size:1.7rem;
    line-height:4.5rem;
    text-align:center;
}
</style>
<scripts>
import {Msg}from "components";
//import datetimePicker from '../datetime-picker/index.js';
import picker from '../picker/index.js';
import popup from '../popup/index.js';

export default{
    props: {
        detail:{
            type:Object,
            default:""
        },
        //是否显示
        visible: {
            type: Boolean,
            default: true
        }
    },
    data () {
        return {
            cardTypeList:[{
                flex: 1,
                values:["身份证","出生证","","","",""],
            }],
            popupType:false,
            fontColor:"#2688c4",
        }
    },
    components:{
        picker,
        popup,
        datetimePicker,
    },
    methods:{
        startType(options,value){
            this.popupType=true
        },
        cancleType(){
            this.popupType=false
        },
        confirmType(){
            this.popupType=false
        },
        onValuesChange(){
            return 0;
        }
    },
    mounted(){
        alert("123")
    }

}


</scripts>