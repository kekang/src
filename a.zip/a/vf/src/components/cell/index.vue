
<template>
    <div class="cell_container">
        <div class="cell_container_sub" @click="onClick" :class="{border_top:isLink}">
            <slot>
                <div class="cell_title"><slot name="img"></slot>{{title}}</div>
                <slot name="value">
                    <div class="cell_value">{{value}} <span v-if="isLink" class="icon" :class="{'dropDown':isDrop}"></span></div>
                </slot>
            </slot>
        </div>
        <div class="title_sub">{{describe}}</div>
    </div>
</template>

<script>
import { go } from './router'
export default {
  props: {
    title: String,
    iconIsRotate: Boolean,
    onChange: {
        type: Function,
        default: function(){}
    },
    value: String,
    describe: String,
    isLink: Boolean,
    link: {
      type: [String, Object]
    }
  },
  data (){
    return {
      isDrop: false
    }
  },
  //方法
  methods: {
    iconRotate () {
    if(this.iconIsRotate){this.isDrop = ! this.isDrop};
    this.onChange(this.isDrop);
    },
    onClick () {
      this.iconRotate();
      go(this.link, this.$router)
    }
  }
}
</script>

<style lang="less" scoped>
    .cell_container{
        position: relative;
        .border_top{
            border-top: 1px solid #ccc;
        }
        .title_sub{
            font-size: 1.5rem;
            line-height: 1;
            position: absolute;
            bottom: .2rem;
            left:1rem;
            color: #999999;
        }
        .cell_container_sub{
            display: flex;
            justify-content: space-between;
            padding: 1rem;
            line-height: 3rem;
            font-size: 1.5rem;
            .cell_value{
                position: relative;
                .icon{
                    display: inline-block;
                    transform: rotate(45deg) ;
                    transition: all .3s;
                    height: .8rem;
                    width: .8rem;
                    border-width: .2rem .2rem 0 0;
                    border-color: #C8C8CD;
                    border-style: solid;
                    position: relative;
                }
                .dropDown{
                    transform: rotate(135deg) ;
                }
            }
        }
    }

</style>
