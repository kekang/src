/**
 * Created by zhangping702 on 16/12/25.
 */

function changeColor() {
    //颜色切换
    switch (sessionStorage.col){
        case "B2":
            return "#4285F6"//66,133,246
        case "Y1":
            return "#D8A161"//216,161,97
        case "O1":
            return "#FF6000"//255,96,0
        case "R1":
            return "#F76B6C"//247,107,108
        case "R2":
            return "#F11B33"//241,27,51
        default:
            return "#2688c4"//38,136,196
    }
}
function changeColor_2() {
    //颜色切换
    switch (sessionStorage.col){
        case "B2":
            return "#4285F6"
        case "Y1":
            return "#D8A161"
        case "O1":
            return "#FF6000"
        case "R1":
            return "#F76B6C"
        case "R2":
            return "#F11B33"
        default:
            return "#ff6600"
    }
}
function HEXshiftRGB(color){
    switch (color){
        case "4285F6":
            return "rgb(66,133,246)"
        case "D8A161":
            return "rgb(216,161,97)"
        case "FF6000":
            return "rgb(255,96,0)"
        case "F76B6C":
            return "rgb(247,107,108)"
        case "F11B33":
            return "rgb(241,27,51)"
        default:
            return "rgb(38,136,196)"
    }
}
module.exports = {
    changeColor,
    changeColor_2,
    HEXshiftRGB
}