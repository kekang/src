/**
 * Created by zhangping702 on 17/2/14.
 */
import {Msg} from "components"
//健康险
//与投保人关系
function hel_relationShip(relationShipCode) {
    switch(relationShipCode){
        case "1":
            return "本人";
        case "2":
            return "配偶";
        case "3":
            return "父母";
        case "4":
            return "子女";
        case "5":
            return "其他";
    }
}
//与被保人一关系
function hel_relationShipEx(relationShipCode) {
    switch(relationShipCode){
        case "1":
            return "本人";
        case "2":
            return "配偶";
        case "3":
            return "子女";
        case "4":
            return "父母";
        case "6":
            return "其他";
    }
}
//证件类型
function hel_insurId(insurIdType) {
    switch(insurIdType){
        case "01":
            return "身份证"
        case "02":
            return "护照"
        case "03":
            return "军人证"
        case "06":
            return "港澳台回乡证"
        case "07":
            return "出生证"
        case "08":
            return "户口本"
    }
}
//性别
function hel_sex(insurGender) {
    switch(insurGender){
        case"M":
            return "男";
        case"F":
            return "女";
        default:
            return ""
    }
}
//地区
function hel_ProvinceCode(place) {
    switch(place){
        case"深圳":
            return "H050000"
        case"天津":
            return "H030000"
        case"辽宁(除大连)":
            return "H060000"
        case"北京":
            return "H010000"
        case"上海":
            return "H020000"
        case"广东":
            return "H040000"
        case"江苏":
            return "H100000"
        case"浙江":
            return "H120000"
    }
}
function hel_Province(place) {
    switch(place){
        case"H050000":
            return "深圳"
        case"H030000":
            return "天津"
        case"H060000":
            return "辽宁(除大连)"
        case"H010000":
            return "北京"
        case"H020000":
            return "上海"
        case"H040000":
            return "广东"
        case"H100000":
            return "江苏"
        case"H120000":
            return "浙江"
    }
}
/*日期操作
 * +-：20170316->2017-03-16
 * --：2017-03-16->20170316
 * +0: 2017316->20170316
 * toParse: 转为时间戳(兼容20170316和2017-03-16格式)
 * toCorrect: 转为标准时间Mon Apr 03 2017 00:00:00 GMT+0800 (兼容20170316，2017-03-16，时间戳)
 * parseToTime0: 时间戳转为20170316
 * parseToTime-: 时间戳转为2017-03-16
 * parseToCorrect: 时间戳转为标准时间Mon Apr 03 2017 00:00:00 GMT+0800
 * */
function changeDate(type,d){//日期格式化，+-，--，转为时间戳
    if(type != '+0' && !d) return '';
    if(type == '+-'){
        let year = d.substring(0,4),month = d.substring(4,6),day = d.substring(6,8);
        return year +"-" + month + "-" + day;
    }else if(type == '--'){
        return d.replace(/-/g, "");
    }else if(type == '+0'){
        let yearMax = new Date().getFullYear(),monthMax = new Date().getMonth() + 1,dayMax = new Date().getDate();
        if(monthMax < 10) monthMax = "0" +monthMax;
        if(dayMax < 10) dayMax = "0" + dayMax;
        return yearMax + "" + monthMax + dayMax;
    }else if(type == 'toParse'){
        if(d.indexOf('-') > -1){
            let arr = d.split('-');
            return Date.parse(arr[0],arr[1]-1,arr[2]);
        }else{
            return Date.parse(d.substring(0,4),d.substring(4,6)-1,d.substring(6,8));
        }
    }else if(type == 'toCorrect'){
        if(d.indexOf('-') > -1){
            let arr = d.split('-');
            return new Date(arr[0],arr[1]-1,arr[2]);
        }else if(d.length < 10){
            return new Date(d.substring(0,4),d.substring(4,6)-1,d.substring(6,8));
        }else{
            return new Date(Number(d));
        }
    }else if(type == 'parseToTime0'){
        d = Number(d);
        let y = new Date(d).getFullYear(),m = new Date(d).getMonth() + 1,d = new Date(d).getDate();
        if(m < 10) m = "0" + m;
        if(d < 10) d = "0" + d;
        return y + ''+ m + d;
    }else if(type == 'parseToTime-'){
        d = Number(d);
        let y = new Date(d).getFullYear(),m = new Date(d).getMonth() + 1,d = new Date(d).getDate();
        if(m < 10) m = "0" + m;
        if(d < 10) d = "0" + d;
        return y + '-'+ m + '-' + d;
    }else if(type == 'parseToCorrect'){
        return new Date(Number(d));
    }else{
        return d;
    }
}
/*根据投保年龄范围计算生日范围
 * 返回最大最小生日范围，默认展示最大还是最小
 * */
function birTimeRange(min,max,defaultAge,minday){//birTimeRange(0,60,25,28),最小28天
    if(isNaN(min) || isNaN(max) || isNaN(defaultAge)) return {};
    let _max = Date.parse(new Date(new Date().getFullYear() - min,
        new Date().getMonth(),
        new Date().getDate())),obj = {};
    _max = _max - (60*60*24*1000)*(min == 0 ? minday : 1);
    let y = new Date(_max).getFullYear(),m = new Date(_max).getMonth() + 1,d = new Date(_max).getDate();
    if(m < 10) m = "0" + m;
    if(d < 10) d = "0" + d;
    obj.max = y + '-'+ m + '-' + d;
    let yy = new Date().getFullYear() - max - 1,mm = new Date().getMonth() + 1,dd = new Date().getDate();
    if(mm < 10) mm = "0" + mm;
    if(dd < 10) dd = "0" + dd;
    obj.min = yy + '-'+ mm + '-' + dd;
    let yyy = new Date().getFullYear() - defaultAge,mmm = new Date().getMonth() + 1,ddd = new Date().getDate() - 1;
    if(mmm < 10) mmm = "0" + mmm;
    if(ddd < 10) ddd = "0" + ddd;
    obj.defaultAge = yyy + '-'+ mmm + '-' + ddd;
    return obj;//{max:'2017-03-10',min:'2017-03-10',defaultAge:'2017-03-10'}生日最大值最小值默认值
}
function birTimeRangeZs(min,max,defaultAge,minday){//周岁，birTimeRange(0,60,25,28),最小28天,境外旅游特供
    if(isNaN(min) || isNaN(max) || isNaN(defaultAge)) return {};
    let _max = Date.parse(new Date(new Date().getFullYear() - min,
        new Date().getMonth(),
        new Date().getDate())),obj = {};
    _max = _max - (60*60*24*1000)*(min == 0 ? minday : 1) + 60*60*24*1000;
    let y = new Date(_max).getFullYear(),m = new Date(_max).getMonth() + 1,d = new Date(_max).getDate();
    if(m < 10) m = "0" + m;
    if(d < 10) d = "0" + d;
    obj.max = y + '-'+ m + '-' + d;
    let yy = new Date().getFullYear() - max - 1,mm = new Date().getMonth() + 1,dd = new Date().getDate();
    if(mm < 10) mm = "0" + mm;
    if(dd < 10) dd = "0" + dd;
    let _m = Date.parse(new Date(yy + '-'+ mm + '-' + dd)) + 60*60*24*1000;
    let a = new Date(_m).getFullYear(),b = new Date(_m).getMonth() + 1,c = new Date(_m).getDate();
    if(b < 10) b = "0" + b;
    if(c < 10) c = "0" + c;
    obj.min = a + '-'+ b + '-' + c;
    let yyy = new Date().getFullYear() - defaultAge,mmm = new Date().getMonth() + 1,ddd = new Date().getDate() - 1;
    if(mmm < 10) mmm = "0" + mmm;
    if(ddd < 10) ddd = "0" + ddd;
    obj.defaultAge = yyy + '-'+ mmm + '-' + ddd;
    return obj;//{max:'2017-03-10',min:'2017-03-10',defaultAge:'2017-03-10'}生日最大值最小值默认值
}
function effTimeRange(fixedEff,minEff,maxEff){//effTimeRange(undefined,1,1)
    let timestamp = Date.parse(new Date()),newTime,obj = {};
    if(fixedEff){
        obj.max = obj.min = changeDate('toParse',fixedEff);
        obj.minShow = obj.maxShow = fixedEff;
    }else if(!fixedEff && minEff && maxEff){
        obj.min = timestamp + minEff*(60*60*24*1000);
        obj.max = timestamp + maxEff*(60*60*24*1000);
        let y = new Date(obj.min).getFullYear(),m = new Date(obj.min).getMonth() + 1,d = new Date(obj.min).getDate();
        if(m < 10) m = "0" + m;
        if(d < 10) d = "0" + d;
        obj.minShow = y + ''+ m + d;
        let yy = new Date(obj.max).getFullYear(),mm = new Date(obj.max).getMonth() + 1,dd = new Date(obj.max).getDate();
        if(mm < 10) mm = "0" + mm;
        if(dd < 10) dd = "0" + dd;
        obj.maxShow = yy + ''+ mm + dd;
    }
    return obj;//obj = {minShow:"2017-03-18",maxShow:"2017-03-18",min:1489795200000,max:1489795200000}生效日最大最小值及时间戳
}
//服务器状态码返回
function resultCode(msg) {
    switch (msg.resultCode){
        //其他错误
        case"99999":
            /**
             *未知异常
             */
            return "系统错误，请稍后再试"
        //以下是保单交易异常状态
        case"11001":
            /**
             *保单产品展示详情入参为空
             */
            return "产品查询错误，请稍后再试"
        case"11002":
            /**
             *合作伙伴产品不可售
             */
            return "合作伙伴暂时无权销售此产品"
        case"11003":
            /**
             *产品组合代码为空
             */
            return "产品组合代码错误，请稍后再试"
        case"11004":
            /**
             *询价失败
             */
            return "询价失败"
        case"11005":
            /**
             *核保失败
             */
            return "核保失败"
        case"11006":
            /**
             *产品订单号为空
             */
            return "产品订单号错误"
        //以下是订单异常状态
        case"13001":
            /**
             *订单非待支付状态
             */
            return "订单非待支付状态"
        case"13002":
            /**
             *订单不存在
             */
            return "订单不存在"
        //以下是投被保人信息异常状态
        case"15001":
            /**
             *投保人、被保人的五项信息校验不通过
             */
            return "投保人、被保人的五项信息校验不通过"
        case"15002":
            /**
             *投保人、被保人的地址信息校验不通过
             */
            return "投保人、被保人的地址信息错误"
        case"15003":
            /**
             *投保人、被保人的地址信息校验异常
             */
            return "投保人、被保人的地址信息错误"
        case"15004":
            /**
             *出生日期为空
             */
            return "出生日期需要填写"
        case"15005":
            /**
             *无常住地址省份
             */
            return "无常住地址省份"
        case"15006":
            /**
             *无常住地址城市
             */
            return "无常住地址城市"
        //以下是记录健康告知信息异常状态
        case"16001":
            /**
             *健康告知返回参数为空
             */
            return "健康告知错误"
        case"16002":
            /**
             *健康告知调查问卷返回答案不符合要求
             */
            return "健康告知调查问卷答案不符合要求"
        //订单再支付
        case"11007":
            /**
             *订单再支付订单展示详情入参为空
             */
            return "查询失败，请稍后再试"
        case"11008":
            /**
             *订单再支付订单号错误或者产品不可售
             */
            return "订单再支付订单号错误或者产品不可售"
        case"11009":
            /**
             *验签失败
             */
            return "系统错误，请稍后再试"
        case"18001":
            /**
             *订单再支付订单号错误或者产品不可售
             */
            return "未查到信息，请手工输入"
        case"18002":
            /**
             *验签失败
             */
            return "未查到信息，请手工输入"
        case"19001":
            /**
             *验签失败
             */
            return "记录保障接口异常"
        case"20001":
            /**
             *验签失败
             */
            return "核保失败"
        case"20002":
            /**
             *验签失败
             */
            return "投保失败"
        case"20003":
            /**
             *验签失败
             */
            return "渠道支付信息查询为空，需配置渠道支付信息。"

        default:
            return msg.resultMsg
    }
}
//证件号校验
var check = {
    // 护照校验：
    checkPassport: function(value) {
        var v = value.replace(/(^\s+)|(\s+$)/g,"").replace(/\s/g,"");
        return (this.checkNumberAndChar(value) && v.length >= 3 && v.length <= 30);
    },
    //其他证件
    checkAnother: function(value) {
        var v = value.replace(/(^\s+)|(\s+$)/g,"").replace(/\s/g,"");
        return (this.checkNumberAndChar(value) && v.length >= 3 && v.length <= 20);
    },
    checkNumberAndChar: function(val) {
        var reg = /^[A-Za-z0-9]+$/;
        return reg.test(val);
    },
    // 军人证：
    armymanId: function(value) {
        return (/((^[\u4e00-\u9fa5]{1}[\u5b57]{1}[\u7b2c]{1}[0-9]{5,14})+$)|((^[\u4e00-\u9fa5]{2}[\u5b57]{1}[\u7b2c]{1}[0-9]{5,14})+$)/.test(value));
    },
    //出生证校验
    checkBirthCard_emit: function (val) {
        return (/^[A-Z]{1}[0-9]{9}$/.test(val));
    },
    //港澳台回乡证
    checkHK: function (val) {
        val=val.replace(/\(/,"").replace(/\)/,"");
        return (/^[0-9A-Za-z]{8,30}$/.test(val));
    },
    //姓名正则
    checkName(val){
        return (isNaN(val));
    },
    // 身份证正则校验
    checkIdNum(num){
        if(String(num).length==18){
            var t=/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X|x)$/
        }else{
            Msg.alert("身份证位数不正确")
        }
        var tet=new RegExp(t);
        return tet.test(num)
    },
    /**
     * 判断邮箱
     * @param email_address 邮箱地址
     * @return
     */
    checkEmail( email_address ){
        var regex = /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g;
        return regex.test( email_address )//test方法用于检测是否匹配正则
    },
    /**
     * 身份证15位编码规则：dddddd yymmdd xx p
     * dddddd：地区码
     * yymmdd: 出生年月日
     * xx: 顺序类编码，无法确定
     * p: 性别，奇数为男，偶数为女
     * <p />
     * 身份证18位编码规则：dddddd yyyymmdd xxx y
     * dddddd：地区码
     * yyyymmdd: 出生年月日
     * xxx:顺序类编码，无法确定，奇数为男，偶数为女
     * y: 校验码，该位数值可通过前17位计算获得
     * <p />
     * 18位号码加权因子为(从右到左) Wi = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2,1 ]
     * 验证位 Y = [ 1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2 ]
     * 校验位计算公式：Y_P = mod( ∑(Ai×Wi),11 )
     * i为身份证号码从右往左数的 2...18 位; Y_P为脚丫校验码所在校验码数组位置
     *
     */
    EmitIdCodeValid(idCard) {
        if (idCard.length == 18) {
            var a_idCard = idCard.split("");// 得到身份证数组
            if (this.isValidityBrithBy18IdCard(idCard) && this.isTrueValidateCodeBy18IdCard(a_idCard)) {
                return true;
            } else {
                return false;
            }
        } else {
            Msg.alert("身份证位数不正确")
            return false;
        }
    },
    /**
     * 验证18位数身份证号码中的生日是否是有效生日
     * @param idCard 18位数身份证字符串
     * @return
     */
    isValidityBrithBy18IdCard(idCard18){
        var year = idCard18.substring(6, 10);
        var month = idCard18.substring(10, 12);
        var day = idCard18.substring(12, 14);
        var temp_date = new Date(year, parseFloat(month) - 1, parseFloat(day));
        if (temp_date.getFullYear() != parseFloat(year) ||
            temp_date.getMonth() != parseFloat(month) - 1 ||
            temp_date.getDate() != parseFloat(day)) {
            return false;
        } else {
            return true;
        }
    },
    /**
     * 判断身份证号码为18位时最后的验证位是否正确
     * @param a_idCard 身份证号码数组
     * @return
     */
    isTrueValidateCodeBy18IdCard(a_idCard){
        var Wi = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1];// 加权因子
        var ValideCode = [1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2];// 身份证验证位值.10代表X
        var sum = 0; // 声明加权求和变量
        if (a_idCard[17].toLowerCase() == 'x') {
            a_idCard[17] = 10;// 将最后位为x的验证码替换为10方便后续操作
        }
        for (var i = 0; i < 17; i++) {
            sum += Wi[i] * a_idCard[i];// 加权求和
        }
        var valCodePosition = sum % 11;// 得到验证码所位置
        if (a_idCard[17] == ValideCode[valCodePosition]) {
            return true;
        }
        else {
            return false;
        }
    },
    /**
     * 判断身份证的出生日期
     * @param num 身份证号码字符串
     * @return
     */
    birthID(num){
        let year = num.substring(6, 10);
        var month = num.substring(10, 12);
        var day = num.substring(12, 14);
        return year + "" +month +day
    },
    /**
     * 判断身份证的性别
     * @param num 身份证号码字符串
     * @return
     */
    sexconfirm(num){
        let idBirth
        //console.log(num)
        if(num.length == 15){
            idBirth = num.substr(14,1);
        }else{
            idBirth = num.substr(16,1);
        }
        if(idBirth%2){//偶数为F
            return "M"
        }else{
            return "F"
        }
    },
    checkPh(num){
        let flag;
        if(num){
            let num3rd = num.toString().substr(0,3);
            var arr = ["130","131","132","155","156","186","185","176","134","135","136","137","138","139","150","151","152","157","158","159","182","183","184","188","187","147","178","133","153","180","181","189","177"];
            for(var i = 0 ; i< arr.length ; i++){
                if(num3rd == arr[i]){
                    flag = true;
                    break;
                }else{
                    flag = false;
                }
            }
            if(num.length < 11) flag = false;
        }
        return flag;
    },
    isRepeat(arr){
        var hash = {};
        for(var i in arr) {
            if(hash[arr[i]]) return true;
            hash[arr[i]] = true;
        }
        return false;
    }
}
//计算年龄
function jsGetAge(strBirthday,strEff){
    var returnAge;
    var birthYear = strBirthday.getFullYear();
    var birthMonth = strBirthday.getMonth()+1;
    var birthDay = strBirthday.getDate();

    var nowYear = strEff.getFullYear();
    var nowMonth = strEff.getMonth() + 1;
    var nowDay = strEff.getDate();

    if(nowYear == birthYear){
        returnAge = 0;//同年 则为0岁
    }
    else{
        var ageDiff = nowYear - birthYear ; //年之差
        if(ageDiff > 0){
            if(nowMonth == birthMonth) {
                var dayDiff = nowDay - birthDay;//日之差
                console.log(dayDiff)
                if(dayDiff < 0)
                {
                    returnAge = ageDiff - 1;
                }
                else
                {
                    returnAge = ageDiff;
                }
            }
            else
            {
                var monthDiff = nowMonth - birthMonth;//月之差
                if(monthDiff < 0)
                {
                    returnAge = ageDiff - 1;
                }
                else
                {
                    returnAge = ageDiff;
                }
            }
        }
        else
        {
            returnAge = -1;//返回-1 表示出生日期输入错误
        }
    }
    return returnAge;//返回周岁年龄
}
function jsGetAgeNum(strBirthday,strEff,min,max){//根据生日计算年龄大小,与最大最小年龄比较，小微
    strBirthday = new Date(strBirthday);
    strEff = new Date(strEff);
    var returnAge;
    var birthYear = strBirthday.getFullYear();
    var birthMonth = strBirthday.getMonth()+1;
    var birthDay = strBirthday.getDate();

    var nowYear = strEff.getFullYear();
    var nowMonth = strEff.getMonth() + 1;
    var nowDay = strEff.getDate();

    if(nowYear == birthYear){
        returnAge = 0;//同年 则为0岁
    }
    else{
        var ageDiff = nowYear - birthYear ; //年之差
        if(ageDiff > 0){
            if(nowMonth == birthMonth) {
                var dayDiff = nowDay - birthDay;//日之差
                console.log(dayDiff)
                if(dayDiff < 1)
                {
                    returnAge = ageDiff - 1;
                }
                else
                {
                    returnAge = ageDiff;
                }
            }
            else
            {
                var monthDiff = nowMonth - birthMonth;//月之差
                if(monthDiff < 0)
                {
                    returnAge = ageDiff - 1;
                }
                else
                {
                    returnAge = ageDiff;
                }
            }
        }
        else
        {
            returnAge = -1;//返回-1 表示出生日期输入错误
        }
    }
    if(returnAge < min || returnAge > max){
        return false;
    }else{
        return true;
    }
    //return returnAge;//返回周岁年龄
};
function getBirByEff(min,max,eff,defaultDay){
    let start = new Date(eff),obj = {};
    if(min > 100){//说明是天，如180天
        let p = Date.parse(start) - 24*60*60*1000*(min+1);
        let y = new Date(p).getFullYear(),m = new Date(p).getMonth() + 1,d = new Date(p).getDate();
        if(m < 10) m = "0" + m;
        if(d < 10) d = "0" + d;
        obj.max = y + '-'+ m + '-' + d;
    }else if(min == 0){
        let p = Date.parse(start) - 24*60*60*1000*(defaultDay);
        let y = new Date(p).getFullYear(),m = new Date(p).getMonth() + 1,d = new Date(p).getDate();
        if(m < 10) m = "0" + m;
        if(d < 10) d = "0" + d;
        obj.max = y + '-'+ m + '-' + d;
    }else{
        let a = new Date(eff).getFullYear() - min,b = new Date(eff).getMonth() + 1,c = new Date(eff).getDate();
        if(b < 10) b = "0" + b;
        if(c < 10) c = "0" + c;
        let p = Date.parse(new Date(a + '-'+ b + '-' + c));
        let yyy = new Date(p).getFullYear(),mmm = new Date(p).getMonth() + 1,ddd = new Date(p).getDate();
        if(mmm < 10) mmm = "0" + mmm;
        if(ddd < 10) ddd = "0" + ddd;
        obj.max = yyy + '-'+ mmm + '-' + ddd;
    }
    let yy = new Date(eff).getFullYear() - max - 1,mm = new Date(eff).getMonth() + 1,dd = new Date(eff).getDate();
    if(mm < 10) mm = "0" + mm;
    if(dd < 10) dd = "0" + dd;
    let q = Date.parse(new Date(yy + '-'+ mm + '-' + dd)) + 24*60*60*1000;
    let yyy = new Date(q).getFullYear(),mmm = new Date(q).getMonth() + 1,ddd = new Date(q).getDate();
    if(mmm < 10) mmm = "0" + mmm;
    if(ddd < 10) ddd = "0" + ddd;
    obj.min = yyy + '-'+ mmm + '-' + ddd;
    return obj
}

function getChildBirByEff(eff){//养老险家庭险计算未成年子女生日
    let obj = {};
    let y = new Date(eff).getFullYear() - 18,m = new Date(eff).getMonth() + 1,d = new Date(eff).getDate();
    if(m < 10) m = "0" + m;
    if(d < 10) d = "0" + d;
    let p = Date.parse(new Date(y + '-'+ m + '-' + d)) + 24*60*60*1000;
    let a = new Date(p).getFullYear(),b = new Date(p).getMonth() + 1,c = new Date(p).getDate();
    if(b < 10) b = "0" + b;
    if(c < 10) c = "0" + c;
    obj.min = a + '-'+ b + '-' + c;
    let yy = new Date(eff).getFullYear(),mm = new Date(eff).getMonth() + 1,dd = new Date(eff).getDate();
    if(mm < 10) mm = "0" + mm;
    if(dd < 10) dd = "0" + dd;
    let q = Date.parse(new Date(yy + '-'+ mm + '-' + dd)) - 24*60*60*1000*29;
    let yyy = new Date(q).getFullYear(),mmm = new Date(q).getMonth() + 1,ddd = new Date(q).getDate();
    if(mmm < 10) mmm = "0" + mmm;
    if(ddd < 10) ddd = "0" + ddd;
    obj.max = yyy + '-'+ mmm + '-' + ddd;
    return obj
}
module.exports = {
    hel_relationShip,
    hel_relationShipEx,
    hel_Province,
    hel_insurId,
    hel_sex,
    hel_ProvinceCode,
    resultCode,
    changeDate,
    birTimeRange,
    birTimeRangeZs,
    getBirByEff,
    getChildBirByEff,
    effTimeRange,
    check,
    jsGetAge,
    jsGetAgeNum
}