/**
 * Created by GONGSHU273 on 2016/11/1.
 */

(function (window) {
    window.NativeBridge = {};
    var ua = navigator.userAgent.toUpperCase();

    window.NativeBridge.IS_ANDROID = ua.indexOf('ANDROID') != -1;    // 当前环境是否为Android平台
    window.NativeBridge.IS_IOS = ua.indexOf('IPHONE OS') != -1;    // 当前环境是否为IOS平台

    //--------------------------------------------------------
    //JS调用Native
    //--------------------------------------------------------

    window.NativeBridge.callNative = function (method) {
        var args = Array.prototype.slice.call(arguments, 1);//参数（非必填）
        var iosParam = {method: method, param: args};
        try {
            if (window.NativeBridge.IS_ANDROID) {
                window.AndroidBridge.service.postMessage(iosParam);
            } else if (window.NativeBridge.IS_IOS) {
                window.webkit.messageHandlers.IOSBridge.postMessage(iosParam);
            } else {
                if (method == "toast" || method == "alert") {
                    alert(args[0]);
                }
            }
        }
        catch (e) {
            if (method == "toast" || method == "alert") {
                alert(args[0]);
            }
        }
    };

    //loading封装
    window.NativeBridge.loading = function (show) {
        window.NativeBridge.callNative("loading", show ? '1' : '0');
    };

    //alert封装
    window.NativeBridge.alert = function (message) {
        window.NativeBridge.callNative("alert", message);
    };

    //toast封装
    window.NativeBridge.toast = function (message) {
        window.NativeBridge.callNative("toast", message);
    };

    //--------------------------------------------------------
    //Native调用JS
    //--------------------------------------------------------

    window.NativeBridge.nativeHandlerList = [];

    window.NativeBridge.registerNativeListener = function (method, handler) {
        var has = false;
        for (var i = 0; i < window.NativeBridge.nativeHandlerList.length; i++) {
            if (window.NativeBridge.nativeHandlerList[i].method == method && window.NativeBridge.nativeHandlerList[i].handler == handler) {
                //has = true;
                throw new Error("已经注册过同一个方法");
                //NativeBridge.nativeHandlerList[i].handler = handler;
            }
        }
        if (!has) {
            window.NativeBridge.nativeHandlerList.push({method: method, handler: handler});
        }
    };
    window.callJS = function(data) {
        console.log("native call js src data:" + data);
        eval(data);
        console.log("native call js:" + data.method + ",参数:" + data.data);
        for (var i = 0; i < window.NativeBridge.nativeHandlerList.length; i++) {
            if (window.NativeBridge.nativeHandlerList[i].method == data.method) {
                window.NativeBridge.nativeHandlerList[i].handler(data.data);
            }
        }
    };
}(window));

export function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) { return callback(WebViewJavascriptBridge); }
    if (window.WVJBCallbacks) { return window.WVJBCallbacks.push(callback); }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function() { document.documentElement.removeChild(WVJBIframe) }, 0)
}
