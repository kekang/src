/**
 * Created by zhangping702 on 16/12/29.
 */
function equipment (){

    var ua = navigator.userAgent;//用户代理

    var android = ua.match(/(Android);?[\s\/]+([\d.]+)?/);
    var ipad = ua.match(/(iPad).*OS\s([\d_]+)/);
    var ipod = ua.match(/(iPod)(.*OS\s([\d_]+))?/);
    var iphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/);

    // Android
    if (android) {
        return "android";
    }
    if (ipad || iphone || ipod) {
        return "ios";
    }
    return "other";
};

module.exports = {
    equipment
}