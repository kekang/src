import VueResource from 'vue-resource'
import Vue from 'vue'
import {isPrd, isString} from './index'
import {Msg, Loading} from 'components'


Vue.use(VueResource)

const TIMEOUT = 30000
function _timeout (req, next) {
    if (req.timeout === 0) {
        next()
        return
    }
    const timer = setTimeout(() => {
        req.abort()

        Loading.close()

        Msg.alert('请求超时')
    }, req.timeout || TIMEOUT)

    next((response) => {
        clearTimeout(timer)
    })
}
Vue.http.interceptors[1] = _timeout


//拦截
Vue.http.interceptors.push((request, next) => {
    function errorAlert (response) {
        Loading.close()
        let msg
        if (response.body && response.body.msg) {
            msg = response.body.msg
            Msg.alert(msg)
            return
        }else{
            Msg.alert(response)
        }
    }

    function checkError (response) {
        if (response.status >= 500 && response.status < 600) {
            errorAlert( "服务器错误:" + response.status)
        } else if (response.status === 200 && response.body ) {
            Loading.close()
            if (isString(response.body)) {
                response.body = JSON.parse(response.body)
            }
        } else if (response.status === 404) {
            errorAlert({
                body: {
                    msg: '服务地址错误:404'
                }
            })
        }
    }

    next(checkError)
})

function getURL (url) {
    Loading.show()
    if (typeof url === 'object') {
        //默认json，设置format:true,则为表单
        if(url.format){
            Vue.http.options.emulateJSON = true;//表单形式
        }else{
            Vue.http.options.emulateHTTP = true;//json形式
        }
        url = url.url
    }else{
        Vue.http.options.emulateJSON = false;//json形式
    }

    return url //本地
    //return 'http://test2-iicp-dmzstg.pingan.com.cn' + url;//icp测试
    //return 'http://test-yl.pingan.com.cn:2080' + url;//isp测试
}

Vue.use((vue) => {
    vue.getUrl = getURL
})
// let mockCfg
// mock = private (根据自有配置决定), all (强制所有mock), none (强制所有非mock)
// export default function config ( mock = 'private') {
//     mockCfg = function () {
//         if (isPrd()) {
//             return 'none'
//         } else {
//             return mock
//         }
//     }
// }




