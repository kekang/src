function setFontSize () {
    let gWidth = document.body.clientWidth, gPicWidth = 750, gmax = gWidth / gPicWidth * 20;
    if (gmax > 14) gmax = 14;
    gmax = parseInt(gmax);
    document.body.style.fontSize = gmax + "px";
    document.documentElement.style.fontSize = gmax + "px";
}

setFontSize()

window.addEventListener('resize', setFontSize)
