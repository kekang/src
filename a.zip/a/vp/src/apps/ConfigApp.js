import Vue from 'vue'
import VueRouter from 'vue-router'
import Vuex from 'vuex'
import createLogger from 'vuex/dist/logger'
import '../styles/common.less'
import '../styles/reset.css'
import App from './index.vue'
import httpconfig from '../utils/httpconfig'
import 'utils/fontset'
import {Loading} from 'components'
import {isFunction, isPrd} from 'utils'
import util from '../utils/util.js'

Vue.use(Vuex)
//state日志
const logger = createLogger({
    collapsed: false,
    transformer (state) {
        return state
    },
    mutationTransformer (mutation) {
        return mutation.type
    }
})

export default function ({router = {}, stores}) {
    Vue.use(VueRouter)

    const Router = new VueRouter({
        mode: 'hash',
        // base: __dirname,
        routes: router.routes,//router路由，routes路线
    })
    //钩子
    Router.beforeEach((to, from, next) => {
        if (!!to.meta.title) {
            document.title = to.meta.title;
        }
        next()
    })

    if (router.beforeEach) {
        router.beforeEach.forEach(f => {
            if (isFunction(f)) {
                Router.beforeEach(f)
            }
        })
    }
    const store = new Vuex.Store({
        modules: {
            ...stores
        },
        // strict: process.env.NODE_ENV !== 'production',
        plugins: isPrd() ? [] : [logger]
    })

    App.store = store
    new Vue({
        router: Router,
        render: h => h(App)
    }).$mount('#app')
    window.router = Router
}
