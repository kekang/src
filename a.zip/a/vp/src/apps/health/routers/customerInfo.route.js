/**
 * Created by zhangping702 on 17/1/18.
 */

export default [{
    path: '/productDetail',
    name: 'productDetail',
    meta: {
        title: '',
    },
    component: resolve => require(['../views/productDetail/productDetail.vue'], resolve)
}]
