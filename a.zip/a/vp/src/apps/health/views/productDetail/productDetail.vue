<template>
    <div>


        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="panel panel-default border_top_red">
                        <div class="panel-body">
                            <i class="glyphicon glyphicon-th"></i> 查询条件
                        </div>
                        <div class="panel-footer">
                            <!--导航结束-->
                            <div class="row">
                                <div class="col-md-offset-1 col-md-11">
                                    <div class="row">
                                        <div class="col-md-2 "></div>
                                        <div class="col-md-7">
                                            <div class="row">
                                                <div class="col-md-offset-1 col-md-8">
                                                    <form class="form-horizontal" role="form" onsubmit="return false">
                                                        <div class="form-group">
                                                            <label class="col-sm-4 control-label">人群名称：</label>
                                                            <div class="col-sm-6">
                                                                <input maxlength="90" type="text" class="form-control" checkVal="optional all" id="personName" placeholder="请输入人群名称">
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="col-sm-4 control-label add">保险公司：</label>
                                                            <div class="col-sm-6">
                                                                <select class="form-control" name="name" id="idInsurCompany">
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <div class="col-sm-offset-2 col-sm-4">
                                                                <button type="submit" class="btn btn-default button_red query"><i class="glyphicon glyphicon-search"></i> 查询</button>
                                                            </div>
                                                            <div class="col-sm-offset-1 col-sm-4">
                                                                <button type="submit" class="btn btn-primary add"><i class="glyphicon glyphicon-plus"></i> 新增</button>
                                                            </div>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <button v-show="closeMyself" @click="closeMyself('closeMyself')">点我隐藏</button>

    </div>
</template>
<style scoped lang="less">

</style>
<script>
    import {Msg,Loading} from 'components'
    //import "../../../../styles/css/bootstrap.min.css";
    import "../../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
    //import $ from 'jQuery'
    var $ = window.jQuery = require("jquery");
    require("bootstrap")
    export default{
        data(){
            return{
                closeMyself:true,
                context:""
            }
        },
        beforeMount(){
            //require('bootstrap')
        },
        mounted(){
            console.log($.fn.jquery)
            console.log($('.add').eq(0).html())
        },
        methods:{
            closeMyself(attr){
                this[attr] = false;
                console.log(this[attr])
            }
        },
    }
</script>
